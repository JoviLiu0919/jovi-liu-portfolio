#!/usr/bin/env python3
"""
GitHub PR Integration for Dell Format Checker
Automatically comments on PRs and sets review status based on commit message format
"""

import requests
import json
import sys
import argparse
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path
import toml
import re
from pr_format_checker import CommitMessageValidator, ValidationResult
from jira_validator import JiraValidator

# Import central configuration loader
sys.path.append(str(Path(__file__).parent.parent.parent.parent))
from config_loader import load_skill_config_with_central_fallback

# Configure logging with UTF-8 encoding
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s', 
                    handlers=[logging.StreamHandler(sys.stdout)])
logger = logging.getLogger(__name__)

@dataclass
class GitHubConfig:
    url: str
    token: str
    auto_review_status: bool = True  # Default to True for backward compatibility
    
    def __post_init__(self):
        # Ensure URL doesn't end with /
        self.url = self.url.rstrip('/')
        self.api_base = f"{self.url}/api/v3"

class GitHubPRChecker:
    """Checks PR format and automatically comments/reviews on GitHub"""
    
    def __init__(self, config_path: str = "config.toml"):
        # Use central configuration loader
        self.config = load_skill_config_with_central_fallback(Path(__file__).parent.parent / config_path)
        self.validator = CommitMessageValidator()
        self.jira_validator = None
        
        # Initialize Jira validator if configured
        jira_config = self._load_jira_config()
        if jira_config and jira_config.url and jira_config.token:
            try:
                self.jira_validator = JiraValidator(jira_config)
                logger.info("Jira validator initialized")
            except Exception as e:
                logger.warning(f"Failed to initialize Jira validator: {e}")
    
    def _load_config(self) -> GitHubConfig:
        """Load GitHub configuration from merged config"""
        try:
            # Try different section names for compatibility
            github_config = {}
            if 'github' in self.config:
                github_config = self.config['github']
            elif 'Github' in self.config:
                github_config = self.config['Github']
            
            return GitHubConfig(
                url=github_config.get('url', ''),
                token=github_config.get('token', ''),
                auto_review_status=github_config.get('auto_review_status', True)
            )
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            sys.exit(1)
    
    def _load_jira_config(self):
        """Load Jira configuration from merged config"""
        try:
            jira_config = self.config.get('jira', {})
            
            if not jira_config.get('url') or not jira_config.get('token'):
                return None
                
            from jira_validator import JiraConfig
            return JiraConfig(
                url=jira_config.get('url', ''),
                token=jira_config.get('token', ''),
                username=jira_config.get('username', '')
            )
        except Exception as e:
            logger.error(f"Failed to load Jira config: {e}")
            return None
    
    def check_pr_and_comment(self, pr_url: str, dry_run: bool = False) -> bool:
        """Check PR format and create comment/review"""
        try:
            # Extract PR info from URL
            repo_path, pr_number = self._parse_pr_url(pr_url)
            
            # Get PR commits
            commits = self._get_pr_commits(repo_path, pr_number)
            if not commits:
                logger.error("No commits found in PR")
                return False
            
            logger.info(f"Processing PR #{pr_number} in {repo_path}")
            
            # Validate all commits
            all_results = []
            for commit in commits:
                # Extract message from commit object
                commit_message = commit.get('commit', {}).get('message', '')
                result = self.validator.validate_commit_message(commit_message)
                result.commit_hash = commit.get('sha', '')
                result.gpg_signed = commit.get('commit', {}).get('verification', {}).get('verified', False)
                all_results.append(result)
            
            # Generate comment
            comment = self._generate_comment(all_results, commits)
            
            # Determine if review should be requested
            has_errors = any(not result.is_valid for result in all_results)
            has_unsigned = any(not result.gpg_signed for result in all_results)
            
            if dry_run:
                logger.info("DRY RUN: Would create comment:")
                # Handle Unicode characters for Windows console
                try:
                    print(comment)
                except UnicodeEncodeError:
                    # Fallback for systems that can't display emoji
                    safe_comment = comment.replace('📊', '[SUMMARY]').replace('⚠️', '[WARNING]').replace('✅', '[VALID]').replace('❌', '[INVALID]').replace('🔒', '[GPG]').replace('⚠️', '[WARNING]').replace('🎫', '[JIRA]').replace('🔧', '[FIX]').replace('📚', '[INFO]').replace('📖', '[EXAMPLE]').replace('🤖', '[AI]').replace('🎯', '[ACTION]').replace('🔄', '[SQUASH]').replace('🔐', '[GPG]').replace('📝', '[FORMAT]')
                    print(safe_comment)
                return True
            
            # Create comment
            comment_url = f"{self.config.api_base}/repos/{repo_path}/issues/{pr_number}/comments"
            comment_data = {'body': comment}
            comment_response = self._make_request('POST', comment_url, comment_data)
            
            if comment_response:
                logger.info(f"Comment created successfully on PR #{pr_number}")
                
                # Set review status based on check results (if enabled)
                if self.config.auto_review_status and (has_errors or has_unsigned):
                    # REQUEST_CHANGES for invalid commits or unsigned commits
                    review_url = f"{self.config.api_base}/repos/{repo_path}/pulls/{pr_number}/reviews"
                    
                    # Generate AI-suggested commit message for the first invalid commit
                    suggested_message = ""
                    format_violations = []
                    
                    for result, commit in zip(all_results, commits):
                        if not result.is_valid:
                            commit_message = commit.get('commit', {}).get('message', '')
                            
                            # Analyze specific format violations first
                            if result.errors:
                                for error in result.errors:
                                    if "Executive summary" in error:
                                        format_violations.append("❌ **Executive Summary**: Use platform prefix format like `PlatformName: Fix PIMS-12345 issue description`")
                                    elif "commit type" in error:
                                        format_violations.append("❌ **Commit Type**: Must be one of: Bug Fix, New Feature, or Enhancement")
                                    elif "Bug Fix:" in error or "Root cause:" in error or "Solution:" in error:
                                        format_violations.append("❌ **Bug Fix Format**: Must include `Bug Fix:`, `Root cause:`, and `Solution:`")
                                    elif "New Feature:" in error or "Purpose:" in error:
                                        format_violations.append("❌ **New Feature Format**: Must include `New Feature:` and `Purpose:`")
                                    elif "Change:" in error or "Purpose:" in error:
                                        format_violations.append("❌ **Enhancement Format**: Must include `Change:` and `Purpose:`")
                                    elif "Systems Affected" in error:
                                        format_violations.append("❌ **Systems Affected**: Use format like `NB [ADL]` or specific system names")
                                    elif "Cherry Pick Info" in error:
                                        format_violations.append("❌ **Cherry Pick Info**: Fill with dependency info or `N/A`")
                            
                            # Generate AI-suggested commit message with violations
                            suggested_message = self.validator.generate_suggested_commit_message(commit_message, format_violations)
                            break
                    
                    review_body = "Commit message format requires changes. Please see detailed comment above for specific issues and fix suggestions.\n\n"
                    
                    if format_violations:
                        review_body += "### 📋 **Format Guidelines Violations:**\n"
                        for violation in format_violations:
                            review_body += f"{violation}\n"
                        review_body += "\n"
                    
                    if suggested_message:
                        review_body += """🤖 **AI-Generated Suggested Commit Message:**
*(Note: This suggestion may contain errors and should be reviewed)*

```
""" + suggested_message + """

```
"""
                    
                    review_data = {
                        'body': review_body,
                        'event': 'REQUEST_CHANGES'
                    }
                    
                    review_response = self._make_request('POST', review_url, review_data)
                    if review_response:
                        logger.info(f"Review state updated to 'REQUEST_CHANGES' for PR #{pr_number}")
                        return True
                else:
                    # All checks passed - only comment, no approve
                    logger.info(f"All commits pass format check for PR #{pr_number} - only commenting")
                    return True
            
            return False
            
        except Exception as e:
            logger.error(f"Failed to check PR: {e}")
            return False
    
    def _parse_pr_url(self, pr_url: str) -> Tuple[str, int]:
        """Parse PR URL to extract repo path and PR number"""
        pattern = r'/([^/]+)/([^/]+)/pull/(\d+)'
        match = re.search(pattern, pr_url)
        
        if not match:
            raise ValueError(f"Invalid PR URL format: {pr_url}")
        
        repo_path = f"{match.group(1)}/{match.group(2)}"
        pr_number = int(match.group(3))
        
        return repo_path, pr_number
    
    def _get_pr_commits(self, repo_path: str, pr_number: int) -> List[Dict]:
        """Get all commits in a PR"""
        url = f"{self.config.api_base}/repos/{repo_path}/pulls/{pr_number}/commits"
        response = self._make_request('GET', url)
        
        if response:
            return response
        return []
    
    def _make_request(self, method: str, url: str, data: Dict = None) -> Optional[Dict]:
        """Make authenticated request to GitHub API"""
        headers = {
            'Authorization': f'token {self.config.token}',
            'Accept': 'application/vnd.github.v3+json',
            'Content-Type': 'application/json'
        }
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers)
            elif method == 'POST':
                response = requests.post(url, headers=headers, json=data)
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            return None
    
    def _generate_comment(self, results: List[ValidationResult], commits: List[Dict]) -> str:
        """Generate detailed comment for PR"""
        total_commits = len(results)
        valid_commits = sum(1 for r in results if r.is_valid and r.gpg_signed)
        invalid_commits = total_commits - valid_commits
        gpg_signed_count = sum(1 for r in results if r.gpg_signed)
        gpg_unsigned_count = total_commits - gpg_signed_count
        invalid_format_count = sum(1 for r in results if not r.is_valid)
        
        # Build action required items
        action_items = []
        if total_commits > 1:
            action_items.append(f"🔄 Squash {total_commits} commits into 1")
        if gpg_unsigned_count > 0:
            action_items.append(f"🔐 Fix GPG signatures ({gpg_unsigned_count} unsigned)")
        if invalid_format_count > 0:
            action_items.append(f"📝 Fix commit message format ({invalid_format_count} invalid)")
        
        action_required = " | ".join(action_items) if action_items else "✅ No action required"
        
        comment = f"""## 📊 PR Format Check Summary

**🎯 Action Required:** {action_required}

**Total Commits:** {total_commits}  
**Valid Commits:** {valid_commits}  
**Invalid Commits:** {invalid_commits}  
**GPG Signed:** {gpg_signed_count}/{total_commits}

"""
        
        # Multiple commits warning
        if total_commits > 1:
            comment += f"""⚠️ **Multiple commits detected. Please squash into a single commit.**

**Suggested command:**
```bash
git rebase -i HEAD~{total_commits}
# Use 'squash' or 'fixup' to combine commits
```

---

"""
        
        # Individual commit results
        for i, (result, commit) in enumerate(zip(results, commits)):
            commit_hash = commit.get('sha', '')[:7]
            
            # Determine commit status icon based on validation results
            if result.is_valid and result.gpg_signed:
                status_icon = "✅"
                status_text = "VALID"
            else:
                status_icon = "❌"
                status_text = "INVALID"
            
            # Use dynamic format with proper status icon
            comment += f"### {status_icon} Commit `{commit_hash}`\n\n"
            
            # GPG signature status
            if not result.gpg_signed:
                comment += "**❌ GPG Signature Not Verified**\n\n"
            else:
                comment += "**GPG Signature:** ✅ Verified\n\n"
            
            if result.errors:
                comment += "**Errors:**\n"
                for error in result.errors:
                    comment += f"- {error}\n"
                comment += "\n"
            
            if result.warnings:
                comment += "**Warnings:**\n"
                for warning in result.warnings:
                    comment += f"- {warning}\n"
                comment += "\n"
            
            # Jira ticket validation
            if result.jira_tickets and self.jira_validator:
                comment += "🎫 **Jira Ticket Validation:**\n"
                for ticket in result.jira_tickets:
                    try:
                        ticket_info = self.jira_validator.get_ticket_info(ticket)
                        if ticket_info.exists:
                            comment += f"- ✅ {ticket}: {ticket_info.summary} ({ticket_info.issue_type})\n"
                        else:
                            comment += f"- ❌ {ticket}: Ticket not found\n"
                    except Exception as e:
                        comment += f"- ⚠️ {ticket}: Could not validate ({e})\n"
                comment += "\n"
            
            # Add commit message preview if available
            if commit.get('message'):
                comment += "### 📄 Commit Message Preview\n\n```\n"
                commit_message = commit['message']
                # Truncate very long messages
                if len(commit_message) > 500:
                    commit_message = commit_message[:500] + "..."
                comment += commit_message + "\n```\n\n"
            
            comment += "---\n\n"
        
        # Add required actions section if there are issues
        if action_items:
            comment += """### 🔧 Required Actions

Please fix the above errors and update your commit message using:
```bash
git commit --amend
```

For GPG signing, ensure your key is configured:
```bash
git config --global commit.gpgsign true
git config --global user.signingkey YOUR_KEY_ID
```

Refer to the Dell commit message format guidelines in the repository documentation.

"""
        
        comment += "\n*This comment was generated automatically by PR Format Checker.*"
        
        return comment

def main():
    parser = argparse.ArgumentParser(description='Check PR format and comment on GitHub')
    parser.add_argument('--pr-url', required=True, help='PR URL to check')
    parser.add_argument('--config', default='config.toml', help='Configuration file path')
    parser.add_argument('--dry-run', action='store_true', help='Check format but do not comment')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')
    parser.add_argument('--no-auto-review', action='store_true', help='Disable automatic review status changes')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    checker = GitHubPRChecker(args.config)
    
    # Override config if command line flag is provided
    if args.no_auto_review:
        checker.config.auto_review_status = False
    
    success = checker.check_pr_and_comment(args.pr_url, args.dry_run)
    
    if success:
        logger.info("PR check completed successfully")
        sys.exit(0)
    else:
        logger.error("PR check failed")
        sys.exit(1)

if __name__ == "__main__":
    main()
