#!/usr/bin/env python3
"""
Jira Integration for PR Format Checker
Validates Jira tickets referenced in commit messages
"""

import requests
import json
import sys
import argparse
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path
import toml
import re
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class JiraConfig:
    url: str
    token: str
    username: str
    
    def __post_init__(self):
        # Ensure URL doesn't end with /
        self.url = self.url.rstrip('/')
        self.api_base = f"{self.url}/rest/api/3"

@dataclass
class JiraTicket:
    key: str
    summary: str
    status: str
    project: str
    issue_type: str
    priority: Optional[str] = None
    assignee: Optional[str] = None
    reporter: Optional[str] = None
    created: Optional[str] = None
    updated: Optional[str] = None
    description: Optional[str] = None
    exists: bool = True

class JiraValidator:
    """Validates Jira tickets and provides ticket information"""
    
    def __init__(self, config: JiraConfig):
        self.config = config
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Basic {self._get_auth_string()}',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })
    
    def _get_auth_string(self) -> str:
        """Create base64 auth string"""
        import base64
        auth_string = f"{self.config.username}:{self.config.token}"
        return base64.b64encode(auth_string.encode()).decode()
    
    def extract_jira_tickets(self, text: str) -> List[str]:
        """Extract Jira ticket numbers from text"""
        patterns = [
            r'CPSE-\d+',
            r'PIMS-\d+',
            r'NUDD-\d+',
            r'PCR-\d+',
            r'TBABP1-\d+'
        ]
        
        tickets = set()
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            tickets.update(matches)
        
        return list(tickets)
    
    def get_ticket_info(self, ticket_key: str) -> JiraTicket:
        """Get detailed information about a Jira ticket"""
        url = f"{self.config.api_base}/issue/{ticket_key}"
        params = {
            'fields': 'summary,status,project,issuetype,priority,assignee,reporter,created,updated,description'
        }
        
        try:
            response = self.session.get(url, params=params)
            
            if response.status_code == 404:
                logger.warning(f"Ticket {ticket_key} not found")
                return JiraTicket(
                    key=ticket_key,
                    summary="NOT FOUND",
                    status="N/A",
                    project="N/A",
                    issue_type="N/A",
                    exists=False
                )
            
            response.raise_for_status()
            data = response.json()
            
            # Extract fields
            fields = data.get('fields', {})
            
            return JiraTicket(
                key=ticket_key,
                summary=fields.get('summary', ''),
                status=fields.get('status', {}).get('name', ''),
                project=fields.get('project', {}).get('key', ''),
                issue_type=fields.get('issuetype', {}).get('name', ''),
                priority=fields.get('priority', {}).get('name') if fields.get('priority') else None,
                assignee=fields.get('assignee', {}).get('displayName') if fields.get('assignee') else None,
                reporter=fields.get('reporter', {}).get('displayName') if fields.get('reporter') else None,
                created=fields.get('created', ''),
                updated=fields.get('updated', ''),
                description=fields.get('description', ''),
                exists=True
            )
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to get ticket {ticket_key}: {e}")
            return JiraTicket(
                key=ticket_key,
                summary="ERROR",
                status="N/A",
                project="N/A",
                issue_type="N/A",
                exists=False
            )
    
    def validate_ticket_references(self, commit_message: str, commit_type: str) -> Tuple[List[str], List[JiraTicket]]:
        """Validate ticket references based on commit type"""
        errors = []
        tickets = []
        
        # Extract tickets from commit message
        ticket_keys = self.extract_jira_tickets(commit_message)
        
        if not ticket_keys:
            if commit_type in ['bug_fix', 'new_feature']:
                errors.append(f"{commit_type.title()} commits should reference a Jira ticket")
            return errors, tickets
        
        # Get ticket information
        for ticket_key in ticket_keys:
            ticket = self.get_ticket_info(ticket_key)
            tickets.append(ticket)
            
            if not ticket.exists:
                errors.append(f"Jira ticket {ticket_key} does not exist")
                continue
            
            # Validate ticket type vs commit type
            if commit_type == 'bug_fix':
                if ticket.issue_type.lower() not in ['bug', 'issue', 'defect', 'problem']:
                    errors.append(f"Bug fix commit references {ticket_key} which has type '{ticket.issue_type}'. Expected Bug/Issue type.")
            
            elif commit_type == 'new_feature':
                if ticket.issue_type.lower() not in ['feature', 'new feature', 'enhancement', 'story']:
                    errors.append(f"New feature commit references {ticket_key} which has type '{ticket.issue_type}'. Expected Feature type.")
        
        return errors, tickets
    
    def search_tickets(self, query: str, project: Optional[str] = None, limit: int = 10) -> List[JiraTicket]:
        """Search for Jira tickets"""
        url = f"{self.config.api_base}/search"
        
        jql = f'text ~ "{query}"'
        if project:
            jql += f' AND project = {project}'
        
        params = {
            'jql': jql,
            'fields': 'summary,status,project,issuetype,priority,assignee,reporter,created,updated',
            'maxResults': limit
        }
        
        try:
            response = self.session.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            
            tickets = []
            for issue in data.get('issues', []):
                fields = issue.get('fields', {})
                ticket = JiraTicket(
                    key=issue.get('key'),
                    summary=fields.get('summary', ''),
                    status=fields.get('status', {}).get('name', ''),
                    project=fields.get('project', {}).get('key', ''),
                    issue_type=fields.get('issuetype', {}).get('name', ''),
                    priority=fields.get('priority', {}).get('name') if fields.get('priority') else None,
                    assignee=fields.get('assignee', {}).get('displayName') if fields.get('assignee') else None,
                    reporter=fields.get('reporter', {}).get('displayName') if fields.get('reporter') else None,
                    created=fields.get('created', ''),
                    updated=fields.get('updated', '')
                )
                tickets.append(ticket)
            
            return tickets
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to search tickets: {e}")
            return []
    
    def get_ticket_changelog(self, ticket_key: str) -> List[Dict]:
        """Get changelog history for a ticket"""
        url = f"{self.config.api_base}/issue/{ticket_key}/changelog"
        
        try:
            response = self.session.get(url)
            response.raise_for_status()
            data = response.json()
            return data.get('histories', [])
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to get changelog for {ticket_key}: {e}")
            return []
    
    def format_ticket_summary(self, tickets: List[JiraTicket]) -> str:
        """Format ticket information for display"""
        if not tickets:
            return "No tickets found"
        
        summary = f"Found {len(tickets)} ticket(s):\n\n"
        
        for ticket in tickets:
            status_emoji = "✅" if ticket.exists else "❌"
            summary += f"{status_emoji} **{ticket.key}** - {ticket.summary}\n"
            summary += f"   Status: {ticket.status} | Type: {ticket.type} | Project: {ticket.project}\n"
            
            if ticket.assignee:
                summary += f"   Assignee: {ticket.assignee}\n"
            
            if ticket.priority:
                summary += f"   Priority: {ticket.priority}\n"
            
            summary += "\n"
        
        return summary
    
    def validate_ticket_workflow(self, ticket: JiraTicket, expected_status: Optional[str] = None) -> List[str]:
        """Validate ticket is in appropriate workflow state"""
        errors = []
        
        if not ticket.exists:
            return [f"Ticket {ticket.key} does not exist"]
        
        # Check if ticket is in appropriate status
        if expected_status and ticket.status != expected_status:
            errors.append(f"Ticket {ticket.key} is in '{ticket.status}' status, expected '{expected_status}'")
        
        # Check for stale tickets
        if ticket.updated:
            try:
                updated_date = datetime.fromisoformat(ticket.updated.replace('Z', '+00:00'))
                days_since_update = (datetime.now(updated_date.tzinfo) - updated_date).days
                
                if days_since_update > 365:
                    errors.append(f"Ticket {ticket.key} hasn't been updated in {days_since_update} days")
            except ValueError:
                pass  # Invalid date format
        
        return errors

def load_config(config_file: str) -> JiraConfig:
    """Load Jira configuration from TOML file"""
    try:
        with open(config_file, 'r') as f:
            config_data = toml.load(f)
        
        jira_config = config_data.get('Jira', {})
        return JiraConfig(
            url=jira_config.get('url', ''),
            token=jira_config.get('token', ''),
            username=jira_config.get('username', '')
        )
    except Exception as e:
        logger.error(f"Failed to load Jira config: {e}")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description='Jira Ticket Validator')
    parser.add_argument('--message-file', type=str, help='File containing commit message')
    parser.add_argument('--message', type=str, help='Commit message as string')
    parser.add_argument('--commit-type', type=str, choices=['bug_fix', 'new_feature', 'enhancement'], 
                       help='Type of commit for validation')
    parser.add_argument('--ticket', type=str, help='Specific ticket to validate')
    parser.add_argument('--search', type=str, help='Search for tickets')
    parser.add_argument('--project', type=str, help='Project for search (e.g., CPSE, PIMS)')
    parser.add_argument('--config', type=str, default='config.toml', help='Configuration file')
    parser.add_argument('--verbose', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Load configuration
    config = load_config(args.config)
    validator = JiraValidator(config)
    
    # Handle different operations
    if args.ticket:
        # Get specific ticket info
        ticket = validator.get_ticket_info(args.ticket)
        print(validator.format_ticket_summary([ticket]))
        
    elif args.search:
        # Search for tickets
        tickets = validator.search_tickets(args.search, args.project)
        print(validator.format_ticket_summary(tickets))
        
    elif args.message_file or args.message:
        # Validate tickets in commit message
        if args.message_file:
            with open(args.message_file, 'r', encoding='utf-8') as f:
                message = f.read()
        else:
            message = args.message
        
        if not args.commit_type:
            logger.error("--commit-type is required when validating commit message")
            sys.exit(1)
        
        errors, tickets = validator.validate_ticket_references(message, args.commit_type)
        
        print(f"\n{'='*60}")
        print(f"Jira Ticket Validation Results")
        print(f"{'='*60}")
        
        if errors:
            print(f"\n❌ Validation Errors:")
            for i, error in enumerate(errors, 1):
                print(f"  {i}. {error}")
        else:
            print(f"\n✅ All ticket references are valid")
        
        print(f"\n{validator.format_ticket_summary(tickets)}")
        print(f"{'='*60}")
        
        sys.exit(1 if errors else 0)
    
    else:
        logger.error("No operation specified. Use --ticket, --search, or --message-file")
        sys.exit(1)

if __name__ == '__main__':
    main()
