#!/usr/bin/env python3
"""
PR Format Checker for Dell GitHub Repository
Validates Git commit messages against Dell formatting standards
"""

import re
import sys
import argparse
import requests
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from pathlib import Path
import toml
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class ValidationResult:
    is_valid: bool
    errors: List[str]
    warnings: List[str]
    commit_type: str  # 'bug_fix', 'new_feature', 'enhancement', 'unknown'
    jira_tickets: List[str]
    gpg_signed: bool = False  # GPG signature status
    commit_hash: str = ""  # Commit hash for reference

class CommitMessageValidator:
    """Validates commit messages against Dell standards"""
    
    # Required sections in commit message
    REQUIRED_SECTIONS = [
        '[Detailed Description]',
        '[Systems Affected]', 
        '[Cherry Pick Info]'
    ]
    
    # Valid commit types and their patterns
    COMMIT_TYPE_PATTERNS = {
        'bug_fix': r'Bug Fix:\s*(.+)',
        'new_feature': r'New Feature:\s*(.+)',
        'enhancement': r'Change:\s*(.+)'
    }
    
    # Jira ticket patterns
    JIRA_PATTERNS = [
        r'CPSE-\d+',
        r'PIMS-\d+',
        r'NUDD-\d+',
        r'PCR-\d+'
    ]
    
    # System affected patterns
    SYSTEM_PATTERNS = [
        r'All\s*\[([^\]]+)\]',
        r'NB\s*\[([^\]]+)\]',
        r'DT\s*\[([^\]]+)\]',
        r'AIO\s*\[([^\]]+)\]',
        r'PW\s*\[([^\]]+)\]',
        r'([A-Za-z0-9_]+(?:,\s*[A-Za-z0-9_]+)*)'
    ]
    
    # Valid chipset codes
    VALID_CHIPSETS = ['CML', 'TGL', 'RKL', 'ADL', 'EGS']
    
    def __init__(self):
        self.jira_checker = None
        
    def validate_commit_message(self, message: str) -> ValidationResult:
        """Main validation function"""
        errors = []
        warnings = []
        
        # Clean message - remove comments and extra whitespace
        cleaned_message = self._clean_message(message)
        
        # Check required sections
        missing_sections = self._check_required_sections(cleaned_message)
        if missing_sections:
            errors.extend([f"Missing required section: {section}" for section in missing_sections])
        
        # Validate executive summary (first line)
        exec_summary_errors = self._validate_executive_summary(cleaned_message)
        errors.extend(exec_summary_errors)
        
        # Determine commit type and validate detailed description
        commit_type, desc_errors = self._validate_detailed_description(cleaned_message)
        errors.extend(desc_errors)
        
        # Extract and validate Jira tickets
        jira_tickets = self._extract_jira_tickets(cleaned_message)
        if not jira_tickets and commit_type in ['bug_fix', 'new_feature']:
            warnings.append("No Jira ticket found - consider adding one for tracking")
        
        # Validate systems affected
        system_errors = self._validate_systems_affected(cleaned_message)
        errors.extend(system_errors)
        
        # Check for N/A placeholders
        na_warnings = self._check_na_placeholders(cleaned_message)
        warnings.extend(na_warnings)
        
        is_valid = len(errors) == 0
        
        return ValidationResult(
            is_valid=is_valid,
            errors=errors,
            warnings=warnings,
            commit_type=commit_type,
            jira_tickets=jira_tickets
        )
    
    def _clean_message(self, message: str) -> str:
        """Remove comments and normalize whitespace"""
        lines = []
        for line in message.split('\n'):
            line = line.strip()
            if line and not line.startswith('#'):
                lines.append(line)
        return '\n'.join(lines)
    
    def _check_required_sections(self, message: str) -> List[str]:
        """Check if all required sections are present"""
        missing = []
        for section in self.REQUIRED_SECTIONS:
            if section not in message:
                missing.append(section)
        return missing
    
    def _validate_executive_summary(self, message: str) -> List[str]:
        """Validate the executive summary (first line)"""
        errors = []
        lines = message.split('\n')
        
        if not lines:
            return ["Empty commit message"]
        
        first_line = lines[0].strip()
        
        # Check if it's too long
        if len(first_line) > 200:
            errors.append("Executive summary too long (should be under 200 characters)")
        
        # Check for Dell format: platform prefix or "If applied, this commit will"
        # More flexible platform patterns - accept various formats
        platform_patterns = [
            r'^[A-Za-z0-9_]+(,\s*[A-Za-z0-9_]+)*:\s*.+',  # Platform: description
            r'^If applied, this commit will\s+.+',          # If applied format
            r'^[A-Za-z0-9_]+\s*:\s*\[.*?\]\s*.+',          # Platform: [ticket] description
            r'^[A-Za-z0-9_]+\s*:\s*.*',                    # Simple platform: description
            r'^.+\s*:\s*.+',                               # Any text: description (more lenient)
            r'^.+$',                                       # Any text (most lenient)
        ]
        
        has_valid_format = any(re.match(pattern, first_line, re.IGNORECASE) for pattern in platform_patterns)
        
        if not has_valid_format:
            # Generate suggested format based on current content
            if ':' in first_line:
                # Already has some format, just needs adjustment
                suggested = first_line
            else:
                # Suggest platform prefix format
                suggested = f"PlatformName: Fix/Update {first_line}"
            
            errors.append(f"Executive summary must use Dell format")
            errors.append(f"Examples:")
            errors.append(f"  - 'HuracanPtl, PerformantePtl: Fix PIMS-398306 Linux,Ubuntu,24.04.3,CI,H14_PTL_DVT2,SUT shows failed...'")
            errors.append(f"  - 'If applied, this commit will fix the issue with...'")
            errors.append(f"  - 'SlatePtlOne: [PIMS-403974] TC_13606 Run test...'")
            errors.append(f"  - 'Any description: Change details...'")
        
        return errors
    
    def _validate_detailed_description(self, message: str) -> Tuple[str, List[str]]:
        """Validate detailed description and determine commit type"""
        errors = []
        commit_type = 'unknown'
        
        # Extract detailed description section
        desc_match = re.search(r'\[Detailed Description\](.*?)(?=\[Systems Affected\]|\[Cherry Pick Info\]|$)', message, re.DOTALL)
        if not desc_match:
            errors.append("Missing [Detailed Description] section")
            return commit_type, errors
        
        desc_content = desc_match.group(1).strip()
        
        # Check for Bug Fix pattern (flexible order and format, support * prefix)
        has_bug_fix = bool(re.search(r'\*?\s*Bug\s*Fix\s*:', desc_content, re.IGNORECASE))
        has_root_cause = bool(re.search(r'\*?\s*Root\s*cause\s*:', desc_content, re.IGNORECASE))
        has_solution = bool(re.search(r'\*?\s*Solution\s*:', desc_content, re.IGNORECASE))
        
        # Check for New Feature pattern (flexible order and format, support * prefix)
        has_new_feature = bool(re.search(r'\*?\s*New\s*Feature\s*:', desc_content, re.IGNORECASE))
        has_purpose = bool(re.search(r'\*?\s*Purpose\s*:', desc_content, re.IGNORECASE))
        
        # Check for Enhancement pattern (flexible order and format, support * prefix)
        has_change = bool(re.search(r'\*?\s*Change\s*:', desc_content, re.IGNORECASE))
        
        # Also check for "Enhancement:" as a valid indicator
        has_enhancement = bool(re.search(r'Enhancement\s*:', desc_content, re.IGNORECASE))
        
        # Determine commit type based on presence of required items
        if has_bug_fix and has_root_cause and has_solution:
            commit_type = 'bug_fix'
        elif has_new_feature and has_purpose:
            commit_type = 'new_feature'
        elif (has_change and has_purpose) or has_enhancement:
            commit_type = 'enhancement'
        elif has_bug_fix or has_root_cause or has_solution:
            # Partial Bug Fix - missing some required items
            commit_type = 'bug_fix'
            missing_items = []
            if not has_bug_fix:
                missing_items.append("Bug Fix:")
            if not has_root_cause:
                missing_items.append("Root cause:")
            if not has_solution:
                missing_items.append("Solution:")
            errors.append(f"Bug Fix type missing required items: {', '.join(missing_items)}")
        elif has_new_feature or has_purpose:
            # Partial New Feature - missing some required items
            commit_type = 'new_feature'
            missing_items = []
            if not has_new_feature:
                missing_items.append("New Feature:")
            if not has_purpose:
                missing_items.append("Purpose:")
            errors.append(f"New Feature type missing required items: {', '.join(missing_items)}")
        elif has_change or has_purpose:
            # Partial Enhancement - missing some required items
            commit_type = 'enhancement'
            missing_items = []
            if not has_change:
                missing_items.append("Change:")
            if not has_purpose:
                missing_items.append("Purpose:")
            errors.append(f"Enhancement type missing required items: {', '.join(missing_items)}")
        else:
            # Check if there's any content at all in detailed description
            if desc_content.strip():
                errors.append("Cannot determine commit type - found content but missing required format. Must include one of: Bug Fix:, Root cause:, Solution: (for Bug Fix) OR New Feature:, Purpose: (for New Feature) OR Change:, Purpose: (for Enhancement) OR Enhancement: (for Enhancement)")
            else:
                errors.append("Cannot determine commit type - [Detailed Description] section is empty. Must include one of: Bug Fix:, Root cause:, Solution: (for Bug Fix) OR New Feature:, Purpose: (for New Feature) OR Change:, Purpose: (for Enhancement) OR Enhancement: (for Enhancement)")
        
        return commit_type, errors
    
    def _validate_bug_fix_format(self, content: str) -> List[str]:
        """Validate bug fix format"""
        errors = []
        
        # Check for Bug Fix line
        bug_fix_match = re.search(r'Bug Fix:\s*(.+)', content, re.IGNORECASE)
        if not bug_fix_match:
            errors.append("Bug Fix format requires 'Bug Fix: <ticket/issue summary>'")
            errors.append("Example: 'Bug Fix: CPSE-12345 BIOS fails to boot on certain systems'")
        else:
            bug_fix_desc = bug_fix_match.group(1).strip()
            # Check if it contains a ticket or issue description
            if not any(pattern in bug_fix_desc for pattern in ['CPSE-', 'PIMS-', 'NUDD-', 'PCR-']):
                # Should have issue description if no ticket
                if len(bug_fix_desc) < 10:
                    errors.append("Bug Fix description too short - provide meaningful issue summary")
                    errors.append("Example: 'Bug Fix: BIOS fails to boot with specific memory configuration'")
        
        # Check for Root Cause
        root_cause_match = re.search(r'Root cause:\s*(.+)', content, re.IGNORECASE)
        if not root_cause_match:
            errors.append("Bug Fix format requires 'Root cause: <brief description>'")
            errors.append("Example: 'Root cause: Memory initialization sequence incorrect in early boot'")
        
        # Check for Solution
        solution_match = re.search(r'Solution:\s*(.+)', content, re.IGNORECASE)
        if not solution_match:
            errors.append("Bug Fix format requires 'Solution: <brief description>'")
            errors.append("Example: 'Solution: Updated memory initialization sequence to handle edge case'")
        
        return errors
    
    def _validate_new_feature_format(self, content: str) -> List[str]:
        """Validate new feature format"""
        errors = []
        
        # Check for New Feature line
        feature_match = re.search(r'New Feature:\s*(.+)', content, re.IGNORECASE)
        if not feature_match:
            errors.append("New Feature format requires 'New Feature: <ticket/feature summary>'")
            errors.append("Example: 'New Feature: NUDD-67890 Add support for new hardware'")
        
        # Check for Purpose
        purpose_match = re.search(r'Purpose:\s*(.+)', content, re.IGNORECASE)
        if not purpose_match:
            errors.append("New Feature format requires 'Purpose: <brief description>'")
            errors.append("Example: 'Purpose: Enable BIOS to support next-generation processors'")
        
        return errors
    
    def _validate_enhancement_format(self, content: str) -> List[str]:
        """Validate enhancement format"""
        errors = []
        
        # Check for Change line
        change_match = re.search(r'Change:\s*(.+)', content, re.IGNORECASE)
        if not change_match:
            errors.append("Enhancement format requires 'Change: <brief description>'")
            errors.append("Example: 'Change: Improved error handling in firmware update process'")
        
        # Check for Purpose
        purpose_match = re.search(r'Purpose:\s*(.+)', content, re.IGNORECASE)
        if not purpose_match:
            errors.append("Enhancement format requires 'Purpose: <brief description>'")
            errors.append("Example: 'Purpose: Better user experience and debugging capabilities'")
        
        return errors
    
    def _extract_jira_tickets(self, message: str) -> List[str]:
        """Extract all Jira ticket references"""
        tickets = set()
        for pattern in self.JIRA_PATTERNS:
            matches = re.findall(pattern, message, re.IGNORECASE)
            tickets.update(matches)
        return list(tickets)
    
    def _validate_systems_affected(self, message: str) -> List[str]:
        """Validate systems affected section"""
        errors = []
        
        # Extract systems affected section
        systems_match = re.search(r'\[Systems Affected\](.*?)(?=\[|$)', message, re.DOTALL)
        if not systems_match:
            return ["Cannot find Systems Affected section - add '[Systems Affected]' section"]
        
        systems_content = systems_match.group(1).strip()
        
        # Check if it's just "N/A"
        if systems_content.upper() == 'N/A':
            errors.append("Systems Affected cannot be 'N/A' - must specify affected systems")
            errors.append("Examples: 'All', 'NB [ADL]', 'DT [TGL, ADL]', 'SpecificSystem1'")
            return errors
        
        # Validate format
        valid_system = False
        for pattern in self.SYSTEM_PATTERNS:
            if re.search(pattern, systems_content, re.IGNORECASE):
                valid_system = True
                break
        
        if not valid_system:
            errors.append("Invalid Systems Affected format - must use one of: All, NB, DT, AIO, PW, or list specific systems")
            errors.append("Examples: 'All', 'NB [ADL]', 'DT [TGL, ADL]', 'AndrewsTgl, SouthPeak14Tgl'")
        
        # Check chipset codes if present
        chipset_matches = re.findall(r'\[([^\]]+)\]', systems_content)
        for chipset in chipset_matches:
            chipset_codes = [c.strip() for c in chipset.split(',')]
            for code in chipset_codes:
                if code and code not in self.VALID_CHIPSETS:
                    errors.append(f"Invalid chipset code: {code}. Valid codes: {', '.join(self.VALID_CHIPSETS)}")
        
        return errors
    
    def _check_na_placeholders(self, message: str) -> List[str]:
        """Check for N/A placeholders that should be filled"""
        warnings = []
        
        # Cherry Pick Info warning removed - N/A is acceptable
        
        return warnings

    def generate_suggested_commit_message(self, message: str, violations: List[str] = None) -> str:
        """Generate AI-suggested commit message based on current content following Dell template"""
        lines = message.split('\n')
        original_first_line = lines[0].strip() if lines else ""
        
        # Extract existing content
        desc_match = re.search(r'\[Detailed Description\](.*?)(?=\[|$)', message, re.DOTALL)
        systems_match = re.search(r'\[Systems Affected\](.*?)(?=\[|$)', message, re.DOTALL)
        cherry_match = re.search(r'\[Cherry Pick Info\](.*?)(?=\[|$)', message, re.DOTALL)
        
        # Extract Jira tickets
        jira_tickets = self._extract_jira_tickets(message)
        ticket_str = f"{jira_tickets[0]} " if jira_tickets else ""
        
        # Generate suggested executive summary
        if ':' in original_first_line:
            # Keep existing format
            suggested_summary = original_first_line
        else:
            # Create new format
            action = "Fix" if "fix" in original_first_line.lower() else "Update"
            suggested_summary = f"PlatformName: {action} {ticket_str}{original_first_line}"
        
        # Generate suggested detailed description based on detected type
        desc_content = desc_match.group(1).strip() if desc_match else ""
        
        # Determine commit type and generate standardized format
        if "bug fix" in desc_content.lower() or "root cause" in desc_content.lower() or "bugfix" in desc_content.lower():
            # Bug Fix format
            # Extract existing Bug Fix content
            bug_fix_match = re.search(r'bugfix\s*:\s*(.+?)(?=RootCause|Root cause|Solution|$)', desc_content, re.IGNORECASE | re.DOTALL)
            if bug_fix_match:
                bug_fix_content = bug_fix_match.group(1).strip()
            else:
                # Try to extract the first line as bug fix content
                lines = desc_content.split('\n')
                bug_fix_content = lines[0].strip() if lines else f"{ticket_str}Issue description"
            
            # Extract existing Root Cause
            root_cause_match = re.search(r'RootCause\s*:\s*(.+?)(?=Solution|$)', desc_content, re.IGNORECASE | re.DOTALL)
            if root_cause_match:
                root_cause_content = root_cause_match.group(1).strip()
            else:
                root_cause_match = re.search(r'Root cause\s*:\s*(.+?)(?=Solution|$)', desc_content, re.IGNORECASE | re.DOTALL)
                root_cause_content = root_cause_match.group(1).strip() if root_cause_match else "PLATFORM_BIN_MODEL_LIST and PLATFORM_BIN_SSID not match"
            
            # Extract existing Solution
            solution_match = re.search(r'Solution\s*:\s*(.+?)(?=$|\[)', desc_content, re.IGNORECASE | re.DOTALL)
            solution_content = solution_match.group(1).strip() if solution_match else "Add the module name to PLATFORM_BIN_MODEL_LIST"
            
            suggested_desc = f"""Bug Fix: {bug_fix_content}
Root cause: {root_cause_content}
Solution: {solution_content}"""
            
        elif "new feature" in desc_content.lower() or "purpose" in desc_content.lower():
            # New Feature format
            if "New Feature:" in desc_content:
                new_feature_line = re.search(r'New Feature:\s*(.+)', desc_content, re.IGNORECASE)
                new_feature_content = new_feature_line.group(1).strip() if new_feature_line else f"{ticket_str}{desc_content}"
            else:
                new_feature_content = f"{ticket_str}{desc_content}"
            
            purpose_match = re.search(r'Purpose:\s*(.+)', desc_content, re.IGNORECASE)
            purpose_content = purpose_match.group(1).strip() if purpose_match else "[Brief of purpose for the change]"
            
            suggested_desc = f"""New Feature: {new_feature_content}
Purpose: {purpose_content}"""
            
        else:
            # Enhancement/Other format
            change_match = re.search(r'Change:\s*(.+)', desc_content, re.IGNORECASE)
            change_content = change_match.group(1).strip() if change_match else desc_content
            
            purpose_match = re.search(r'Purpose:\s*(.+)', desc_content, re.IGNORECASE)
            purpose_content = purpose_match.group(1).strip() if purpose_match else "[Brief of purpose for the change]"
            
            suggested_desc = f"""Change: {change_content}
Purpose: {purpose_content}"""
        
        # Get systems affected with proper format
        systems_content = systems_match.group(1).strip() if systems_match else "N/A"
        
        # Get cherry pick info
        cherry_content = cherry_match.group(1).strip() if cherry_match else "N/A"
        
        suggested_message = f"""{suggested_summary}

[Detailed Description]
{suggested_desc}

[Systems Affected]
{systems_content}

[Cherry Pick Info]
{cherry_content}"""
        
        return suggested_message

def main():
    parser = argparse.ArgumentParser(description='Validate PR commit message format')
    parser.add_argument('--message-file', type=str, help='File containing commit message')
    parser.add_argument('--message', type=str, help='Commit message as string')
    parser.add_argument('--pr-url', type=str, help='PR URL for automatic commenting')
    parser.add_argument('--config', type=str, default='config.toml', help='Configuration file')
    parser.add_argument('--verbose', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Get commit message
    if args.message_file:
        try:
            with open(args.message_file, 'r', encoding='utf-8') as f:
                message = f.read()
        except FileNotFoundError:
            logger.error(f"Message file not found: {args.message_file}")
            sys.exit(1)
    elif args.message:
        message = args.message
    else:
        logger.error("Either --message-file or --message must be provided")
        sys.exit(1)
    
    # Validate
    validator = CommitMessageValidator()
    result = validator.validate_commit_message(message)
    
    # Output results
    print(f"\n{'='*60}")
    print(f"Commit Message Validation Results")
    print(f"{'='*60}")
    print(f"Status: {'VALID' if result.is_valid else 'INVALID'}")
    print(f"Commit Type: {result.commit_type}")
    if result.jira_tickets:
        print(f"Jira Tickets: {', '.join(result.jira_tickets)}")
    
    if result.errors:
        print(f"\nERRORS ({len(result.errors)}):")
        for i, error in enumerate(result.errors, 1):
            print(f"  {i}. {error}")
    
    if result.warnings:
        print(f"\nWARNINGS ({len(result.warnings)}):")
        for i, warning in enumerate(result.warnings, 1):
            print(f"  {i}. {warning}")
    
    print(f"{'='*60}")
    
    # Exit with appropriate code
    sys.exit(0 if result.is_valid else 1)

if __name__ == '__main__':
    main()
