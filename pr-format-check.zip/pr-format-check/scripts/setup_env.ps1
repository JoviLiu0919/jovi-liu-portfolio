#!/usr/bin/env pwsh
"""
Setup script for PR Format Check Skill dependencies
"""

Write-Host "Setting up PR Format Check Skill environment..." -ForegroundColor Green

# Check if Python is installed
try {
    $pythonVersion = python --version 2>$null
    Write-Host "Found Python: $pythonVersion" -ForegroundColor Cyan
} catch {
    Write-Host "Error: Python is not installed or not in PATH" -ForegroundColor Red
    Write-Host "Please install Python 3.8 or higher" -ForegroundColor Yellow
    exit 1
}

# Create virtual environment if it doesn't exist
$venvPath = ".\.venv"
if (-not (Test-Path $venvPath)) {
    Write-Host "Creating virtual environment..." -ForegroundColor Yellow
    python -m venv $venvPath
} else {
    Write-Host "Virtual environment already exists" -ForegroundColor Green
}

# Activate virtual environment
Write-Host "Activating virtual environment..." -ForegroundColor Yellow
& "$venvPath\Scripts\Activate.ps1"

# Upgrade pip
Write-Host "Upgrading pip..." -ForegroundColor Yellow
python -m pip install --upgrade pip

# Install required packages
Write-Host "Installing required packages..." -ForegroundColor Yellow

$packages = @(
    "requests>=2.31.0",
    "toml>=0.10.2",
    "argparse",
    "pathlib",
    "dataclasses",
    "typing-extensions"
)

foreach ($package in $packages) {
    Write-Host "Installing $package..." -ForegroundColor Cyan
    try {
        pip install $package
    } catch {
        Write-Host "Warning: Failed to install $package" -ForegroundColor Yellow
    }
}

# Create requirements.txt for reference
Write-Host "Creating requirements.txt..." -ForegroundColor Yellow
$requirements = @"
requests>=2.31.0
toml>=0.10.2
"@

$requirements | Out-File -FilePath "requirements.txt" -Encoding UTF8

# Test the installation
Write-Host "Testing installation..." -ForegroundColor Yellow

try {
    # Test imports
    python -c "import requests, toml; print('Dependencies imported successfully')"
    Write-Host "✅ Dependencies test passed" -ForegroundColor Green
} catch {
    Write-Host "❌ Dependencies test failed" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Create config template if it doesn't exist
$configPath = "config.toml"
if (-not (Test-Path $configPath)) {
    Write-Host "Creating config template..." -ForegroundColor Yellow
    $configTemplate = @"
[Github]
# GitHub Enterprise Server URL - Update this!
url = "https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025"

# Personal Access Token (generate from GitHub account settings) - Update this!
token = "ghp_your_token_here"

[Jira]
# Jira Server URL (optional, for ticket validation)
url = "https://jira.cec.delllabs.net"
username = "your_username"
token = "your_jira_token"
"@
    $configTemplate | Out-File -FilePath $configPath -Encoding UTF8
    Write-Host "✅ Config template created: $configPath" -ForegroundColor Green
    Write-Host "⚠️  Please update the config file with your actual tokens and URLs" -ForegroundColor Yellow
} else {
    Write-Host "✅ Config file already exists" -ForegroundColor Green
}

# Test script functionality
Write-Host "Testing script functionality..." -ForegroundColor Yellow

try {
    # Test pr_format_checker
    $testMessage = @"
If applied, this commit will add test functionality

[Detailed Description]
New Feature: TEST-123 Add test feature
Purpose: Test the validation system

[Systems Affected]
All

[Cherry Pick Info]
N/A
"@
    
    $result = python scripts/pr_format_checker.py --message $testMessage
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ PR format checker test passed" -ForegroundColor Green
    } else {
        Write-Host "⚠️  PR format checker test failed (this might be expected)" -ForegroundColor Yellow
    }
} catch {
    Write-Host "⚠️  Script test failed: $($_.Exception.Message)" -ForegroundColor Yellow
}

Write-Host "`n" + "="*60 -ForegroundColor Cyan
Write-Host "Setup completed!" -ForegroundColor Green
Write-Host "="*60 -ForegroundColor Cyan
Write-Host "Next steps:" -ForegroundColor White
Write-Host "1. Update config.toml with your GitHub token and URLs" -ForegroundColor Yellow
Write-Host "2. Test with: python scripts/pr_format_checker.py --help" -ForegroundColor Yellow
Write-Host "3. Check a PR: python scripts/github_integration.py --pr-url <PR_URL> --dry-run" -ForegroundColor Yellow
Write-Host "="*60 -ForegroundColor Cyan

# Keep the virtual environment activated for the user
Write-Host "Virtual environment is activated. You can now use the scripts." -ForegroundColor Green
Write-Host "To deactivate later, run: deactivate" -ForegroundColor Cyan
