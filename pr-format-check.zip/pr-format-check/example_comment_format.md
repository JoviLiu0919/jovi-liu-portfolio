## 📊 PR Format Check Summary

**🎯 Action Required:** 🔄 Squash 2 commits into 1 | 🔐 Fix GPG signatures (1 unsigned) | 📝 Fix commit message format (2 invalid)

**Total Commits:** 2  
**Valid Commits:** 0  
**Invalid Commits:** 2  
**GPG Signed:** 1/2

⚠️ **Multiple commits detected. Consider squashing into a single commit.**

**Suggested command:**
```bash
git rebase -i HEAD~2
# Use 'squash' or 'fixup' to combine commits
```

---

### ❌ Commit `abc12345`

**❌ GPG Signature Not Verified**

**Errors:**
- Missing required section: [Detailed Description]
- Executive summary must complete: "If applied, this commit will..."
- Bug Fix format requires 'Root cause: <brief description>'

**Warnings:**
- No Jira ticket found - consider adding one for tracking

### 🔧 Required Actions

Please fix the above errors and update your commit message using:
```bash
git commit --amend
```

For GPG signing, ensure your key is configured:
```bash
git config --global commit.gpgsign true
git config --global user.signingkey YOUR_KEY_ID
```

Refer to the Dell commit message format guidelines in the repository documentation.

### 📄 Commit Message Preview

```
Fix BIOS issue
```

---

### ✅ Commit `def67890`

**GPG Signature:** ✅ Verified

### 📄 Commit Message Preview

```
If applied, this commit will improve memory initialization

[Detailed Description]
Bug Fix: CPSE-12345 BIOS fails to boot on certain systems
Root cause: Memory initialization issue in early boot
Solution: Updated memory initialization sequence

[Systems Affected]
All

[Cherry Pick Info]
N/A
```

---

### ❌ Commit `ghi11111`

**❌ GPG Signature Not Verified**

**Errors:**
- Invalid Systems Affected format - must use one of: All, NB, DT, AIO, PW, or list specific systems

### 📄 Commit Message Preview

```
If applied, this commit will add new feature

[Detailed Description]
New Feature: NUDD-67890 Add support for new hardware
Purpose: Enable BIOS to support next-generation processors

[Systems Affected]
InvalidFormat

[Cherry Pick Info]
N/A
```
