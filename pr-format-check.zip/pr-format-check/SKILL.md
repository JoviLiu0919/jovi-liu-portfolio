---
name: pr-format-check
description: Automatically check if PR Git commit messages comply with Dell specifications, and automatically comment and change review status on GitHub. Use when validating PR commit messages, checking Dell formatting compliance, or automating PR reviews.
---

# PR Format Check Skill

Automatically check if pull request Git commit messages comply with Dell format specifications. If they do not comply, automatically comment in the PR and set the review status to "Request Changes".

## Features

- **Automatic Format Check**: Verify if commit messages comply with Dell standard format
- **GPG Signature Verify**: Check if commits are correctly signed, unsigned commits will be marked as invalid
- **Multi-commit Merge Suggestion**: Automatically detect multiple commits and suggest merging into a single commit
- **Jira Integration**: Verify if referenced Jira tickets exist and have correct type (PIMS/CPSE)
- **GitHub Automation**: Automatically comment in PR and change review status
- **Detailed Bug Report**: Provide specific modification suggestions and format guidance

## Configuration

### 1. Install Dependencies (One-time)
```powershell
cd .windsurf/skills/pr-format-check
.\scripts\setup_env.ps1
```

### 2. Configure Configuration File
Edit `config.toml` File:

```toml
[Github]
# GitHub Enterprise Server URL
url = "https://githubcsg.cec.delllabs.net"
# Personal Access Token (requires repo permission)
token = "YOUR_GITHUB_TOKEN_your_token_here"
# Automatically configure review status (true/false)
auto_review_status = true

[Jira]
# Jira Server URL (Optional, for ticket verification)
url = "https://jira.cpg.dell.com"
token = "your_jira_token"
```

## Usage

### 1. Check Single Commit Message
```powershell
# Check from File
python scripts/pr_format_checker.py --message-file commit_msg.txt

# Direct Input Message
python scripts/pr_format_checker.py --message "If applied, this commit will..."
```

### 2. Complete PR Check with Automatic Comments (Main Function)
```powershell
# Check PR and automatically comment/change review status
python scripts/github_integration.py --pr-url "https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/123"

# Only check without executing actions (dry run)
python scripts/github_integration.py --pr-url "..." --dry-run

# Disable automatic review status change, only comment
python scripts/github_integration.py --pr-url "..." --no-auto-review
```

### 3. Jira Ticket Verification
```powershell
# Verify specific ticket
python scripts/jira_validator.py --ticket PIMS-12345

# Search tickets
python scripts/jira_validator.py --search "BIOS issue" --project PIMS
```

## Dell Commit Message Format Specification

### Required Sections
- **Executive Summary (first line)**: Must comply with Dell platform format
- **[Detailed Description]**: Required, cannot be "N/A"
- **[Systems Affected]**: Required, specify affected systems
- **[Cherry Pick Info]**: Can fill "N/A"

### Executive Summary Format

#### Platform Prefix Format (recommended)
```
HuracanPtl, PerformantePtl: Fix PIMS-398306 Linux,Ubuntu,24.04.3,CI,H14_PTL_DVT2,SUT shows failed when run "WB/CB Tests" in CheckBox Stress Tests
```

#### If applied Format
```
If applied, this commit will fix the issue with...
```

### Commit Type Format

#### 1. Bug Fix Format (for issue fixes)
```
Bug Fix: PIMS-398306 Linux,Ubuntu,24.04.3,CI,H14_PTL_DVT2,SUT shows failed when run "WB/CB Tests" in CheckBox Stress Tests
Root cause: Test configuration issue in stress test framework
Solution: Updated test configuration to handle proper environment setup
```

#### 2. New Feature Format
```
New Feature: NUDD-67890 Add support for new hardware
Purpose: Enable BIOS to support next-generation processors
```

#### 3. Enhancement or Others Format (for CR/change request)
```
Change: Improved error handling in firmware update process
Purpose: Better user experience and debugging capabilities
```

### Systems Affected Format
```
# Option 1: All chipsets
All

# Option 2: Specific type + chipset
NB [TGL, ADL]

# Option 3: Specific system
AndrewsTgl, SouthPeak14Tgl

# Option 4: Mixed format
NB [ADL], DT [EGS], SpecificSystem1
```

### Valid chipset codes
- **CML**: Comet Lake
- **TGL**: Tiger Lake  
- **RKL**: Rocket Lake
- **ADL**: Alder Lake
- **EGS**: Emerald Rapids

## Automation Process

### Complete PR Check Process
1. Get PR Information: Get all commits from PR via GitHub API
2. Check one by one: Verify each commit message format and GPG sign status
3. Multi-commit detection: If there are multiple commits, suggest merging into a single commit
4. Jira Verify: Check if referenced PIMS/CPSE tickets exist
5. Generate comments: Create detailed check result comments
6. Update Review Status: 
   - All correct and GPG sign verify passed → Leave only confirmation comment
   - Has bugs or GPG not signed → REQUEST_CHANGES, provide remediation suggestions

### Review Status Configuration

- **All correct and GPG sign verify passed** → Leave only confirmation comment: "PR commit message format confirms okay. "
- **Has bugs or GPG not signed** → REQUEST_CHANGES, provide detailed bug report
- Has bugs or GPG not signed → REQUEST_CHANGES, provide detailed bug report

## Comment Format Example

```markdown
## 📊 PR Format Check Summary

**Total Commits:** 3  
**Valid Commits:** 1  
**Invalid Commits:** 2

⚠️ **Multiple commits detected. Consider squashing into a single commit.**

---

### ❌ Commit `abc12345`

**❌ GPG Signature Not Verified**

**Errors:**
- Missing required section: [Detailed Description]
- Executive summary must use Dell format
- Bug Fix format requires 'Root cause: <brief description>'

**Warnings:**
- No Jira ticket found - consider adding one for tracking

### 🔧 Required Actions

Please fix the above errors and update your commit message using:
```bash
git commit --amend
```

For GPG signing, ensure your key is configured:
```bash
git config --global commit.gpgsign true
git config --global user.signingkey YOUR_KEY_ID
```
```

## Troubleshooting

### Common Bugs and Solutions

#### 1. Authentication Failed
```
ERROR: Failed to create comment: 401 Unauthorized
```
**Solution**: Check if GitHub token has `repo` permission

#### 2. PR Not Found
```
ERROR: Invalid PR URL format
```
**Solution**: Confirm URL format is correct, include complete pull/number path

#### 3. Jira Connection Failed
```
WARNING: Could not validate Jira tickets
```
**Solution**: Check Jira configuration or skip ticket verification

## Advanced Configuration

### Debug Mode
```powershell
# Enable Detailed Output
python scripts/github_integration.py --pr-url "..." --verbose
```
