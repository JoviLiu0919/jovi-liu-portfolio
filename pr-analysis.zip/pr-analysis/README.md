# PR Analysis Skill

## Overview
This skill provides comprehensive analysis of Pull Request data from version control systems. It filters, classifies, and generates detailed reports for project-specific PR analysis.

## Features

- **Project Filtering**: Focus on specific target projects
- **PR Classification**: Automatic categorization based on file types and content
- **Excel Reports**: Generate detailed Excel reports with multiple sheets
- **Data Validation**: Built-in data validation and error handling
- **Configurable**: Easy configuration through TOML files

## Quick Start

### 1. Setup
```bash
# Install dependencies
pip install -r requirements.txt
```

### 2. Configure
Edit `config.toml` to set your:
- Target projects
- Platform paths
- Classification keywords
- Output preferences

### 3. Prepare Data
Place your CSV files in the `input_data/` directory:
- `bitbucket_data.csv`
- `github_data.csv`

### 4. Run Analysis
```bash
python scripts/run_analysis.py
```

## Configuration

### config.toml Structure
```toml
[analysis_criteria]
target_projects = ["Project1", "Project2"]
platform_paths = ["path/to/platform", "another/path"]
platform_setting_extensions = [".h", ".dsc", ".dec"]
classification_keywords = ["PIMS", "CPSE"]

[output]
default_filename = "PR_Analysis.xlsx"
```

## Output Structure

The generated Excel file contains:

1. **Summary Sheet**: Overall statistics
2. **Detailed_Breakdown Sheet**: Categorized breakdown
3. **Project Sheets**: Individual project analysis with classification columns

## File Structure

```
pr_analysis/
├── SKILL.md              # Skill documentation
├── README.md              # This file
├── config.toml           # Configuration
├── requirements.txt      # Dependencies
├── scripts/
│   ├── pr_analyzer.py     # Main analysis engine
│   ├── data_validator.py  # Data validation
│   └── run_analysis.py    # Simple runner
├── input_data/            # Place CSV files here
└── output/               # Generated reports
```

## Data Format

Input CSV files should contain the following columns:
- PR ID
- Title
- Description
- File paths
- Author
- Timestamp
- Project information

## Classification Rules

### Platform Setting Only PRs
PRs that only modify files with specified extensions (e.g., .h, .dsc, .dec)

### PIMS Fix PRs
PRs containing specific keywords in title or description

### PIMS with Platform Setting
PRs that are both PIMS fixes AND only modify platform setting files

## Troubleshooting

### Common Issues

1. **Missing Input Files**
   - Ensure CSV files are in `input_data/` directory
   - Check file names match expected format

2. **Configuration Errors**
   - Verify `config.toml` syntax
   - Check all required sections are present

3. **Import Errors**
   - Install all dependencies: `pip install -r requirements.txt`

### Getting Help

- Check the console output for detailed error messages
- Verify input data format matches expected structure
- Ensure configuration values are appropriate for your data

## Advanced Usage

### Custom Analysis
```python
from scripts.pr_analyzer import CBDCITPRAnalyzer

analyzer = CBDCITPRAnalyzer()
analyzer.target_projects = ["YourProject"]
analyzer.platform_paths = ["your/platform/path"]

success = analyzer.analyze(
    bitbucket_file="path/to/bitbucket.csv",
    github_file="path/to/github.csv",
    output_file="output.xlsx"
)
```

### Data Validation
```python
from scripts.data_validator import DataValidator

validator = DataValidator()
issues = validator.validate_file("input_data/bitbucket_data.csv")
if issues:
    print("Validation issues found:", issues)
```

## License

This skill is provided as-is for educational and development purposes.
