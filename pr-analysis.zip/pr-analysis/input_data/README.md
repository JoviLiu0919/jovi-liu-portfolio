# Input Data Directory

Place your CSV files in this directory for analysis.

## Expected Files

### bitbucket_data.csv
CSV file containing Bitbucket PR data with the following columns:
- PR_ID
- Title
- Description
- Author
- Timestamp
- File_Paths
- Project

### github_data.csv
CSV file containing GitHub PR data with similar structure to bitbucket_data.csv

## File Format

Both files should be comma-separated CSV files with headers in the first row.

## Sample Data Structure

```csv
PR_ID,Title,Description,Author,Timestamp,File_Paths,Project
123,"Fix platform settings","Updated configuration files",John Doe,2024-01-15,DellPkgs/DellPlatformPkgs/NB/config.h,SlatePtl
124,"Add new feature","Implemented new functionality",Jane Smith,2024-01-16,Common/Driver/feature.c,SlatePtl
```

## Notes

- Files in this directory are ignored by git (see .gitignore)
- Make sure your data files match the expected column structure
- Large files may take time to process
