# Output Directory

Generated analysis reports will be saved in this directory.

## Output Files

### PR_Analysis.xlsx
Main Excel report containing:
- Summary sheet with overall statistics
- Detailed breakdown by project
- Individual project sheets with classifications

## File Structure

The Excel file contains multiple sheets:
1. **Summary**: Overall PR statistics across all projects
2. **Detailed_Breakdown**: Categorized PR analysis
3. **Project Sheets**: Individual project analysis with classification columns

## Classification Columns

Each project sheet includes:
- `Platform Setting`: ✓ for platform setting only PRs
- `PIMS Fix`: ✓ for PIMS fix PRs
- `PIMS with Platform Setting`: ✓ for PRs that are both

## Notes

- This directory is ignored by git (see .gitignore)
- Output files are generated automatically by the analysis script
- Previous output files will be overwritten when running new analysis
