---
name: pr-analysis
description: Pull Request analysis tool for project data classification and reporting. Use when analyzing PR data, generating project statistics, or creating classification reports.
---

# PR Analysis Skill

## Description
Analyzes Pull Request data from version control systems, focusing on project-specific filtering and classification. Generates detailed Excel reports with statistics and categorization.

## Features

### Project Filtering
- Filters PRs for target projects based on configurable project names
- Classifies PRs as Platform vs Common based on file paths
- Only includes Platform PRs in analysis

### Classification Criteria
- **Platform Setting Only PRs**: PRs that only modify files with specific extensions (.h, .dsc, .dec, .png, .jpg, .xml, .inc, .bmp)
- **PIMS Fix PRs**: PRs mentioning specific keywords in title/description
- **PIMS with Platform Setting PRs**: PRs that are both PIMS fixes AND only modify platform setting files

### Output Structure
1. **Summary Sheet**: Overall statistics for each project
2. **Detailed_Breakdown Sheet**: Categorized breakdown by project
3. **Project Sheets**: All Platform PRs for each project with classification columns

## Usage

### Basic Usage
```python
from scripts.pr_analyzer import CBDCITPRAnalyzer

analyzer = CBDCITPRAnalyzer()
analyzer.analyze(
    bitbucket_file="input_data/bitbucket_data.csv",
    github_file="input_data/github_data.csv",
    output_file="PR_Analysis.xlsx"
)
```

## Configuration
Edit `config.toml` to modify:
- Target projects
- Platform paths and extensions
- Classification keywords
- Output settings

## Output Files
- **Excel Report**: Contains all analysis results
- **Console Output**: Summary statistics printed to console

## Dependencies
- pandas >= 1.5.0
- numpy >= 1.21.0
- openpyxl >= 3.0.0

## File Structure
```
pr_analysis/
├── scripts/
│   ├── pr_analyzer.py          # Main analysis engine
│   ├── data_validator.py       # Data validation utilities
│   └── run_*.py               # Various runner scripts
├── input_data/                 # Raw data files
├── output/                     # Analysis results
├── config.toml                # Configuration
└── requirements.txt           # Dependencies
```

## Key Features
- Configurable project filtering
- Automatic PR classification
- Excel report generation
- Data validation and error handling
- Modular script architecture
