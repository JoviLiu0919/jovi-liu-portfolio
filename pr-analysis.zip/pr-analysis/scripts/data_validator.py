#!/usr/bin/env python3
"""
CBDCIT PR Data Validator
Verify Input Data Format whether conforms to Analyze Requirements
"""

import pandas as pd
import sys
from pathlib import Path

def validate_csv_file(file_path, file_type):
    """Validate single CSV file"""
    print(f"Validating {file_type} data: {file_path}")
    
    if not Path(file_path).exists():
        print(f"  ERROR: File does not exist")
        return False
    
    try:
        df = pd.read_csv(file_path)
        print(f"  SUCCESS: Successfully read {len(df)} records")
        
        # Check available columns
        available_columns = df.columns.tolist()
        print(f"  Available columns: {', '.join(available_columns)}")
        
        # Check for required functionality (not exact column names)
        title_columns = ['title', 'pr_title', 'pr_summary', 'pr_1stline']
        description_columns = ['body', 'pr_summary', 'description']
        file_path_columns = ['pr_files', 'changes', 'filename', 'file_paths']
        
        # Check if we have title information
        has_title = any(col in available_columns for col in title_columns)
        if has_title:
            print(f"  SUCCESS: Found title information")
        else:
            print(f"  WARNING: No title column found")
        
        # Check if we have description information
        has_description = any(col in available_columns for col in description_columns)
        if has_description:
            print(f"  SUCCESS: Found description information")
        else:
            print(f"  WARNING: No description column found")
        
        # Check if we have file path information
        has_file_paths = any(col in available_columns for col in file_path_columns)
        if has_file_paths:
            print(f"  SUCCESS: Found file path information")
        else:
            print(f"  WARNING: No file path column found")
        
        # Check data quality
        print("  Checking data quality...")
        
        # Check target projects
        target_projects = ['SlatePtl', 'BladePtl', 'CongoWcl']
        project_found = False
        
        # Check in project columns
        project_columns = ['projectname', 'project', 'impactedprojects', 'impacted_projects']
        for col in project_columns:
            if col in df.columns:
                # Convert to string to avoid .str accessor issues
                col_data = df[col].astype(str)
                for project in target_projects:
                    matches = col_data.str.contains(project, case=False, na=False).sum()
                    if matches > 0:
                        print(f"  SUCCESS: Found {matches} {project} records in {col}")
                        project_found = True
        
        # Check in text columns if not found in project columns
        if not project_found:
            text_columns = title_columns + description_columns
            for col in text_columns:
                if col in df.columns:
                    # Convert to string to avoid .str accessor issues
                    col_data = df[col].astype(str)
                    for project in target_projects:
                        matches = col_data.str.contains(project, case=False, na=False).sum()
                        if matches > 0:
                            print(f"  SUCCESS: Found {matches} {project} records in {col}")
                            project_found = True
        
        if not project_found:
            print("  WARNING: No target project records found (SlatePtl, BladePtl, CongoWcl)")
        
        # Check file path format
        for col in file_path_columns:
            if col in df.columns:
                sample_paths = df[col].dropna().head(3).tolist()
                print(f"  {col} samples:")
                for i, path in enumerate(sample_paths, 1):
                    print(f"    {i}. {str(path)[:100]}...")
                break
        
        print(f"  SUCCESS: {file_type} validation completed")
        return True
        
    except Exception as e:
        print(f"  ERROR: Failed to read file: {e}")
        return False

def validate_analysis_readiness():
    """Validate analysis readiness"""
    print("=" * 60)
    print("PR Analysis - Data Validation Tool")
    print("=" * 60)
    print()
    
    base_dir = Path(__file__).parent.parent
    
    # Check input files
    bitbucket_file = base_dir / "input_data" / "bitbucket_pr_data.csv"
    github_file = base_dir / "input_data" / "github_pr_data.csv"
    
    # If default files don't exist, try the latest timestamped files
    if not bitbucket_file.exists():
        input_dir = base_dir / "input_data"
        bitbucket_files = list(input_dir.glob("bitbucket_pr_data_*.csv"))
        if bitbucket_files:
            bitbucket_file = max(bitbucket_files, key=lambda x: x.stat().st_mtime)
    
    if not github_file.exists():
        input_dir = base_dir / "input_data"
        github_files = list(input_dir.glob("github_pr_data_*.csv"))
        if github_files:
            github_file = max(github_files, key=lambda x: x.stat().st_mtime)
    
    print("Checking input files...")
    print()
    
    bitbucket_valid = validate_csv_file(bitbucket_file, "Bitbucket")
    print()
    github_valid = validate_csv_file(github_file, "GitHub")
    print()
    
    # Summary
    print("=" * 40)
    print("Validation Results Summary:")
    print(f"  Bitbucket data: {'VALID' if bitbucket_valid else 'INVALID'}")
    print(f"  GitHub data: {'VALID' if github_valid else 'INVALID'}")
    print()
    
    if bitbucket_valid and github_valid:
        print("SUCCESS: Data validation passed! Ready to run analysis.")
        print()
        print("Run command:")
        print("  python scripts/run_production_analysis.py")
        return True
    else:
        print("ERROR: Data validation failed. Please fix issues and retry.")
        print()
        print("Suggestions:")
        if not bitbucket_valid:
            print("  - Check Bitbucket CSV file format")
        if not github_valid:
            print("  - Check GitHub CSV file format")
        print()
        print("For detailed guide, see: DATA_PREPARATION_GUIDE.md")
        return False

def show_expected_format():
    """Display expected Data Format"""
    print("=" * 60)
    print("Expected CSV Data Format")
    print("=" * 60)
    print()
    print("Required fields:")
    print("  title        - PR Title")
    print("  description  - PR description") 
    print("  file_paths   - Modified File Paths (separated by commas)")
    print()
    print("Suggested fields:")
    print("  id           - PR number")
    print("  author       - PR Author")
    print("  date         - PR Date")
    print("  status       - PR Status")
    print()
    print("FilePathFormatExample:")
    print('  "DellPkgs\\DellPlatformPkgs\\NB\\SlatePtl\\config.h,DellPkgs\\DellPlatformPkgs\\NB\\SlatePtl\\platform.dsc"')
    print()
    print("Target project keywords:")
    print("  - SlatePtl")
    print("  - BladePtl")
    print("  - CongoWcl")
    print()
    print("Platform Path patterns:")
    print("  - DellPkgs\\DellPlatformPkgs\\NB")
    print("  - DellPkgs\\DellPlatformPkgs\\DT")
    print("  - DellPkgs\\DellPlatformPkgs\\PW")
    print()

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--format":
        show_expected_format()
    else:
        validate_analysis_readiness()
