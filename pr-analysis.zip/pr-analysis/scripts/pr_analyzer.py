#!/usr/bin/env python3
"""
CBDCIT PR Data Analyzer
Analyzes Pull Request data from Bitbucket and GitHub for AgS_2025 project
Generates Excel charts with detailed statistics for specific projects
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import re
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Import central configuration loader
import sys
sys.path.append(str(Path(__file__).parent.parent.parent.parent))
from config_loader import load_skill_config_with_central_fallback

class CBDCITPRAnalyzer:
    def __init__(self, config_path: str = None):
        if config_path is None:
            config_path = Path(__file__).parent.parent / "config.toml"
        
        # Load configuration
        self.config = load_skill_config_with_central_fallback(Path(config_path))
        
        # Load analysis criteria from config
        analysis_criteria = self.config.get('analysis_criteria', {})
        self.platform_paths = analysis_criteria.get('platform_paths', [
            'DellPkgs/DellPlatformPkgs/NB',
            'DellPkgs/DellPlatformPkgs/DT',
            'DellPkgs/DellPlatformPkgs/PW'
        ])
        self.platform_setting_extensions = set(analysis_criteria.get('platform_setting_extensions', ['.h', '.dsc', '.dec', '.png', '.jpg']))
        self.target_projects = analysis_criteria.get('target_projects', ['SlatePtl', 'BladePtl', 'CongoWcl'])
        self.leading_project = 'SlatePtl'  # Leading project for multi-project PRs
        self.data = None
        
    def load_data(self, bitbucket_file=None, github_file=None):
        """Load PR data from CSV files"""
        dfs = []
        
        if bitbucket_file and Path(bitbucket_file).exists():
            df_bb = pd.read_csv(bitbucket_file)
            df_bb['source'] = 'Bitbucket'
            dfs.append(df_bb)
            
        if github_file and Path(github_file).exists():
            df_gh = pd.read_csv(github_file)
            df_gh['source'] = 'GitHub'
            dfs.append(df_gh)
            
        if dfs:
            self.data = pd.concat(dfs, ignore_index=True)
            print(f"Loaded {len(self.data)} PR records total")
            return True
        return False
    
    def filter_target_projects(self):
        """Filter PRs for target projects - include both Platform and Common PRs"""
        if self.data is None:
            return None
            
        # First classify all PRs as Platform or Common
        self.data = self.classify_pr_type(self.data)
        
        # Filter PRs that are either Platform PRs OR Common PRs that have relevant project paths
        platform_prs = self.data[self.data['pr_type'] == 'Platform'].copy()
        
        # Also include Common PRs that might be relevant to our analysis
        # (Common PRs are those that modify files outside target project paths)
        common_prs = self.data[self.data['pr_type'] == 'Common'].copy()
        
        # Combine both Platform and Common PRs
        all_relevant_prs = pd.concat([platform_prs, common_prs], ignore_index=True)
        
        print(f"Filtered to {len(platform_prs)} Platform PRs and {len(common_prs)} Common PRs (from {len(self.data)} total PRs)")
        return all_relevant_prs
    
    def classify_pr_type(self, pr_data):
        """Classify PRs as Common or Platform based on file paths"""
        
        def classify_single_row(row):
            # Choose the right file path column based on data source
            file_paths = None
            
            if row.get('source') == 'Bitbucket':
                # Bitbucket uses pr_files
                if pd.notna(row.get('pr_files')):
                    file_paths = str(row['pr_files'])
            elif row.get('source') == 'GitHub':
                # GitHub uses filename or changes
                if pd.notna(row.get('filename')):
                    file_paths = str(row['filename'])
                elif pd.notna(row.get('changes')):
                    file_paths = str(row['changes'])
            else:
                # Fallback: try any available column
                for col in ['filename', 'pr_files', 'changes', 'file_paths']:
                    if pd.notna(row.get(col)):
                        file_paths = str(row[col])
                        break
            
            if not file_paths or file_paths == 'nan':
                return 'Unknown'
                
            # Define target project paths (exact match required)
            target_project_paths = [
                'DellPkgs/DellPlatformPkgs/NB/SlatePtlOnePkg',
                'DellPkgs/DellPlatformPkgs/NB/BladePtlOnePkg', 
                'DellPkgs/DellPlatformPkgs/NB/CongoWclOnePkg'
            ]
            
            # Define general platform paths to check for Common PR
            general_platform_paths = [
                'DellPkgs/DellPlatformPkgs/DT',
                'DellPkgs/DellPlatformPkgs/NB',
                'DellPkgs/DellPlatformPkgs/PW'
            ]
            
            # Split paths by comma and clean
            individual_paths = [path.strip() for path in file_paths.split(',')]
            
            # Check if any path is outside general platform paths
            for path in individual_paths:
                if not path:  # Skip empty paths
                    continue
                    
                # Check if path is within general platform paths
                is_in_platform = any(platform_path in path for platform_path in general_platform_paths)
                
                if not is_in_platform:
                    return 'Common'  # Found path outside platform folders
            
            # If all paths are within platform folders, check if they are ONLY target project paths
            for path in individual_paths:
                if not path:  # Skip empty paths
                    continue
                    
                # Check if path is one of the allowed target project paths
                is_target_project = any(target_path in path for target_path in target_project_paths)
                
                if not is_target_project:
                    return 'Common'  # Found platform path but not target project
            
            # If we reach here, all paths are within target project folders
            return 'Platform'
        
        pr_data['pr_type'] = pr_data.apply(classify_single_row, axis=1)
        return pr_data
    
    def identify_platform_settings(self, pr_data):
        """Identify PRs that only change platform setting files"""
        
        def check_platform_settings(row):
            # Choose the right file path column based on data source
            file_paths = None
            
            if row.get('source') == 'Bitbucket':
                if pd.notna(row.get('pr_files')):
                    file_paths = str(row['pr_files'])
            elif row.get('source') == 'GitHub':
                if pd.notna(row.get('filename')):
                    file_paths = str(row['filename'])
                elif pd.notna(row.get('changes')):
                    file_paths = str(row['changes'])
            else:
                for col in ['filename', 'pr_files', 'changes', 'file_paths']:
                    if pd.notna(row.get(col)):
                        file_paths = str(row[col])
                        break
            
            if not file_paths or file_paths == 'nan':
                return False
                
            files = re.findall(r'[^,\s]+\.[a-zA-Z0-9]+', file_paths)
            
            if not files:
                return False
                
            # Check if all files have platform setting extensions
            for file in files:
                ext = Path(file).suffix.lower()
                if ext not in self.platform_setting_extensions:
                    return False
            return True
        
        pr_data['is_platform_setting'] = pr_data.apply(check_platform_settings, axis=1)
        return pr_data
    
    def identify_pims_fixes(self, pr_data):
        """Identify PRs that mention PIMS, CPSE, or ticket"""
        text_cols = ['title', 'pr_title', 'pr_summary', 'body', 'pr_1stline', 'description']
        available_cols = [col for col in text_cols if col in pr_data.columns]
        
        def has_pims_reference(row):
            for col in available_cols:
                if pd.notna(row[col]) and re.search(r'PIMS|CPSE|ticket', str(row[col]), re.IGNORECASE):
                    return True
            return False
        
        pr_data['is_pims_fix'] = pr_data.apply(has_pims_reference, axis=1)
        return pr_data
    
    def identify_cr_pims(self, pr_data):
        """Identify CR PIMS - PIMS that are Change Requests (excluding Bug Fix cases)"""
        text_cols = ['title', 'pr_title', 'pr_summary', 'body', 'pr_1stline', 'description']
        available_cols = [col for col in text_cols if col in pr_data.columns]
        
        def is_cr_pims(row):
            if not row.get('is_pims_fix', False):
                return False
            
            # EXCLUSION: If Bug Fix is found, this is NOT CR PIMS (it's PIMS Fix only)
            for col in available_cols:
                if pd.notna(row[col]):
                    content = str(row[col])
                    # Look for "Bug Fix" pattern (case insensitive)
                    if re.search(r'Bug Fix', content, re.IGNORECASE):
                        return False
            
            # Priority 1: Check for explicit "CR PIMS-XXXXXX" pattern
            for col in available_cols:
                if pd.notna(row[col]):
                    content = str(row[col])
                    # Look for "CR PIMS-XXXXXX" pattern (case insensitive)
                    if re.search(r'CR\s+PIMS-\d+', content, re.IGNORECASE):
                        return True
            
            # Priority 2: Check for separate CR and PIMS keywords in same text
            for col in available_cols:
                if pd.notna(row[col]):
                    content = str(row[col])
                    # Look for both CR and PIMS keywords in the same field
                    if re.search(r'CR|Change Request', content, re.IGNORECASE) and \
                       re.search(r'PIMS|CPSE|ticket', content, re.IGNORECASE):
                        return True
            
            # Priority 3: Check for CR keyword in any field (already confirmed PIMS)
            for col in available_cols:
                if pd.notna(row[col]) and re.search(r'CR|Change Request', str(row[col]), re.IGNORECASE):
                    return True
            
            return False
        
        pr_data['is_cr_pims'] = pr_data.apply(is_cr_pims, axis=1)
        return pr_data
    
    def identify_multi_project_prs(self, pr_data):
        """Identify multi-project PRs - only PRs that modify multiple target projects, excluding Common PRs"""
        def check_multi_project(row):
            # Only consider Platform PRs for multi-project classification
            if row.get('pr_type') != 'Platform':
                return False
                
            # Choose the right file path column based on data source
            file_paths = None
            
            if row.get('source') == 'Bitbucket':
                if pd.notna(row.get('pr_files')):
                    file_paths = str(row['pr_files'])
            elif row.get('source') == 'GitHub':
                if pd.notna(row.get('filename')):
                    file_paths = str(row['filename'])
                elif pd.notna(row.get('changes')):
                    file_paths = str(row['changes'])
            else:
                for col in ['filename', 'pr_files', 'changes', 'file_paths']:
                    if pd.notna(row.get(col)):
                        file_paths = str(row[col])
                        break
            
            if not file_paths or file_paths == 'nan':
                return False
                
            # Check for multiple target project paths
            target_paths = [
                'DellPkgs/DellPlatformPkgs/NB/SlatePtlOnePkg',
                'DellPkgs/DellPlatformPkgs/NB/BladePtlOnePkg', 
                'DellPkgs/DellPlatformPkgs/NB/CongoWclOnePkg'
            ]
            
            found_projects = []
            for target_path in target_paths:
                if target_path in file_paths:
                    found_projects.append(target_path)
            
            return len(found_projects) > 1
        
        pr_data['is_multi_project'] = pr_data.apply(check_multi_project, axis=1)
        return pr_data
    
    def identify_common_prs(self, pr_data):
        """Identify Common PRs based on existing pr_type classification"""
        # Common PRs are those classified as 'Common' in pr_type
        pr_data['is_common_pr'] = pr_data['pr_type'] == 'Common'
        return pr_data
    
    def generate_statistics(self, filtered_data):
        """Generate statistics for each project"""
        if filtered_data is None or filtered_data.empty:
            return {}
            
        stats = {}
        
        def filter_project_prs(project_path, project_name):
            """Filter PRs for a specific project using data source logic"""
            project_prs_list = []
            
            for _, row in filtered_data.iterrows():
                # Skip multi-project PRs unless this is the leading project
                if row.get('is_multi_project', False) and project_name != self.leading_project:
                    continue
                
                # Choose the right file path column based on data source
                file_paths = None
                
                if row.get('source') == 'Bitbucket':
                    if pd.notna(row.get('pr_files')):
                        file_paths = str(row['pr_files'])
                elif row.get('source') == 'GitHub':
                    if pd.notna(row.get('filename')):
                        file_paths = str(row['filename'])
                    elif pd.notna(row.get('changes')):
                        file_paths = str(row['changes'])
                else:
                    for col in ['filename', 'pr_files', 'changes', 'file_paths']:
                        if pd.notna(row.get(col)):
                            file_paths = str(row[col])
                            break
                
                if file_paths and file_paths != 'nan':
                    # For multi-project PRs, if this is leading project, include them
                    if row.get('is_multi_project', False) and project_name == self.leading_project:
                        # Check if any path contains any target project path
                        target_paths = [
                            'DellPkgs/DellPlatformPkgs/NB/SlatePtlOnePkg',
                            'DellPkgs/DellPlatformPkgs/NB/BladePtlOnePkg', 
                            'DellPkgs/DellPlatformPkgs/NB/CongoWclOnePkg'
                        ]
                        if any(target_path in file_paths for target_path in target_paths):
                            project_prs_list.append(row)
                    else:
                        # Single project PRs - check if path contains the target project path
                        if project_path in file_paths:
                            project_prs_list.append(row)
            
            return pd.DataFrame(project_prs_list)
        
        for project in self.target_projects:
            # Determine the target path for this project
            if project == 'SlatePtl':
                target_path = 'DellPkgs/DellPlatformPkgs/NB/SlatePtlOnePkg'
            elif project == 'BladePtl':
                target_path = 'DellPkgs/DellPlatformPkgs/NB/BladePtlOnePkg'
            elif project == 'CongoWcl':
                target_path = 'DellPkgs/DellPlatformPkgs/NB/CongoWclOnePkg'
            else:
                continue
            
            # Filter PRs for this specific project
            project_prs = filter_project_prs(target_path, project)
            
            # Calculate statistics - ensure they match project sheet checkboxes
            total_platform_prs = len(project_prs)
            common_prs = len(project_prs[project_prs['is_common_pr']])
            platform_setting_only = len(project_prs[project_prs['is_platform_setting']])
            pims_fix_prs = len(project_prs[project_prs['is_pims_fix']])
            pims_and_setting = len(project_prs[project_prs['is_platform_setting'] & project_prs['is_pims_fix']])
            modular_platform_common = len(project_prs[project_prs['is_multi_project']])
            
            # Platform PR should exclude Common PR
            platform_unique_prs = len(project_prs[~project_prs['is_common_pr'] & ~project_prs['is_multi_project']])
            total_platform_prs = modular_platform_common + platform_unique_prs
            
            # Platform PR Sorting (w/o CR PIMS): Exclude CR PIMS from Platform PR counts
            cr_pims_mask = project_prs['is_cr_pims']
            
            # With Settings Only: (Platform Setting) AND NOT (Common PR) AND NOT (CR PIMS)
            platform_pr_with_settings = len(project_prs[project_prs['is_platform_setting'] & ~project_prs['is_common_pr'] & ~cr_pims_mask])
            
            # PIMS Fix PR with Platform Settings: (PIMS with Platform Setting) AND NOT (Common PR) AND NOT (CR PIMS)
            pims_fix_with_platform_settings = len(project_prs[(project_prs['is_platform_setting'] & project_prs['is_pims_fix']) & ~project_prs['is_common_pr'] & ~cr_pims_mask])
            
            # PIMS Fix PR: (PIMS Fix) AND NOT (Common PR) AND NOT (CR PIMS)
            pims_fix_pr_count = len(project_prs[project_prs['is_pims_fix'] & ~project_prs['is_common_pr'] & ~cr_pims_mask])
            
            # CR PIMS: Include all CR PIMS (no exclusions)
            cr_pims = len(project_prs[project_prs['is_cr_pims']])
            
            # Calculate CR PIMS subcategories
            cr_pims_common = len(project_prs[project_prs['is_common_pr'] & project_prs['is_cr_pims']])
            cr_pims_modular = len(project_prs[project_prs['is_multi_project'] & project_prs['is_cr_pims']])
            cr_pims_platform = len(project_prs[~project_prs['is_common_pr'] & ~project_prs['is_multi_project'] & project_prs['is_cr_pims']])
            
            # Total PR: (Common PR) + (Platform PR)
            total_prs = common_prs + total_platform_prs
            
            stats[project] = {
                'total_prs': total_prs,
                'common_prs': common_prs,
                'total_platform_prs': total_platform_prs,  # Total Platform PR (Modular + Unique)
                'modular_platform_common': modular_platform_common,
                'platform_unique_prs': platform_unique_prs,  # Platform Unique PR
                'platform_setting_only': platform_setting_only,
                'pims_and_setting': pims_and_setting,
                'pims_fix_prs': pims_fix_pr_count,  # PIMS Fix PR count
                'platform_pr_with_settings': platform_pr_with_settings,  # Platform PR with Settings Only
                'pims_fix_with_platform_settings': pims_fix_with_platform_settings,  # PIMS Fix PR with Platform Settings
                'cr_pims': cr_pims,
                'cr_pims_common': cr_pims_common,
                'cr_pims_modular': cr_pims_modular,
                'cr_pims_platform': cr_pims_platform
            }
            
        return stats
    
    def create_excel_report(self, stats, output_file='PR_Analysis.xlsx'):
        """Create Excel file with detailed statistics and charts"""
        # Store the filtered data for use in project sheets
        self.filtered_data = self.filter_target_projects()
        
        # Apply remaining classifications to filtered data
        self.filtered_data = self.identify_platform_settings(self.filtered_data)
        self.filtered_data = self.identify_pims_fixes(self.filtered_data)
        self.filtered_data = self.identify_cr_pims(self.filtered_data)
        self.filtered_data = self.identify_multi_project_prs(self.filtered_data)
        self.filtered_data = self.identify_common_prs(self.filtered_data)
        
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            # Summary statistics (transposed: projects as columns, statistics as rows)
            summary_data = []
            
            # Define statistic categories
            stat_categories = [
                'Total PR',
                'Common PR',
                'Platform PR',
                '  - Modular Platform Common',
                '  - Platform Unique PR',
                '',  # Empty row for spacing
                'Platform PR Sorting (w/o CR PIMS)',
                '  - With Settings Only',
                '  - PIMS Fix PR with Platform Settings',
                '  - PIMS Fix PR',
                '',  # Second empty row for spacing
                'CR PIMS',
                '  - Common PR',
                '  - Modualrity Platform Common',
                '  - Platform PR'
            ]
            
            # Create transposed data structure
            for stat_category in stat_categories:
                if stat_category == '':  # Empty row for spacing
                    row_data = {'Statistic': ''}
                    for project in stats.keys():
                        row_data[project] = ''
                else:
                    row_data = {'Statistic': stat_category}
                    for project in stats.keys():
                        if stat_category == 'Total PR':
                            row_data[project] = stats[project]['total_prs']
                        elif stat_category == 'Common PR':
                            row_data[project] = stats[project]['common_prs']
                        elif stat_category == 'Platform PR':
                            row_data[project] = stats[project]['total_platform_prs']
                        elif stat_category == '  - Modular Platform Common':
                            row_data[project] = stats[project]['modular_platform_common']
                        elif stat_category == '  - Platform Unique PR':
                            row_data[project] = stats[project]['platform_unique_prs']
                        elif stat_category == 'Platform PR Sorting (w/o CR PIMS)':
                            row_data[project] = ''  # Parent category, no data
                        elif stat_category == '  - With Settings Only':
                            row_data[project] = stats[project]['platform_pr_with_settings']
                        elif stat_category == '  - PIMS Fix PR with Platform Settings':
                            row_data[project] = stats[project]['pims_fix_with_platform_settings']
                        elif stat_category == '  - PIMS Fix PR':
                            row_data[project] = stats[project]['pims_fix_prs']
                        elif stat_category == 'CR PIMS':
                            row_data[project] = stats[project]['cr_pims']
                        elif stat_category == '  - Common PR':
                            row_data[project] = stats[project]['cr_pims_common']
                        elif stat_category == '  - Modualrity Platform Common':
                            row_data[project] = stats[project]['cr_pims_modular']
                        elif stat_category == '  - Platform PR':
                            row_data[project] = stats[project]['cr_pims_platform']
                
                summary_data.append(row_data)
            
            summary_df = pd.DataFrame(summary_data)
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
            
            # Create detailed project sheets
            self.create_project_sheets(writer, stats)
            
        # Excel report created (charts disabled as requested)
        # self.create_charts(summary_df, output_file)
        
    def create_project_sheets(self, writer, stats):
        """Create detailed sheets for each project"""
        
        def filter_project_prs(project_path, project_name):
            """Filter PRs for a specific project using data source logic"""
            project_prs_list = []
            
            for _, row in self.filtered_data.iterrows():
                # Skip multi-project PRs unless this is the leading project
                if row.get('is_multi_project', False) and project_name != self.leading_project:
                    continue
                
                # Choose the right file path column based on data source
                file_paths = None
                
                if row.get('source') == 'Bitbucket':
                    if pd.notna(row.get('pr_files')):
                        file_paths = str(row['pr_files'])
                elif row.get('source') == 'GitHub':
                    if pd.notna(row.get('filename')):
                        file_paths = str(row['filename'])
                    elif pd.notna(row.get('changes')):
                        file_paths = str(row['changes'])
                else:
                    for col in ['filename', 'pr_files', 'changes', 'file_paths']:
                        if pd.notna(row.get(col)):
                            file_paths = str(row[col])
                            break
                
                if file_paths and file_paths != 'nan':
                    # For multi-project PRs, if this is leading project, include them
                    if row.get('is_multi_project', False) and project_name == self.leading_project:
                        # Check if any path contains any target project path
                        target_paths = [
                            'DellPkgs/DellPlatformPkgs/NB/SlatePtlOnePkg',
                            'DellPkgs/DellPlatformPkgs/NB/BladePtlOnePkg', 
                            'DellPkgs/DellPlatformPkgs/NB/CongoWclOnePkg'
                        ]
                        if any(target_path in file_paths for target_path in target_paths):
                            project_prs_list.append(row)
                    else:
                        # Single project PRs - check if path contains the target project path
                        if project_path in file_paths:
                            project_prs_list.append(row)
            
            return pd.DataFrame(project_prs_list)
        
        for project in self.target_projects:
            # Determine the target path for this project
            if project == 'SlatePtl':
                target_path = 'DellPkgs/DellPlatformPkgs/NB/SlatePtlOnePkg'
            elif project == 'BladePtl':
                target_path = 'DellPkgs/DellPlatformPkgs/NB/BladePtlOnePkg'
            elif project == 'CongoWcl':
                target_path = 'DellPkgs/DellPlatformPkgs/NB/CongoWclOnePkg'
            else:
                continue
            
            # Filter PRs for this specific project
            project_prs = filter_project_prs(target_path, project)
            
            if project_prs.empty:
                continue
            
            # Add classification columns at the front with proper naming
            project_prs.insert(0, 'Common PR', project_prs['is_common_pr'].apply(lambda x: 'X' if x else ''))
            project_prs.insert(1, 'Platform PR', project_prs.apply(lambda row: 'X' if not row['is_common_pr'] and not row['is_multi_project'] else '', axis=1))
            project_prs.insert(2, 'Platform Setting', project_prs['is_platform_setting'].apply(lambda x: 'X' if x else ''))
            
            # PIMS Fix: Exclude CR PIMS (if CR PIMS is checked, PIMS Fix should not be checked)
            project_prs.insert(3, 'PIMS Fix', 
                             project_prs.apply(lambda row: 'X' if row['is_pims_fix'] and not row['is_cr_pims'] else '', axis=1))
            
            project_prs.insert(4, 'PIMS with Platform Setting', 
                             project_prs.apply(lambda row: 'X' if row['is_platform_setting'] and row['is_pims_fix'] and not row['is_cr_pims'] else '', axis=1))
            project_prs.insert(5, 'CR PIMS', 
                             project_prs['is_cr_pims'].apply(lambda x: 'X' if x else ''))
            project_prs.insert(6, 'Modular Platform Common', 
                             project_prs['is_multi_project'].apply(lambda x: 'X' if x else ''))
            
            # Reorder columns to put important ones first
            important_cols = ['Common PR', 'Platform PR', 'Platform Setting', 'PIMS Fix', 'PIMS with Platform Setting', 'CR PIMS', 'Modular Platform Common',
                           'prid', 'title', 'pr_title', 'pr_summary', 'description',
                           'projectname', 'project', 'pr_state', 'state', 'filename', 'pr_files', 'changes']
            
            # Get available important columns
            available_cols = [col for col in important_cols if col in project_prs.columns]
            
            # Get remaining columns
            remaining_cols = [col for col in project_prs.columns if col not in available_cols]
            
            # Reorder DataFrame
            project_prs = project_prs[available_cols + remaining_cols]
            
            # Write to Excel sheet
            project_prs.to_excel(writer, sheet_name=project, index=False)
            
            print(f"Created {project} sheet with {len(project_prs)} PRs")
        
    def create_charts(self, summary_df, excel_file):
        """Create and save charts"""
        plt.style.use('seaborn-v0_8')
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('PR Analysis Dashboard', fontsize=16, fontweight='bold')
        
        # Chart 1: Total Platform PRs by Project
        axes[0, 0].bar(summary_df['Project'], summary_df['Total Platform PRs'], color='#1f77b4')
        axes[0, 0].set_title('Total Platform PRs by Project')
        axes[0, 0].set_ylabel('Number of PRs')
        
        # Chart 2: Platform Setting Only PRs
        axes[0, 1].bar(summary_df['Project'], summary_df['Platform Setting Only PRs'], color='#ff7f0e')
        axes[0, 1].set_title('Platform Setting Only PRs')
        axes[0, 1].set_ylabel('Number of PRs')
        
        # Chart 3: PIMS Fix PRs
        axes[1, 0].bar(summary_df['Project'], summary_df['PIMS Fix PRs'], color='#2ca02c')
        axes[1, 0].set_title('PIMS Fix PRs')
        axes[1, 0].set_ylabel('Number of PRs')
        
        # Chart 4: Stacked breakdown
        categories = ['Platform Setting Only PRs', 'PIMS Fix PRs', 'PIMS with Platform Setting PRs']
        bottom = np.zeros(len(summary_df))
        colors = ['#ff7f0e', '#2ca02c', '#d62728']
        
        for i, (cat, color) in enumerate(zip(categories, colors)):
            values = summary_df[cat].values
            axes[1, 1].bar(summary_df['Project'], values, bottom=bottom, 
                          label=cat, color=color, alpha=0.8)
            bottom += values
            
        axes[1, 1].set_title('PR Categories Breakdown')
        axes[1, 1].set_ylabel('Number of PRs')
        axes[1, 1].legend()
        
        plt.tight_layout()
        chart_file = excel_file.replace('.xlsx', '_charts.png')
        plt.savefig(chart_file, dpi=300, bbox_inches='tight')
        plt.show()
        
        print(f"Charts saved to {chart_file}")
        
    def analyze(self, bitbucket_file=None, github_file=None, output_file='CBDCIT_PR_Analysis.xlsx'):
        """Main analysis pipeline"""
        print("Starting CBDCIT PR Analysis...")
        
        # Load data
        if not self.load_data(bitbucket_file, github_file):
            print("Error: Could not load data files")
            return
            
        # Filter for target projects
        filtered_data = self.filter_target_projects()
        if filtered_data is None:
            return
            
        # Classify PRs
        filtered_data = self.classify_pr_type(filtered_data)
        filtered_data = self.identify_platform_settings(filtered_data)
        filtered_data = self.identify_pims_fixes(filtered_data)
        filtered_data = self.identify_cr_pims(filtered_data)
        filtered_data = self.identify_multi_project_prs(filtered_data)
        filtered_data = self.identify_common_prs(filtered_data)
        
        # Generate statistics
        stats = self.generate_statistics(filtered_data)
        
        # Create Excel report
        self.create_excel_report(stats, output_file)
        
        print(f"\nAnalysis complete! Results saved to {output_file}")
        print("\nSummary Statistics:")
        for project, data in stats.items():
            print(f"\n{project}:")
            print(f"  Total PR: {data['total_prs']}")
            print(f"  Common PR: {data['common_prs']}")
            print(f"  Platform PR: {data['total_platform_prs']}")
            print(f"    - Modular Platform Common: {data['modular_platform_common']}")
            print(f"    - Platform Unique PR: {data['platform_unique_prs']}")
            print(f"  Platform PR Sorting (w/o CR PIMS):")
            print(f"    - With Settings Only: {data['platform_pr_with_settings']}")
            print(f"    - PIMS Fix PR with Platform Settings: {data['pims_fix_with_platform_settings']}")
            print(f"    - PIMS Fix PR: {data['pims_fix_prs']}")
            print(f"  CR PIMS: {data['cr_pims']}")
            print(f"    - Common PR: {data['cr_pims_common']}")
            print(f"    - Modular Platform Common: {data['cr_pims_modular']}")
            print(f"    - Platform PR: {data['cr_pims_platform']}")

if __name__ == "__main__":
    analyzer = CBDCITPRAnalyzer()
    
    # Example usage - replace with actual file paths
    analyzer.analyze(
        bitbucket_file="bitbucket_pr_data.csv",
        github_file="github_pr_data.csv", 
        output_file="CBDCIT_PR_Analysis.xlsx"
    )
