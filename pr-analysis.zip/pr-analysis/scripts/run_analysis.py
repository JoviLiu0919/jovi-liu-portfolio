#!/usr/bin/env python3
"""
PR Analysis Runner Script
Simple script to run PR analysis with default configuration
"""

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from pr_analyzer import CBDCITPRAnalyzer
import toml

def load_config():
    """Load configuration from config.toml"""
    config_path = Path(__file__).parent.parent / "config.toml"
    if config_path.exists():
        with open(config_path, 'r') as f:
            return toml.load(f)
    return {}

def main():
    """Main analysis runner"""
    print("Starting PR Analysis...")
    
    # Load configuration
    config = load_config()
    
    # Initialize analyzer
    analyzer = CBDCITPRAnalyzer()
    
    # Update analyzer with config values
    if 'analysis_criteria' in config:
        criteria = config['analysis_criteria']
        analyzer.target_projects = criteria.get('target_projects', ['SlatePtl', 'BladePtl', 'CongoWcl'])
        analyzer.platform_paths = criteria.get('platform_paths', [])
        analyzer.platform_setting_extensions = set(criteria.get('platform_setting_extensions', ['.h', '.dsc', '.dec']))
        analyzer.pims_keywords = criteria.get('pims_keywords', ['PIMS', 'CPSE'])
    
    # Set file paths
    input_dir = Path(__file__).parent.parent / "input_data"
    output_dir = Path(__file__).parent.parent / "output"
    output_dir.mkdir(exist_ok=True)
    
    bitbucket_file = input_dir / "bitbucket_data.csv"
    github_file = input_dir / "github_data.csv"
    output_file = output_dir / "PR_Analysis.xlsx"
    
    # Run analysis
    try:
        success = analyzer.analyze(
            bitbucket_file=str(bitbucket_file),
            github_file=str(github_file),
            output_file=str(output_file)
        )
        
        if success:
            print(f"Analysis completed successfully!")
            print(f"Output saved to: {output_file}")
        else:
            print("Analysis failed. Check input data and configuration.")
            
    except Exception as e:
        print(f"Error during analysis: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
