#!/usr/bin/env python3
"""
CBDCIT PR Analysis - Production Environment
Execute complete CBDCIT PR analysis, using real Confluence data
"""

import sys
import os
from pathlib import Path
from datetime import datetime

# Add scripts directory to Python path
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

try:
    from pr_analyzer import CBDCITPRAnalyzer
except ImportError:
    print("ERROR: Cannot import pr_analyzer module")
    sys.exit(1)

def main():
    """Main execution function"""
    print("=" * 60)
    print("PR Analysis - Production Environment")
    print("=" * 60)
    print(f"Execution time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Initialize analyzer
    analyzer = CBDCITPRAnalyzer()
    
    # Set file paths
    base_dir = Path(__file__).parent.parent
    
    # Input file paths (need to be provided by user)
    bitbucket_file = base_dir / "input_data" / "bitbucket_pr_data.csv"
    github_file = base_dir / "input_data" / "github_pr_data.csv"
    
    # If default files don't exist, try the latest timestamped files
    if not bitbucket_file.exists():
        input_dir = base_dir / "input_data"
        bitbucket_files = list(input_dir.glob("bitbucket_pr_data_*.csv"))
        if bitbucket_files:
            bitbucket_file = max(bitbucket_files, key=lambda x: x.stat().st_mtime)
    
    if not github_file.exists():
        input_dir = base_dir / "input_data"
        github_files = list(input_dir.glob("github_pr_data_*.csv"))
        if github_files:
            github_file = max(github_files, key=lambda x: x.stat().st_mtime)
    
    # Output file path with target projects
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    target_projects_str = '_'.join(analyzer.target_projects)
    output_file = base_dir / "output" / f"PR_Analysis_{target_projects_str}_{timestamp}.xlsx"
    
    # Ensure directories exist
    bitbucket_file.parent.mkdir(exist_ok=True)
    github_file.parent.mkdir(exist_ok=True)
    output_file.parent.mkdir(exist_ok=True)
    
    print("Analysis Configuration:")
    print(f"   Bitbucket data: {bitbucket_file}")
    print(f"   GitHub data: {github_file}")
    print(f"   Output file: {output_file}")
    print()
    
    # Check if input files exist
    missing_files = []
    if not bitbucket_file.exists():
        missing_files.append(str(bitbucket_file))
    if not github_file.exists():
        missing_files.append(str(github_file))
    
    if missing_files:
        print("ERROR: Missing input files:")
        for file in missing_files:
            print(f"   - {file}")
        print()
        print("Please follow these steps to prepare data:")
        print("   1. Access Bitbucket PR data:")
        print("      https://confluence.cpg.dell.com/spaces/~jacky_lin3/pages/906697122/RawData+AgS_2025-Main_PRList")
        print("   2. Access GitHub PR data:")
        print("      https://confluence.cpg.dell.com/spaces/~jacky_lin3/pages/1075817038/RawData+Github_AgS_2025-Main_PRList")
        print("   3. Export both pages as CSV files")
        print("   4. Place files in input_data directory")
        print()
        return False
    
    # Execute analysis
    print("Starting CBDCIT PR Analysis...")
    print()
    
    try:
        analyzer.analyze(
            bitbucket_file=str(bitbucket_file),
            github_file=str(github_file),
            output_file=str(output_file)
        )
        
        print()
        print("SUCCESS: Analysis completed!")
        print(f"Results saved to: {output_file}")
        print(f"Charts saved to: {output_file.with_suffix('.png')}")
        print()
        
        # Display file info
        if output_file.exists():
            file_size = output_file.stat().st_size
            print(f"Excel file size: {file_size:,} bytes")
        
        chart_file = output_file.with_suffix('.png')
        if chart_file.exists():
            chart_size = chart_file.stat().st_size
            print(f"Chart file size: {chart_size:,} bytes")
        
        print()
        print("Analysis objectives achieved:")
        print("   X Filtered SlatePtl, BladePtl, CongoWcl project PRs")
        print("   X Classified Platform vs Common PRs")
        print("   X Identified Platform Setting PRs")
        print("   X Detected PIMS Fix PRs")
        print("   X Generated beautiful Excel charts")
        print()
        
        return True
        
    except Exception as e:
        print(f"ERROR: Analysis execution failed: {e}")
        print()
        print("Troubleshooting suggestions:")
        print("   1. Check CSV file format is correct")
        print("   2. Confirm files contain required columns (title, description, file_paths)")
        print("   3. Check files contain expected project data")
        print()
        return False

def show_analysis_criteria():
    """Display analysis criteria"""
    print("PR Analysis Criteria:")
    print("=" * 40)
    print()
    print("Target Projects:")
    print("   - SlatePtl")
    print("   - BladePtl") 
    print("   - CongoWcl")
    print()
    print("Platform PR Paths:")
    for path in ['DellPkgs\\DellPlatformPkgs\\NB', 'DellPkgs\\DellPlatformPkgs\\DT', 'DellPkgs\\DellPlatformPkgs\\PW']:
        print(f"   - {path}")
    print()
    print("Platform Setting Files:")
    print("   - .h (Header files)")
    print("   - .dsc (Description files)")
    print("   - .dec (Declaration files)")
    print("   - .png (Image files)")
    print("   - .jpg (Image files)")
    print()
    print("PIMS Fix Keywords:")
    print("   - PIMS")
    print("   - CPSE")
    print("   - ticket")
    print()
    print("Output Statistics:")
    print("   1. Total Platform PRs per project")
    print("   2. Platform Setting Only PRs")
    print("   3. PIMS Fix Platform PRs")
    print("   4. PIMS Fix + Platform Setting PRs")
    print()

if __name__ == "__main__":
    # Display analysis criteria
    show_analysis_criteria()
    
    # Execute main analysis
    success = main()
    
    if success:
        print("SUCCESS: PR Analysis completed!")
    else:
        print("Please prepare input data and re-run")
        sys.exit(1)
