---
name: nudd-confluence-workflow
description: Integration of Confluence and JIRA to download NUDD Architecture Documents
---

# NUDD Confluence Workflow

Complete workflow for integrating Confluence and JIRA to download NUDD Architecture Documents.

## 🎯 Progress Visibility

**This workflow provides complete real-time progress tracking:**
- ✅ **Total PBA tickets found and processed**
- ✅ **Individual ticket processing progress (1/91, 2/91, etc.)**
- ✅ **Architecture documents discovered per ticket**
- ✅ **Files downloaded count**
- ✅ **Processing percentage and completion status**

## Overview

This workflow automates the complete process of extracting NUDD data from Confluence pages and downloading related Architecture Documents.

## Workflow Steps

### 1. Get Confluence Page
- **Skill**: `confluence-integration`
- **Command**: `get`
- **Parameters**: 
  - `id`: "1125476618" (Default NUDD page ID)
- **Progress Display**: 
  ```
  🔍 Starting NUDD Confluence Workflow...
  📄 Fetching Confluence page: 1125476618
  ✅ Confluence page retrieved successfully
  ```
- **Output**: JSON format page content

### 2. Parse PBA Tickets
- **Skill**: `builtin` (Built-in parsing functionality)
- **Command**: `parse_pba_tickets`
- **Parameters**:
  - `source`: From step 1 output
  - `pattern`: "PBA-\\d+" (PBA ticket format)
- **Progress Display**: 
  ```
  🔍 Extracting PBA tickets from Confluence content...
  📋 Found [NUMBER] PBA tickets to process
  📊 Processing scope: [NUMBER] total tickets
  ```
- **Output**: PBA tickets list

### 3. Download Architecture Documents
- **Skill**: `jira-integration`
- **Command**: `nudd-download`
- **Parameters**:
  - `confluence_page_id`: From step 1 (for auto-detection)
  - `base_dir`: "NUDD" (Download directory)
  - `save_report`: true (Generate report)
- **Progress Display**: 
  ```
  🔍 Analyzing Confluence page [PAGE_ID] for filter...
  ✅ Found filter [FILTER_ID] ([TYPE]) from Confluence page '[TITLE]'
  🚀 Starting NUDD Architecture Document Downloader
  ============================================================
  [1/91] Processing PBA-4427...
  📁 Found 4 Architecture Documents
  [2/91] Processing PBA-5577...
  📁 Found 8 Architecture Documents
  ...
  ✅ Completed: 91/91 tickets processed
  ```
- **Error Handling**:
  ```
  ❌ Failed to analyze Confluence page: [ERROR]
  Confluence page analysis failed - possible causes:
     - Page ID [PAGE_ID] may not exist
     - Page may not contain JIRA filter information
     - Confluence configuration may be incorrect
  
  💡 Suggestions:
     1. Use manual filter: --filter <filter_id>
     2. Try a different Confluence page ID
     3. Check Confluence configuration
  
  ❌ Aborting due to Confluence page analysis failure.
  ```
- **Output**: Download results and statistics

## Input Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `confluence_page_id` | string | "1125476618" | Confluence page ID (see Available Pages below) |
| `base_directory` | string | "NUDD" | Download directory |
| `save_report` | boolean | true | Whether to generate report |

### Available Confluence Pages
| Page ID | Description | Filter ID | Quarter |
|---------|-------------|-----------|---------|
| 791554665 | 26QX x86 NUDDs Projects | 131015 | 26Q1-26Q3 |
| 591345589 | 25Q1 NUDDs Projects | 73485 | 25Q1 |
| 1125476618 | 27QX x86 NUDDs Projects | 139839 | 26Q4-27Q1 |

## Output Results

- `pba_tickets`: Extracted PBA tickets list
- `downloaded_files`: Downloaded files statistics
- `report_path`: Generated report file path

## Usage Examples

### Standard Execution with Progress Display
```bash
/nudd-confluence-workflow
```

**Expected Output Flow:**
```
🔍 Starting NUDD Confluence Workflow...
📄 Fetching Confluence page: 1125476618
✅ Confluence page retrieved successfully

🔍 Extracting PBA tickets from Confluence content...
📋 Found 91 PBA tickets to process
📊 Processing scope: 91 total tickets

🚀 Starting NUDD Architecture Document Downloader
============================================================
[1/91] Processing PBA-4427...
📁 Found 4 Architecture Documents
[2/91] Processing PBA-5577...
📁 Found 8 Architecture Documents
...
✅ Completed: 91/91 tickets processed

📊 Final Statistics:
- Total tickets processed: 91
- Tickets with Architecture Documents: 58 (63.7%)
- Total files downloaded: 147
- Report saved to: .windsurf/Reports/nudd_architecture_documents_download_2026-02-24_15-03-04.md
```

### Custom Page - 26QX Projects
```bash
/nudd-confluence-workflow --page-id 791554665
```

### Custom Page - 25Q1 Projects
```bash
/nudd-confluence-workflow --page-id 591345589
```

### Custom Directory
```bash
/nudd-confluence-workflow --base-dir CUSTOM_NUDD
```

## Progress Tracking

The workflow provides real-time progress updates:

### 📊 Processing Statistics
- **Total PBA Tickets Found**: [Displayed during execution]
- **Tickets Processed**: [Updated in real-time]
- **Tickets with Architecture Documents**: [Counted during processing]
- **Files Downloaded**: [Accumulated during processing]

### 🔄 Progress Indicators
```
🔍 Extracting PBA tickets from Confluence...
📋 Found X PBA tickets to process
⏳ Processing ticket 1/X: PBA-XXXX...
📁 Downloading Architecture Documents...
✅ Completed: Y/X tickets processed
📊 Final Statistics: X total, Y with docs, Z files downloaded
```

## Error Handling

- Retry count: 3 times
- Timeout: 300 seconds
- Stop on error: false (Continue processing other steps)

## Dependencies

- `confluence-integration`: Get Confluence pages
- `jira-integration`: Download Architecture Documents

## Setup

1. **Install Dependencies** (One-time):
   ```powershell
   cd .windsurf/skills/confluence-integration && .\scripts\setup_env.ps1
   cd .windsurf/skills/jira-integration && .\scripts\setup_env.ps1
   ```

2. **Configuration**:
   - Ensure `confluence-integration` and `jira-integration` are properly configured
   - Check related `config.toml` files

## Compliance with skill_guides

This workflow follows all guidelines specified in `.windsurf/skills/skill_guides/SKILL.md`:
- **Core Integration Architecture**: Uses confluence-integration and jira-integration for data access
- **Zero-Temp-File Policy**: All processing done in memory
- **Report Generation Standards**: Saves bilingual reports to `.windsurf/Reports/`
- **Cross-Session Consistency**: Ensures consistent behavior across sessions

## Interaction Rules (Agent Instructions)

* **Validation First**: Always validate Confluence page ID and JIRA access before execution
* **Progress Display**: **CRITICAL** - Show real-time progress statistics during execution:
  - Always display "🔍 Starting NUDD Confluence Workflow..."
  - Always show Confluence page fetch status
  - Always display "📋 Found X PBA tickets to process"
  - Always show "📊 Processing scope: X total tickets"
  - Never suppress the built-in progress output from jira-integration nudd-download
* **Confirmation**: Before downloading large amounts of data, outline the scope to the user
* **Error Handling**: Provide clear error messages and suggestions for resolution
* **Progress Updates**: Keep user informed of workflow progress with specific counts and percentages

## Agent Execution Guidelines

### MANDATORY Progress Display Requirements:

1. **Always Show These Messages:**
   ```
   🔍 Starting NUDD Confluence Workflow...
   📄 Fetching Confluence page: [PAGE_ID]
   ✅ Confluence page retrieved successfully
   🔍 Extracting PBA tickets from Confluence content...
   📋 Found [NUMBER] PBA tickets to process
   📊 Processing scope: [NUMBER] total tickets
   ```

2. **Never Suppress Built-in Progress:**
   - Do NOT add --quiet or --silent flags to jira-integration commands
   - Let the nudd-download command show its natural progress: `[1/91] Processing PBA-XXXX...`
   - Allow all file download progress messages to be displayed

3. **Final Summary Requirements:**
   ```
   📊 Final Statistics:
   - Total tickets processed: [NUMBER]
   - Tickets with Architecture Documents: [NUMBER] ([PERCENTAGE]%)
   - Total files downloaded: [NUMBER]
   - Report saved to: [REPORT_PATH]
   ```

### What NOT to Do:
- ❌ Do NOT summarize or shorten the progress output
- ❌ Do NOT suppress the individual ticket processing messages
- ❌ Do NOT skip the intermediate progress updates
- ❌ Do NOT show only the final summary without the processing flow

## Enhanced Workflow Execution

### Step-by-Step Progress Flow:

1. **Initial Assessment**:
   ```
   🔍 Starting NUDD Confluence Workflow...
   📄 Fetching Confluence page: 1125476618
   ```

2. **PBA Ticket Extraction**:
   ```
   🔍 Extracting PBA tickets from Confluence content...
   📋 Found 91 PBA tickets to process
   📊 Processing scope: 91 total tickets
   ```

3. **Processing Progress**:
   ```
   ⏳ Processing PBA tickets (1/91): PBA-4427...
   📁 Found 4 Architecture Documents
   ⏳ Processing PBA tickets (2/91): PBA-5577...
   📁 Found 8 Architecture Documents
   ...
   ✅ Completed: 91/91 tickets processed
   ```

4. **Final Summary**:
   ```
   📊 Final Statistics:
   - Total tickets processed: 91
   - Tickets with Architecture Documents: 22 (24.2%)
   - Total files downloaded: 70
   - Report saved to: .windsurf/Reports/nudd_architecture_documents_download_2026-02-23_19-09-11.md
   ```
