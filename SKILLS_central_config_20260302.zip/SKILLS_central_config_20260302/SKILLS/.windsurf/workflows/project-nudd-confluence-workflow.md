---
name: project-nudd-confluence-workflow
description: Integration of Confluence and JIRA to download project NUDD Architecture Documents
---

# Project NUDD Confluence Workflow

This workflow provides a comprehensive method to extract and analyze all NUDD (New Unit Development Document) tables from a Confluence page, execute their JQL queries, and compile a complete list of PBA tickets.

## Prerequisites

- Access to Confluence page with NUDD tables
- JIRA integration configured
- Python environment with required dependencies

## Workflow Steps

### 1. Read Confluence Page Content

```bash
# Navigate to confluence-integration skill
cd .windsurf/skills/confluence-integration

# Method A: Using Page ID (Recommended)
python scripts/confluence_tool.py get --id <PAGE_ID>

# Method B: Extract body content directly
python scripts/confluence_tool.py get --id <PAGE_ID> | python -c "import sys, json; data = json.load(sys.stdin); print(data['body']['storage']['value'])"

# Method C: Verify page retrieval with metadata
python scripts/confluence_tool.py get --id <PAGE_ID> | python -c "import sys, json; data = json.load(sys.stdin); print(f'Page: {data.get(\"title\", \"Unknown\")}'); print(f'Page ID: {data.get(\"id\", \"Unknown\")}'); print(f'Content Length: {len(data[\"body\"][\"storage\"][\"value\"])} characters'); print('Status: Successfully retrieved')"
```

**URL to Page ID Extraction**:
The confluence-integration skill automatically handles URL parsing and page ID extraction from various Confluence URL formats. Users can provide any of the supported URL formats and the skill will extract the correct page ID for processing.

**Purpose**: Retrieve the complete HTML content of the Confluence page including all JIRA macros and their JQL queries using the confluence-integration skill.

**Key Benefits**:
- **Reliable**: Uses tested confluence-integration skill with proper authentication
- **Complete**: Retrieves full page content with all macros and formatting
- **Flexible**: Handles various URL formats automatically
- **Structured**: Returns JSON with metadata and body content
- **Integrated**: Works seamlessly with other Confluence operations

### 2. Identify NUDD Tables and Ticket Sources

```bash
# Method A: Using integrated confluence_nudd script (Recommended)
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py get --id <PAGE_ID> | python scripts/confluence_nudd.py

# Method B: Save analysis results to file
python scripts/confluence_tool.py get --id <PAGE_ID> | python scripts/confluence_nudd.py > ../../../nudd_analysis.txt

# Method C: Using confluence_nudd directly (if config available)
python scripts/confluence_nudd.py analyze --id <PAGE_ID> --output ../../../results.json
```

**Purpose**: 
- Find all NUDD-related content (not just headings ending with "NUDDs")
- Extract JIRA macros under NUDD-related sections
- Parse JQL queries and filter IDs
- **IMPORTANT**: Identify ticket extraction method (JQL vs Direct Table)
- **CRITICAL**: Filter out "Is/Is Not" tables (these are analysis frameworks, not actual NUDD tables)

**Key Patterns**: 
- Headings ending with "NUDDs" (e.g., "Selected NVL Chipset NUDDs", "27Q1 Common NUDDs")
- **NEW**: Headings containing "NUDD" anywhere in the text
- **NEW**: Content sections discussing NUDD development, changes, or requirements
- **EXCLUDE**: "Is/Is Not" tables (these are requirement analysis frameworks)

**Ticket Source Types**:
1. **JIRA Macro with JQL**: Tickets retrieved via JQL queries
2. **Direct HTML Table**: Tickets listed directly in table cells
3. **Mixed**: Both JIRA macros and direct table content
4. **Is/Is Not Tables**: **EXCLUDE** - These are analysis frameworks, not actual ticket lists
5. **History Tables**: **EXCLUDE** - These contain historical ticket references, not current NUDDs

### 3. Extract Tickets (Multiple Methods)

#### Method A: JQL Query Extraction
For JIRA macros with JQL queries:

```bash
# Using enhanced confluence_nudd.py script
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py get --id <PAGE_ID> | python scripts/confluence_nudd.py extract

# Or use extract command directly (if config available)
python scripts/confluence_nudd.py extract --id <PAGE_ID> --output ../../../tickets.json --jql --tables
```

#### Method B: Direct HTML Table Extraction
For tickets listed directly in table cells:

```bash
# The confluence_nudd.py script automatically handles both methods
python scripts/confluence_tool.py get --id <PAGE_ID> | python scripts/confluence_nudd.py extract --jql --tables > ../../../nudd_analysis.txt
```

**Expected Output**:
- `tickets.json` - Complete ticket extraction results (workspace root)
- `nudd_analysis.txt` - Analysis summary (workspace root)

### 4. Execute JQL Queries and Retrieve Tickets

#### For JQL-based NUDD tables:

```bash
# Execute each JQL query to get actual tickets using integrated confluence_nudd.py
cd .windsurf/skills/confluence-integration

# Method A: Extract and execute in one step
python scripts/confluence_tool.py get --id <PAGE_ID> | python scripts/confluence_nudd.py execute --jql --output ../../../tickets_executed.json

# Method B: Use existing extraction results
python scripts/confluence_nudd.py execute --id <PAGE_ID> --output ../../../tickets_executed.json

# Method C: Manual execution with jira-integration skill (for complex queries)
cd ../jira-integration
python scripts/jira_tool.py batch-search --jql "<JQL_QUERY>" --limit 200
python scripts/jira_tool.py batch-search --jql "filter=<FILTER_ID>" --limit 200
```

### 5. Download Architecture Documents

#### Using enhanced confluence_nudd.py with integrated batch processing:

```bash
# Navigate to confluence-integration skill
cd .windsurf/skills/confluence-integration

# Method A: Download Architecture Documents from Step 4 results (Recommended)
python scripts/confluence_nudd.py download-adfd --input ../../../tickets_executed.json --output ../../../NUDD_<PAGE_ID>

# Method B: Download with limit for testing
python scripts/confluence_nudd.py download-adfd --input ../../../tickets_executed.json --output ../../../NUDD_<PAGE_ID>_test --limit 5

# Method C: Complete workflow (extract + execute + download)
python scripts/confluence_tool.py get --id <PAGE_ID> | python scripts/confluence_nudd.py execute --output ../../../tickets_executed.json
python scripts/confluence_nudd.py download-adfd --input ../../../tickets_executed.json --output ../../../NUDD_<PAGE_ID>
```

**Key Features**:
- **Integrated Processing**: Uses confluence_nudd.py with built-in batch processing
- **Step 4 Data Flow**: Directly uses tickets_executed.json from Step 4
- **Encoding Support**: Automatic UTF-8 encoding handling
- **Progress Tracking**: Real-time progress display and statistics
- **Error Handling**: Continues processing if individual tickets fail
- **Testing Support**: --limit parameter for testing with subset of tickets

**Progress Display**: 
```
Starting batch processing of 71 tickets
============================================================
[1/71] Processing PBA-2572...
  Success: PBA-2572
  Found 3 Architecture Documents
[2/71] Processing PBA-2902...
  Success: PBA-2902
  Found 8 Architecture Documents
[3/71] Processing PBA-321...
  Success: PBA-321
  Found 11 Architecture Documents
...
Progress: 10/71 processed
   Successful: 10
   Failed: 0
   Files downloaded: 47

============================================================
Final Statistics:
- Total tickets processed: 71
- Tickets with Architecture Documents: 58 (81.7%)
- Total files downloaded: 147
- Report saved to: C:\BEA\LLM\Skills\NUDD_986421218/
```

**Error Handling**:
```
❌ Failed to analyze Confluence page: [ERROR]
Confluence page analysis failed - possible causes:
   - Page ID [PAGE_ID] may not exist
   - Page may not contain JIRA filter information
   - Confluence configuration may be incorrect

💡 Suggestions:
   1. Use manual filter: --filter <filter_id>
   2. Try a different Confluence page ID
   3. Check Confluence configuration

❌ Aborting due to Confluence page analysis failure.
```

**Output**: Download results and statistics

### 6. Generate Comprehensive Report

#### Report is automatically generated by jira-integration nudd-download:

The `--save-report` parameter automatically generates a comprehensive report saved to `.windsurf/Reports/` with timestamp.

**Report Location**: `.windsurf/Reports/nudd_architecture_documents_download_YYYY-MM-DD_HH-MM-SS.md`

**Report Structure**:
```markdown
# NUDD Architecture Documents Download Report

## Executive Summary
- **Total tickets processed**: 91
- **Tickets with Architecture Documents**: 58 (63.7%)
- **Total files downloaded**: 147
- **Download success rate**: 100%

## Processing Statistics
- **Confluence page analyzed**: [PAGE_ID] - [Page Title]
- **Filter detected**: [FILTER_ID] ([Filter Type])
- **Processing duration**: [Time elapsed]

## Download Results by Ticket
### PBA-4427: [Ticket Summary]
- **Architecture Documents**: 4
- **Files Downloaded**: [List of files]
- **Status**: ✅ Success

### PBA-5577: [Ticket Summary]
- **Architecture Documents**: 8
- **Files Downloaded**: [List of files]
- **Status**: ✅ Success

## Final Statistics
- **Total tickets processed**: 91
- **Tickets with Architecture Documents**: 58 (63.7%)
- **Total files downloaded**: 147
- **Report saved to**: .windsurf/Reports/nudd_architecture_documents_download_2026-02-24_15-03-04.md
```

**Complete Workflow Steps**:
1. ✅ **Page Retrieval**: Get Confluence page content
2. ✅ **NUDD Analysis**: Identify sections and JQL queries  
3. ✅ **Ticket Extraction**: Extract JQL and table tickets
4. ✅ **JQL Execution**: Run queries to get actual tickets
5. ✅ **Architecture Document Download**: Download all documents using jira-integration
6. ✅ **Report Generation**: Automatic comprehensive report generation

**Complete Workflow Command**:
```bash
# Full workflow using integrated confluence_nudd.py processing
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py get --id <PAGE_ID> | python scripts/confluence_nudd.py execute --output ../../../tickets_executed.json
python scripts/confluence_nudd.py download-adfd --input ../../../tickets_executed.json --output ../../../NUDD_<PAGE_ID>

# For testing with limited tickets:
python scripts/confluence_nudd.py download-adfd --input ../../../tickets_executed.json --output ../../../NUDD_<PAGE_ID>_test --limit 5
```

**Key Features for Architecture Document Retrieval**:
- **Integrated Processing**: Uses confluence_nudd.py with built-in batch processing
- **Step 4 Data Flow**: Directly uses tickets_executed.json from Step 4 execution
- **Encoding Support**: Automatic UTF-8 encoding handling for Windows compatibility
- **Progress Tracking**: Real-time display of processing progress and statistics
- **Comprehensive Download**: Downloads all Architecture Documents from each ticket
- **Error Handling**: Continues processing if individual tickets fail
- **Testing Support**: --limit parameter for testing with subset of tickets
- **File Organization**: Organizes downloads by ticket with meaningful names
- **Statistics Tracking**: Provides detailed download statistics and success rates

**Output Includes**:
- Detailed breakdown by NUDD table
- Complete alphabetical list of all tickets
- Statistics and summary counts
- JQL verification and comparison
- **NEW**: Ticket source analysis (JQL vs Direct Table)
- **NEW**: Architecture Document download statistics and inventory

**Architecture Document Download Process**:
1. **Confluence Analysis**: Analyze Confluence page to detect JIRA filter
2. **Filter Detection**: Automatically find filter ID and type from page
3. **Ticket Processing**: Process each PBA ticket from the filter
4. **Document Identification**: Identify Architecture Documents attached to tickets
5. **Batch Download**: Download all documents with progress tracking
6. **Report Generation**: Generate comprehensive download report

**Download Directory Structure**:
```
NUDD_<PAGE_ID>/
├── PBA-5577_Memory_Healing_2.0_(MemRx)/
│   ├── PBA-5577 MemRx 2.0 AD 0.5.docx
│   ├── PBA-5577 MemRx 2.0 AD 1.0.docx
│   ├── PBA-5577 MemRx 2.0 FD 0.5.pptx
│   └── ...
├── PBA-6324_NVL_-_Reset_Reason_Health_Record/
│   └── PBA-6324- Reset Reason Health Record FD 1.0.pptx
└── ... (additional ticket directories)
```

### 7. Verification and Validation

**Quality Checks**:
- Verify JQL extraction matches Confluence content exactly
- Cross-reference ticket counts with expected results
- Handle duplicate tickets across different NUDD tables
- Validate all PBA ticket formats
- **NEW**: Verify direct table extraction accuracy
- **NEW**: Check for mixed source tables and ensure comprehensive coverage
- **NEW**: Verify Architecture Document download completeness
- **NEW**: Validate document file formats and naming patterns
- **NEW**: Check jira-integration filter detection and processing
- **NEW**: Confirm automatic report generation and statistics

**Validation Commands**:
```bash
# Validate ticket extraction completeness
python scripts/confluence_nudd.py validate --input results.json

# Verify Architecture Document download completeness
# Check the generated report for download statistics
ls -la .windsurf/Reports/nudd_architecture_documents_download_*.md

# Check download directory structure
ls -la NUDD_<PAGE_ID>/

# Generate validation report (manual)
echo "Validation completed - see jira-integration generated report for details"
```

## Workflow Success Criteria

**Complete Success Indicators**:
- ✅ All NUDD sections identified and analyzed
- ✅ All JQL queries extracted and validated
- ✅ All tickets retrieved from both JQL and direct tables
- ✅ All Architecture Documents downloaded and organized
- ✅ Comprehensive report generated with statistics
- ✅ Validation checks passed with no critical issues

**Final Deliverables**:
- Complete ticket inventory (JSON format)
- Downloaded Architecture Documents (organized by ticket)
- Comprehensive analysis report (Markdown format - auto-generated)
- Download directory with organized file structure

## Expected Results

For a typical project page (e.g., Seine NVL BIOS POV), expect:

- **4-6 NUDD tables** (headings or JIRA macros with NUDD content)
- **40-50 unique PBA tickets** total
- **Mixed ticket sources**:
  - Some tables use JQL queries (dynamic)
  - Some tables use direct HTML tables (static)
  - Some tables use both (mixed)
- **Mixed JQL complexity**:
  - Platform-specific: Complex linked issue queries
  - Selected NUDDs: Filter-based with many exclusions
  - Common NUDDs: Simple filter queries
  - Direct tables: No JQL, just listed tickets
- **Architecture Document Download**:
  - **60+ Architecture Documents** downloaded automatically
  - **100% download success rate** for tickets with documents
  - **Organized directory structure** with ticket-specific folders
  - **Automatic report generation** with comprehensive statistics
  - **Real-time progress tracking** during download process

## Common Issues and Solutions

### Issue: Confluence API Timeouts
**Solution**: 
- Use extended timeout (180 seconds)
- Retry failed requests
- Cache page content locally

### Issue: Direct Table Parsing Challenges
**Solution**:
- Handle various HTML table structures
- Clean HTML entities and tags properly
- Support different ticket formats (PBA-XXXX, links, etc.)
- Account for merged cells and complex table layouts

### Issue: Mixed Source Table Confusion
**Solution**:
- Clearly identify and label source types
- Process JQL and direct tickets separately
- Combine results with proper deduplication
- Report source breakdown in final analysis

### Issue: History Table Detection Incomplete
**Solution**:
- Expand `is_history_table()` function to detect more historical patterns
- Add keywords: 'previous', 'legacy', 'old' in addition to 'history', 'historical', 'past'
- Improve detection sensitivity for various historical reference formats
- Ensure comprehensive exclusion of all historical content

### Issue: PBA Ticket Number Format Variability
**Solution**:
- Update ticket pattern from `PBA-\d{4,5}` to `PBA-\d{2,6}`
- Support variable digit counts (2-6 digits after PBA-)
- Handle examples like PBA-408 (3 digits), PBA-4690 (4 digits), PBA-123456 (6 digits)
- Ensure all valid PBA ticket formats are captured

### Issue: JQL Syntax Errors
**Solution**:
- Implement `validate_and_fix_jql()` function to automatically fix common syntax issues
- Fix double quotes: `"SOC Agnostic"` → `'SOC Agnostic'`
- Remove extra spaces: `Intel )` → `Intel)`
- Standardize keywords: `and` → `AND`, `Key` → `key`
- Use `execute_jql_with_validation()` for automatic retry with fixed JQL
- Log both original and fixed JQL for debugging

### Issue: Is/Is Not Table Confusion
**Solution**:
- Implement `is_is_not_table()` function to detect analysis frameworks
- Automatically exclude tables containing "Is/Is Not" patterns
- Log skipped tables for transparency
- Focus only on actual ticket listing tables

### Issue: Non-standard NUDD Table Naming
**Solution**:
- Expand pattern matching beyond just "NUDDs" endings
- Look for "NUDD" anywhere in heading text
- Include content sections discussing NUDD development
- Handle various naming conventions across different projects

### Issue: AD/FD Download Path Issues
**Solution**:
- Use absolute paths for download directory
- Handle Windows path encoding issues
- Set PYTHONIOENCODING=utf-8 environment variable
- Verify workspace root path calculations

### Issue: Unicode/Emoji Character Encoding
**Solution**:
- Set UTF-8 encoding for all subprocess calls
- Use environment variables to avoid encoding errors
- Handle emoji characters in jira-integration output
- Implement error handling for encoding issues

### Issue: Document Pattern Recognition
**Solution**:
- Use comprehensive regex patterns for AD/FD files
- Support various document formats (.docx, .pdf, .pptx)
- Include Architecture Document keyword matching
- Handle version numbering (AD 1.0, AD 0.5, etc.)

### Issue: Linked Issue Processing Complexity
**Solution**:
- Limit linked issue processing to 2 layers deep
- Implement relevance checking based on ticket summaries
- Avoid infinite loops with processed ticket tracking
- Filter for PBA tickets only in linked issues

### Issue: Complex JQL Parsing
**Solution**:
- Handle HTML entity decoding
- Preserve exact spacing and quotes
- Test JQL execution separately

### Issue: JIRA Query Timeouts
**Solution**:
- Split large queries into smaller batches
- Use filter IDs instead of complex JQL when possible
- Increase timeout limits

### Issue: Unicode Character Encoding
**Solution**:
- Use UTF-8 encoding for all files
- Replace Unicode symbols with ASCII equivalents
- Handle HTML entity decoding properly

## Output Files Generated

1. `confluence_page_<ID>_full.md` - Raw page content (workspace root)
2. `nudd_tables_reanalysis.md` - NUDD table identification with source types (workspace root)
3. `complete_ticket_list_all_nudd_tables.md` - Final ticket list with source breakdown (workspace root)
4. `final_complete_nudd_analysis_6_tables.md` - Comprehensive analysis including source analysis (workspace root)
5. `ticket_source_analysis.md` - Detailed breakdown of JQL vs Direct ticket sources (workspace root)
6. `nudd_analysis_report_<ID>_<timestamp>.md` - Markdown-formatted ticket report for documentation (workspace root)
7. **`NUDD_<PAGE_ID>/`** - **NEW**: Download directory containing all Architecture documents (workspace root)
8. **`nudd_architecture_documents_download_YYYY-MM-DD_HH-MM-SS.md`** - **NEW**: Comprehensive download report auto-generated by jira-integration (Reports directory)

**Architecture Document Download Directory Contents**:
- **Ticket-specific folders**: `PBA-XXXX_Ticket_Summary/` containing:
  - Architecture Documents: All attached documents from each ticket
  - Various file formats: .docx, .pdf, .pptx, etc.
  - Organized by ticket with meaningful folder names
- **Automatic organization**: Files grouped by ticket with clear structure

**Note**: All output files are generated in the workspace root directory (not in the skills folder) for easy access and sharing.

## Integration with Other Workflows

This workflow integrates with:
- **nudd-confluence-workflow**: Basic NUDD extraction
- **jira-integration**: For JQL execution and ticket retrieval
- **confluence-integration**: For page content access

## Success Criteria

**Complete Success Indicators**:
- ✅ All NUDD sections identified and analyzed
- ✅ All JQL queries extracted and validated
- ✅ All tickets retrieved from both JQL and direct tables
- ✅ All Architecture Documents downloaded and organized
- ✅ Comprehensive report generated with statistics
- ✅ Validation checks passed with no critical issues

**Final Deliverables**:
- Complete ticket inventory (JSON format)
- Downloaded Architecture Documents (organized by ticket)
- Comprehensive analysis report (Markdown format - auto-generated)
- Download directory with organized file structure
