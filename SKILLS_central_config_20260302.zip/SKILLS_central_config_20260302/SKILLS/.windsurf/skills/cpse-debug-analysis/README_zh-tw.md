# CPSE Debug Analysis Skill - Traditional Chinese Support

## Overview

The CPSE Debug Analysis skill now supports Traditional Chinese report generation, providing deeper analysis that better meets localization requirements.

## Language Support

### Supported Languages
- **English (en)**: Default language, traditional English technical report
- **Traditional Chinese (zh-tw)**: Complete Traditional Chinese report, including localization of all technical terms

### Usage Method

#### Generate Traditional Chinese Report
```bash
python scripts/cpse_analyzer_enhanced.py \
  --ticket CPSE-46745 \
  --codebase ../../ \
  --dell-knowledge ../dell_domain_knowledge/SKILL.md \
  --language zh-tw \
  --markdown-report
```

#### Generate English Report (Default)
```bash
python scripts/cpse_analyzer_enhanced.py \
  --ticket CPSE-46745 \
  --codebase ../../ \
  --dell-knowledge ../dell_domain_knowledge/SKILL.md \
  --language en \
  --markdown-report
```

## Traditional Chinese Report Features

### Localized Content
- **Report Title**: Uses professional terms like "Deep Analysis Report"
- **Technical Classification**: "Issue Classification", "Root Cause Analysis", etc.
- **Solutions**: "Recommended Solutions", "Implementation Steps", etc.
- **Risk Assessment**: "Risk Assessment", "Verification Strategy", etc.

### Example Output

```
# CPSE-46745 Deep Analysis Report

## Executive Summary
**Issue**: [CongoLnlOne] BIOS exe cannot be flash after enable PQC
**Platform**: CongoLnlOne (Dell Lunar Lake platform)
**Root Cause**: PQC Sign Verify Failed, because EC payload lacks public key category mapping
**Impact**: Critical - BIOS Update Failed prevents system firmware update
**Priority**: High

## Technical Analysis

### Issue Classification
- **Primary Issue Type**: PQC Sign configuration issue
- **Secondary Issue Type**: EC payload verify failed
- **Platform**: CongoLnlOne (Dell Lunar Lake platform)
- **Configuration**: PQC Support enabled
```

## Technical Terminology Comparison Table

| English Term | Traditional Chinese Translation |
|---|---|
| Executive Summary | Executive Summary |
| Root Cause | Root Cause |
| Technical Analysis | Technical Analysis |
| Issue Classification | Issue Classification |
| Solution Architecture | Solution Architecture |
| Risk Assessment | Risk Assessment |
| Verification Strategy | Verification Strategy |
| Implementation Steps | Implementation Steps |
| Dell Domain Context | Dell Domain Context |
| Critical Error Patterns | Critical Error Patterns |

## Parameter Instructions

### --language Parameter
- `en`: Generate English report (Default)
- `zh-tw`: Generate Traditional Chinese report

### Other Parameters
- `--ticket`: CPSE ticket number (required)
- `--codebase`: Codebase root directory path (required)
- `--dell-knowledge`: Dell domain knowledge documentation path (optional)
- `--markdown-report`: Generate Markdown report (enabled by default)
- `--jira-tool`: JIRA tools path (optional)

## Example Commands

### Complete Traditional Chinese Analysis
```bash
cd .windsurf/skills/cpse-debug-analysis
python scripts/cpse_analyzer_enhanced.py \
  --ticket CPSE-46745 \
  --codebase ../../ \
  --dell-knowledge ../dell_domain_knowledge/SKILL.md \
  --language zh-tw \
  --markdown-report
```

### Quick Traditional Chinese Analysis (using default paths)
```bash
cd .windsurf/skills/cpse-debug-analysis
python scripts/cpse_analyzer_enhanced.py \
  --ticket CPSE-46745 \
  --codebase ../../ \
  --language zh-tw
```

## Output Files

Reports will be saved in the temporary directory, file name format:
- English: `CPSE-{ticket_key}_Analysis_Report.md`
- Traditional Chinese: `CPSE-{ticket_key}_Analysis_Report.md` (content in Traditional Chinese)

## Notes

1. **Encoding Support**: All report files use UTF-8 encoding to ensure Traditional Chinese characters display correctly
2. **Terminology Consistency**: Technical term translations maintain consistency, following Dell internal terminology standards
3. **Format Preservation**: Traditional Chinese reports maintain the same structure and format as English reports
4. **Timezone Handling**: Timestamps remain in UTC format, unaffected by language configuration

## Troubleshooting

### Common Issues

**Q: Traditional Chinese characters display as garbled text**
A: Please ensure your editor supports UTF-8 encoding

**Q: Report title is still in English**
A: Please confirm `--language zh-tw` parameter is correctly configured

**Q: Technical term translation is inaccurate**
A: Welcome to provide term improvement suggestions, we will continuously optimize translation quality

## Version Information

- **Version**: 2.0
- **Added Features**: Traditional Chinese report support
- **Update Date**: 2026-02-04
- **Compatibility**: Supports all existing CPSE analysis functions

---
*CPSE Debug Analysis Skill - Multilingual Version*
