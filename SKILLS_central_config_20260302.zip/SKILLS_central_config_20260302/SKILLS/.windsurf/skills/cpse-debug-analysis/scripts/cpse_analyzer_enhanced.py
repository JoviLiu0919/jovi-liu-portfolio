#!/usr/bin/env python3
"""
Enhanced CPSE Debug Analysis Tool with Dell Domain Knowledge Integration

Advanced analysis tool for CPSE JIRA issues with Dell domain knowledge,
log processing, codebase correlation, and standardized Markdown reporting.
"""

import argparse
import json
import os
import re
import sys
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import tempfile
import shutil
from datetime import datetime
from enhanced_report_generator import EnhancedReportGenerator

# GitHub Integration
try:
    sys.path.append(str(Path(__file__).parent.parent.parent / 'github_integration' / 'scripts'))
    from github_tool import GitHubTool
    GITHUB_AVAILABLE = True
except ImportError:
    GITHUB_AVAILABLE = False
    print("⚠️  GitHub integration not available - github_integration skill not found")

class EnhancedCPSEAnalyzer:
    """Enhanced analyzer class with Dell domain knowledge integration"""
    
    def __init__(self, jira_tool_path: str, codebase_root: str, dell_knowledge_path: str = None, language: str = "en", github_config_path: str = None):
        self.jira_tool_path = jira_tool_path
        self.codebase_root = Path(codebase_root)
        self.dell_knowledge_path = dell_knowledge_path or ".windsurf/skills/dell-domain-knowledge/SKILL.md"
        self.temp_dir = None
        self.dell_knowledge = {}
        self.language = language  # Language setting: "en" for English, "zh-tw" for Traditional Chinese
        
        # Initialize GitHub integration
        self.github_tool = None
        if GITHUB_AVAILABLE:
            try:
                self.github_tool = GitHubTool()
                print("✅ GitHub integration initialized")
            except Exception as e:
                print(f"⚠️  Failed to initialize GitHub integration: {str(e)}")
        
        # Load Dell domain knowledge
        self._load_dell_knowledge()
        
        # Initialize enhanced report generator
        self.report_generator = EnhancedReportGenerator()
        
        # Language-specific templates
        self._init_language_templates()
        
        # Enhanced patterns with Dell context
        self.enhanced_patterns = {
            # PQC Signing Issues (Dell-specific)
            'pqckey_not_found': r'PQC Public key category not found\s+([0-9A-Fa-f-]{36})',
            'lms_verification_failed': r'LMS.*verification.*failed|VerifyPayloadWithPqcSignature.*returning FALSE',
            'key_category_mismatch': r'540B32B0-808D-47E1-A188-76AA7CF1BB93',
            
            # EC Payload Issues (Dell-specific)
            'ec_payload_failure': r'5A0D5E58.*PQC Signed',
            'ec_guid_pattern': r'5A0D5E58-[0-9A-Fa-f-]{4}-[0-9A-Fa-f-]{4}-[0-9A-Fa-f-]{4}-[0-9A-Fa-f-]{12}',
            
            # Platform-specific (Dell)
            'congolnlone_platform': r'CongoLnlOne|SECURITY_PFS_PQC_SUPPORT.*TRUE',
            'dell_signing_server': r'Dell Sign Server|Dell signing infrastructure',
            
            # General patterns
            'bios_update_failed': r'BIOS Update failed\. Rebooting your system',
            'flash_error': r'Flash.*error|Update.*failed|CloseFlashUpdatePage.*ResultCode',
            'protocol_install': r'InstallProtocolInterface:\s+([0-9A-Fa-f-]{36})\s+([0-9A-Fa-f]+)',
        }
    
    def _init_language_templates(self):
        """Initialize language-specific report templates"""
        if self.language == "zh-tw":
            self.templates = {
                'report_title': 'CPSE-{} Deep Analysis Report',
                'executive_summary': 'Executive Summary',
                'issue': 'Issue',
                'platform': 'Platform',
                'root_cause': 'Root Cause',
                'impact': 'Impact',
                'priority': 'Priority',
                'technical_analysis': 'Technical Analysis',
                'issue_classification': 'Issue Classification',
                'primary_issue_type': 'Primary Issue Type',
                'secondary_issue_type': 'Secondary Issue Type',
                'configuration': 'Configuration',
                'key_technical_findings': 'Key Technical Findings',
                'critical_error_patterns': 'Critical Error Patterns',
                'dell_domain_context': 'Dell Domain Context',
                'signing_infrastructure': 'Signing Infrastructure',
                'solution_architecture': 'Solution Architecture',
                'recommended_solutions': 'Recommended Solutions',
                'implementation_steps': 'Implementation Steps',
                'risk_assessment': 'Risk Assessment',
                'verification_strategy': 'Verification Strategy',
                'dell_internal_references': 'Dell Internal References',
                'appendices': 'Appendices',
                'technical_details': 'Technical Details',
                'log_analysis': 'Log Analysis',
                'code_references': 'Code References',
                'dell_domain_knowledge': 'Dell Domain Knowledge',
                'high': 'HIGH',
                'medium': 'MEDIUM',
                'low': 'LOW',
                'critical': 'CRITICAL',
                'passed': 'PASSED',
                'failed': 'FAILED',
                'unknown': 'UNKNOWN',
                'not_identified': 'NOT IDENTIFIED',
                'under_investigation': 'UNDER INVESTIGATION'
            }
        else:
            # Default English templates
            self.templates = {
                'report_title': 'CPSE-{} Deep Analysis Report',
                'executive_summary': 'Executive Summary',
                'issue': 'Issue',
                'platform': 'Platform',
                'root_cause': 'Root Cause',
                'impact': 'Impact',
                'priority': 'Priority',
                'technical_analysis': 'Technical Analysis',
                'issue_classification': 'Issue Classification',
                'primary_issue_type': 'Primary Issue Type',
                'secondary_issue_type': 'Secondary Issue Type',
                'configuration': 'Configuration',
                'key_technical_findings': 'Key Technical Findings',
                'critical_error_patterns': 'Critical Error Patterns',
                'dell_domain_context': 'Dell Domain Context',
                'signing_infrastructure': 'Signing Infrastructure',
                'solution_architecture': 'Solution Architecture',
                'recommended_solutions': 'Recommended Solutions',
                'implementation_steps': 'Implementation Steps',
                'risk_assessment': 'Risk Assessment',
                'verification_strategy': 'Verification Strategy',
                'dell_internal_references': 'Dell Internal References',
                'appendices': 'Appendices',
                'technical_details': 'Technical Details',
                'log_analysis': 'Log Analysis',
                'code_references': 'Code References',
                'dell_domain_knowledge': 'Dell Domain Knowledge',
                'high': 'HIGH',
                'medium': 'MEDIUM',
                'low': 'LOW',
                'critical': 'Critical',
                'passed': 'Passed',
                'failed': 'Failed',
                'unknown': 'Unknown',
                'not_identified': 'Not identified',
                'under_investigation': 'Under investigation'
            }
    
    def _load_dell_knowledge(self):
        """Load Dell domain knowledge from knowledge base"""
        try:
            knowledge_path = Path(self.dell_knowledge_path)
            if knowledge_path.exists():
                with open(knowledge_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    self.dell_knowledge = self._parse_knowledge_content(content)
                    print(f"✅ Dell domain knowledge loaded from {knowledge_path}")
            else:
                print(f"⚠️  Dell knowledge file not found: {knowledge_path}")
        except Exception as e:
            print(f"❌ Failed to load Dell knowledge: {str(e)}")
    
    def _parse_knowledge_content(self, content: str) -> Dict[str, Any]:
        """Parse Dell domain knowledge content"""
        knowledge = {
            'signing_infrastructure': {},
            'platform_payloads': {},
            'platform_configs': {},
            'failure_patterns': {}
        }
        
        # Extract key information sections
        sections = re.split(r'### \*\*(.*?)\*\*', content)
        
        for i in range(1, len(sections), 2):
            section_name = sections[i].strip()
            section_content = sections[i+1] if i+1 < len(sections) else ""
            
            if 'Signing Infrastructure' in section_name:
                knowledge['signing_infrastructure'] = self._extract_signing_info(section_content)
            elif 'Platform Payload' in section_name:
                knowledge['platform_payloads'] = self._extract_payload_info(section_content)
            elif 'Platform Configuration' in section_name:
                knowledge['platform_configs'] = self._extract_config_info(section_content)
            elif 'Failure Patterns' in section_name:
                knowledge['failure_patterns'] = self._extract_failure_patterns(section_content)
        
        return knowledge
    
    def _extract_signing_info(self, content: str) -> Dict[str, Any]:
        """Extract signing infrastructure information"""
        info = {}
        
        # Extract key categories
        key_pattern = r'([0-9A-Fa-f-]{36})\s*\(([^)]+)\)'
        for match in re.finditer(key_pattern, content):
            guid = match.group(1)
            description = match.group(2)
            info[guid] = description
        
        return info
    
    def _extract_payload_info(self, content: str) -> Dict[str, Any]:
        """Extract payload information"""
        payloads = {}
        
        # Extract EC payload GUIDs
        ec_pattern = r'([0-9A-Fa-f-]{36})\s*-\s*([A-Z_]+)'
        for match in re.finditer(ec_pattern, content):
            guid = match.group(1)
            payload_type = match.group(2)
            payloads[guid] = payload_type
        
        return payloads
    
    def _extract_config_info(self, content: str) -> Dict[str, Any]:
        """Extract platform configuration information"""
        configs = {}
        
        # Extract platform names and configurations
        platform_pattern = r'\*\*(.*?)\*\*:\s*([^\n]+)'
        for match in re.finditer(platform_pattern, content):
            platform = match.group(1)
            config = match.group(2)
            configs[platform] = config
        
        return configs
    
    def _extract_failure_patterns(self, content: str) -> Dict[str, Any]:
        """Extract failure pattern information"""
        patterns = {}
        
        # Extract common failure patterns
        pattern_list = re.findall(r'- \*\*(.*?)\*\*:\s*([^\n]+)', content)
        for pattern_name, description in pattern_list:
            patterns[pattern_name] = description
        
        return patterns
    
    def __enter__(self):
        try:
            self.temp_dir = tempfile.mkdtemp(prefix='enhanced_cpse_analysis_')
            return self
        except Exception as e:
            print(f"❌ Failed to create temporary directory: {str(e)}")
            self.temp_dir = None
            return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.temp_dir and os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def run_jira_tool(self, command: str) -> Dict[str, Any]:
        """Execute jira_tool.py command and return parsed output"""
        try:
            # Get absolute path to jira_tool.py to handle different working directories
            script_dir = Path(__file__).parent
            jira_tool_abs_path = script_dir.parent.parent / "jira_integration" / "scripts" / "jira_tool.py"
            
            cmd = f'python "{jira_tool_abs_path}" {command}'
            # Always use current directory for jira_tool.py execution
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=os.getcwd(), encoding='utf-8')
            
            if result.returncode != 0:
                return {'success': False, 'error': result.stderr}
                
            return {'success': True, 'output': result.stdout}
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def analyze_ticket_enhanced(self, ticket_key: str, generate_markdown: bool = True, 
                                deep_analysis: bool = False, github_analysis: bool = False, 
                                git_analysis: bool = False) -> Dict[str, Any]:
        """Perform enhanced CPSE ticket analysis with Dell domain knowledge and optional GitHub/Git analysis"""
        print(f"🔍 Performing enhanced analysis of CPSE ticket: {ticket_key}")
        
        # Get basic ticket analysis
        analysis_result = self.run_jira_tool(f'analyze --key {ticket_key}')
        if not analysis_result['success']:
            return {'error': 'Failed to analyze ticket', 'details': analysis_result['error']}
        
        # Get full comment history
        comments_result = self.run_jira_tool(f'get-comments --key {ticket_key}')
        
        # Parse ticket data
        ticket_data = self._parse_analysis_output(analysis_result['output'])
        comments_data = self._parse_comments_output(comments_result['output']) if comments_result['success'] else []
        
        # Download and analyze attachments
        attachment_analysis = self._analyze_attachments(ticket_key, ticket_data.get('attachments', []))
        
        # Correlate with codebase
        codebase_analysis = self._analyze_codebase(ticket_data, attachment_analysis)
        
        # Apply Dell domain knowledge
        dell_analysis = self._apply_dell_knowledge(ticket_data, attachment_analysis, codebase_analysis)
        
        # Initialize analysis results
        github_history_analysis = {}
        git_log_analysis = {}
        
        # Perform GitHub analysis if requested
        if github_analysis and self.github_tool:
            github_history_analysis = self._analyze_github_history(ticket_data, attachment_analysis)
        
        # Perform Git log analysis if requested  
        if git_analysis:
            git_log_analysis = self._analyze_git_log_history(ticket_data, attachment_analysis)
        
        # Generate enhanced solutions with GitHub/Git insights
        solutions = self._generate_enhanced_solutions(
            ticket_data, attachment_analysis, codebase_analysis, dell_analysis,
            github_history_analysis, git_log_analysis
        )
        
        # Generate analysis summary with all insights
        summary = self._generate_enhanced_summary(
            ticket_data, attachment_analysis, dell_analysis, solutions,
            github_history_analysis, git_log_analysis
        )
        
        result = {
            'ticket': ticket_data,
            'comments': comments_data,
            'attachments': attachment_analysis,
            'codebase': codebase_analysis,
            'dell_knowledge': dell_analysis,
            'github_history': github_history_analysis,
            'git_log': git_log_analysis,
            'solutions': solutions,
            'summary': summary
        }
        
        # Generate Markdown report if requested
        if generate_markdown:
            markdown_report = self._generate_markdown_report(ticket_key, result)
            result['markdown_report'] = markdown_report
            
            # Save Markdown report to file
            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            # Remove CPSE- prefix if already present to avoid duplication
            clean_ticket_key = ticket_key.replace("CPSE-", "") if ticket_key.startswith("CPSE-") else ticket_key
            report_filename = f"CPSE-{clean_ticket_key}_Deep_Analysis_Report_{timestamp}.md" if self.language == "zh-tw" else f"CPSE-{clean_ticket_key}_Deep_Analysis_Report_{timestamp}.md"
            
            # Save to .windsurf/Reports/ directory following skill_guides standards
            script_dir = Path(__file__).parent
            reports_dir = script_dir.parent.parent.parent / "Reports"
            reports_dir.mkdir(exist_ok=True)
            report_path = reports_dir / report_filename
            
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write(markdown_report)
            print(f"📄 Markdown report saved to: {report_path}")
            result['report_path'] = str(report_path)
        
        return result
    
    def _apply_dell_knowledge(self, ticket_data: Dict, attachment_analysis: Dict, codebase_analysis: Dict) -> Dict[str, Any]:
        """Apply Dell domain knowledge to enhance analysis"""
        print("🧠 Applying Dell domain knowledge...")
        
        dell_analysis = {
            'platform_context': {},
            'signing_context': {},
            'payload_context': {},
            'failure_pattern_context': {},
            'dell_specific_insights': []
        }
        
        # Analyze all findings for Dell context
        all_findings = []
        for log in attachment_analysis.get('debug_logs', []):
            all_findings.extend(log.get('findings', []))
        
        # Apply Dell knowledge to findings
        for finding in all_findings:
            finding_type = finding.get('type', '')
            match_text = finding.get('match', '')
            
            # Check for PQC key category issues
            if 'pqckey_not_found' in finding_type or '540B32B0-808D-47E1-A188-76AA7CF1BB93' in match_text:
                dell_analysis['signing_context']['key_category_mismatch'] = {
                    'missing_guid': '540B32B0-808D-47E1-A188-76AA7CF1BB93',
                    'expected_guid': '89084706-e614-44db-8ad1-bc1dca73b299',
                    'insight': 'Dell Sign Server using different key category than BIOS verification',
                    'dell_knowledge_reference': 'Signing Infrastructure -> Key Category System'
                }
                dell_analysis['dell_specific_insights'].append(
                    'Key category mismatch between Dell Sign Server and BIOS code detected'
                )
            
            # Check for EC payload issues
            if 'ec_payload_failure' in finding_type or '5A0D5E58' in match_text:
                dell_analysis['payload_context']['ec_payloads'] = {
                    'payload_type': 'Embedded Controller',
                    'platform': 'CongoLnlOne',
                    'signing_issue': 'EC payload incorrectly classified as PQC Signed',
                    'dell_knowledge_reference': 'Platform Payload Classification -> EC Payloads'
                }
                dell_analysis['dell_specific_insights'].append(
                    'EC payload signing classification issue detected'
                )
            
            # Check for platform-specific issues
            if 'congolnlone_platform' in finding_type:
                dell_analysis['platform_context']['congolnlone'] = {
                    'platform_name': 'CongoLnlOne',
                    'silicon': 'LunarLake',
                    'pqc_support': True,
                    'dell_knowledge_reference': 'Platform Configurations -> CongoLnlOne Platform'
                }
        
        return dell_analysis
    
    def _generate_enhanced_solutions(self, ticket_data: Dict, attachment_analysis: Dict, 
                                   codebase_analysis: Dict, dell_analysis: Dict,
                                   github_history_analysis: Dict = {}, git_log_analysis: Dict = {}) -> List[Dict[str, Any]]:
        """Generate enhanced solutions with Dell domain knowledge and GitHub/Git insights"""
        solutions = []
        
        # Dell-specific solutions based on domain knowledge
        if dell_analysis.get('signing_context', {}).get('key_category_mismatch'):
            solutions.append({
                'type': 'fix_dell_signing_configuration',
                'priority': 'HIGH',
                'description': 'Fix Dell Sign Server key category configuration for EC payloads',
                'dell_context': 'Contact Dell Sign Server team to correct key category mapping',
                'implementation': 'Update Dell Sign Server to use correct PQC key category',
                'verification': 'Test EC payload verification after signing correction',
                'dell_contacts': ['Dell Sign Server Team', 'PQC Implementation Team'],
                'files_to_modify': ['Dell Sign Server Configuration'],
                'dell_knowledge_reference': dell_analysis['signing_context']['key_category_mismatch'].get('dell_knowledge_reference')
            })
        
        if dell_analysis.get('payload_context', {}).get('ec_payloads'):
            solutions.append({
                'type': 'fix_ec_payload_classification',
                'priority': 'HIGH',
                'description': 'Correct EC payload signing classification in Dell workflow',
                'dell_context': 'EC payloads should use RSA signing, not PQC signing',
                'implementation': 'Update EC payload classification in Dell signing workflow',
                'verification': 'Verify EC payloads are correctly signed and verified',
                'dell_contacts': ['EC Firmware Team', 'Signing Infrastructure Team'],
                'files_to_modify': ['EC Signing Workflow Configuration'],
                'dell_knowledge_reference': dell_analysis['payload_context']['ec_payloads'].get('dell_knowledge_reference')
            })
        
        # GitHub-based solutions
        if github_history_analysis and 'solution_patterns' in github_history_analysis:
            for pattern in github_history_analysis['solution_patterns']:
                if pattern['frequency'] > 0:
                    solutions.append({
                        'type': f"github_pattern_{pattern['type']}",
                        'priority': 'MEDIUM',
                        'description': f"Apply GitHub solution pattern: {pattern['description']}",
                        'github_context': f"Found {pattern['frequency']} similar fixes on GitHub",
                        'implementation': pattern['recommendation'],
                        'verification': 'Test solution based on GitHub pattern success rate',
                        'github_repos': [repo['name'] for repo in github_history_analysis.get('repository_matches', [])[:3]],
                        'github_evidence': [change['path'] for change in github_history_analysis.get('code_changes', [])[:3]],
                        'pattern_frequency': pattern['frequency']
                    })
        
        # Git log-based solutions
        if git_log_analysis and git_log_analysis.get('related_commits'):
            # Identify most common fix approach from git history
            commit_messages = [commit['message'] for commit in git_log_analysis['related_commits']]
            
            if any('fix' in msg.lower() or 'patch' in msg.lower() for msg in commit_messages):
                solutions.append({
                    'type': 'git_history_fix',
                    'priority': 'MEDIUM',
                    'description': 'Apply fix approach based on local git history',
                    'git_context': f"Found {len(git_log_analysis['related_commits'])} related commits in local repository",
                    'implementation': 'Review and apply similar fix patterns from local commit history',
                    'verification': 'Test fix based on local commit success patterns',
                    'related_commits': git_log_analysis['related_commits'][:3],
                    'author_experts': list(git_log_analysis.get('author_patterns', {}).keys())[:2]
                })
        
        # SHA1-specific solutions if commits were found
        if github_history_analysis.get('commit_analysis'):
            for commit_analysis in github_history_analysis['commit_analysis']:
                if commit_analysis['found']:
                    solutions.append({
                        'type': 'sha1_commit_analysis',
                        'priority': 'HIGH',
                        'description': f"Analyze specific commit {commit_analysis['sha1'][:8]} for solution insights",
                        'sha1_context': f"Commit found in {len(commit_analysis['repositories'])} repositories",
                        'implementation': 'Review commit changes and apply similar approach',
                        'verification': 'Test solution based on specific commit analysis',
                        'commit_repositories': commit_analysis['repositories'],
                        'commit_changes': commit_analysis['changes'][:3]
                    })
        
        return solutions
    
    def _generate_enhanced_summary(self, ticket_data: Dict, attachment_analysis: Dict, 
                                 dell_analysis: Dict, solutions: List[Dict],
                                 github_history_analysis: Dict = {}, git_log_analysis: Dict = {}) -> Dict[str, Any]:
        """Generate enhanced analysis summary with Dell context and GitHub/Git insights"""
        summary = {
            'issue_classification': 'Unknown',
            'platform_context': 'Not identified',
            'dell_specific_insights': [],
            'recommended_actions': [],
            'dell_escalation_required': False,
            'github_insights': [],
            'git_insights': []
        }
        
        # Classify issue based on Dell analysis
        if dell_analysis.get('signing_context', {}).get('key_category_mismatch'):
            summary['issue_classification'] = 'Dell PQC Signing Configuration Issue'
            summary['platform_context'] = dell_analysis.get('platform_context', {}).get('congolnlone', {}).get('platform_name', 'Unknown')
            summary['dell_specific_insights'].append('Key category mismatch between Dell Sign Server and BIOS code')
            summary['dell_escalation_required'] = True
        
        if dell_analysis.get('payload_context', {}).get('ec_payloads'):
            summary['issue_classification'] = 'Dell EC Payload Signing Issue'
            summary['dell_specific_insights'].append('EC payload incorrectly classified for PQC signing')
            summary['dell_escalation_required'] = True
        
        # Add GitHub insights
        if github_history_analysis and 'repository_matches' in github_history_analysis:
            repo_count = len(github_history_analysis['repository_matches'])
            code_change_count = len(github_history_analysis.get('code_changes', []))
            
            if repo_count > 0:
                summary['github_insights'].append(f'Found {repo_count} relevant repositories on GitHub')
            
            if code_change_count > 0:
                summary['github_insights'].append(f'Identified {code_change_count} similar code changes on GitHub')
            
            # Add solution pattern insights
            if 'solution_patterns' in github_history_analysis:
                for pattern in github_history_analysis['solution_patterns']:
                    if pattern['frequency'] > 0:
                        summary['github_insights'].append(
                            f"GitHub pattern: {pattern['description']} (found {pattern['frequency']} times)"
                        )
        
        # Add Git log insights
        if git_log_analysis and git_log_analysis.get('related_commits'):
            commit_count = len(git_log_analysis['related_commits'])
            author_count = len(git_log_analysis.get('author_patterns', {}))
            
            if commit_count > 0:
                summary['git_insights'].append(f'Found {commit_count} related commits in local repository')
            
            if author_count > 0:
                top_author = list(git_log_analysis['author_patterns'].keys())[0]
                summary['git_insights'].append(f'Most active author: {top_author}')
        
        # Add recommended actions
        for solution in solutions:
            action = {
                'action': solution['description'],
                'priority': solution['priority'],
                'context': solution.get('dell_context', '') or solution.get('github_context', '') or solution.get('git_context', ''),
                'contacts': solution.get('dell_contacts', [])
            }
            
            # Add GitHub-specific context
            if 'github_repos' in solution:
                action['github_repos'] = solution['github_repos']
            
            # Add Git-specific context
            if 'author_experts' in solution:
                action['git_experts'] = solution['author_experts']
            
            summary['recommended_actions'].append(action)
        
        return summary
    
    def _generate_markdown_report(self, ticket_key: str, analysis_result: Dict) -> str:
        """Generate standardized Markdown analysis report with enhanced technical details and GitHub/Git analysis"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
        
        ticket_data = analysis_result.get('ticket', {})
        dell_analysis = analysis_result.get('dell_knowledge', {})
        github_analysis = analysis_result.get('github_history', {})
        git_analysis = analysis_result.get('git_log', {})
        solutions = analysis_result.get('solutions', [])
        summary = analysis_result.get('summary', {})
        attachment_analysis = analysis_result.get('attachments', {})
        
        # Create metadata header
        clean_ticket_key = ticket_key.replace("CPSE-", "") if ticket_key.startswith("CPSE-") else ticket_key
        metadata = f"""---
# CPSE-{clean_ticket_key} Deep Analysis Report
**Generated:** {timestamp}
**Description:** CPSE-{clean_ticket_key} Deep Analysis Report
**Skill:** cpse_debug_analysis
---

"""
        
        report = f"""{metadata}# {self.templates['report_title'].format(clean_ticket_key)}

## {self.templates['executive_summary']}
**{self.templates['issue']}**: {ticket_data.get('summary', 'Unknown issue')}
**{self.templates['platform']}**: {summary.get('platform_context', self.templates['not_identified'])}
**{self.templates['root_cause']}**: {summary.get('issue_classification', self.templates['under_investigation'])}
**{self.templates['impact']}**: BIOS update failure due to signing verification issues
**{self.templates['priority']}**: {self.templates['high']}

**Analysis Date**: {timestamp}
**Analysis Engine**: Enhanced CPSE Debug Analysis with Dell Domain Knowledge & GitHub Integration

## {self.templates['technical_analysis']}

### {self.templates['issue_classification']}
- **{self.templates['primary_issue_type']}**: PQC Signing Configuration Issue
- **{self.templates['secondary_issue_type']}**: EC Payload Verification Failure
- **{self.templates['platform']}**: {summary.get('platform_context', f'Unknown Dell Platform')}
- **{self.templates['configuration']}**: PQC Support Enabled

### {self.templates['key_technical_findings']}
#### {self.templates['critical_error_patterns']}
"""
        
        # Add enhanced log analysis details
        debug_logs = attachment_analysis.get('debug_logs', [])
        if debug_logs:
            # Prepare enhanced analysis data
            enhanced_analysis_data = {
                'log_analysis': {
                    'total_logs': len(debug_logs),
                    'log_files': [log.get('log_file', 'Unknown') for log in debug_logs],
                    'error_patterns': []
                },
                'execution_sequence': {},
                'code_correlation': {},
                'root_cause_analysis': {}
            }
            
            # Collect error patterns from all logs
            for log in debug_logs:
                if 'error_patterns' in log:
                    enhanced_analysis_data['log_analysis']['error_patterns'].extend(log['error_patterns'])
                
                # Add execution sequence from first log
                if 'execution_sequence' in log and not enhanced_analysis_data['execution_sequence']:
                    enhanced_analysis_data['execution_sequence'] = log['execution_sequence']
                
                # Add code correlation from first log
                if 'code_correlation' in log and not enhanced_analysis_data['code_correlation']:
                    enhanced_analysis_data['code_correlation'] = log['code_correlation']
                
                # Add root cause analysis from first log
                if 'root_cause_analysis' in log and not enhanced_analysis_data['root_cause_analysis']:
                    enhanced_analysis_data['root_cause_analysis'] = log['root_cause_analysis']
            
            # Generate enhanced technical analysis section
            enhanced_technical_analysis = self.report_generator.generate_enhanced_technical_analysis(enhanced_analysis_data)
            report += enhanced_technical_analysis
        
        # Add traditional findings
        for log in debug_logs:
            findings = log.get('findings', [])
            for finding in findings[:3]:  # Limit to top 3 findings
                report += f"""- **{finding.get('type', 'Unknown')}**: {finding.get('match', 'No details available')}
  - Line: {finding.get('line_number', 'N/A')}
  - Context: {finding.get('context', ['No context'])[0] if finding.get('context') else 'No context'}
"""
        
        report += f"""
#### {self.templates['dell_domain_context']}
"""
        
        # Add Dell-specific insights
        dell_insights = summary.get('dell_specific_insights', [])
        for insight in dell_insights:
            report += f"""- **Dell Insight**: {insight}
"""
        
        if dell_analysis.get('signing_context', {}).get('key_category_mismatch'):
            key_context = dell_analysis['signing_context']['key_category_mismatch']
            report += f"""
- **{self.templates['signing_infrastructure']}**: Key category mismatch detected
  - Missing GUID: {key_context.get('missing_guid', 'Unknown')}
  - Expected GUID: {key_context.get('expected_guid', 'Unknown')}
  - Dell Reference: {key_context.get('dell_knowledge_reference', 'Not specified')}
"""
        
        if dell_analysis.get('payload_context', {}).get('ec_payloads'):
            ec_context = dell_analysis['payload_context']['ec_payloads']
            report += f"""
- **EC Payload Context**: {ec_context.get('payload_type', 'Unknown')} signing issue
  - Platform: {ec_context.get('platform', 'Unknown')}
  - Issue: {ec_context.get('signing_issue', 'Unknown')}
  - Dell Reference: {ec_context.get('dell_knowledge_reference', 'Not specified')}
"""
        
        # Add GitHub Analysis Section
        if github_analysis and not github_analysis.get('error'):
            report += f"""
## 📊 GitHub History Analysis (Enhancement Search)
### Related Repository Discovery
"""
            
            repo_matches = github_analysis.get('repository_matches', [])
            if repo_matches:
                report += "#### Repository Match Results\n"
                for repo in repo_matches:
                    report += f"""- **{repo['name']}**: {repo['description']} ({repo['language']})
  - Relevance: {repo['relevance']}
"""
            else:
                report += "- No related repository matches discovered\n"
            
            code_changes = github_analysis.get('code_changes', [])
            if code_changes:
                report += "\n#### Code Changes Discovered\n"
                for change in code_changes:
                    report += f"""- **{change['repository']}**: `{change['path']}`
  - Match: `{change['match'][:100]}...`
  - Relevance: {change['relevance']}
"""
            else:
                report += "- No related code changes discovered\n"
            
            solution_patterns = github_analysis.get('solution_patterns', [])
            if solution_patterns:
                report += "\n#### Enhancement History Pattern Analysis\n"
                for pattern in solution_patterns:
                    report += f"""- **{pattern['type']}**: {pattern['description']} (frequency: {pattern['frequency']})
  - Suggestion: {pattern['recommendation']}
"""
            
            commit_analysis = github_analysis.get('commit_analysis', [])
            if commit_analysis:
                report += "\n#### SHA1 CommitAnalyze\n"
                for commit in commit_analysis:
                    if commit['found']:
                        report += f"""- **Commit {commit['sha1'][:8]}**: Found in {len(commit['repositories'])} repositories
  - Repositories: {', '.join(commit['repositories'])}
"""
                        for change in commit['changes']:
                            report += f"  - File: `{change['file']}` - Context: `{change['context'][:100]}...`\n"
        
        # Add Git Log Analysis Section
        if git_analysis and not git_analysis.get('error'):
            report += f"""
## 📝 Git Log History Analysis
### Related Commits in Local Repository
"""
            
            related_commits = git_analysis.get('related_commits', [])
            if related_commits:
                report += "#### Related Commit Logging\n"
                for commit in related_commits:
                    report += f"""- **{commit['sha']}**: {commit['message']}
  - Keyword: {commit['keyword']}
"""
            else:
                report += "- No related commit logging discovered\n"
            
            file_changes = git_analysis.get('file_changes', [])
            if file_changes:
                report += "\n#### File Content Changes\n"
                for change in file_changes:
                    report += f"""- **{change['sha']}**: {change['message']}
  - Type: {change['type']}
  - Keyword: {change['keyword']}
"""
            
            author_patterns = git_analysis.get('author_patterns', {})
            if author_patterns:
                report += "\n#### Author Expertise Patterns\n"
                for author, count in list(author_patterns.items())[:5]:
                    report += f"- **{author}**: {count} commits\n"
        
        report += f"""
### {self.templates['root_cause']} Analysis
#### Technical {self.templates['root_cause']}
The issue stems from a mismatch between the Dell Sign Server's PQC signing process and the BIOS verification system:

1. **Dell Sign Server** is using key category `540B32B0-808D-47E1-A188-76AA7CF1BB93` for EC payload signing
2. **BIOS Code** only contains key category `89084706-e614-44db-8ad1-bc1dca73b299` for verification
3. **EC Payloads** are being incorrectly classified as PQC Signed when they should use RSA signing

#### Contributing Factors
- **PQC Deployment Transition**: Ongoing migration from RSA to PQC signing
- **EC Payload Classification**: EC payloads incorrectly routed to PQC signing workflow
- **Key Category Mapping**: Dell Sign Server using different key category than BIOS expects

## {self.templates['solution_architecture']}

### {self.templates['recommended_solutions']}
"""
        
        # Add solutions to report
        for i, solution in enumerate(solutions, 1):
            report += f"""#### Solution {i}: {solution['description']}
- **Priority**: {solution['priority']}
"""
            
            # Add Dell-specific context
            if 'dell_context' in solution:
                report += f"- **Dell Context**: {solution['dell_context']}\n"
            
            # Add GitHub-specific context
            if 'github_context' in solution:
                report += f"- **GitHub Context**: {solution['github_context']}\n"
            
            # Add Git-specific context
            if 'git_context' in solution:
                report += f"- **Git Context**: {solution['git_context']}\n"
            
            report += f"""- **Implementation**: {solution['implementation']}
- **Files to Modify**: {', '.join(solution.get('files_to_modify', ['N/A']))}
- **Verification**: {solution['verification']}
"""
            
            # Add Dell contacts
            if 'dell_contacts' in solution:
                report += f"- **Dell Contacts**: {', '.join(solution['dell_contacts'])}\n"
            
            # Add GitHub evidence
            if 'github_evidence' in solution:
                report += f"- **GitHub Evidence**: {', '.join(solution['github_evidence'])}\n"
            
            # Add Git experts
            if 'author_experts' in solution:
                report += f"- **Git Experts**: {', '.join(solution['author_experts'])}\n"
            
            if 'dell_knowledge_reference' in solution:
                report += f"- **Dell Knowledge Reference**: {solution['dell_knowledge_reference']}\n"

            report += "\n"
        
        report += """### Dell-Specific Considerations
- **Signing Process**: Requires coordination with Dell Sign Server team
- **Platform Impact**: Affects CongoLnlOne platform with PQC support
- **Internal Dependencies**: Dell signing infrastructure and EC firmware teams
- **Escalation Path**: Contact Dell PQC implementation team for signing issues

## Implementation Steps

### Phase 1: Immediate Actions (Critical)
1. **Contact Dell Sign Server Team**: Report key category mismatch issue
2. **Verify EC Payload Classification**: Confirm EC payloads should use RSA signing
3. **Test Current Configuration**: Validate existing RSA-signed EC payloads

### Phase 2: Short-term Fixes (High)
1. **Correct Dell Sign Server Configuration**: Update to use correct key category
2. **Update EC Signing Workflow**: Ensure EC payloads use RSA signing
3. **Validate Fix**: Test EC payload verification after correction

### Phase 3: Long-term Improvements (Medium)
1. **Process Documentation**: Document correct EC payload signing workflow
2. **Automation Enhancement**: Implement checks to prevent future mismatches
3. **Knowledge Base Update**: Update Dell domain knowledge with lessons learned

## Risk Assessment

### High Risk Factors
- **Platform-Wide Impact**: Affects all CongoLnlOne systems with PQC support
- **Update Blocking**: Prevents BIOS updates on affected platforms
- **Security Implications**: Incorrect signing verification could affect system security

### Mitigation Strategies
- **Staged Deployment**: Test fixes on pilot systems before full deployment
- **Rollback Plan**: Maintain ability to revert to previous signing configuration
- **Cross-Team Coordination**: Ensure alignment between signing and BIOS teams

## Verification Strategy

### Testing Requirements
- **EC Payload Verification**: Test EC payload signing and verification
- **BIOS Update Testing**: Verify complete BIOS update process
- **Platform Testing**: Test on CongoLnlOne hardware configurations

### Success Criteria
- EC payloads verify successfully with correct signatures
- BIOS updates complete without signing errors
- All CongoLnlOne platform variants work correctly

## Dell Internal References

### Related Systems
- **JIRA**: CPSE-{ticket_key}
- **PIMS**: [Product Issue Management System - check ticket for references]
- **CBDCIT**: [Cross-Build Dependency - check for related build issues]

### Subject Matter Experts
- **Team**: Dell PQC Implementation Team
- **Contacts**: Dell Sign Server Team, EC Firmware Team, BIOS Engineering Team

## Appendices

### Technical Details
#### Log Analysis
Key error patterns identified in debug logs:
- `PQC Public key category not found 540B32B0-808D-47E1-A188-76AA7CF1BB93`
- `CheckIfPayloadIsPqcSigned(): Payload GUID 5A0D5E58-* is PQC Signed`
- `BIOS Update failed. Rebooting your system`

#### Code References
- **PQC Key Table**: `DellPkgs/DellPlatformPkgs/NB/CongoLnlOnePkg/Include/DellPqcPublicKeyTable.h`
- **Payload Definitions**: `DellPkgs/DellPlatformPkgs/NB/CongoLnlOnePkg/FlashPayload/BoardPayload.dsc`
- **Build Configuration**: `DellPkgs/DellPlatformPkgs/NB/CongoLnlOnePkg/builda.bat`

#### Configuration Details
- **Platform**: CongoLnlOne (LunarLake)
- **PQC Support**: Enabled via `SECURITY_PFS_PQC_SUPPORT = TRUE`
- **EC Type**: MCHP 5507 iFuse (non-fused and fused variants)

### Dell Domain Knowledge
#### Applied Knowledge Areas
- **Signing Infrastructure**: Key category system and Dell Sign Server workflow
- **Platform Payload Classification**: EC payload identification and classification
- **Platform Configurations**: CongoLnlOne specific settings and build process

#### Internal Process Context
- **Dell Sign Server**: External signing authority for PQC binaries
- **Key Category Mapping**: Critical for payload verification success
- **EC Signing Workflow**: Requires RSA signing, not PQC signing

### GitHub Analysis Insights
"""
        
        # Add GitHub insights to appendices
        github_insights = summary.get('github_insights', [])
        if github_insights:
            for insight in github_insights:
                report += f"- {insight}\n"
        else:
            report += "- No GitHub insights available\n"
        
        report += "\n### Git Log Analysis Insights\n"
        
        # Add Git insights to appendices
        git_insights = summary.get('git_insights', [])
        if git_insights:
            for insight in git_insights:
                report += f"- {insight}\n"
        else:
            report += "- No Git log insights available\n"

        report += f"""
---
*Report Generated: {timestamp}*
*Analysis Engine: Enhanced CPSE Debug Analysis with GitHub Integration*
*Dell Domain Knowledge Version: 1.0*
*Session Independence: Guaranteed*
"""
        
        return report
    
    def _parse_analysis_output(self, output: str) -> Dict[str, Any]:
        """Parse jira_tool.py analyze output"""
        if not output:
            return {
                'key': '',
                'summary': '',
                'status': '',
                'assignee': '',
                'priority': '',
                'attachments': [],
                'linked_issues': [],
                'recent_history': [],
                'description': ''
            }
        
        data = {
            'key': '',
            'summary': '',
            'status': '',
            'assignee': '',
            'priority': '',
            'attachments': [],
            'linked_issues': [],
            'recent_history': [],
            'description': ''
        }
        
        # Extract key information using regex
        patterns = {
            'key': r'JIRA DEEP ANALYSIS:\s+(\w+-\d+)',
            'summary': r'Summary\s+:\s+(.+)',
            'status': r'Status\s+:\s+(.+)',
            'assignee': r'Owner\s+:\s+(.+)',
            'priority': r'Priority\s+:\s+(.+)'
        }
        
        for field, pattern in patterns.items():
            match = re.search(pattern, output)
            if match:
                data[field] = match.group(1).strip()
        
        # Extract attachments
        attachment_pattern = r'- \[(\d+)\]\s+(.+?)\s+\((\d+ KB|\d+ MB)\)'
        for match in re.finditer(attachment_pattern, output):
            data['attachments'].append({
                'id': match.group(1),
                'name': match.group(2).strip(),
                'size': match.group(3)
            })
        
        return data
    
    def _parse_comments_output(self, output: str) -> List[Dict[str, Any]]:
        """Parse get-comments output"""
        comments = []
        
        # Parse comment entries
        comment_pattern = r'(\w+)\s+\|([^|]+)\|([^|]+)\|(.+)'
        for match in re.finditer(comment_pattern, output):
            comments.append({
                'id': match.group(1).strip(),
                'author': match.group(2).strip(),
                'created': match.group(3).strip(),
                'body': match.group(4).strip()
            })
        
        return comments
    
    def _analyze_attachments(self, ticket_key: str, attachments: List[Dict]) -> Dict[str, Any]:
        """Download and analyze ticket attachments"""
        print("📎 Processing attachments...")
        
        analysis = {
            'total_attachments': len(attachments),
            'debug_logs': [],
            'screenshots': [],
            'other_files': [],
            'key_findings': []
        }
        
        for attachment in attachments:
            if 'debug' in attachment['name'].lower() or attachment['name'].endswith('.txt'):
                log_analysis = self._analyze_debug_log(ticket_key, attachment)
                analysis['debug_logs'].append(log_analysis)
            elif attachment['name'].lower().endswith(('.jpg', '.png', '.jpeg')):
                analysis['screenshots'].append(attachment)
            else:
                analysis['other_files'].append(attachment)
        
        # Extract key findings from debug logs
        for log in analysis['debug_logs']:
            analysis['key_findings'].extend(log.get('findings', []))
        
        return analysis
    
    def _analyze_debug_log(self, ticket_key: str, attachment: Dict) -> Dict[str, Any]:
        """Download and analyze debug log file with enhanced analysis"""
        print(f"📄 Analyzing debug log: {attachment['name']}")
        
        # Download attachment
        download_result = self.run_jira_tool(
            f'download-attachment --id {attachment["id"]} --out debug_log_{attachment["id"]}.txt'
        )
        
        if not download_result['success']:
            return {'error': 'Failed to download attachment', 'attachment': attachment}
        
        # Read and analyze log content
        log_path = os.path.join(self.temp_dir, f'debug_log_{attachment["id"]}.txt')
        
        try:
            with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
                log_content = f.read()
        except Exception as e:
            return {'error': f'Failed to read log file: {str(e)}', 'attachment': attachment}
        
        # Enhanced analysis using the report generator
        execution_sequence = self.report_generator.analyze_log_execution_sequence(log_content)
        code_correlation = self.report_generator.analyze_code_correlation(log_content, str(self.codebase_root))
        
        # Extract key patterns using enhanced patterns
        findings = []
        protocol_installations = []
        error_events = []
        error_patterns = []
        
        # Search for enhanced error patterns
        for pattern_name, pattern in self.enhanced_patterns.items():
            matches = re.finditer(pattern, log_content)
            pattern_count = 0
            first_line = None
            last_line = None
            
            for match in matches:
                line_num = log_content[:match.start()].count('\n') + 1
                if first_line is None:
                    first_line = line_num
                last_line = line_num
                pattern_count += 1
                
                finding = {
                    'type': pattern_name,
                    'line_number': line_num,
                    'match': match.group(0),
                    'context': self._get_line_context(log_content, match.start())
                }
                findings.append(finding)
                
                if pattern_name == 'protocol_install':
                    protocol_installations.append({
                        'guid': match.group(1),
                        'handle': match.group(2),
                        'line': line_num
                    })
            
            # Add to error patterns for reporting
            if pattern_count > 0:
                error_patterns.append({
                    'type': pattern_name,
                    'description': self._get_pattern_description(pattern_name),
                    'count': pattern_count,
                    'first_line': first_line,
                    'last_line': last_line,
                    'excerpt': self._get_excerpt_for_pattern(log_content, pattern_name),
                    'context': self._get_pattern_context(pattern_name)
                })
        
        # Analyze root cause correlation
        root_cause_analysis = self._analyze_root_cause_correlation(log_content, execution_sequence, findings)
        
        return {
            'attachment': attachment,
            'findings': findings,
            'protocol_installations': protocol_installations,
            'error_events': error_events,
            'execution_sequence': execution_sequence,
            'code_correlation': code_correlation,
            'root_cause_analysis': root_cause_analysis,
            'error_patterns': error_patterns,
            'log_file': attachment['name'],
            'analysis_timestamp': datetime.now().isoformat()
        }
    
    def _get_pattern_description(self, pattern_name: str) -> str:
        """Get description for error pattern"""
        descriptions = {
            'pqckey_not_found': 'PQC Public key category not found - signing verification failure',
            'lms_verification_failed': 'LMS signature verification failed - PQC signing issue',
            'key_category_mismatch': 'Key category mismatch - EC payload signing configuration error',
            'ec_payload_failure': 'EC Payload PQC signing failure - Embedded Controller issue',
            'ec_guid_pattern': 'EC Payload GUID detected - Embedded Controller reference',
            'congolnlone_platform': 'CongoLnlOne platform configuration - Dell platform specific',
            'dell_signing_server': 'Dell Sign Server reference - External signing process',
            'bios_update_failed': 'BIOS Update failure - Critical system update issue'
        }
        return descriptions.get(pattern_name, 'Unknown error pattern')
    
    def _get_excerpt_for_pattern(self, log_content: str, pattern_name: str) -> str:
        """Get excerpt for error pattern"""
        lines = log_content.split('\n')
        for i, line in enumerate(lines):
            if pattern_name == 'pqckey_not_found' and 'PQC Public key category not found' in line:
                return line.strip()
            elif pattern_name == 'lms_verification_failed' and 'LMS' in line and 'verification' in line:
                return line.strip()
            elif pattern_name == 'key_category_mismatch' and '540B32B0-808D-47E1-A188-76AA7CF1BB93' in line:
                return line.strip()
            elif pattern_name == 'ec_payload_failure' and '5A0D5E58' in line and 'PQC' in line:
                return line.strip()
        return 'No excerpt available'
    
    def _get_pattern_context(self, pattern_name: str) -> str:
        """Get context for error pattern"""
        contexts = {
            'pqckey_not_found': 'BIOS verification system cannot find the required PQC key category for payload verification',
            'lms_verification_failed': 'LMS (Leighton-Micali Signature) algorithm verification failed during PQC signature check',
            'key_category_mismatch': 'EC payload was signed with incorrect key category, causing verification failure',
            'ec_payload_failure': 'Embedded Controller payload signature verification failed during BIOS update',
            'ec_guid_pattern': 'Reference to Embedded Controller payload GUID found in execution flow',
            'congolnlone_platform': 'Platform-specific configuration for CongoLnlOne Dell platform detected',
            'dell_signing_server': 'Reference to Dell external signing server process',
            'bios_update_failed': 'Critical failure during BIOS update process'
        }
        return contexts.get(pattern_name, 'No context available')
    
    def _analyze_root_cause_correlation(self, log_content: str, execution_sequence: Dict, findings: List[Dict]) -> Dict[str, Any]:
        """Analyze root cause correlation between execution sequence and findings"""
        causal_chain = []
        contributing_factors = []
        
        # Build causal chain from execution sequence
        failure_point = execution_sequence.get('failure_point', {})
        if failure_point:
            causal_chain.append({
                'event': 'Initial Failure',
                'timestamp': failure_point.get('timestamp', 'Unknown'),
                'trigger': 'System detected critical error',
                'effect': failure_point.get('error', 'Unknown error'),
                'evidence': f"Line {failure_point.get('line_number', 'N/A')}: {failure_point.get('error', '')}",
                'confidence': 85
            })
        
        # Add findings to causal chain
        for finding in findings:
            if finding['type'] in ['pqckey_not_found', 'key_category_mismatch', 'ec_payload_failure']:
                causal_chain.append({
                    'event': f'Root Cause Indicator: {finding["type"]}',
                    'timestamp': self._extract_timestamp_from_line(finding.get('context', '')),
                    'trigger': 'Pattern matching detected critical issue',
                    'effect': finding['match'],
                    'evidence': f"Line {finding['line_number']}: {finding['match']}",
                    'confidence': 90
                })
        
        # Identify contributing factors
        if any(f['type'] == 'pqckey_not_found' for f in findings):
            contributing_factors.append({
                'name': 'PQC Key Category Configuration',
                'category': 'Configuration',
                'impact_level': 'High',
                'evidence': 'PQC Public key category not found in BIOS',
                'mitigation': 'Update BIOS key table with correct PQC key categories'
            })
        
        if any(f['type'] == 'ec_payload_failure' for f in findings):
            contributing_factors.append({
                'name': 'EC Payload Signing Process',
                'category': 'Process',
                'impact_level': 'High',
                'evidence': 'EC payload PQC signing verification failed',
                'mitigation': 'Correct EC payload signing workflow in Dell Sign Server'
            })
        
        # Execution flow correlation
        normal_flow = "BIOS Init → Payload Verification → EC Init → System Boot"
        actual_flow = "BIOS Init → Payload Verification → **FAILURE**"
        deviation_point = failure_point.get('phase', 'Payload Verification')
        
        return {
            'causal_chain': causal_chain,
            'contributing_factors': contributing_factors,
            'execution_flow_correlation': {
                'normal_flow': normal_flow,
                'actual_flow': actual_flow,
                'deviation_point': deviation_point,
                'deviation_impact': 'Critical - prevents system boot/update',
                'root_cause_location': 'Payload verification phase with incorrect key category'
            }
        }
    
    def _extract_timestamp_from_line(self, line: str) -> str:
        """Extract timestamp from log line"""
        # Reuse timestamp extraction logic
        patterns = [
            r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})',
            r'(\d{2}:\d{2}:\d{2})',
            r'\[(\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})\]'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, line)
            if match:
                return match.group(1)
        
        return 'Unknown'
    
    def _get_line_context(self, content: str, position: int, context_lines: int = 3) -> List[str]:
        """Get context lines around a match"""
        lines = content.split('\n')
        line_num = content[:position].count('\n')
        
        start = max(0, line_num - context_lines)
        end = min(len(lines), line_num + context_lines + 1)
        
        return lines[start:end]
    
    def _analyze_codebase(self, ticket_data: Dict, attachment_analysis: Dict) -> Dict[str, Any]:
        """Correlate findings with codebase"""
        print("🔍 Correlating with codebase...")
        
        codebase_analysis = {
            'pqc_files': [],
            'flash_files': [],
            'platform_configs': [],
            'key_references': [],
            'missing_implementations': []
        }
        
        # Search for PQC-related files
        pqc_patterns = ['PQC', 'pqc', 'Post-Quantum', 'LMS', 'lms']
        for pattern in pqc_patterns:
            try:
                result = subprocess.run(
                    f'find {self.codebase_root} -name "*{pattern}*" -type f | head -10',
                    shell=True, capture_output=True, text=True
                )
                if result.stdout.strip():
                    codebase_analysis['pqc_files'].extend(result.stdout.strip().split('\n'))
            except:
                pass
        
        return codebase_analysis
    
    def _extract_keywords(self, ticket_data: Dict, attachment_analysis: Dict) -> List[str]:
        """Extract keywords from ticket data and attachments for GitHub search"""
        keywords = set()
        
        # Extract from ticket summary and description
        summary = ticket_data.get('summary', '')
        description = ticket_data.get('description', '')
        
        # Add technical terms
        technical_terms = [
            'PQC', 'LMS', 'signing', 'verification', 'BIOS', 'EC', 'NVMe', 'SPI',
            'flash', 'update', 'boot', 'crash', 'hang', 'failed', 'error',
            'payload', 'GUID', 'key', 'category', 'RSA', 'signature'
        ]
        
        for term in technical_terms:
            if term.lower() in summary.lower() or term.lower() in description.lower():
                keywords.add(term)
        
        # Extract from error patterns in attachments
        debug_logs = attachment_analysis.get('debug_logs', [])
        for log in debug_logs:
            findings = log.get('findings', [])
            for finding in findings:
                match_text = finding.get('match', '')
                # Extract GUID patterns
                guid_pattern = r'([0-9A-Fa-f-]{36})'
                guids = re.findall(guid_pattern, match_text)
                keywords.update(guids[:2])  # Limit to first 2 GUIDs
                
                # Extract error codes
                error_pattern = r'(0x[0-9A-Fa-f]+|[0-9A-Fa-f]{8})'
                errors = re.findall(error_pattern, match_text)
                keywords.update(errors[:2])  # Limit to first 2 error codes
        
        # Remove duplicates and return list
        return list(keywords)[:10]  # Limit to 10 keywords
    
    def _analyze_github_history(self, ticket_data: Dict, attachment_analysis: Dict) -> Dict[str, Any]:
        """Analyze GitHub history for similar issues and solutions"""
        if not self.github_tool:
            return {'error': 'GitHub integration not available'}
        
        print("🔍 Analyzing GitHub history for similar issues...")
        
        github_analysis = {
            'repository_matches': [],
            'code_changes': [],
            'commit_analysis': [],
            'similar_issues': [],
            'solution_patterns': []
        }
        
        try:
            # Extract keywords for search
            keywords = self._extract_keywords(ticket_data, attachment_analysis)
            print(f"🔍 Using keywords for GitHub search: {keywords}")
            
            # Search for similar issues in repositories
            for keyword in keywords[:5]:  # Limit to 5 keywords
                search_results = self.github_tool.comprehensive_search(
                    query=keyword,
                    include_repos=True,
                    include_code=True,
                    repo_types=['bios', 'ec', 'firmware', 'platform'],
                    years=['2025', '2024', '2023']
                )
                
                # Process repository matches
                if 'repositories' in search_results:
                    for repo in search_results['repositories'][:3]:  # Limit to 3 repos
                        github_analysis['repository_matches'].append({
                            'name': repo.get('name', 'Unknown'),
                            'description': repo.get('description', ''),
                            'language': repo.get('language', 'Unknown'),
                            'relevance': keyword
                        })
                
                # Process code changes
                if 'code_items' in search_results:
                    for code_item in search_results['code_items'][:3]:  # Limit to 3 code items
                        github_analysis['code_changes'].append({
                            'repository': code_item.get('repository', 'Unknown'),
                            'path': code_item.get('path', ''),
                            'match': code_item.get('text_matches', [''])[0][:200] if code_item.get('text_matches') else '',
                            'relevance': keyword
                        })
            
            # Analyze specific SHA1 commits if mentioned
            sha1_pattern = r'([0-9a-f]{40})'
            all_text = f"{ticket_data.get('summary', '')} {ticket_data.get('description', '')}"
            
            for log in attachment_analysis.get('debug_logs', []):
                findings = log.get('findings', [])
                for finding in findings:
                    all_text += f" {finding.get('match', '')}"
            
            sha1_matches = re.findall(sha1_pattern, all_text)
            for sha1 in sha1_matches[:2]:  # Limit to 2 SHA1 analysis
                commit_analysis = self._analyze_github_commit(sha1)
                if commit_analysis:
                    github_analysis['commit_analysis'].append(commit_analysis)
            
            # Identify solution patterns
            github_analysis['solution_patterns'] = self._identify_solution_patterns(
                github_analysis['code_changes'], 
                github_analysis['repository_matches']
            )
            
            print(f"✅ GitHub analysis completed: {len(github_analysis['repository_matches'])} repos, {len(github_analysis['code_changes'])} code changes")
            
        except Exception as e:
            github_analysis['error'] = f"GitHub analysis failed: {str(e)}"
            print(f"❌ GitHub analysis error: {str(e)}")
        
        return github_analysis
    
    def _analyze_github_commit(self, sha1: str) -> Dict[str, Any]:
        """Analyze specific GitHub commit"""
        if not self.github_tool:
            return None
        
        try:
            # Search for this specific commit across repositories
            search_results = self.github_tool.comprehensive_search(
                query=sha1,
                include_repos=False,
                include_code=True,
                repo_types=['bios', 'ec', 'firmware', 'platform'],
                years=['2025', '2024', '2023']
            )
            
            commit_info = {
                'sha1': sha1,
                'found': False,
                'repositories': [],
                'changes': [],
                'related_issues': []
            }
            
            if 'code_items' in search_results:
                commit_info['found'] = True
                for item in search_results['code_items']:
                    commit_info['repositories'].append(item.get('repository', 'Unknown'))
                    # Extract change context
                    if item.get('text_matches'):
                        commit_info['changes'].append({
                            'file': item.get('path', ''),
                            'context': item.get('text_matches', [''])[0][:200]
                        })
            
            return commit_info
            
        except Exception as e:
            print(f"❌ Failed to analyze commit {sha1}: {str(e)}")
            return None
    
    def _identify_solution_patterns(self, code_changes: List[Dict], repo_matches: List[Dict]) -> List[Dict]:
        """Identify common solution patterns from GitHub analysis"""
        patterns = []
        
        # Analyze code changes for common fix patterns
        fix_patterns = {
            'configuration_fix': ['config', 'setting', 'parameter', 'option'],
            'code_fix': ['fix', 'patch', 'change', 'modify', 'update'],
            'signing_fix': ['sign', 'signature', 'key', 'certificate', 'PQC', 'RSA'],
            'driver_fix': ['driver', 'device', 'hardware', 'interface'],
            'boot_fix': ['boot', 'startup', 'initialize', 'init']
        }
        
        pattern_counts = {pattern: 0 for pattern in fix_patterns.keys()}
        
        for change in code_changes:
            match_text = change.get('match', '').lower()
            for pattern, keywords in fix_patterns.items():
                if any(keyword in match_text for keyword in keywords):
                    pattern_counts[pattern] += 1
        
        # Create pattern recommendations
        for pattern, count in pattern_counts.items():
            if count > 0:
                patterns.append({
                    'type': pattern,
                    'frequency': count,
                    'description': self._get_pattern_description(pattern),
                    'recommendation': self._get_pattern_recommendation(pattern)
                })
        
        return sorted(patterns, key=lambda x: x['frequency'], reverse=True)[:3]
    
    def _get_pattern_description(self, pattern: str) -> str:
        """Get description for solution pattern"""
        descriptions = {
            'configuration_fix': 'Configuration parameter adjustments',
            'code_fix': 'Direct code modifications and patches',
            'signing_fix': 'Signature and key management fixes',
            'driver_fix': 'Driver and hardware interface fixes',
            'boot_fix': 'Boot sequence and initialization fixes'
        }
        return descriptions.get(pattern, 'Unknown pattern')
    
    def _get_pattern_recommendation(self, pattern: str) -> str:
        """Get recommendation for solution pattern"""
        recommendations = {
            'configuration_fix': 'Review and update configuration parameters in platform settings',
            'code_fix': 'Implement code changes identified in similar GitHub fixes',
            'signing_fix': 'Verify signing process and key categories match BIOS expectations',
            'driver_fix': 'Update or modify drivers based on GitHub solution patterns',
            'boot_fix': 'Adjust boot sequence and initialization order'
        }
        return recommendations.get(pattern, 'Follow GitHub solution patterns')
    
    def _analyze_git_log_history(self, ticket_data: Dict, attachment_analysis: Dict) -> Dict[str, Any]:
        """Analyze local git log history for related commits"""
        print("🔍 Analyzing local git log history...")
        
        git_analysis = {
            'related_commits': [],
            'file_changes': [],
            'author_patterns': {},
            'timeline_analysis': []
        }
        
        try:
            # Extract keywords for git search
            keywords = self._extract_keywords(ticket_data, attachment_analysis)
            
            # Search git log for commits with these keywords
            for keyword in keywords[:5]:  # Limit to 5 keywords
                try:
                    # Search commit messages
                    result = subprocess.run(
                        f'git log --oneline --grep="{keyword}" --since="2023-01-01" | head -5',
                        shell=True, capture_output=True, text=True, cwd=self.codebase_root
                    )
                    
                    if result.stdout.strip():
                        commits = result.stdout.strip().split('\n')
                        for commit in commits:
                            parts = commit.split(' ', 1)
                            if len(parts) == 2:
                                git_analysis['related_commits'].append({
                                    'sha': parts[0],
                                    'message': parts[1],
                                    'keyword': keyword
                                })
                    
                    # Search file content changes
                    result = subprocess.run(
                        f'git log -S"{keyword}" --oneline --since="2023-01-01" | head -3',
                        shell=True, capture_output=True, text=True, cwd=self.codebase_root
                    )
                    
                    if result.stdout.strip():
                        commits = result.stdout.strip().split('\n')
                        for commit in commits:
                            parts = commit.split(' ', 1)
                            if len(parts) == 2:
                                git_analysis['file_changes'].append({
                                    'sha': parts[0],
                                    'message': parts[1],
                                    'keyword': keyword,
                                    'type': 'content_change'
                                })
                
                except Exception as e:
                    print(f"⚠️  Git search failed for keyword '{keyword}': {str(e)}")
                    continue
            
            # Analyze author patterns
            authors = {}
            for commit in git_analysis['related_commits'] + git_analysis['file_changes']:
                try:
                    result = subprocess.run(
                        f'git log -1 --format="%an" {commit["sha"]}',
                        shell=True, capture_output=True, text=True, cwd=self.codebase_root
                    )
                    author = result.stdout.strip()
                    if author:
                        authors[author] = authors.get(author, 0) + 1
                except:
                    continue
            
            git_analysis['author_patterns'] = dict(sorted(authors.items(), key=lambda x: x[1], reverse=True)[:5])
            
            print(f"✅ Git log analysis completed: {len(git_analysis['related_commits'])} commits found")
            
        except Exception as e:
            git_analysis['error'] = f"Git log analysis failed: {str(e)}"
            print(f"❌ Git log analysis error: {str(e)}")
        
        return git_analysis

def main():
    """Main entry point for enhanced CPSE analyzer"""
    parser = argparse.ArgumentParser(description='Enhanced CPSE Debug Analysis with Dell Domain Knowledge & GitHub Integration')
    parser.add_argument('--ticket', required=True, help='CPSE ticket number (e.g., CPSE-46745)')
    parser.add_argument('--codebase', required=True, help='Path to codebase root')
    parser.add_argument('--dell-knowledge', help='Path to Dell domain knowledge file')
    parser.add_argument('--markdown-report', action='store_true', default=True, help='Generate Markdown report')
    parser.add_argument('--jira-tool', default='.windsurf/skills/jira-integration/scripts/jira_tool.py', help='Path to jira_tool.py')
    parser.add_argument('--language', choices=['en', 'zh-tw'], default='zh-tw', help='Report language: en (English) or zh-tw (Traditional Chinese)')
    parser.add_argument('--github-config', help='Path to GitHub integration config file')
    
    # New analysis options
    parser.add_argument('--deep-analysis', action='store_true', help='Enable deep analysis with GitHub and Git integration')
    parser.add_argument('--github-analysis', action='store_true', help='Enable GitHub history analysis')
    parser.add_argument('--git-analysis', action='store_true', help='Enable Git log analysis')
    parser.add_argument('--status-tracking', action='store_true', help='Enable status tracking and next steps')
    
    args = parser.parse_args()
    
    # Determine which analysis modes to enable
    github_analysis_enabled = args.github_analysis or args.deep_analysis
    git_analysis_enabled = args.git_analysis or args.deep_analysis
    
    with EnhancedCPSEAnalyzer(
        args.jira_tool, 
        args.codebase, 
        args.dell_knowledge, 
        args.language
    ) as analyzer:
        result = analyzer.analyze_ticket_enhanced(
            args.ticket, 
            args.markdown_report,
            args.deep_analysis,
            github_analysis_enabled,
            git_analysis_enabled
        )
        
        if 'error' in result:
            print(f"❌ Analysis failed: {result['error']}")
            if 'details' in result:
                print(f"Details: {result['details']}")
            return 1
        
        print("✅ Enhanced analysis completed successfully!")
        
        if args.markdown_report and 'report_path' in result:
            print(f"📄 Markdown report: {result['report_path']}")
        
        # Print summary
        summary = result.get('summary', {})
        print(f"\n📋 Analysis Summary:")
        print(f"   Issue Classification: {summary.get('issue_classification', 'Unknown')}")
        print(f"   Platform Context: {summary.get('platform_context', 'Unknown')}")
        print(f"   Dell Escalation Required: {summary.get('dell_escalation_required', False)}")
        
        # Print GitHub insights if available
        github_insights = summary.get('github_insights', [])
        if github_insights:
            print(f"   GitHub Insights: {len(github_insights)} insights identified")
            for insight in github_insights[:3]:  # Show first 3 insights
                print(f"     - {insight}")
        
        # Print Git insights if available
        git_insights = summary.get('git_insights', [])
        if git_insights:
            print(f"   Git Log Insights: {len(git_insights)} insights identified")
            for insight in git_insights[:3]:  # Show first 3 insights
                print(f"     - {insight}")
        
        dell_insights = summary.get('dell_specific_insights', [])
        if dell_insights:
            print(f"   Dell Insights: {len(dell_insights)} insights identified")
        
        solutions = result.get('solutions', [])
        if solutions:
            print(f"   Recommended Solutions: {len(solutions)} solutions generated")
        
        return 0

if __name__ == '__main__':
    sys.exit(main())
