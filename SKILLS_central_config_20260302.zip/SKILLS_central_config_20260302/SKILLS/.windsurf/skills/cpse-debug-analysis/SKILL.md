---
name: cpse-debug-analysis
description: Advanced CPSE JIRA issue deep analysis with Dell domain knowledge integration, GitHub history analysis, and standardized Markdown reporting. Use when analyzing CPSE issues, investigating root causes, or generating comprehensive debug reports.
---

# CPSE Debug Analysis Skill

This skill provides comprehensive deep analysis capabilities for CPSE (Common Platform Systems Engineering) JIRA issues, featuring both standard analysis and enhanced Dell domain knowledge integration with professional Markdown reporting, **plus GitHub integration for historical solution analysis**.

## Core Capabilities

### **Primary Analysis Functions**
- **Deep Issue Analysis**: Multi-dimensional CPSE ticket analysis with technical context
- **Log Processing**: Automated download and analysis of debug logs and attachments  
- **Problem Localization**: Pinpoint exact failure points in BIOS/UEFI update flows
- **Codebase Correlation**: Map issues to specific source code components and configurations
- **Solution Architecture**: Provide detailed, actionable fix recommendations with code examples
- **Dell Domain Integration**: Leverage proprietary Dell knowledge for enhanced analysis
- **Standardized Reporting**: Generate consistent Markdown-formatted analysis reports
- **🆕 GitHub History Analysis**: Search GitHub repositories for similar issues and solutions
- **🆕 SHA1 Commit Analysis**: Analyze specific commits mentioned in tickets
- **🆕 Git Log Integration**: Search local repository history for related changes
- **🆕 Historical Pattern Recognition**: Identify solution patterns from GitHub and Git history

### **🆕 Resolved Issue Analysis**
- **Solution Status Detection**: Automatically detect if issue is Closed/Development Done
- **Actual Solution Extraction**: Extract Resolution Details and implementation comments
- **Predicted vs Actual Comparison**: Compare analysis predictions with implemented solutions
- **Learning Experience Generation**: Document lessons learned and best practices
- **Solution Efficiency Analysis**: Evaluate complexity predictions vs actual implementation

### **Analysis Modes**

#### **Standard Analysis Mode**
- **General CPSE Analysis Framework**: BIOS/UEFI, hardware integration, platform configurations
- **Pattern Recognition**: Automated identification of common failure patterns
- **Codebase Mapping**: Direct correlation with source code components
- **Solution Generation**: Technical fix recommendations

#### **Enhanced Analysis Mode**
- **Dell Knowledge Integration**: Automatic consultation of `dell_domain_knowledge` skill
- **Platform-Specific Analysis**: Apply Dell platform configuration insights
- **Signing Process Understanding**: Leverage Dell signing infrastructure knowledge
- **Professional Reporting**: Standardized Markdown reports with Dell context

#### **🆕 Deep Analysis Mode with GitHub Integration**
- **GitHub Repository Search**: Find relevant repositories and code changes
- **Historical Solution Analysis**: Identify similar issues and their fixes
- **SHA1 Commit Tracking**: Analyze specific commits mentioned in tickets
- **Git Log Correlation**: Search local repository for related changes
- **Pattern Recognition**: Identify common solution approaches
- **Expert Author Identification**: Find developers with relevant expertise

### **General CPSE Analysis Framework**
- **BIOS/UEFI Issues**: Flash updates, driver initialization, protocol failures
- **Hardware Integration**: Memory, storage, power management, thermal issues
- **Platform Configurations**: CongoLnlOne, VisionWCL, SlatePtlOne, and other Dell platforms
- **Firmware Dependencies**: Driver conflicts, dependency resolution, initialization sequences
- **Performance & Stability**: Boot issues, system stability, performance degradation
- **Security & Authentication**: Secure boot, encryption, signature verification
- **PQC (Post-Quantum Cryptography)**: LMS signing, key management, protocol failures
- **Manufacturing & Testing**: DDA testing, manufacturing mode, validation failures

## Usage Instructions

### **Standard Analysis**
```bash
# Basic CPSE analysis (English)
python scripts/cpse_analyzer.py --ticket CPSE-XXXXX --codebase ../../

# Basic CPSE analysis (Traditional Chinese)
python scripts/cpse_analyzer.py --ticket CPSE-XXXXX --codebase ../../ --language zh-tw

# Manual analysis approach
py  --jira-tool .windsurf/skills/jira-integration/scripts/jira_tool.py analyze --key CPSE-XXXXX
```

### **Enhanced Analysis with Dell Knowledge**
```bash
# Enhanced analysis with Dell domain knowledge (English)
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-XXXXX --codebase ../../ --dell-knowledge ../dell_domain_knowledge/SKILL.md --markdown-report

# Enhanced analysis with Dell domain knowledge (Traditional Chinese)
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-XXXXX --codebase ../../ --dell-knowledge ../dell_domain_knowledge/SKILL.md --markdown-report --language zh-tw
```

### **🆕 Deep Analysis with GitHub Integration**
```bash
# Deep analysis with GitHub and Git history (English)
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-XXXXX --codebase ../../ --deep-analysis --language en

# Deep analysis with GitHub and Git history (Traditional Chinese)
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-XXXXX --codebase ../../ --deep-analysis --language zh-tw

# GitHub analysis only
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-XXXXX --codebase ../../ --github-analysis

# Git log analysis only
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-XXXXX --codebase ../../ --git-analysis

# Both GitHub and Git analysis
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-XXXXX --codebase ../../ --github-analysis --git-analysis
```

### **Skill Invocation**
```
@cpse_debug_analysis analyze CPSE-46745 with standard mode
@cpse_debug_analysis analyze CPSE-46745 with enhanced Dell knowledge integration
@cpse_debug_analysis generate professional Markdown report for CPSE-46745
@cpse_debug_analysis analyze CPSE-46745 in Traditional Chinese
@cpse_debug_analysis analyze CPSE-46745 with enhanced Dell knowledge integration in Traditional Chinese
@cpse_debug_analysis deep analyze CPSE-46745 with GitHub integration and log processing
@cpse_debug_analysis analyze CPSE-46745 with current status tracking and next steps
@cpse_debug_analysis analyze CPSE-46745 with GitHub history analysis and SHA1 commit tracking
```

## Usage Guidelines (Agent Behavior)

### **Command Priority Guidelines**
When users ask for CPSE analysis:
1. **First Priority**: Use `--deep-analysis` for comprehensive analysis with GitHub and Git integration
2. **Alternative**: Use `--github-analysis` or `--git-analysis` for specific historical analysis
3. **Fallback**: Use standard enhanced analysis for Dell knowledge integration
4. **Basic**: Use standard analysis for simple ticket review

### **Expected Output Format**
- **Structure**: Executive Summary → Technical Analysis → GitHub/Git History → Solutions → Implementation Steps
- **Language**: Bilingual support (Traditional Chinese [Default], English)
- **Sections**: Clear headers with emojis and consistent formatting
- **Reports**: Automatic saving to `.windsurf/Reports/` with timestamped filenames
- **GitHub Integration**: Repository matches, code changes, SHA1 analysis, solution patterns
- **Git Integration**: Local commits, author expertise, content changes

### **Common User Requests & Commands**
| User Request Pattern | Recommended Command |
|---------------------|---------------------|
| "Analyze CPSE-XXXXX" | `--deep-analysis --language zh-tw` |
| "Quick analysis" | Standard enhanced analysis |
| "GitHub history" | `--github-analysis` |
| "Find similar issues" | `--deep-analysis` |
| "SHA1 analysis" | `--deep-analysis` (auto-detects SHA1) |
| "Expert identification" | `--git-analysis` |
| "English report" | `--language en` |
| "Chinese report" | `--language zh-tw` (default) |

### **Critical Requirements**
- **ALWAYS include `--deep-analysis` for comprehensive GitHub/Git analysis**
- **ALWAYS save reports to `.windsurf/Reports/` following skill_guides standards**
- **ALWAYS use bilingual format (English + Traditional Chinese)**
- **NEVER create temporary files - use in-memory processing**
- **ALWAYS validate GitHub integration availability before use**
- **ALWAYS provide graceful degradation if GitHub/Git analysis fails**

## Quick Start Section

### **For New Users (Immediate Results)**
```bash
# Comprehensive analysis with GitHub integration (Recommended)
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-46745 --codebase . --deep-analysis

# English version (if needed)
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-46745 --codebase . --deep-analysis --language en
```

### **Quick Analysis Options**
```bash
# GitHub-focused analysis
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-46745 --codebase . --github-analysis

# Git history analysis  
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-46745 --codebase . --git-analysis

# Standard Dell knowledge analysis (Default zh-tw)
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-46745 --codebase .
```

## Report Generation Compliance

### **skill_guides Compliance**
This skill follows skill_guides Report Generation Standards:
- **✅ Reads skill_guides/SKILL.md** for compliance requirements
- **✅ Saves reports to `.windsurf/Reports/`** (not `.windsurf/skills/Reports/`)
- **✅ Uses bilingual format** (English + Traditional Chinese)
- **✅ Includes metadata headers** with timestamps and skill information
- **✅ Uses timestamped filenames** to avoid overwrites
- **✅ Implements centralized report generation** following Reference Implementation Pattern

### **Report Structure Standards**
Each generated report includes:
```markdown
---
# CPSE-[TICKET] Deep Analysis Report
**Generated:** [timestamp]
**Description:** CPSE-[TICKET] Deep Analysis Report
**Skill:** cpse_debug_analysis
---

# [Main Content - English Structure]
## 📊 GitHub History Analysis (Enhancement Search)
## 📝 Git Log History Analysis
## 📋 BilingualSummary / Bilingual Summary
```

### **Automatic Report Saving**
- **Location**: `.windsurf/Reports/`
- **Naming**: `CPSE-[TICKET]_Deep_Analysis_Report_[timestamp].md`
- **Encoding**: UTF-8 for proper Chinese character support
- **Metadata**: Complete header with generation information

## 🆕 GitHub Integration Features

### **SHA1 Commit Analysis**
- **Automatic Detection**: Extract SHA1 hashes from ticket descriptions and attachments
- **Cross-Repository Search**: Search across all BIOS, EC, firmware, and platform repositories
- **Change Context**: Analyze specific code changes and their impact
- **Solution Insights**: Identify how similar commits fixed related issues

### **Similar Issue Search**
- **Keyword Extraction**: Automatically extract technical keywords from tickets
- **Repository Matching**: Find relevant repositories based on issue content
- **Code Change Analysis**: Identify similar code changes and fixes
- **Pattern Recognition**: Detect common solution approaches

### **Historical Solution Patterns**
- **Solution Classification**: Categorize fixes (configuration, code, signing, driver, boot)
- **Frequency Analysis**: Identify most common solution patterns
- **Recommendation Engine**: Suggest solutions based on historical success
- **Evidence-Based**: Provide GitHub evidence for recommended solutions

### **Git Log Integration**
- **Local Repository Search**: Search local git history for related commits
- **Author Expertise**: Identify developers with relevant experience
- **Content Changes**: Find commits that modified similar code
- **Timeline Analysis**: Track issue evolution over time

## Standardized Analysis Report Format

### **Enhanced Report Structure with GitHub Integration**

The enhanced reports now include:

```markdown
## 📊 GitHub History Analysis (Enhancement Search)
### Related Repository Discovery
#### Repository Match Results
#### Code Changes Discovered
#### Enhancement History Pattern Analysis
#### SHA1 Commit Analysis

## 📝 Git Log History Analysis
### Related Commits in Local Repository
#### Related Commit Logging
#### File Content Changes
#### Author Expertise Patterns

## 🎯 Actual Solution Analysis (For Resolved Issues Only)
### Solution Status
- **Issue Status**: Closed/Development Done Detection
- **Implementer**: Engineer responsible for solution
- **Solution Time**: Timeline from Development to Close

### Specific Implementation Steps
- **Resolution Details**: Extract JIRA solution details
- **Key Comments**: Important discussions during implementation
- **Implementation Timeline**: Implementation process of solution

### Predicted vs Actual Comparison
- **Predicted Solution**: Analysis suggested solution
- **Actual Implementation**: Actually executed solution
- **Complexity Evaluation**: Estimated vs actual complexity comparison
- **Efficiency Analysis**: Solution time and resource usage evaluation

### Learning Experience and Best Practices
- **Issue Classification Fix**: Issue re-classification based on actual solution
- **Solution Patterns**: Identify valid solution patterns
- **Prevention Measures**: Prevention suggestions based on learning experience
- **Process Improvement**: Future similar issue handling process suggestions
```

### **Solution Integration**

Solutions now include GitHub and Git context:

```markdown
#### Solution 1: [Solution Name]
- **Priority**: HIGH
- **GitHub Context**: Found 3 similar fixes on GitHub
- **Git Context**: Found 5 related commits in local repository
- **GitHub Evidence**: DellPkgs/DellPlatformPkgs/NB/CongoLnlOnePkg/...
- **Git Experts**: [Author names with relevant experience]
```

## Multi-Language Support

### **Language Options**
This skill supports multiple output languages for Dell teams:

- **Traditional Chinese** (`zh-tw`) - **Default**: For Dell Taiwan and APAC teams
- **English** (`en`): Standard international format

### **Language Parameter Usage**
```bash
# Generate report in specific language
@cpse_debug_analysis analyze CPSE-XXXXX in [Language]

# Enhanced analysis with language specification
@cpse_debug_analysis analyze CPSE-XXXXX with enhanced Dell knowledge integration in [Language]

# Deep analysis with GitHub integration and language specification
@cpse_debug_analysis deep analyze CPSE-XXXXX with GitHub integration in [Language]

# Script-based language selection
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-XXXXX --language [language-code]
```

## Command Line Options

### **New GitHub Integration Options**
```bash
--deep-analysis          # Enable both GitHub and Git analysis
--github-analysis        # Enable GitHub history analysis only
--git-analysis           # Enable Git log analysis only
--github-config PATH     # Path to GitHub integration config file
--status-tracking        # Enable status tracking and next steps
--resolved-analysis      # Enable resolved issue analysis (auto-detects closed issues)
--compare-solutions      # Compare predicted vs actual solutions for closed issues
--learning-experience    # Generate learning experience and best practices section
```

### **Complete Command Examples**
```bash
# Full deep analysis with all features
python scripts/cpse_analyzer_enhanced.py \
  --ticket CPSE-46745 \
  --codebase ../../ \
  --dell-knowledge ../dell_domain_knowledge/SKILL.md \
  --deep-analysis \
  --status-tracking \
  --resolved-analysis \
  --compare-solutions \
  --learning-experience

# Analysis of resolved issue with learning experience
python scripts/cpse_analyzer_enhanced.py \
  --ticket CPSE-46745 \
  --codebase ../../ \
  --resolved-analysis \
  --learning-experience \
  --language zh-tw

# Quick check if issue is resolved and extract actual solution
python scripts/cpse_analyzer_enhanced.py \
  --ticket CPSE-46745 \
  --codebase ../../ \
  --resolved-analysis \
  --compare-solutions

# GitHub-focused analysis
python scripts/cpse_analyzer_enhanced.py \
  --ticket CPSE-46745 \
  --codebase ../../ \
  --github-analysis \
  --github-config .windsurf/skills/github-integration/config.toml \
  --language zh-tw

# Git history-focused analysis
python scripts/cpse_analyzer_enhanced.py \
  --ticket CPSE-46745 \
  --codebase ../../ \
  --git-analysis \
  --language zh-tw
```

## Dependencies and Integration

### **Required Dependencies**
- **jira_integration skill**: For JIRA ticket analysis
- **dell_domain_knowledge skill**: For Dell-specific domain knowledge
- **🆕 github_integration skill**: For GitHub repository and code search
- **Local Git Repository**: For git log analysis

### **Configuration Requirements**
- **GitHub Token**: Configure in `github_integration/config.toml`
- **JIRA Access**: Configure in `jira_integration/config.toml`
- **Dell Knowledge**: Path to `dell_domain_knowledge/SKILL.md`

### **Report Storage**
- **Standard Location**: `.windsurf/Reports/` following skill_guides standards
- **Timestamped Filenames**: Avoid overwrites with unique timestamps
- **Metadata Headers**: Include generation information and skill details
- **UTF-8 Encoding**: Proper support for Traditional Chinese characters

## Quality Assurance Checklist

Before finalizing analysis, ensure:
- [ ] All debug attachments have been processed and analyzed
- [ ] Key error patterns have been identified and categorized
- [ ] Technical findings correlate with codebase components
- [ ] Solutions are specific and actionable with file paths
- [ ] Implementation guidance includes code examples
- [ ] Verification strategy is clearly defined
- [ ] Dell domain knowledge applied when relevant
- [ ] Professional Markdown report format used
- [ ] Current discussion status analyzed with blocking points
- [ ] Log analysis includes attachment processing
- [ ] Codebase analysis identifies specific files and components
- [ ] Solution architecture provides implementation details
- [ ] Next steps and recommendations are clearly defined
- [ ] 🆕 GitHub analysis completed when requested
- [ ] 🆕 SHA1 commits analyzed if mentioned in ticket
- [ ] 🆕 Git log history searched for related changes
- [ ] 🆕 Historical solution patterns identified
- [ ] 🆕 GitHub evidence provided for solutions
- [ ] 🆕 Git expert authors identified

## Error Handling and Edge Cases

### **GitHub Integration Issues**
- **GitHub Token Missing**: Graceful fallback with warning message
- **Rate Limiting**: Handle API limits with retry logic
- **Repository Access**: Skip private repositories without access
- **Network Issues**: Continue analysis without GitHub data

### **Git Log Analysis Issues**
- **Not a Git Repository**: Skip git analysis with warning
- **No Relevant Commits**: Report no findings gracefully
- **Large Repository**: Limit search scope for performance
- **Permission Issues**: Handle git command failures gracefully

---

*Enhanced CPSE Analysis Skill Version: 3.1*
*Multi-Language Support: Enabled (Traditional Chinese [Default], English)*
*Deep Analysis Components: Log Processing, Codebase Investigation, Status Tracking*
*GitHub Integration: Repository Search, Commit Analysis, Historical Patterns*
*🆕 Resolved Issue Analysis: Solution Status Detection, Learning Experience Generation*
*Dell Domain Knowledge Integration: Enabled*
*Standardized Reporting: Markdown Format*
*Session Independence: Guaranteed*

## Standardized Analysis Report Format
### **CPSE Deep Analysis Report Template (English)**

```markdown
# CPSE-[TICKET] Deep Analysis Report

## Executive Summary
**Issue**: [Brief issue description]
**Platform**: [Affected Dell platform]
**Root Cause**: [Primary technical finding]
**Impact**: [Business/technical impact]
**Priority**: [HIGH/MEDIUM/LOW]

## Technical Analysis

### Issue Classification
- **Primary Issue Type**: [Category]
- **Secondary Issue Type**: [Category]
- **Platform**: [Specific Dell platform]
- **Configuration**: [Relevant settings]

### Key Technical Findings
#### Critical Error Patterns
- **Pattern 1**: [Error pattern with log excerpt]
- **Pattern 2**: [Error pattern with log excerpt]
- **Pattern 3**: [Error pattern with log excerpt]

#### Dell Domain Context
- **Signing Infrastructure**: [Dell-specific signing details]
- **Platform Configuration**: [Platform-specific insights]
- **Internal Workflow**: [Dell process context]

### Root Cause Analysis
#### Technical Root Cause
[Detailed technical explanation with Dell domain knowledge]

#### Contributing Factors
- [Factor 1 with Dell context]
- [Factor 2 with Dell context]
- [Factor 3 with Dell context]

## Solution Architecture

### Recommended Solutions
#### Solution 1: [Solution Name]
- **Priority**: [HIGH/MEDIUM/LOW]
- **Description**: [Solution description]
- **Implementation**: [Code/configuration changes]
- **Files to Modify**: [Specific file paths]
- **Verification**: [Testing approach]

#### Solution 2: [Solution Name] (Alternative)
- **Priority**: [HIGH/MEDIUM/LOW]
- **Description**: [Alternative solution]
- **Implementation**: [Implementation details]
- **Files to Modify**: [File paths]
- **Verification**: [Testing approach]

### Dell-Specific Considerations
- **Signing Process**: [Dell signing workflow impact]
- **Platform Impact**: [Platform-specific considerations]
- **Internal Dependencies**: [Dell internal system dependencies]

## Implementation Steps

### Phase 1: Immediate Actions (Critical)
1. [Action 1 with Dell context]
2. [Action 2 with Dell context]
3. [Action 3 with Dell context]

### Phase 2: Short-term Fixes (High)
1. [Action 1]
2. [Action 2]
3. [Action 3]

### Phase 3: Long-term Improvements (Medium)
1. [Action 1]
2. [Action 2]
3. [Action 3]

## Risk Assessment

### High Risk Factors
- [Risk factor 1 with Dell context]
- [Risk factor 2 with Dell context]

### Mitigation Strategies
- [Mitigation 1]
- [Mitigation 2]
- [Mitigation 3]

## Verification Strategy

### Testing Requirements
- [Test requirement 1]
- [Test requirement 2]
- [Test requirement 3]

### Success Criteria
- [Success criterion 1]
- [Success criterion 2]
- [Success criterion 3]

## Dell Internal References

### Related Systems
- **JIRA**: [CPSE ticket references]
- **PIMS**: [Product Issue Management System references]
- **CBDCIT**: [Cross-Build Dependency references]

### Subject Matter Experts
- **Team**: [Dell team responsible]
- **Contact**: [SME contact information]

## Appendices

### Technical Details
#### Log Analysis
[Relevant log excerpts with analysis]

#### Code References
[Code snippets and file locations]

#### Configuration Details
[Platform-specific configurations]

### Dell Domain Knowledge
#### Applied Knowledge Areas
- [Knowledge area 1 from dell_domain_knowledge skill]
- [Knowledge area 2 from dell_domain_knowledge skill]

#### Internal Process Context
[Dell-specific process information]

---
*Report Generated: [Timestamp]*
*Analysis Engine: Enhanced CPSE Debug Analysis*
*Dell Domain Knowledge Version: [Version]*
```

### **CPSE Deep Analysis Report Template (Traditional Chinese)**

```markdown
# CPSE-[TICKET] Deep Analysis Report

## Executive Summary
**Issue**: [Brief issue description]
**Platform**: [Affected Dell platform]
**Root Cause**: [Primary technical finding]
**Impact**: [Business/technical impact]
**Priority**: [HIGH/MEDIUM/LOW]

## Technical Analysis

### Issue Classification
- **Primary Issue Type**: [Category]
- **Secondary Issue Type**: [Category]
- **Platform**: [Specific Dell platform]
- **Configuration**: [Relevant settings]

### Key Technical Findings
#### Critical Error Patterns
- **Pattern 1**: [Error pattern with log excerpt]
- **Pattern 2**: [Error pattern with log excerpt]
- **Pattern 3**: [Error pattern with log excerpt]

#### Dell Domain Context
- **Signing Infrastructure**: [Dell-specific signing details]
- **Platform Configuration**: [Platform-specific insights]
- **Internal Workflow**: [Dell process context]

### Root Cause Analysis
#### Technical Root Cause
[Detailed technical explanation with Dell domain knowledge]

#### Contributing Factors
- [Factor 1 with Dell context]
- [Factor 2 with Dell context]
- [Factor 3 with Dell context]

## Current Status Analysis

### Current Discussion Phase
- **Latest Activity**: [Summary of discussions in last 7-14 days]
- **Main Participants**: [Team members participating in current discussions]
- **Key Decisions**: [Critical decisions made or pending]

### Current Blocking Points
#### Main Blocking Factors
- **Blocker 1**: [Specific blocking reason and impact]
- **Blocker 2**: [Specific blocking reason and impact]
- **Blocker 3**: [Specific blocking reason and impact]

#### Status Indicators
- **Waiting for Solution**: [Technical solution development status]
- **Waiting for Logs**: [Debug information collection status]
- **Waiting for Validation**: [Test result verification status]
- **Action Required**: [Actions needed immediately]

### Next Steps Recommendations
#### Immediate Actions (Critical)
1. [Specific actions needed immediately]
2. [Responsible person and deadline]
3. [Expected results and verification methods]

#### Short-term Direction (High Priority)
1. [Development direction for next 1-2 weeks]
2. [Resource requirements and allocation]
3. [Risk assessment and mitigation]

#### Long-term Planning (Medium Priority)
1. [Long-term solution architecture]
2. [Cross-team collaboration requirements]
3. **Technical Debt**: [Technical debt items to resolve]

## Solution Architecture

### Recommended Solutions
#### Solution 1: [Solution Name]
- **Priority**: [HIGH/MEDIUM/LOW]
- **Description**: [Solution description]
- **Implementation**: [Code/configuration changes]
- **Files to Modify**: [Specific file paths]
- **Verification**: [Testing methods]

#### Solution 2: [Solution Name] (Alternative)
- **Priority**: [HIGH/MEDIUM/LOW]
- **Description**: [Alternative solution]
- **Implementation**: [Implementation details]
- **Files to Modify**: [File paths]
- **Verification**: [Testing methods]

### Dell-Specific Considerations
- **Signing Process**: [Dell signing workflow impact]
- **Platform Impact**: [Platform-specific considerations]
- **Internal Dependencies**: [Dell internal system dependencies]

## Implementation Steps

### Phase 1: Immediate Actions (Critical)
1. [Action 1 with Dell context]
2. [Action 2 with Dell context]
3. [Action 3 with Dell context]

### Phase 2: Short-term Fixes (High)
1. [Action 1]
2. [Action 2]
3. [Action 3]

### Phase 3: Long-term Improvements (Medium)
1. [Action 1]
2. [Action 2]
3. [Action 3]

## Risk Assessment

### High Risk Factors
- [Risk factor 1 with Dell context]
- [Risk factor 2 with Dell context]

### Mitigation Strategies
- [Mitigation 1]
- [Mitigation 2]
- [Mitigation 3]

## Verification Strategy

### Testing Requirements
- [Test requirement 1]
- [Test requirement 2]
- [Test requirement 3]

### Success Criteria
- [Success criterion 1]
- [Success criterion 2]
- [Success criterion 3]

## Dell Internal References

### Related Systems
- **JIRA**: [CPSE ticket references]
- **PIMS**: [Product Issue Management System references]
- **CBDCIT**: [Cross-Build Dependency references]

### Subject Matter Experts
- **Team**: [Dell team responsible]
- **Contact**: [SME contact information]

## Appendices

### Technical Details
#### Log Analysis
[Relevant log excerpts with analysis]

#### Code References
[Code snippets and file locations]

#### Configuration Details
[Platform-specific configurations]

### Dell Domain Knowledge
#### Applied Knowledge Areas
- [Knowledge area 1 from dell_domain_knowledge skill]
- [Knowledge area 2 from dell_domain_knowledge skill]

#### Internal Process Context
[Dell-specific process information]

---
*Report Generated: [Timestamp]*
*Analysis Engine: Enhanced CPSE Debug Analysis*
*Dell Domain Knowledge Version: [Version]*
```

## Multi-Language Support

### **Language Options**
This skill supports multiple output languages for Dell teams:

- **Traditional Chinese** (`zh-tw`) - **Default**: For Dell Taiwan and APAC teams
- **English** (`en`): Standard international format

### **Language Parameter Usage**
```bash
# Generate report in specific language
@cpse_debug_analysis analyze CPSE-XXXXX in [Language]

# Enhanced analysis with language specification
@cpse_debug_analysis analyze CPSE-XXXXX with enhanced Dell knowledge integration in [Language]

# Script-based language selection
python scripts/cpse_analyzer_enhanced.py --ticket CPSE-XXXXX --language [language-code]
```

### **Supported Language Commands**
- `in Traditional Chinese` / `in zh-tw` (Default)
- `in English` / `in en`

### **Template Localization**
Each language includes:
- **Localized Section Headers**: Executive Summary → ExecuteSummary
- **Technical Terminology**: Maintained in English for consistency
- **Cultural Adaptation**: Region-specific business context
- **Dell Branding**: Consistent Dell terminology across languages

### **Current Status Analysis Section**
Enhanced reports include analysis of current discussion status and blocking points:

#### **Status Tracking**
- **Current Discussion Phase**: Analysis of recent JIRA comments and activities
- **Blocking Points**: Identification of current blockers (waiting for solutions, logs, validation)
- **Next Steps**: Recommended immediate actions and directions

#### **Status Indicators**
- **Waiting for Solution**: Technical solutions under development
- **Waiting for Logs**: Debug information pending collection
- **Waiting for Validation**: Test results pending verification
- **Action Required**: Immediate team action needed

#### **Progress Tracking**
- **Recent Activities**: Summary of last 7-14 days of development
- **Key Decision Points**: Critical decisions made or pending
- **Resource Allocation**: Current team assignments and responsibilities

### **Deep Analysis Components**
Enhanced analysis includes comprehensive technical investigation:

#### **Log Analysis**
- **JIRA Attachment Processing**: Automatic download and analysis of all attachments
- **Screenshot Analysis**: Error message extraction from UI screenshots
- **Driver Package Analysis**: Wireless driver package content and compatibility
- **Hardware ID Extraction**: Device identification and chipset information

#### **Codebase Analysis**
- **BIOSConnect Module Analysis**: Network stack and wireless integration components
- **WCL Integration Files**: Intel Wireless Connection Library configuration and setup
- **Protocol Analysis**: Network protocols and launcher protocols for BIOSConnect
- **Platform Configuration**: XML configuration files and binary components

#### **Solution Architecture**
- **Specific Code Modifications**: Actual file paths and code examples
- **Configuration Changes**: TOML/INF file modifications with examples
- **Error Handling Enhancement**: Robust error detection and fallback mechanisms
- **Implementation Guidance**: Step-by-step technical implementation details

## Dell Knowledge Integration

### **Automatic Domain Knowledge Retrieval**
When using enhanced analysis mode:
1. **Issue Classification**: Match against known Dell failure patterns
2. **Knowledge Consultation**: Reference relevant sections in `dell_domain_knowledge` skill
3. **Context Application**: Apply platform-specific configurations
4. **Enhanced Solutions**: Generate Dell-appropriate recommendations

### **Dell-Specific Pattern Recognition**

#### **PQC Signing Issues**
```powershell
# Enhanced PQC analysis with Dell context
Select-String -Pattern "(PQC.*key.*not.*found|LMS.*verification.*failed|540B32B0-808D-47E1-A188-76AA7CF1BB93)" -Path debug.log

# Consult Dell domain knowledge for EC payload information
Reference: dell_domain_knowledge skill -> Dell Signing Infrastructure -> Key Category System
```

#### **EC Payload Issues**
```powershell
# EC-specific pattern analysis
Select-String -Pattern "5A0D5E58.*Embedded Controller|EC.*Primary|EC.*Failsafe" -Path debug.log

# Apply Dell EC knowledge
Reference: dell_domain_knowledge skill -> Platform Payload Classification -> EC Payloads
```

#### **Platform Configuration Issues**
```powershell
# Platform-specific analysis
Select-String -Pattern "CongoLnlOne|SECURITY_PFS_PQC_SUPPORT.*TRUE" -Path debug.log

# Use platform configuration knowledge
Reference: dell_domain_knowledge skill -> Platform Configurations -> CongoLnlOne Platform
```

## Supporting Tools

### **Standard Analyzer**
- **Location**: `scripts/cpse_analyzer.py`
- **Function**: Basic CPSE analysis without Dell knowledge
- **Output**: Technical analysis and recommendations

### **Enhanced Analyzer**
- **Location**: `scripts/cpse_analyzer_enhanced.py`
- **Function**: Advanced analysis with Dell knowledge integration
- **Output**: Professional Markdown reports with Dell context

## Session Independence Guarantee

### **Cross-Session Consistency**
This skill maintains consistency across different AI sessions through:

1. **Standardized Templates**: Fixed Markdown report format
2. **Knowledge Integration**: Consistent Dell domain knowledge reference
3. **Deterministic Workflow**: Clear step-by-step analysis process
4. **External Knowledge Source**: Relies on `dell_domain_knowledge` skill for domain context

## Quality Assurance Checklist

Before finalizing analysis, ensure:
- [ ] All debug attachments have been processed and analyzed
- [ ] Key error patterns have been identified and categorized
- [ ] Technical findings correlate with codebase components
- [ ] Solutions are specific and actionable with file paths
- [ ] Implementation guidance includes code examples
- [ ] Verification strategy is clearly defined
- [ ] Dell domain knowledge applied when relevant
- [ ] Professional Markdown report format used
- [ ] Current discussion status analyzed with blocking points
- [ ] Log analysis includes attachment processing
- [ ] Codebase analysis identifies specific files and components
- [ ] Solution architecture provides implementation details
- [ ] Next steps and recommendations are clearly defined
- [ ] **For Resolved Issues**: Issue status detected (Closed/Development Done)
- [ ] **For Resolved Issues**: Actual solution extracted from Resolution Details
- [ ] **For Resolved Issues**: Predicted vs actual solution comparison completed
- [ ] **For Resolved Issues**: Learning experience and best practices documented
- [ ] **For Resolved Issues**: Solution efficiency analysis included

## Error Handling and Edge Cases

### **Insufficient Data**
- **Missing Logs**: Request additional debug information
- **Incomplete Attachments**: Identify missing technical files
- **Vague Descriptions**: Ask for specific error scenarios and reproduction steps

### **Complex Multi-Issue Scenarios**
- **Cross-Platform Issues**: Analyze multiple platform configurations
- **Dependency Conflicts**: Identify competing requirements
- **Legacy Compatibility**: Balance new features with existing functionality

### **Dell-Specific Escalation Criteria**
- **Security Implications**: Flag issues with Dell security impact
- **Platform-Wide Impact**: Identify issues affecting multiple Dell platforms
- **Signing Infrastructure**: Prioritize issues affecting Dell signing processes
- **Internal Dependencies**: Flag issues with Dell internal system dependencies

---

## skill_guides Compliance Statement

### **Mandatory Requirements Compliance**
This skill fully complies with skill_guides/SKILL.md mandatory requirements:

- **✅ Core Integration Architecture**: Uses `github_integration`, `jira_integration` as core skills
- **✅ Priority of Data Access**: All GitHub/JIRA access goes through core integration skills  
- **✅ Zero-Temp-File Policy**: Implements in-memory processing, no temporary files created
- **✅ Report Generation Standards**: Saves to `.windsurf/Reports/`, bilingual format, metadata headers
- **✅ Usage Guidelines Documentation**: Complete agent behavior guidelines included
- **✅ Cross-Session Consistency**: Deterministic workflow with documented expected outputs
- **✅ Configuration Centralization**: Uses centralized GitHub configuration from `github_integration`

### **Implementation Checklist Compliance**
- [x] **Read skill_guides/SKILL.md** completely before implementation
- [x] **Follow Core Integration Architecture** (Section 1)
- [x] **Implement Report Generation** following standards (Section 7)
- [x] **Use Zero-Temp-File Policy** (Section 5)
- [x] **Document Usage Guidelines** (Section 11)
- [x] **Follow Report Generation Standards** (Section 7)

### **Session Independence Guarantee**
New sessions following documented procedures will achieve identical results:
1. **Command Consistency**: Same commands produce same outputs
2. **Format Consistency**: Standardized bilingual report structure  
3. **Analysis Consistency**: Deterministic GitHub and Git analysis workflow
4. **Output Consistency**: Same file naming and storage locations

---
*Enhanced CPSE Analysis Skill Version: 3.1*
*Multi-Language Support: Enabled (Traditional Chinese [Default], English)*
*Deep Analysis Components: Log Processing, Codebase Investigation, Status Tracking*
*GitHub Integration: Repository Search, Commit Analysis, Historical Patterns*
*🆕 Resolved Issue Analysis: Solution Status Detection, Learning Experience Generation*
*Dell Domain Knowledge Integration: Enabled*
*Standardized Reporting: Markdown Format*
*Session Independence: Guaranteed*
*skill_guides Compliance: Full (Mandatory Requirements Met)*
