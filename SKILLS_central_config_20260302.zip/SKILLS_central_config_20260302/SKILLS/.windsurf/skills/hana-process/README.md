# Hana Process Skill

Specialized independent tool for quick check and handle TBABP1 (Hana) tickets.

## 🚀 Quick Start

### Installation and Configuration

#### 1. Install Dependencies
```bash
pip install atlassian-python-api tomli
```

#### 2. Configure Jira Connection
Copy example configuration file:
```bash
cp config.toml.example config.toml
```

Edit `config.toml`:
```toml
[jira]
url = "https://jira.cpg.dell.com"
token = "your_jira_token_here"
default_assignee = "ProcessBiosNVMB"

[options]
debug = false
comment_length_limit = 200
```

#### 3. Configure Git Ignore (Automatically Configured)
```bash
echo "config.toml" >> .gitignore
```

## 📋 Command Details

### Check Class Commands

#### Check Single Ticket
Check ticket status and required fields, and display ProcessBiosNVMB's last comment:
```bash
python scripts/hana_processor.py check --ticket TBABP1-75207
```

**Output includes:**
- Ticket basic information (Link, Status, assignee, etc.)
- Required field check (SSID, BIOS_Version, BIOS_Source, Epic Link)
- ProcessBiosNVMB's last comment
- Build status analysis

#### Batch Check Tickets
Check multiple tickets at once and generate detailed report:
```bash
python scripts/hana_processor.py batch-check --tickets "TBABP1-75207,TBABP1-75168,TBABP1-74827"
```

**Report will be saved to:** `.windsurf/Reports/batch_check_YYYYMMDD_HHMMSS.txt`

### Operation Class Commands

#### Build TBABP1 Ticket
Execute complete build process: Check → Approve → Transfer to ProcessBiosNVMB:
```bash
python scripts/hana_processor.py build --ticket TBABP1-75207
```

**Process Steps:**
1. 🔍 Check ticket status and required fields
2. 📝 Add "Approved" comment
3. 👤 Transfer to ProcessBiosNVMB

#### Batch Build Tickets
Handle multiple tickets' build process at once:
```bash
python scripts/hana_processor.py batch-build --tickets "TBABP1-75207,TBABP1-75168"
```

**Report will be saved to:** `.windsurf/Reports/batch_build_YYYYMMDD_HHMMSS.txt`

### Search Class Commands

#### Search Tickets
Search tickets according to different conditions:
```bash
# Search specified user's tickets
python scripts/hana_processor.py search --assignee "username" --limit 10

# Search specific status tickets
python scripts/hana_processor.py search --status "To Do" --limit 20

# Search specific project's tickets
python scripts/hana_processor.py search --project "TBABP1" --limit 15

# Comprehensive search
python scripts/hana_processor.py search --assignee "username" --status "In Review" --limit 5
```

### Direct Jira Operations

#### Get Ticket Detailed Information
```bash
python scripts/hana_processor.py get --ticket TBABP1-75207
```

#### Get Comments
```bash
python scripts/hana_processor.py get-comments --ticket TBABP1-75207
```

#### Add Comment
```bash
python scripts/hana_processor.py comment --ticket TBABP1-75207 --body "Your comment here"
```

#### Assign Ticket
```bash
python scripts/hana_processor.py assign --ticket TBABP1-75207 --user "username"
```

## 📊 Field Check Instructions

### Required Fields
This tool will check the following four required fields:

1. **SSID** (`customfield_27700`)
   - Must be "Green" or other valid values
   - Affects ticket's security classification

2. **BIOS_Version** (parsed from description)
   - Format: `BIOS_Version=x.x.x`
   - BIOS version information

3. **BIOS_Source** (parsed from description)
   - Format: `BIOS_Source=path/to/source`
   - BIOS source code path

4. **Epic Link** (`customfield_12300`)
   - Format: `CPSE-xxxxx`
   - Related Epic ticket

### Check Result
- ✅ **PASSED** - All required fields have been correctly filled
- ❌ **FAILED** - Missing required fields, please supplement and check again

## 🔧 Advanced Configuration

### Configuration File Options
```toml
[jira]
url = "https://jira.cpg.dell.com"          # Jira Server URL
token = "your_jira_token"                  # Jira API token
default_assignee = "ProcessBiosNVMB"       # Default assignee

[options]
debug = false                              # Debug pattern
comment_length_limit = 200                 # Comment display length limitations
```

### Environment Variables
Can also be configured through environment variables:
```bash
export JIRA_URL="https://jira.cpg.dell.com"
export JIRA_TOKEN="your_jira_token"
export JIRA_DEBUG="true"
```

## 🚨 Notes

### Security
- `config.toml` contains sensitive information, automatically added to `.gitignore`
- Please do not commit `config.toml` to version control system
- Suggestion to regularly change Jira token

### Encoding Issues
- Tool has solved Windows system's encoding issues
- All output is forced to use UTF-8 encoding
- Support Chinese and special character display

### Performance Considerations
- Batch operations will handle one by one to avoid API limitations
- Large number of tickets suggestion to handle in batches
- Network connection issues will automatically retry

## 📁 File Structure

```
Hana_process/
├── scripts/
│   └── hana_processor.py          # Main program
├── config.toml                    # Configuration file (not committed)
├── config.toml.example            # Configuration template
├── CONFIG.md                      # Configuration instructions
├── .gitignore                     # Git ignore rules
└── README.md                      # This file
```

## 🤝 Automatic Trigger

When you mention any ticket ID starting with TBABP1- in the conversation, this skill will automatically trigger check.

## 🔗 Related Links

- [Jira API Documentation](https://developer.atlassian.com/cloud/jira/platform/rest/v3/)
- [Atlassian Python API](https://atlassian-python-api.readthedocs.io/)
- [configureInstructions](CONFIG.md)
