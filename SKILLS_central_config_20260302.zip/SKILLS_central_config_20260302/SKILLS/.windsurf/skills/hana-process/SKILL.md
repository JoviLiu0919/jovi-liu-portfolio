---
name: hana-process
description: Dedicated skill for quick check of TBABP1 (Hana) tickets. Use when validating TBABP1 tickets, checking required fields, or processing Hana workflow tickets.
---

# Hana Process Skill

Specialized skill for quick check and handle TBABP1 (Hana) tickets.

## 📚 Function Features

- **Quick TBABP1 Ticket Check**: Automatically verify required fields of TBABP1 tickets
- **Batch Handle**: Support checking multiple TBABP1 tickets simultaneously
- **Smart Identification**: Automatically identify ticket IDs starting with TBABP1-
- **Report Generation**: Automatically generate check reports and save to `.windsurf/Reports/`

## Usage Method

### Check Single TBABP1 Ticket
When you mention any ticket ID starting with TBABP1-, this skill will automatically:
1. Use jira_integration's check-tbabp1 functions
2. Verify required fields (SSID, BIOS_Version, BIOS_Source, Epic Link)
3. Display check results

**Example Input:**
- "Help me check TBABP1-74418"
- "check TBABP1-12345"
- "TBABP1-67890 Status"

### Batch Check Multiple Tickets
Use `batch-check` command to check multiple tickets at once:

```powershell
python scripts/hana_processor.py batch-check --tickets "TBABP1-74418,TBABP1-74419,TBABP1-74420"
```

### Build TBABP1 Ticket
Execute complete build process: Check ticket status, approve, transfer to ProcessBiosNVMB

```powershell
python scripts/hana_processor.py build --ticket TBABP1-74418
```

#### Batch Check Multiple Tickets
```bash
python scripts/hana_processor.py batch-check --tickets "TBABP1-74418,TBABP1-74417"
```

#### Search TBABP1 tickets
```bash
# Search by status
python scripts/hana_processor.py search --status "To Do" --limit 10

# Search by assignee
python scripts/hana_processor.py search --assignee "Liu, Larry" --limit 20

# Combined search
python scripts/hana_processor.py search --status "To Do" --assignee "ProcessBiosNVMB" --limit 15
```

#### Build TBABP1 ticket (Check → Approve → Transfer)
```bash
python scripts/hana_processor.py build --ticket TBABP1-74418
```

#### Batch Build Multiple Tickets
```bash
python scripts/hana_processor.py batch-build --tickets "TBABP1-74485,TBABP1-74486"
```

## Automatic Trigger Conditions

This skill will automatically trigger in the following situations:

1. **Ticket ID Identification**: When input contains "TBABP1-" followed by numbers
2. **Keyword Matching**: When using the following keywords
   - "Check TBABP1"
   - "check TBABP1"
   - "TBABP1 ticket"
   - "hana ticket"
   - "build TBABP1" - Add build command trigger

## Output Format

### Single Ticket Check Result
```
TBABP1-74418 CheckResult
==================================================
Ticket Link: https://jira.cpg.dell.com/browse/TBABP1-74418
Summary: 20260205_01_BolanPtl_89.35.11
Status: To Do
Assignee: ProcessBiosNVMB
Priority: Highest
Reporter: Liu, Larry
Created: 2026-02-04
Updated: 2026-02-05

Required field check:

SSID: 0x0DD6 ✅
BIOS_Version: 89.35.10 ✅
BIOS_Source: TestRelease/BolanPtl/89.35.11 ✅
Epic Link: CPSE-36363 (Task BolanMlk_PTL_BIOS_1090) ✅

✅ PASSED - All required fields have been correctly filled
```

### Build Command Output Format
```
🔍 Start build process for TBABP1-74418...
📋 Step 1: Check ticket status...
✅ Ticket status check through
📝 Step 2: Add approved comment...
✅ Approved comment has been added
👤 Step 3: Transfer to ProcessBiosNVMB...
✅ Has been transferred to ProcessBiosNVMB

✅ Build process complete for TBABP1-74418

📋 Detailed result:
  ticket: TBABP1-74418
  status_check: ✅ through
  comment: ✅ Approved has been added
  assignment: ✅ Has been transferred to ProcessBiosNVMB
```

### Batch Check Report
Automatically generate and save to `.windsurf/Reports/Hana_batch_check_YYYY-MM-DD_HH-mm-ss.md`

## Dependencies

This skill depends on:
- **jira_integration**: Used for actual Jira API operations
- **Python 3.7+**: Execution environment
- **atlassian-python-api**: Jira API library

## Configuration

Ensure `jira_integration` skill is correctly configured:
1. Jira URL and API token are configured
2. Required Python packages are installed

## Bug Handling

- **Ticket does not exist**: Display clear error message
- **Field missing**: Indicate specific missing required fields
- **API connection issue**: Provide troubleshooting suggestions

## Extended Functions

Future possible functions:
- Automatically create TBABP1 tickets
- Batch update ticket status
- Automatically generate BIOS handling report
- Integration GitHub CI/CD status
