# Configuration File Instructions

## config.toml

Hana Process uses `config.toml` file to manage configuration.

### Configuration Steps

1. **Copy template file:**
   ```bash
   cp config.toml.example config.toml
   ```

2. **Edit configuration file:**
   ```toml
   [jira]
   url = "https://jira.cpg.dell.com"
   token = "your_JIRA_TOKEN"
   default_assignee = "ProcessBiosNVMB"
   
   [options]
   debug = false
   comment_length_limit = 200
   ```

3. **Get Jira token:**
   - Login to Jira
   - Go to Account Settings > Security > API tokens
   - Create new Personal Access Token
   - Copy the token to the configuration file

### Configuration Options

#### [jira] section
- `url`: Jira Server URL
- `token`: Personal Access Token
- `default_assignee`: Default assignee for build operations

#### [options] section
- `debug`: Enable debug output (true/false)
- `comment_length_limit`: Comment display length limitations (characters)

### Security

- `config.toml` added to `.gitignore`, will not be committed to version control
- Please do not share configuration files containing tokens
- Suggestion to regularly update Jira token

### Troubleshooting

If encountering configuration file related bugs:
1. Confirm `config.toml` exists in the correct location
2. Check if TOML syntax is correct
3. Verify if Jira token is valid
4. Configure `debug = true` to obtain detailed bug information
