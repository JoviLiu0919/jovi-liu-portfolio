import argparse
import subprocess
import os
import sys
import json
import re
from datetime import datetime
from pathlib import Path

# Try to import fitz for PDF extraction
try:
    import fitz # PyMuPDF
    HAS_FITZ = True
except ImportError:
    HAS_FITZ = False

# Try to import python-docx for DOCX extraction
try:
    from docx import Document
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False

# Try to import python-pptx for PowerPoint extraction
try:
    from pptx import Presentation
    HAS_PPTX = True
except ImportError:
    HAS_PPTX = False

# Try to import extract-msg for Outlook email extraction
try:
    import extract_msg
    HAS_MSG = True
except ImportError:
    HAS_MSG = False

# Report generation function following skill_guides standards
def save_report(content, report_name, description="", skill_name="deep_research"):
    """
    Save markdown report to centralized Reports directory following skill_guides standards
    
    Args:
        content: Report content in markdown format
        report_name: Base name for the report file
        description: Optional description for the report
        skill_name: Name of the skill generating the report
    """
    try:
        # Save to centralized Reports directory following skill_guides standards
        reports_dir = Path(os.path.join(ROOT_DIR, ".windsurf", "Reports"))
        reports_dir.mkdir(exist_ok=True)
        
        # Generate timestamped filename
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        filename = f"{report_name}_{timestamp}.md"
        filepath = reports_dir / filename
        
        # Add report metadata header
        report_header = f"""---
# {report_name} Report
**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Description:** {description}
**Skill:** {skill_name}
---

"""
        
        # Combine header and content
        full_content = report_header + content
        
        # Save to file
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(full_content)
        
        return f"✅ Report saved to: {filepath}"
        
    except Exception as e:
        return f"❌ Failed to save report: {str(e)}"

# Determine paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_ROOT = os.path.dirname(SCRIPT_DIR)
JIRA_TOOL_PATH = os.path.abspath(os.path.join(SKILL_ROOT, "..", "jira-integration", "scripts", "jira_tool.py"))
JIRA_CONFIG_PATH = os.path.abspath(os.path.join(SKILL_ROOT, "..", "jira-integration", "config.toml"))
CONFLUENCE_TOOL_PATH = os.path.abspath(os.path.join(SKILL_ROOT, "..", "confluence-integration", "scripts", "confluence_tool.py"))
CONFLUENCE_CONFIG_PATH = os.path.abspath(os.path.join(SKILL_ROOT, "..", "confluence-integration", "config.toml"))
GITHUB_TOOL_PATH = os.path.abspath(os.path.join(SKILL_ROOT, "..", "github-integration", "scripts", "github_tool.py"))
GITHUB_CONFIG_PATH = os.path.abspath(os.path.join(SKILL_ROOT, "..", "github-integration", "config.toml"))
ROOT_DIR = os.path.abspath(os.path.join(SKILL_ROOT, "..", "..", ".."))

# Defaults
DEFAULT_JIRA_PROJECTS = ["PIMS", "PBA", "CBA", "CBDCIT", "CPSE", "CBDSE", "CSSE"]
RELEVANT_PROJECTS = ["PBA", "CPSE", "PIMS", "CBA", "CBDCIT"]
DEFAULT_MAX_ITEMS = 5
SPEC_KEYWORDS = ["spec", "specification", "checklist", "requirement", "pba", "cba"]

def run_script(script_path, args, is_json=False):
    """Runs a python script and returns stdout."""
    cmd = [sys.executable, script_path] + args
    try:
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        result = subprocess.run(cmd, capture_output=True, text=True, check=True, encoding='utf-8', env=env)
        stdout = result.stdout.strip()
        if is_json:
            try:
                return json.loads(stdout)
            except json.JSONDecodeError:
                return None
        return stdout
    except subprocess.CalledProcessError as e:
        print(f"Error running {script_path} {' '.join(args)}: {e.stderr}")
        return None

def extract_docx_text(docx_path):
    """Extracts text from a DOCX file using python-docx."""
    if not HAS_DOCX:
        return "[python-docx not installed, skipping extraction]"
    try:
        doc = Document(docx_path)
        text = ""
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
        return text[:3000].strip() # Return first 3000 chars
    except Exception as e:
        return f"[Error extracting DOCX: {e}]"

def extract_pptx_text(pptx_path):
    """Extracts text from a PowerPoint file using python-pptx."""
    if not HAS_PPTX:
        return "[python-pptx not installed, skipping extraction]"
    try:
        prs = Presentation(pptx_path)
        text = ""
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text:
                    text += shape.text + "\n"
            # Also extract notes
            if hasattr(slide, "notes_slide") and slide.notes_slide:
                for shape in slide.notes_slide.shapes:
                    if hasattr(shape, "text") and shape.text:
                        text += f"[Note]: {shape.text}\n"
        return text[:3000].strip() # Return first 3000 chars
    except Exception as e:
        return f"[Error extracting PowerPoint: {e}]"

def extract_msg_text(msg_path):
    """Extracts text from Outlook MSG file using extract-msg."""
    if not HAS_MSG:
        return "[extract-msg not installed, skipping extraction]"
    try:
        msg = extract_msg.Message(msg_path)
        text = ""
        
        # Extract headers
        text += f"From: {msg.sender}\n"
        text += f"To: {msg.to}\n"
        text += f"CC: {msg.cc}\n"
        text += f"Subject: {msg.subject}\n"
        text += f"Date: {msg.date}\n"
        text += "---\n"
        
        # Extract body
        if msg.body:
            text += msg.body
        
        # Extract attachments info
        if hasattr(msg, 'attachments') and msg.attachments:
            text += "\n---\nAttachments:\n"
            for att in msg.attachments:
                text += f"- {att.longFilename}\n"
        
        return text[:3000].strip() # Return first 3000 chars
    except Exception as e:
        return f"[Error extracting Outlook MSG: {e}]"

def extract_txt_text(txt_path):
    """Extracts text from a plain text file."""
    try:
        with open(txt_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        return content[:3000].strip() # Return first 3000 chars
    except Exception as e:
        return f"[Error extracting TXT: {e}]"

def search_local_codebase(query, root_dir=None, max_results=20):
    """Search local codebase using grep-like functionality."""
    if root_dir is None:
        root_dir = ROOT_DIR
    
    findings = []
    
    # Common code file extensions
    code_extensions = ["*.c", "*.h", "*.cpp", "*.hpp", "*.py", "*.js", "*.ts", "*.java", "*.go", "*.rs", "*.md", "*.txt"]
    
    try:
        for ext in code_extensions:
            for file_path in Path(root_dir).rglob(ext):
                # Skip .git, node_modules, build directories
                if any(skip in str(file_path) for skip in ['.git', 'node_modules', '__pycache__', 'build', 'dist']):
                    continue
                
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                        if query.lower() in content.lower():
                            # Find line numbers where query appears
                            lines = content.split('\n')
                            matches = []
                            for i, line in enumerate(lines, 1):
                                if query.lower() in line.lower():
                                    matches.append(f"Line {i}: {line.strip()[:100]}")
                            
                            findings.append({
                                "file": str(file_path.relative_to(root_dir)),
                                "matches": matches[:5],  # Limit to 5 matches per file
                                "total_matches": len(matches)
                            })
                            
                            if len(findings) >= max_results:
                                break
                except Exception:
                    continue
                    
            if len(findings) >= max_results:
                break
                
    except Exception as e:
        print(f"Error searching local codebase: {e}")
    
    return findings

def analyze_git_log(query, root_dir=None, max_results=10):
    """Analyze git log for query-related commits."""
    if root_dir is None:
        root_dir = ROOT_DIR
    
    findings = []
    
    try:
        # Get git log with search
        cmd = ["git", "-C", root_dir, "log", "--oneline", "--grep", query, "-n", str(max_results)]
        result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8')
        
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            for line in lines:
                if line.strip():
                    parts = line.split(' ', 1)
                    if len(parts) >= 2:
                        commit_hash = parts[0]
                        message = parts[1]
                        findings.append({
                            "commit": commit_hash,
                            "message": message
                        })
        
        # Also search commit content
        cmd = ["git", "-C", root_dir, "log", "--oneline", "--grep", query, "-S", query, "-n", str(max_results)]
        result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8')
        
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            for line in lines:
                if line.strip() and not any(f["commit"] == line.split(' ')[0] for f in findings):
                    parts = line.split(' ', 1)
                    if len(parts) >= 2:
                        commit_hash = parts[0]
                        message = parts[1]
                        findings.append({
                            "commit": commit_hash,
                            "message": message + " (content match)"
                        })
                        
    except Exception as e:
        print(f"Error analyzing git log: {e}")
    
    return findings[:max_results]

def search_github_repositories(query, limit=10):
    """Search GitHub repositories using github_integration enhanced search."""
    try:
        # Use github_tool.py's enhanced search method
        search_cmd = ["comprehensive-search", "--query", query, "--include-repos", "--include-code"]
        output = run_script(GITHUB_TOOL_PATH, search_cmd)
        
        if not output:
            return []
        
        # Parse JSON output
        try:
            data = json.loads(output)
            repo_results = data.get('repositories', [])
            code_results = data.get('code', [])
            
            # Combine repository and code results
            findings = []
            
            # Add only repository results (filter by type)
            for item in repo_results[:limit]:
                if item.get('type') == 'repository':
                    findings.append({
                        "name": item.get('name', ''),
                        "description": item.get('description', ''),
                        "language": item.get('language', ''),
                        "stars": item.get('stars', 0),
                        "url": item.get('url', ''),
                        "type": "repository"
                    })
            
            return findings
            
        except json.JSONDecodeError:
            return []
        
    except Exception as e:
        print(f"Error searching GitHub repositories: {e}")
        return []

def search_github_code(query, repo=None, limit=10):
    """Search code within GitHub repositories using github_integration enhanced search."""
    try:
        if repo:
            # Search specific repository
            search_cmd = ["search-code", "--repo", repo, "--query", query]
            output = run_script(GITHUB_TOOL_PATH, search_cmd)
            
            if output:
                try:
                    data = json.loads(output)
                    items = data.get('items', [])
                    
                    findings = []
                    for item in items[:limit]:
                        findings.append({
                            "repository": repo,
                            "file": item.get('path', ''),
                            "url": item.get('html_url', ''),
                            "matches": item.get('text_matches', [])
                        })
                    return findings
                except json.JSONDecodeError:
                    return []
        else:
            # Use BIOS-specific search
            search_cmd = ["search-bios", "--query", query]
            output = run_script(GITHUB_TOOL_PATH, search_cmd)
            
            if output:
                try:
                    data = json.loads(output)
                    return data  # Return the structured results directly
                except json.JSONDecodeError:
                    return []
        
        return []
        
    except Exception as e:
        print(f"Error searching GitHub code: {e}")
        return []

def extract_pdf_text(pdf_path):
    if not HAS_FITZ:
        return "[PyMuPDF not installed, skipping extraction]"
    try:
        doc = fitz.open(pdf_path)
        text = ""
        for i in range(min(5, len(doc))): # Process first 5 pages max
             text += doc[i].get_text()
             if len(text) > 5000: break
        doc.close()
        return text[:3000].strip() # Return first 3000 chars
    except Exception as e:
        return f"[Error extracting PDF: {e}]"

def search_jira(query, projects=DEFAULT_JIRA_PROJECTS, limit=DEFAULT_MAX_ITEMS):
    project_str = ",".join(projects)
    jql = f'project in ({project_str}) AND text ~ "{query}" ORDER BY created DESC'
    print(f"Identifying Jira tickets with JQL: {jql}")
    
    output = run_script(JIRA_TOOL_PATH, ["--config", JIRA_CONFIG_PATH, "search", "--jql", jql, "--limit", str(limit)], is_json=True)
    if not output:
        return []

    # atlassian-python-api search returns a list of issues or dict with 'issues'
    issues = output.get('issues', []) if isinstance(output, dict) else output
    keys = []
    for issue in issues:
        key = issue.get('key')
        if key:
            keys.append(key)
    
    return keys[:limit]

def get_jira_details(keys, depth=0):
    findings = []
    visited = set()
    
    for key in keys:
        if key in visited: continue
        visited.add(key)
        
        print(f"Summarizing Jira Ticket: {key}")
        # Get full detail including fields for attachments and links
        # Need to use 'get' for raw JSON to access links and attachments easily
        issue_data = run_script(JIRA_TOOL_PATH, ["--config", JIRA_CONFIG_PATH, "get", "--key", key], is_json=True)
        if not issue_data: continue
        
        # Summarize for human readable part
        summary_text = run_script(JIRA_TOOL_PATH, ["--config", JIRA_CONFIG_PATH, "summarize", "--key", key])
        
        findings.append({
            "key": key,
            "summary": summary_text,
            "data": issue_data
        })
        
        # Recursively explore linked issues if depth < 1
        if depth < 1:
            links = issue_data.get('fields', {}).get('issuelinks', [])
            linked_keys = []
            for link in links:
                target = link.get('outwardIssue') or link.get('inwardIssue')
                if target:
                    t_key = target.get('key')
                    t_proj = t_key.split('-')[0]
                    if t_proj in RELEVANT_PROJECTS:
                        linked_keys.append(t_key)
            
            if linked_keys:
                print(f"  -> Exploring {len(linked_keys)} linked issues for {key}...")
                sub_findings = get_jira_details(linked_keys[:3], depth + 1)
                findings.extend(sub_findings)
                
    return findings

def download_and_analyze_attachments(findings, is_jira=True):
    temp_dir = Path(SCRIPT_DIR) / "temp_docs"
    temp_dir.mkdir(exist_ok=True)
    
    results = []
    for item in findings:
        attachments = []
        if is_jira:
            attachments = item.get('data', {}).get('fields', {}).get('attachment', [])
        else:
            # Confluence get returns raw JSON
            # Need to implement list-attachments if 'get' doesn't include them
            pass
            
        for a in attachments:
            filename = a.get('filename', '')
            file_ext = filename.lower().split('.')[-1] if '.' in filename else ''
            
            # Check for specification documents (multiple formats)
            if any(k in filename.lower() for k in SPEC_KEYWORDS) and file_ext in ['pdf', 'docx', 'pptx', 'txt', 'msg']:
                aid = a.get('id')
                print(f"  [Spec Detected] Downloading {filename} (ID: {aid})...")
                out_path = temp_dir / filename
                
                # Use jira_tool download
                dl_res = run_script(JIRA_TOOL_PATH, ["--config", JIRA_CONFIG_PATH, "download-attachment", "--id", aid, "--out", str(out_path)], is_json=True)
                if dl_res and dl_res.get('success'):
                    # Extract text based on file type
                    if file_ext == 'pdf':
                        content = extract_pdf_text(str(out_path))
                    elif file_ext == 'docx':
                        content = extract_docx_text(str(out_path))
                    elif file_ext == 'pptx':
                        content = extract_pptx_text(str(out_path))
                    elif file_ext == 'msg':
                        content = extract_msg_text(str(out_path))
                    elif file_ext == 'txt':
                        content = extract_txt_text(str(out_path))
                    else:
                        content = f"[Unsupported format: {file_ext}]"
                    
                    results.append({
                        "source": item.get('key') or item.get('id'),
                        "filename": filename,
                        "content": content,
                        "type": file_ext.upper()
                    })
                    # Cleanup after reading
                    try: os.remove(out_path)
                    except: pass
    return results

def search_confluence(query, limit=DEFAULT_MAX_ITEMS):
    cql = f'text ~ "{query}"'
    print(f"Searching Confluence with CQL: {cql}")
    data = run_script(CONFLUENCE_TOOL_PATH, ["--config", CONFLUENCE_CONFIG_PATH, "cql-search", "--query", cql, "--limit", str(limit)], is_json=True)
    if not data: return []
    
    results = data.get('results', [])
    page_ids = []
    for item in results:
        pid = item.get('content', {}).get('id') or item.get('id')
        if pid: page_ids.append(pid)
    return list(set(page_ids))[:limit]

def get_confluence_details(page_ids):
    findings = []
    for pid in page_ids:
        print(f"Reading Confluence Page: {pid}")
        content = run_script(CONFLUENCE_TOOL_PATH, ["--config", CONFLUENCE_CONFIG_PATH, "get", "--id", pid])
        if content:
            findings.append({"id": pid, "content": content})
    return findings

def generate_report(query, jira_data, confluence_data, spec_data, local_code_data, git_data, github_repo_data, github_code_data, output_file):
    report_lines = []
    report_lines.append(f"# Deep Research Data: {query}")
    report_lines.append(f"**Date**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report_lines.append(f"**Query**: `{query}`")
    report_lines.append("")
    
    report_lines.append("> [!IMPORTANT]")
    report_lines.append("> **AI Analysis Required**: This file contains raw research data from multiple sources. Please ask your AI Assistant to \"Analyze this research report\" to get an Executive Summary and insights.")
    report_lines.append("")
    
    # Specification Documents
    if spec_data:
        report_lines.append("## Specification Document Insights")
        for spec in spec_data:
            report_lines.append(f"### {spec['type']}: {spec['filename']} (from {spec['source']})")
            report_lines.append("```text")
            report_lines.append(spec['content'])
            report_lines.append("```")
            report_lines.append("")

    # Local Codebase Findings
    if local_code_data:
        report_lines.append("## Local Codebase Findings")
        for finding in local_code_data:
            report_lines.append(f"### File: {finding['file']} ({finding['total_matches']} matches)")
            for match in finding['matches']:
                report_lines.append(f"- {match}")
            report_lines.append("")
    else:
        report_lines.append("## Local Codebase Findings")
        report_lines.append("No local code matches found.")
        report_lines.append("")

    # Git Log Analysis
    if git_data:
        report_lines.append("## Git Log Analysis")
        for commit in git_data:
            report_lines.append(f"### {commit['commit']}")
            report_lines.append(commit['message'])
            report_lines.append("")
    else:
        report_lines.append("## Git Log Analysis")
        report_lines.append("No relevant git commits found.")
        report_lines.append("")

    # GitHub Repository Search
    if github_repo_data:
        report_lines.append("## GitHub Repository Search")
        for repo in github_repo_data:
            report_lines.append(f"### {repo['name']}")
            report_lines.append(f"**Language**: {repo['language']}")
            report_lines.append(f"**Stars**: {repo['stars']}")
            report_lines.append(f"**Description**: {repo['description']}")
            report_lines.append(f"**URL**: {repo['url']}")
            report_lines.append("")
    else:
        report_lines.append("## GitHub Repository Search")
        report_lines.append("No GitHub repositories found.")
        report_lines.append("")

    # GitHub Code Search
    if github_code_data:
        report_lines.append("## GitHub Code Search")
        for code in github_code_data:
            report_lines.append(f"### {code['repository']} - {code['file']}")
            report_lines.append(f"**URL**: {code['url']}")
            if code['matches']:
                report_lines.append("**Matches**:")
                for match in code['matches'][:3]:  # Limit matches
                    report_lines.append(f"- {match}")
            report_lines.append("")
    else:
        report_lines.append("## GitHub Code Search")
        report_lines.append("No GitHub code matches found.")
        report_lines.append("")

    # Jira Findings
    report_lines.append("## Jira Findings")
    if jira_data:
        seen = set()
        for item in jira_data:
            if item['key'] in seen: continue
            seen.add(item['key'])
            report_lines.append(f"### {item['key']}")
            report_lines.append(item['summary'])
            report_lines.append("")
    else:
        report_lines.append("No Jira items found.")
    report_lines.append("")

    # Confluence Findings
    report_lines.append("## Confluence Findings")
    if confluence_data:
        for item in confluence_data:
            # Parse JSON content to extract page title and generate proper URL
            try:
                import json
                content_json = json.loads(item['content'])
                page_id = item['id']
                page_title = content_json.get('title', f'Page {page_id}')
                proper_url = f"https://confluence.cpg.dell.com/pages/viewpage.action?pageId={page_id}"
                
                report_lines.append(f"### {page_title}")
                report_lines.append(f"**URL**: {proper_url}")
                report_lines.append(f"**Page ID**: {page_id}")
                report_lines.append("")
                
                # Add a snippet of the content (first 500 chars)
                body_content = content_json.get('body', {}).get('storage', {}).get('value', '')
                if body_content:
                    # Remove HTML tags for readability
                    import re
                    clean_content = re.sub(r'<[^>]+>', '', body_content)
                    snippet = clean_content[:500] + "..." if len(clean_content) > 500 else clean_content
                    report_lines.append(f"**Content Preview**: {snippet}")
                report_lines.append("")
            except (json.JSONDecodeError, KeyError):
                # Fallback to original format if JSON parsing fails
                report_lines.append(f"### Page ID: {item['id']}")
                report_lines.append(f"**URL**: https://confluence.cpg.dell.com/pages/viewpage.action?pageId={item['id']}")
                report_lines.append(item['content'])
                report_lines.append("")
    else:
        report_lines.append("No Confluence items found.")
        
    # Save to centralized Reports directory using save_report function
    report_content = "\n".join(report_lines)
    save_result = save_report(report_content, output_file, f"Deep research data for: {query}", "deep-research")
    print(save_result)

def conduct_research(query, output, include_local=True, include_git=True, include_github=True):
    print(f"Starting comprehensive deep research for: {query}")
    
    # 1. Jira Search
    print("1. Searching Jira...")
    jira_keys = search_jira(query)
    jira_findings = get_jira_details(jira_keys)
    
    # 2. Specs Analysis (Jira attachments)
    print("2. Analyzing specifications...")
    spec_findings = download_and_analyze_attachments(jira_findings)
    
    # 3. Confluence Search
    print("3. Searching Confluence...")
    confluence_ids = search_confluence(query)
    confluence_findings = get_confluence_details(confluence_ids)
    
    # 4. Local Codebase Search
    local_code_findings = []
    if include_local:
        print("4. Searching local codebase...")
        local_code_findings = search_local_codebase(query)
    
    # 5. Git Log Analysis
    git_findings = []
    if include_git:
        print("5. Analyzing git log...")
        git_findings = analyze_git_log(query)
    
    # 6. GitHub Search
    github_repo_findings = []
    github_code_findings = []
    if include_github:
        print("6. Searching GitHub...")
        github_repo_findings = search_github_repositories(query)
        github_code_findings = search_github_code(query)
    
    # 7. Generate Report
    print("7. Generating comprehensive report...")
    generate_report(query, jira_findings, confluence_findings, spec_findings, 
                   local_code_findings, git_findings, github_repo_findings, 
                   github_code_findings, output)
    
    print("Research completed!")

def main():
    parser = argparse.ArgumentParser(description="Deep Research Tool")
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    research_parser = subparsers.add_parser("conduct-research", help="Conduct deep research")
    research_parser.add_argument("--query", required=True, help="Search query")
    research_parser.add_argument("--output", default="research_report.md", help="Output Markdown file")
    research_parser.add_argument("--no-local", action="store_true", help="Skip local codebase search")
    research_parser.add_argument("--no-git", action="store_true", help="Skip git log analysis")
    research_parser.add_argument("--no-github", action="store_true", help="Skip GitHub search")
    
    args = parser.parse_args()
    
    if args.command == "conduct-research":
        conduct_research(args.query, args.output, 
                        include_local=not args.no_local,
                        include_git=not args.no_git, 
                        include_github=not args.no_github)

if __name__ == "__main__":
    main()
