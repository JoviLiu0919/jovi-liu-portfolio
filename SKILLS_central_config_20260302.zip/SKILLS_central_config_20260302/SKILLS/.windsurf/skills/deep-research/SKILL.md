---
name: deep-research
description: Conduct deep research across Jira and Confluence to generate comprehensive reports. Use when researching topics across multiple platforms, analyzing project data, or generating unified insight reports.
---

# Deep Research Skill

Orchestrates searches across Jira Data Center and Confluence, performs recursive link analysis, and extracts text from specification documents to provide unified insight reports.

## Current Capabilities

*   **Jira Search**: Queries Jira Data Center across multiple projects (PIMS, PBA, CBA, CBDCIT, CPSE, CBDSE, CSSE)
*   **Confluence Search**: Searches Confluence pages using CQL queries
*   **Local Codebase Search**: Searches local files (C, H, Python, JS, etc.) with grep-like functionality
*   **Git Log Analysis**: Analyzes git commit history for query-related changes
*   **GitHub Integration**: Searches GitHub repositories and code using github_integration skill
*   **Recursive Link Analysis**: Automatically identifies and expands relevant linked Jira tickets (1 level deep) for broader context
*   **Enhanced Spec Analysis**: Detects specification-related attachments (PDF, DOCX, PowerPoint, TXT, Outlook MSG) and extracts text using specialized libraries
*   **Standardized Reporting**: Saves reports to `.windsurf/Reports/` directory following skill_guides standards

## Current Limitations

*   **Basic Deduplication**: Only removes duplicate ticket keys, not content similarity
*   **Project Scope**: Limited to predefined Jira projects list
*   **Attachment Processing**: Limited to 3000 characters per file, requires optional libraries for full functionality
*   **Local Search Scope**: Searches from root directory with basic file extension filtering
*   **GitHub Dependencies**: Requires github_integration skill to be properly configured

## Planned Enhancements

*   **Advanced Deduplication**: Content similarity analysis and intelligent merging
*   **Extended Attachment Support**: Excel, CSV, and other office format processing
*   **Enhanced Local Search**: More sophisticated code analysis and pattern matching
*   **Cross-System Integration**: PIMS and other internal system integration
*   **Performance Optimization**: Parallel processing and caching mechanisms

## Interaction Rules (Agent Instructions)

*   **Objective**: Use this skill when the user asks for a "deep research" or comprehensive summary of a topic across both tracking and documentation systems.
*   **Workflow**:
    1.  Run the `conduct-research` command.
    2.  **CRITICAL**: The tool generates a *raw data* file (e.g., `research_report.md`). **You (the Agent) MUST read this file.**
    3.  **Synthesis (The Output)**: Do not just show the raw file to the user.
        *   **Generate an Analysis Report**: You MUST create a new, synthesized Markdown file (e.g., `Analysis_Report.md`). This report MUST follow a professional, high-density format (often referred to as "HEVC-style"):
            *   **Language**: **Default to Traditional Chinese unless the user explicitly requests another language.
            *   **Executive Summary**: A 1-2 paragraph overview of the most critical takeaway.
            *   **Evidence Table**: A Markdown table listing all relevant tickets/pages with columns for: **Key/ID (Hyperlinked)**, **Summary**, **Status**, and **Analyst/Owner**.
            *   **Technical Breakdown**: Thematic groupings of findings (e.g., "BIOS Behavior", "Compatibility Issues").
            *   **Document Evidence**: Direct snippets or quotes from analyzed Specification documents (Jira attachments) or Confluence pages.
            *   **Actionable Recommendations**: Clear next steps or solutions.
        *   **Present Results**: 
            1.  **Direct Display**: You MUST render the key parts of the synthesized report (Executive Summary and Evidence Table at minimum) directly in the chat dialogue using Markdown formatting.
            2.  **File Links**: Provide direct links to both the *Analysis Report* and the *Raw Data* file.
        *   **Hyperlinks**: Every Jira ticket key (e.g., [CPSE-123](https://jira.cpg.dell.com/browse/CPSE-123)) and Confluence page mentioned MUST be a direct, clickable hyperlink.

## Setup

1.  **Configuration**:
    Ensure `config.toml` is configured with limits and credentials.
    *Note: This skill relies on `jira_integration` and `confluence_integration` being configured.*
2.  **Dependencies**: Requires `PyMuPDF` (`fitz`) for PDF extraction.

## Commands

### Conduct Research
Performs comprehensive multi-source research process:
1.  Searches Jira and Confluence.
2.  Searches local codebase files.
3.  Analyzes git commit history.
4.  Searches GitHub repositories and code.
5.  Expand linked issues (1 level deep) for context.
6.  Download and extract text from specification attachments (PDF, DOCX, PowerPoint, TXT, Outlook MSG).
7.  Aggregates results into a comprehensive raw Markdown report.

```powershell
# Full comprehensive research (all sources)
python .windsurf/deep_research/scripts/research_tool.py conduct-research --query "USB Type-C" --output "raw_report.md"

# Skip specific sources for faster research
python .windsurf/deep_research/scripts/research_tool.py conduct-research --query "IMEI" --output "imei_report.md" --no-github

# Research without local codebase search
python .windsurf/deep_research/scripts/research_tool.py conduct-research --query "SMBIOS" --output "smbios_report.md" --no-local
```

## Dependencies

*   **PyMuPDF** (`fitz`): For PDF text extraction
*   **python-docx**: For DOCX text extraction
*   **python-pptx**: For PowerPoint text extraction
*   **extract-msg**: For Outlook MSG email extraction
*   **jira_integration**: For Jira Data Center access
*   **confluence_integration**: For Confluence page access  
*   **github_integration**: For GitHub repository and code search

**Note**: All attachment processing libraries are optional - the skill will gracefully skip formats if their respective libraries are not installed.
