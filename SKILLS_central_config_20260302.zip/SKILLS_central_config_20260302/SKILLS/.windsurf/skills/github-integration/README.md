# GitHub Integration Skill

A comprehensive GitHub integration skill for managing repositories, pull requests, issues, and commits. This skill provides both agent-optimized tools and CLI utilities for GitHub operations.

## Features

- **Repository Management**: List, search, and analyze repositories
- **Pull Request Operations**: Create, update, merge, and review pull requests
- **Commit Analysis**: View commit details, diffs, and file changes
- **Issue Management**: Create, update, and track issues
- **Comment Management**: Add and retrieve comments on issues and PRs
- **Branch Operations**: Create, delete, and manage branches
- **Search & Filtering**: Advanced search capabilities
- **Repository Analytics**: Statistics and activity monitoring
- **Favorite Repositories**: Quick access to frequently used repositories

## Quick Start

### 1. Setup Environment

```powershell
cd .windsurf/github_integration
.\scripts\setup_env.ps1
```

### 2. Configure GitHub Token

Edit `config.toml` and replace `YOUR_GITHUB_TOKEN` with your actual GitHub token:

```toml
[github]
token = "ghp_your_actual_token_here"
```

### 3. Basic Usage

```powershell
# List repositories
python scripts/github_tool.py list-repos

# Get pull request details
python scripts/github_tool.py get-pr --repo CDC_AgS_2025 --number 123

# Get pull request diff
python scripts/github_tool.py get-pr-diff --repo CDC_AgS_2025 --number 123
```

## Directory Structure

```
github_integration/
├── SKILL.md                 # Complete skill documentation
├── README.md               # This file
├── requirements.txt        # Python dependencies
├── config.toml            # Configuration file (created by setup)
├── scripts/
│   ├── github_tool.py     # Main CLI tool
│   ├── batch_operations.py # Batch operations tool
│   └── setup_env.ps1      # Environment setup script
└── .venv/                 # Virtual environment (created by setup)
```

## Configuration

### Required Configuration

Edit `config.toml` with your GitHub settings:

```toml
[github]
base_url = "https://githubcsg.cec.delllabs.net/api/v3"  # or "https://api.github.com" for public GitHub
owner = "CSG-Firmware-Engineering"  # Your organization/username
token = "ghp_your_actual_token_here"

[api]
timeout = 30
max_retries = 3
per_page = 100

[favorites]
repos = [
    "CDC_AgS_2025",
    "CDC_Intel_2025",
    # ... more repositories
]
```

### GitHub Token Permissions

Your GitHub token should have the following permissions for full functionality:

- **Repository permissions**: Read, Write, Admin
- **Pull requests**: Read, Write
- **Issues**: Read, Write
- **Contents**: Read, Write
- **Metadata**: Read

## Common Workflows

### Pull Request Review Workflow

```powershell
# 1. List open pull requests
python scripts/github_tool.py search-prs --repo CDC_AgS_2025 --query "is:open"

# 2. Get PR details and diff
python scripts/github_tool.py get-pr --repo CDC_AgS_2025 --number 123
python scripts/github_tool.py get-pr-diff --repo CDC_AgS_2025 --number 123

# 3. Add review comment
python scripts/github_tool.py add-comment --repo CDC_AgS_2025 --number 123 --type "pr" --body "Please update the documentation"

# 4. Approve and merge
python scripts/github_tool.py merge-pr --repo CDC_AgS_2025 --number 123 --merge-method "squash"
```

### Issue Management Workflow

```powershell
# 1. Create issue
python scripts/github_tool.py create-issue --repo CDC_AgS_2025 --title "Bug in module" --body "Description of the bug"

# 2. Assign and label
python scripts/github_tool.py assign-issue --repo CDC_AgS_2025 --number 456 --assignees "developer1"
python scripts/github_tool.py add-labels --repo CDC_AgS_2025 --number 456 --labels "bug,high-priority"

# 3. Track progress
python scripts/github_tool.py get-issue --repo CDC_AgS_2025 --number 456
```

### Repository Analysis Workflow

```powershell
# 1. Get repository statistics
python scripts/github_tool.py get-stats --repo CDC_AgS_2025

# 2. Get recent activity
python scripts/github_tool.py get-activity --repo CDC_AgS_2025 --days 30

# 3. List contributors
python scripts/github_tool.py get-contributors --repo CDC_AgS_2025
```

## Integration with Other Skills

### Jira Integration

Link GitHub operations to Jira tickets:

```powershell
# Create PR with Jira reference
python scripts/github_tool.py create-pr --repo CDC_AgS_2025 --title "Fix CPSE-456: Memory leak" --body "Fixes CPSE-456" --head "fix/memory-leak" --base "main"
```

### Confluence Integration

Generate documentation for Confluence:

```powershell
# Export repository information for documentation
python scripts/github_tool.py get-repo --repo CDC_AgS_2025 > repo_info.json
```

## Error Handling

The tool provides detailed error messages for common issues:

- **Authentication errors**: Check your GitHub token
- **Repository not found**: Verify repository name and permissions
- **Rate limiting**: The tool handles rate limiting automatically
- **Invalid parameters**: Check command syntax and required arguments

## Best Practices

1. **Token Security**: Never commit your GitHub token to version control
2. **Rate Limits**: Be mindful of GitHub API rate limits
3. **Permissions**: Ensure your token has the necessary permissions
4. **Favorites**: Use favorite repositories for quick access
5. **Batch Operations**: Use batch operations for multiple repositories when possible

## Troubleshooting

### Common Issues

1. **SSL Certificate Errors**: The tool disables SSL verification for internal GitHub instances
2. **Authentication Failures**: Verify your token is valid and has proper permissions
3. **Repository Access**: Ensure you have access to the specified repositories
4. **Virtual Environment**: Always activate the virtual environment before use

### Debug Mode

Enable debug output by setting environment variable:

```powershell
$env:DEBUG = "1"
python scripts/github_tool.py list-repos
```

## Contributing

To extend the GitHub integration skill:

1. Add new methods to the `GitHubTool` class in `scripts/github_tool.py`
2. Update the CLI parser to include new commands
3. Update `SKILL.md` with new functionality documentation
4. Test with different GitHub repositories and scenarios

## Support

For issues and questions:

1. Check this README and `SKILL.md` for documentation
2. Verify your configuration and permissions
3. Test with a simple command like `list-repos`
4. Check the GitHub API documentation for endpoint details

## License

This skill is part of the BEA LLM Skills framework and follows the same licensing terms.
