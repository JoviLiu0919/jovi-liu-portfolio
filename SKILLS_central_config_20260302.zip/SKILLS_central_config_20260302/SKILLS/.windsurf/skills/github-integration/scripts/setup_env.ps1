# GitHub Integration Skill Setup Script
# This script sets up the environment for the GitHub integration skill

Write-Host "Setting up GitHub Integration Skill environment..." -ForegroundColor Green

# Check if Python is installed
try {
    $pythonVersion = python --version 2>$null
    Write-Host "Found Python: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "Error: Python is not installed or not in PATH" -ForegroundColor Red
    exit 1
}

# Create virtual environment if it doesn't exist
if (-not (Test-Path ".venv")) {
    Write-Host "Creating virtual environment..." -ForegroundColor Yellow
    python -m venv .venv
} else {
    Write-Host "Virtual environment already exists" -ForegroundColor Green
}

# Activate virtual environment
Write-Host "Activating virtual environment..." -ForegroundColor Yellow
& .\.venv\Scripts\Activate.ps1

# Install required packages
Write-Host "Installing required packages..." -ForegroundColor Yellow
pip install requests urllib3 toml

# Create config file if it doesn't exist
if (-not (Test-Path "config.toml")) {
    Write-Host "Creating config.toml file..." -ForegroundColor Yellow
    @"
[github]
base_url = "https://githubcsg.cec.delllabs.net/api/v3"
owner = "CSG-Firmware-Engineering"
token = "YOUR_GITHUB_TOKEN"

[api]
timeout = 30
max_retries = 3
per_page = 100

[favorites]
repos = [
    "CDC_AgS_2025",
    "CDC_Intel_2025", 
    "CDC_Edk2_2025",
    "CDC_Edk2Platforms_2025",
    "CBF_DellFeaturesPkg",
    "CBF_DellBiosConnectPkg",
    "CBF_DellManageabilityPkg",
    "CDC_OpensslBinPkg",
    "CDC_Amd_2025"
]
"@ | Out-File -FilePath "config.toml" -Encoding utf8
    Write-Host "Created config.toml. Please update token with your actual GitHub token." -ForegroundColor Yellow
} else {
    Write-Host "config.toml already exists" -ForegroundColor Green
}

# Create scripts directory if it doesn't exist
if (-not (Test-Path "scripts")) {
    New-Item -ItemType Directory -Path "scripts" -Force
    Write-Host "Created scripts directory" -ForegroundColor Green
}

Write-Host "Setup completed successfully!" -ForegroundColor Green
Write-Host "Please update config.toml with your GitHub token before using the skill." -ForegroundColor Yellow
Write-Host "To activate the virtual environment, run: .\.venv\Scripts\Activate.ps1" -ForegroundColor Cyan
