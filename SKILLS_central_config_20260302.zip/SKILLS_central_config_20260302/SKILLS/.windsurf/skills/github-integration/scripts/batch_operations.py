#!/usr/bin/env python3
"""
Batch Operations for GitHub Integration - Advanced repository management and analysis
"""

import argparse
import json
import sys
import os
from datetime import datetime, timedelta
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import toml

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from github_tool import GitHubTool


class BatchOperations:
    def __init__(self):
        self.tool = GitHubTool()
    
    def batch_update_repos(self, repos, action, **kwargs):
        """Perform batch operations on multiple repositories"""
        results = {}
        
        with ThreadPoolExecutor(max_workers=5) as executor:
            future_to_repo = {
                executor.submit(self._update_single_repo, repo, action, **kwargs): repo 
                for repo in repos
            }
            
            for future in as_completed(future_to_repo):
                repo = future_to_repo[future]
                try:
                    result = future.result()
                    results[repo] = result
                except Exception as e:
                    results[repo] = f"Error: {str(e)}"
        
        return results
    
    def _update_single_repo(self, repo, action, **kwargs):
        """Update a single repository with the specified action"""
        if action == "sync-branches":
            return self._sync_branches(repo)
        elif action == "cleanup-prs":
            return self._cleanup_old_prs(repo, kwargs.get("days", 30))
        elif action == "update-labels":
            return self._update_repo_labels(repo, kwargs.get("labels", []))
        elif action == "health-check":
            return self._health_check(repo)
        else:
            return f"Unknown action: {action}"
    
    def _sync_branches(self, repo):
        """Sync main branch across repositories"""
        try:
            branches = self.tool.get_branches(repo)
            if isinstance(branches, str) and branches.startswith("Error"):
                return branches
            
            main_branch = None
            for branch in branches:
                if branch["name"] in ["main", "master", "develop"]:
                    main_branch = branch["name"]
                    break
            
            if not main_branch:
                return "No main/master/develop branch found"
            
            return f"Main branch '{main_branch}' found in {repo}"
        except Exception as e:
            return f"Error syncing branches: {str(e)}"
    
    def _cleanup_old_prs(self, repo, days):
        """Clean up old closed pull requests"""
        try:
            cutoff_date = datetime.now() - timedelta(days=days)
            prs = self.tool.search_prs(repo, f"is:pr is:closed closed:<{cutoff_date.isoformat()}")
            
            if isinstance(prs, str) and prs.startswith("Error"):
                return prs
            
            if "items" in prs:
                old_prs = prs["items"]
                return f"Found {len(old_prs)} PRs older than {days} days in {repo}"
            else:
                return f"No old PRs found in {repo}"
        except Exception as e:
            return f"Error cleaning up PRs: {str(e)}"
    
    def _update_repo_labels(self, repo, labels):
        """Update repository labels"""
        try:
            # This would require implementing label management in GitHubTool
            return f"Label update requested for {repo}: {labels}"
        except Exception as e:
            return f"Error updating labels: {str(e)}"
    
    def _health_check(self, repo):
        """Perform health check on repository"""
        try:
            health_data = {
                "repository": repo,
                "timestamp": datetime.now().isoformat(),
                "checks": {}
            }
            
            # Check if repository exists
            repo_info = self.tool.get_repo(repo)
            if isinstance(repo_info, str) and repo_info.startswith("Error"):
                health_data["checks"]["repository_exists"] = False
                health_data["checks"]["error"] = repo_info
                return health_data
            
            health_data["checks"]["repository_exists"] = True
            health_data["checks"]["default_branch"] = repo_info.get("default_branch", "unknown")
            health_data["checks"]["is_archived"] = repo_info.get("archived", False)
            health_data["checks"]["size_kb"] = repo_info.get("size", 0)
            health_data["checks"]["open_issues"] = repo_info.get("open_issues_count", 0)
            
            # Check recent activity
            activity = self.tool.get_activity(repo, days=30)
            if not (isinstance(activity, str) and activity.startswith("Error")):
                health_data["checks"]["recent_commits_30d"] = len(activity) if isinstance(activity, list) else 0
            
            # Check open PRs
            open_prs = self.tool.search_prs(repo, "is:pr is:open")
            if not (isinstance(open_prs, str) and open_prs.startswith("Error")):
                health_data["checks"]["open_prs"] = len(open_prs.get("items", [])) if "items" in open_prs else 0
            
            # Overall health score
            health_score = self._calculate_health_score(health_data["checks"])
            health_data["health_score"] = health_score
            health_data["health_status"] = self._get_health_status(health_score)
            
            return health_data
        except Exception as e:
            return {"error": f"Health check failed: {str(e)}"}
    
    def _calculate_health_score(self, checks):
        """Calculate repository health score"""
        score = 100
        
        # Deduct points for issues
        if checks.get("is_archived", False):
            score -= 50
        
        open_issues = checks.get("open_issues", 0)
        if open_issues > 50:
            score -= 20
        elif open_issues > 20:
            score -= 10
        elif open_issues > 10:
            score -= 5
        
        open_prs = checks.get("open_prs", 0)
        if open_prs > 20:
            score -= 15
        elif open_prs > 10:
            score -= 10
        elif open_prs > 5:
            score -= 5
        
        recent_commits = checks.get("recent_commits_30d", 0)
        if recent_commits == 0:
            score -= 30
        elif recent_commits < 5:
            score -= 15
        elif recent_commits < 10:
            score -= 5
        
        return max(0, score)
    
    def _get_health_status(self, score):
        """Get health status from score"""
        if score >= 90:
            return "Excellent"
        elif score >= 75:
            return "Good"
        elif score >= 60:
            return "Fair"
        elif score >= 40:
            return "Poor"
        else:
            return "Critical"
    
    def generate_repository_report(self, repos, format="markdown"):
        """Generate comprehensive repository report"""
        report_data = {
            "generated_at": datetime.now().isoformat(),
            "repositories": repos,
            "summary": {},
            "details": {}
        }
        
        # Get health check for all repositories
        health_results = self.batch_update_repos(repos, "health-check")
        
        # Process results
        total_score = 0
        status_counts = {}
        
        for repo, health in health_results.items():
            report_data["details"][repo] = health
            
            if isinstance(health, dict) and "health_score" in health:
                score = health["health_score"]
                status = health["health_status"]
                
                total_score += score
                status_counts[status] = status_counts.get(status, 0) + 1
        
        # Calculate summary
        if repos:
            report_data["summary"] = {
                "total_repositories": len(repos),
                "average_health_score": total_score / len(repos) if total_score > 0 else 0,
                "health_status_distribution": status_counts
            }
        
        # Format output
        if format == "json":
            return json.dumps(report_data, indent=2)
        elif format == "markdown":
            return self._format_markdown_report(report_data)
        else:
            return report_data
    
    def _format_markdown_report(self, report_data):
        """Format report as markdown"""
        md = []
        md.append("# Repository Health Report")
        md.append(f"Generated: {report_data['generated_at']}")
        md.append("")
        
        # Summary
        summary = report_data.get("summary", {})
        if summary:
            md.append("## Summary")
            md.append(f"- **Total Repositories**: {summary.get('total_repositories', 0)}")
            md.append(f"- **Average Health Score**: {summary.get('average_health_score', 0):.1f}")
            md.append("")
            
            md.append("### Health Status Distribution")
            status_dist = summary.get("health_status_distribution", {})
            for status, count in status_dist.items():
                md.append(f"- **{status}**: {count}")
            md.append("")
        
        # Details
        md.append("## Repository Details")
        details = report_data.get("details", {})
        
        for repo, health in details.items():
            md.append(f"### {repo}")
            
            if isinstance(health, dict) and "health_score" in health:
                checks = health.get("checks", {})
                md.append(f"- **Health Score**: {health['health_score']}/100 ({health['health_status']})")
                md.append(f"- **Default Branch**: {checks.get('default_branch', 'N/A')}")
                md.append(f"- **Open Issues**: {checks.get('open_issues', 0)}")
                md.append(f"- **Open PRs**: {checks.get('open_prs', 0)}")
                md.append(f"- **Recent Commits (30d)**: {checks.get('recent_commits_30d', 0)}")
                md.append(f"- **Archived**: {checks.get('is_archived', False)}")
            else:
                md.append(f"- **Status**: Error")
                md.append(f"- **Details**: {health}")
            
            md.append("")
        
        return "\n".join(md)
    
    def batch_create_prs(self, repos, title, body, head_branch, base_branch="main"):
        """Create pull requests across multiple repositories"""
        results = {}
        
        for repo in repos:
            try:
                # Check if head branch exists
                branch_info = self.tool.get_branch(repo, head_branch)
                if isinstance(branch_info, str) and branch_info.startswith("Error"):
                    results[repo] = f"Branch '{head_branch}' not found: {branch_info}"
                    continue
                
                # Create PR
                pr_result = self.tool.create_pr(repo, title, body, head_branch, base_branch)
                results[repo] = pr_result
            except Exception as e:
                results[repo] = f"Error creating PR: {str(e)}"
        
        return results


def main():
    parser = argparse.ArgumentParser(description="Batch Operations for GitHub Integration")
    batch_ops = BatchOperations()
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Batch update
    batch_update_parser = subparsers.add_parser("batch-update", help="Perform batch operations on repositories")
    batch_update_parser.add_argument("--repos", required=True, help="Comma-separated list of repositories")
    batch_update_parser.add_argument("--action", required=True, choices=["sync-branches", "cleanup-prs", "health-check"], help="Action to perform")
    batch_update_parser.add_argument("--days", type=int, default=30, help="Days for cleanup operations")
    
    # Generate report
    report_parser = subparsers.add_parser("generate-report", help="Generate repository health report")
    report_parser.add_argument("--repos", required=True, help="Comma-separated list of repositories")
    report_parser.add_argument("--format", choices=["json", "markdown"], default="markdown", help="Report format")
    
    # Batch create PRs
    batch_pr_parser = subparsers.add_parser("batch-create-pr", help="Create pull requests across repositories")
    batch_pr_parser.add_argument("--repos", required=True, help="Comma-separated list of repositories")
    batch_pr_parser.add_argument("--title", required=True, help="Pull request title")
    batch_pr_parser.add_argument("--body", required=True, help="Pull request body")
    batch_pr_parser.add_argument("--head", required=True, help="Head branch")
    batch_pr_parser.add_argument("--base", default="main", help="Base branch")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    try:
        if args.command == "batch-update":
            repos = [repo.strip() for repo in args.repos.split(",")]
            kwargs = {"days": args.days} if args.action == "cleanup-prs" else {}
            results = batch_ops.batch_update_repos(repos, args.action, **kwargs)
            print(json.dumps(results, indent=2))
        
        elif args.command == "generate-report":
            repos = [repo.strip() for repo in args.repos.split(",")]
            report = batch_ops.generate_repository_report(repos, args.format)
            print(report)
        
        elif args.command == "batch-create-pr":
            repos = [repo.strip() for repo in args.repos.split(",")]
            results = batch_ops.batch_create_prs(repos, args.title, args.body, args.head, args.base)
            print(json.dumps(results, indent=2))
        
        else:
            print(f"Unknown command: {args.command}")
    
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
