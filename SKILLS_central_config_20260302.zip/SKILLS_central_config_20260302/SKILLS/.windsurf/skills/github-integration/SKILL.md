---
name: github-integration
description: Manage GitHub repositories, pull requests, and commits (Create, Update, Search, Review). Use when accessing GitHub repositories, managing PRs, or analyzing code changes.
---

# GitHub Integration Skill

Start here to manage GitHub repositories and pull requests. This skill provides comprehensive tools for GitHub operations including repository management, pull request handling, and commit analysis.

## 📚 Compliance with skill_guides

This skill follows all guidelines specified in `.windsurf/skills/skill-guides/SKILL.md`:
- **Core Integration Architecture**: Uses centralized GitHub configuration
- **Zero-Temp-File Policy**: All processing done in memory
- **Report Generation Standards**: Saves bilingual reports to `.windsurf/Reports/`
- **Cross-Session Consistency**: Ensures consistent behavior across sessions

## Interaction Rules (Agent Instructions)

*   **Validation**: Before running any command, check if all required arguments (e.g., `repo`, `pull_number`, `sha`) are present. If missing, **ask the user** first.
*   **Confirmation (CRITICAL)**: You **MUST** ask for user confirmation before executing any action that modifies state. This includes:
    *   **Create** (pull requests, issues, comments)
    *   **Update** (pull requests, issues, labels)
    *   **Merge** (pull requests)
    *   **Close** (issues, pull requests)
    *   **Assign** (assignees, reviewers)
    *   **Any other destructive action**
    *   *Exception*: You may proceed without confirmation ONLY if the user explicitly provided the full command or asked you to "just do it".
*   **Read-Only**: For `get`, `list`, `diff`, and `search` commands, you may proceed without confirmation.

## Usage Guidelines (Agent Behavior)

### Repository Analysis Priority
When users ask for repository analysis, listing, or overview:
1. **First Priority**: Use `list-repos --format summary --include-bios-submodules` for comprehensive analysis
2. **Alternative**: Use `list-repos-detailed --include-bios-submodules` for more detailed output
3. **Simple List**: Use `list-repos --format summary` for basic overview

### BIOS TOT Repository Handling
When users mention "BIOS repositories", "CDC_AgS", or ask for repository analysis:
1. **Always include BIOS submodules analysis** with `--include-bios-submodules`
2. **Expect bilingual output** (English content + Chinese summary)
3. **Automatic categorization** will separate BIOS TOT from Other repositories

### Expected Output Format
The repository analysis should produce:
- **English main content** with Markdown tables
- **Bilingual summary section** (🇹🇼 Chinese + 🇺🇸 English)
- **BIOS TOT submodules analysis** (if requested)
- **Statistics and categorization**

### CRITICAL: Command Execution Requirements
- **NEVER reformat or modify the tool output** - Display the exact Markdown output from the command
- **ALWAYS use the recommended command** from the table below for consistency
- **DO NOT create custom summaries** - Let the tool generate the complete report
- **PRESERVE Markdown formatting** including tables, headers, and emojis
- **ALWAYS include --include-bios-submodules** for repository analysis requests - This parameter is MANDATORY for CDC_AgS repositories and submodules analysis

### When to Use Different Commands
- **General repository overview**: `list-repos --format summary --include-bios-submodules`
- **BIOS-specific analysis**: `analyze-bios-submodules` or `list-repos --include-bios-submodules`
- **Quick repository list**: `list-repos --format summary` (only if user explicitly asks for "quick" or "simple")
- **Detailed statistics**: `list-repos-detailed --include-bios-submodules`

## Setup

1.  **Install Dependencies** (One-time):
    ```powershell
    cd .windsurf/github_integration
    .\scripts\setup_env.ps1
    ```
2.  **Configuration**:
    Ensure `config.toml` has your `token`, `owner`, and `base_url`.

## Quick Start (For New Users/Sessions)

### Get Repository Analysis Immediately
For comprehensive repository analysis with BIOS TOT submodules and bilingual output:

```powershell
# This is the RECOMMENDED command for most use cases
python scripts/github_tool.py list-repos --format summary --include-bios-submodules

# Alternative using module syntax
python -m github_tool list-repos --format summary --include-bios-submodules
```

**WARNING**: DO NOT use `list-repos --format summary` without `--include-bios-submodules` - this will miss CDC_AgS submodules analysis!

**Expected Output:**
- 📊 Statistics Overview (total repositories, categories)
- 🔥 BIOS TOT Repositories table (CDC_AgS_2021-2025)
- 📦 Other Repositories table (first 30)
- 🔧 BIOS TOT Submodules Analysis (detailed mapping)
- ⭐ Favorite Repositories
- 🔧 Programming Languages statistics
- 📋 Bilingual Summary (Chinese + English)

### Quick Examples
```powershell
# Basic repository list (no submodules)
python scripts/github_tool.py list-repos --format summary

# BIOS-specific submodules analysis only
python scripts/github_tool.py analyze-bios-submodules

# Analyze specific BIOS years
python scripts/github_tool.py analyze-bios-submodules --years "2025,2024"
```

### Common User Requests & Expected Commands
| User Request | Recommended Command | **MANDATORY** |
|--------------|-------------------|----------------|
| "Show me my repositories" | `list-repos --format summary --include-bios-submodules` | **EXACT OUTPUT REQUIRED** |
| "Analyze BIOS repositories" | `list-repos --format summary --include-bios-submodules` | **EXACT OUTPUT REQUIRED** |
| "List CDC_AgS repositories" | `list-repos --format summary --include-bios-submodules` | **EXACT OUTPUT REQUIRED** |
| "Repository overview" | `list-repos --format summary --include-bios-submodules` | **EXACT OUTPUT REQUIRED** |
| "BIOS submodules analysis" | `analyze-bios-submodules` | **EXACT OUTPUT REQUIRED** |

**IMPORTANT**: For ALL requests above, you MUST:
1. Execute the EXACT command shown
2. Display the RAW output WITHOUT modification
3. DO NOT reformat, summarize, or alter the Markdown
4. Preserve ALL tables, headers, emojis, and formatting

## Repository Management

### List Repositories
```powershell
# List all repositories (JSON format - original behavior)
python scripts/github_tool.py list-repos

# List repositories with formatted summary (in-memory processing)
python scripts/github_tool.py list-repos --format summary

# List repositories with BIOS TOT submodules analysis (bilingual output)
python scripts/github_tool.py list-repos --format summary --include-bios-submodules

# Detailed repository summary with statistics and categorization
python scripts/github_tool.py list-repos-detailed

# Detailed summary with BIOS TOT submodules analysis
python scripts/github_tool.py list-repos-detailed --include-bios-submodules

# List favorite repositories from config.toml
python scripts/github_tool.py list-favorites
```

**Enhanced Repository Listing Features:**
- **In-Memory Processing**: No temporary files created
- **Smart Categorization**: Automatically identifies BIOS TOT repositories (CDC_AgS_*) vs Others
- **BIOS TOT Analysis**: Automatic submodules analysis for BIOS repositories
- **Bilingual Output**: English content with Traditional Chinese summary
- **Statistics**: Language distribution and update frequency
- **Favorites Integration**: Highlights configured favorite repositories
- **Formatted Output**: Human-readable Markdown tables with emojis

**BIOS TOT Repository Features:**
- **Automatic Detection**: Identifies CDC_AgS_* pattern repositories
- **Submodules Mapping**: Shows core and platform submodule usage
- **Usage Statistics**: Frequency and usage rates across versions
- **Detailed Information**: Complete submodule lists with branch information
- **Bilingual Summary**: English analysis with Chinese overview

### BIOS TOT Submodules Analysis
```powershell
# Analyze all BIOS TOT repository submodules
python scripts/github_tool.py analyze-bios-submodules

# Analyze specific years
python scripts/github_tool.py analyze-bios-submodules --years "2025,2024,2023"
```

**BIOS Submodules Analysis Features:**
- **Automatic Detection**: Identifies CDC_AgS_* repositories as BIOS TOT
- **Submodule Mapping**: Creates mapping tables of submodule usage
- **Usage Statistics**: Shows frequency and usage rates across versions
- **Categorized Tables**: Separates core and platform submodules
- **Detailed Information**: Lists all submodules with branch information
- **In-Memory Processing**: No temporary files created

### Get Repository Information
```powershell
# Get repository details
python scripts/github_tool.py get-repo --repo CDC_AgS_2025

# Get repository contents
python scripts/github_tool.py get-contents --repo CDC_AgS_2025 --path "/"

# Get repository branches
python scripts/github_tool.py get-branches --repo CDC_AgS_2025
```

## Pull Request Management

### Get Pull Request Information
```powershell
# Get PR details
python scripts/github_tool.py get-pr --repo CDC_AgS_2025 --number 123

# Get PR diff
python scripts/github_tool.py get-pr-diff --repo CDC_AgS_2025 --number 123

# Get PR files
python scripts/github_tool.py get-pr-files --repo CDC_AgS_2025 --number 123
```

### Create Pull Request
```powershell
# Create a new pull request
python scripts/github_tool.py create-pr --repo CDC_AgS_2025 --title "Fix bug in module" --body "Description of changes" --head "feature-branch" --base "main"
```

### Update Pull Request
```powershell
# Update PR title and description
python scripts/github_tool.py update-pr --repo CDC_AgS_2025 --number 123 --title "New title" --body "Updated description"

# Add reviewers
python scripts/github_tool.py add-reviewers --repo CDC_AgS_2025 --number 123 --reviewers "user1,user2"

# Assign PR
python scripts/github_tool.py assign-pr --repo CDC_AgS_2025 --number 123 --assignees "user1"
```

### Pull Request Actions
```powershell
# Merge pull request
python scripts/github_tool.py merge-pr --repo CDC_AgS_2025 --number 123 --merge-method "squash"

# Close pull request
python scripts/github_tool.py close-pr --repo CDC_AgS_2025 --number 123

# Reopen pull request
python scripts/github_tool.py reopen-pr --repo CDC_AgS_2025 --number 123
```

## Commit Management

### Get Commit Information
```powershell
# Get commit details
python scripts/github_tool.py get-commit --repo CDC_AgS_2025 --sha "abc123"

# Get commit diff
python scripts/github_tool.py get-commit-diff --repo CDC_AgS_2025 --sha "abc123"

# Get commit files
python scripts/github_tool.py get-commit-files --repo CDC_AgS_2025 --sha "abc123"
```

### List Commits
```powershell
# List commits for a branch
python scripts/github_tool.py list-commits --repo CDC_AgS_2025 --branch "main"

# List commits for a PR
python scripts/github_tool.py list-pr-commits --repo CDC_AgS_2025 --number 123
```

## Issue Management

### Get Issue Information
```powershell
# Get issue details
python scripts/github_tool.py get-issue --repo CDC_AgS_2025 --number 456

# List issues
python scripts/github_tool.py list-issues --repo CDC_AgS_2025 --state "open"

# Search issues
python scripts/github_tool.py search-issues --repo CDC_AgS_2025 --query "bug"
```

### Create and Update Issues
```powershell
# Create issue
python scripts/github_tool.py create-issue --repo CDC_AgS_2025 --title "Bug report" --body "Description of bug"

# Update issue
python scripts/github_tool.py update-issue --repo CDC_AgS_2025 --number 456 --title "Updated title" --body "Updated description"

# Add labels to issue
python scripts/github_tool.py add-labels --repo CDC_AgS_2025 --number 456 --labels "bug,high-priority"

# Assign issue
python scripts/github_tool.py assign-issue --repo CDC_AgS_2025 --number 456 --assignees "user1"
```

## Comment Management

### Add Comments
```powershell
# Add comment to issue
python scripts/github_tool.py add-comment --repo CDC_AgS_2025 --number 456 --type "issue" --body "This is a comment"

# Add comment to pull request
python scripts/github_tool.py add-comment --repo CDC_AgS_2025 --number 123 --type "pr" --body "Review comments"
```

### Get Comments
```powershell
# Get issue comments
python scripts/github_tool.py get-comments --repo CDC_AgS_2025 --number 456 --type "issue"

# Get PR comments
python scripts/github_tool.py get-comments --repo CDC_AgS_2025 --number 123 --type "pr"
```

## Search and Filtering

### Search Repositories
```powershell
# Search repositories
python scripts/github_tool.py search-repos --query "firmware"

# Search code
python scripts/github_tool.py search-code --repo CDC_AgS_2025 --query "function_name"
```

### Search Pull Requests
```powershell
# Search pull requests
python scripts/github_tool.py search-prs --repo CDC_AgS_2025 --query "is:open is:pr"

# Search by author
python scripts/github_tool.py search-prs --repo CDC_AgS_2025 --query "author:username"
```

## Branch Management

### Branch Operations
```powershell
# Create branch
python scripts/github_tool.py create-branch --repo CDC_AgS_2025 --branch "feature-branch" --from "main"

# Delete branch
python scripts/github_tool.py delete-branch --repo CDC_AgS_2025 --branch "feature-branch"

# Get branch information
python scripts/github_tool.py get-branch --repo CDC_AgS_2025 --branch "feature-branch"
```

## Repository Analytics

### Repository Statistics
```powershell
# Get repository statistics
python scripts/github_tool.py get-stats --repo CDC_AgS_2025

# Get contributor information
python scripts/github_tool.py get-contributors --repo CDC_AgS_2025

# Get commit activity
python scripts/github_tool.py get-activity --repo CDC_AgS_2025 --days 30
```

## Workflow Automation

### Create Workflow
```powershell
# Create GitHub Actions workflow
python scripts/github_tool.py create-workflow --repo CDC_AgS_2025 --name "CI" --workflow-file ".github/workflows/ci.yml"
```

### Trigger Workflow
```powershell
# Trigger workflow run
python scripts/github_tool.py trigger-workflow --repo CDC_AgS_2025 --workflow-id "12345"
```

## Favorite Repositories

### Manage Favorites
```powershell
# Add repository to favorites
python scripts/github_tool.py add-favorite --repo CDC_AgS_2025

# Remove repository from favorites
python scripts/github_tool.py remove-favorite --repo CDC_AgS_2025

# Show favorite repositories
python scripts/github_tool.py show-favorites
```

## Advanced Operations

### Batch Operations
```powershell
# Batch update multiple repositories
python scripts/github_tool.py batch-update --repos "repo1,repo2,repo3" --action "sync-branches"

# Batch create pull requests
python scripts/github_tool.py batch-create-pr --repos "repo1,repo2" --title "Update dependencies" --body "Automated dependency update"
```

### Repository Health Check
```powershell
# Check repository health
python scripts/github_tool.py health-check --repo CDC_AgS_2025

# Generate repository report
python scripts/github_tool.py generate-report --repo CDC_AgS_2025 --format "markdown"
```

## Common GitHub API Patterns

### Rate Limiting
The GitHub API has rate limits. The tool automatically handles rate limiting and will retry when limits are reached.

### Authentication
All operations use the configured GitHub token from `config.py`. Ensure the token has the necessary permissions for the operations you want to perform.

### Error Handling
The tool provides detailed error messages for common issues:
- Authentication errors
- Repository not found
- Insufficient permissions
- Rate limiting
- Invalid parameters

## Integration with Other Skills

### Jira Integration
Link GitHub pull requests to Jira tickets:
```powershell
# Link PR to Jira ticket in PR description
python scripts/github_tool.py update-pr --repo CDC_AgS_2025 --number 123 --body "Fixes CPSE-456: Description of fix"
```

### Confluence Integration
Generate documentation from repository:
```powershell
# Generate repository documentation for Confluence
python scripts/github_tool.py generate-docs --repo CDC_AgS_2025 --format "confluence"
```
