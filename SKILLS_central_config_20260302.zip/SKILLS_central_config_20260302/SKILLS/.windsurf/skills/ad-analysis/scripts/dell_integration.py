#!/usr/bin/env python3
"""
Dell Domain Knowledge Integration - Simplified Version
Provide Dell specific background knowledge and analysis insights
"""

# Dell specific technical knowledge
DELL_TECHNICAL_KNOWLEDGE = {
    'PQC': {
        'description': 'Product Quality Control - Product quality control',
        'context': 'Dell product quality control process',
        'impact': 'Affects product quality and verification process'
    },
    'ATS': {
        'description': 'Agree To Ship - Agree to ship',
        'context': 'Mechanism that allows certain issues to be resolved after MP',
        'impact': 'Affects product shipment schedule'
    },
    'CPSE': {
        'description': 'Customer Product Support Engineering - Customer product support engineering',
        'context': 'Dell customer product support team',
        'impact': 'Affects customer support process'
    },
    'ODM': {
        'description': 'Original Design Manufacturer - Original design manufacturer',
        'context': 'Dell cooperative partner manufacturer',
        'impact': 'Affects manufacturing process and quality'
    },
    'VM': {
        'description': 'Validation Management - Validation management',
        'context': 'Dell validation management team',
        'impact': 'Affects validation process and schedule'
    }
}

# Dell platform specific considerations
DELL_PLATFORM_CONSIDERATIONS = {
    'INTEL_FSP': {
        'description': 'Intel FSP architecture considerations',
        'details': 'Special requirements for Intel Firmware Support Package on Dell platform',
        'recommendations': ['Follow Dell FSP integration guide', 'Pay attention to BootGuard compatibility']
    },
    'AMD_AGESA': {
        'description': 'AMD AGESA architecture considerations',
        'details': 'Special requirements for AMD Generic Encapsulated Software Architecture on Dell platform',
        'recommendations': ['Follow Dell AGESA integration guide', 'Pay attention to PSP security']
    },
    'SECURE_BOOT': {
        'description': 'Secure boot considerations',
        'details': 'Special requirements for Dell secure boot implementation',
        'recommendations': ['Follow Dell secure boot policy', 'Pay attention to key management']
    },
    'SIGNING_PROCESS': {
        'description': 'Signing process considerations',
        'details': 'Special requirements for Dell BIOS/firmware signing process',
        'recommendations': ['Follow Dell signing policy', 'Pay attention to key security']
    }
}

# Dell team collaboration process
DELL_TEAM_COLLABORATION = {
    'BIOS_SE': {
        'description': 'BIOS system engineer',
        'responsibilities': ['BIOS development', 'Function implementation', 'Test verification'],
        'collaboration': ['Collaborate with ODM', 'Collaborate with VM', 'Collaborate with CPSE']
    },
    'ODM_ENGINEER': {
        'description': 'ODM engineer',
        'responsibilities': ['Hardware design', 'Manufacturing support', 'Quality assurance'],
        'collaboration': ['Collaborate with Dell BIOS SE', 'Collaborate with VM']
    },
    'VM_ENGINEER': {
        'description': 'Validation management engineer',
        'responsibilities': ['Validation planning', 'Test execution', 'Issue tracking'],
        'collaboration': ['Collaborate with BIOS SE', 'Collaborate with ODM', 'Collaborate with CPSE']
    },
    'CPSE_ENGINEER': {
        'description': 'Customer product support engineer',
        'responsibilities': ['Customer support', 'Issue analysis', 'Solution'],
        'collaboration': ['Collaborate with BIOS SE', 'Collaborate with VM']
    }
}

def get_dell_domain_insights(content_text: str) -> dict:
    """Get Dell specific insights"""
    insights = {}
    content_lower = content_text.lower()
    
    # Analyze Dell specific technology
    dell_tech = {}
    for tech, info in DELL_TECHNICAL_KNOWLEDGE.items():
        if tech.lower() in content_lower:
            dell_tech[tech] = info
    
    # Analyze platform specific considerations
    platform_considerations = {}
    for platform, info in DELL_PLATFORM_CONSIDERATIONS.items():
        if any(keyword in content_lower for keyword in platform.lower().split('_')):
            platform_considerations[platform] = info
    
    # Analyze team collaboration
    team_collaboration = {}
    for team, info in DELL_TEAM_COLLABORATION.items():
        if any(keyword in content_lower for keyword in team.lower().split('_')):
            team_collaboration[team] = info
    
    insights = {
        'dell_technical_knowledge': dell_tech,
        'platform_considerations': platform_considerations,
        'team_collaboration': team_collaboration,
        'is_dell_specific': len(dell_tech) > 0 or len(platform_considerations) > 0
    }
    
    return insights

def format_dell_insights(insights: dict) -> str:
    """Format Dell insights as report content"""
    if not insights.get('is_dell_specific', False):
        return ""
    
    formatted_insights = []
    
    # Dell technical knowledge
    dell_tech = insights.get('dell_technical_knowledge', {})
    if dell_tech:
        formatted_insights.append("### 🏢️ Dell Technical Knowledge")
        for tech, info in dell_tech.items():
            formatted_insights.append(f"- **{tech}**: {info['description']}")
            formatted_insights.append(f"  - background: {info['context']}")
            formatted_insights.append(f"  - impact: {info['impact']}")
        formatted_insights.append("")
    
    # Platform specific considerations
    platform_considerations = insights.get('platform_considerations', {})
    if platform_considerations:
        formatted_insights.append("### 🔧 Platform Specific Considerations")
        for platform, info in platform_considerations.items():
            formatted_insights.append(f"- **{platform}**: {info['description']}")
            formatted_insights.append(f"  - details: {info['details']}")
            formatted_insights.append(f"  - suggestions: {', '.join(info['recommendations'])}")
        formatted_insights.append("")
    
    # Team collaboration
    team_collaboration = insights.get('team_collaboration', {})
    if team_collaboration:
        formatted_insights.append("### 👥 Team Collaboration Process")
        for team, info in team_collaboration.items():
            formatted_insights.append(f"- **{team}**: {info['description']}")
            formatted_insights.append(f"  - responsibilities: {', '.join(info['responsibilities'])}")
            formatted_insights.append(f"  - collaboration: {', '.join(info['collaboration'])}")
        formatted_insights.append("")
    
    return '\n'.join(formatted_insights)

def enhance_bios_summary_with_dell_knowledge(content_text: str, current_summary: str) -> str:
    """Use Dell knowledge enhancement BIOS summary"""
    dell_insights = get_dell_domain_insights(content_text)
    
    if dell_insights.get('is_dell_specific', False):
        dell_formatted = format_dell_insights(dell_insights)
        if dell_formatted:
            return f"{current_summary}\n\n{dell_formatted}"
    
    return current_summary
