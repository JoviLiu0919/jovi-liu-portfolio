#!/usr/bin/env python3
"""
Batch AD/FD Analysis Script
Analyze all AD/FD documentation in the entire 25Qx_NUDD directory
"""

import os
import sys
import glob
from pathlib import Path
from datetime import datetime

# Add current directory to path
sys.path.append(os.path.dirname(__file__))

try:
    from llm_ad_analyzer import ADAnalyzer
except ImportError:
    print("Error: Cannot import ADAnalyzer")
    sys.exit(1)

def find_ad_fd_files(directories):
    """
    Find all AD/FD documentation in multiple directories
    
    Args:
        directories: List of directories to search
        
    Returns:
        list: List of found AD/FD documentation paths
    """
    ad_fd_files = []
    
    for directory in directories:
        if os.path.exists(directory):
            # Search all .docx Documentation
            for docx_file in glob.glob(os.path.join(directory, "**/*.docx"), recursive=True):
                ad_fd_files.append(docx_file)
        else:
            print(f"⚠️ Directory does not exist: {directory}")
    
    # Sort by path
    ad_fd_files.sort()
    
    return ad_fd_files

def analyze_single_file(file_path, output_dir):
    """
    Analyze a single AD/FD documentation file
    
    Args:
        file_path: Path to the documentation file
        output_dir: Output directory
        
    Returns:
        str: Path to the generated report
    """
    try:
        # Directly call the main function from llm_ad_analyzer
        import llm_ad_analyzer
        
        # Simulate command line parameters
        sys.argv = ['llm_ad_analyzer.py', file_path]
        
        # Redirect output to avoid interference
        import io
        from contextlib import redirect_stdout
        
        # Capture output
        f = io.StringIO()
        with redirect_stdout(f):
            llm_ad_analyzer.main()
        
        # Construct clean_name same as llm_ad_analyzer
        import re
        from pathlib import Path
        
        original_name = Path(file_path).stem
        clean_name = original_name.replace(" ", "_").replace("-", "_")
        clean_name = ''.join(c for c in clean_name if c.isalnum() or c in ['_', '.'])
        if len(clean_name) > 50:
            clean_name = clean_name[:50]
        
        # Find recently generated report
        import glob
        pattern = os.path.join(output_dir, f"AD_Analysis_*_{clean_name}_*.md")
        reports = glob.glob(pattern)
        
        if reports:
            # Sort by modification time, return the latest
            reports.sort(key=lambda x: os.path.getmtime(x), reverse=True)
            return reports[0]
        
        return None
    except Exception as e:
        print(f"Error analyzing {file_path}: {str(e)}")
        return None

def extract_dell_features_from_filename(filename):
    """
    Extract Dell function features from documentation name
    
    Args:
        filename: Documentation name
        
    Returns:
        list: Dell function features list
    """
    features = []
    filename_lower = filename.lower()
    
    # Dell specific function keywords
    dell_keywords = {
        'pqc': 'Post-Quantum Cryptography',
        'rpmc': 'RPMC (Replay Protected Memory)',
        'esol': 'eSOL (Embedded Standard Out-of-Band)',
        'ediag': 'eDiag (Dell Diagnostics)',
        'memrx': 'Memory Healing (MemRx)',
        'spdm': 'SPDM (Security Protocol and Data Model)',
        'dlrm': 'Dynamic Link Rate Management',
        'adif': 'Automatic Display Issue Feedback',
        'nvme': 'NVMe (Non-Volatile Memory Express)',
        'stm': 'STM (Sensor Hub)',
        'i3c': 'I3C Interface',
        'mds': 'MDS (Mobile Design Studio)',
        'rfim': 'RFIM (Radio Frequency Interference Mitigation)',
        'encryption': 'Hardware Optimized Storage Encryption',
        'battery': 'Battery Calibration',
        'eusb': 'Enhanced USB',
        'sensor': 'Sensor Fusion',
        'telemetry': 'Platform Energy Telemetry',
        'spbt': 'Smart PC Boost & Throttle',
        'erpc': 'EU ErP Lot 3 Ecodesign',
        'rim': 'Reference Integrity Manifest',
        'tpm': 'TPM (Trusted Platform Module)',
        'thermal': 'Thermal Management',
        'wifi': 'Wi-Fi Features',
        'sppr': 'Software Post Package Repair',
        'iidt': 'Intel Intelligent Display Technology',
        'mfd': 'Multi-Frequency Display',
        'dar': 'Display Adaptive Resolution',
        'ubrr': 'USB-Based Retimer',
        'hdr': 'Smart Power HDR',
        'biosconnect': 'BIOSConnect',
        'inpu': 'Intelligent Processing Unit',
        'dnx': 'Deep Neural Network',
        'ec': 'Embedded Controller',
        'alienfx': 'AlienFX Lighting',
        'audio': 'Audio Codec Support',
        'cy27': 'CY27 Modular Design',
        'manufacture': 'Manufacturing Tool',
        'bootguard': 'Intel BootGuard',
        'psu': 'Power Supply Unit',
        'pio': 'Platform I/O',
        'amd': 'AMD Platform',
        'intel': 'Intel Platform',
        'nvl': 'Nova Lake',
        'recovery': 'BIOS Recovery',
        'controlvault': 'ControlVault',
        'rgb': 'RGB Lighting',
        'tbt': 'Thunderbolt',
        'aim': 'AIM (AMD Infrastructure Management)',
        'combo': 'Combo PI',
        'beep': 'PreOS Beep',
        'codec': 'Audio Codec',
        'flash': 'Flash Update',
        'spi': 'SPI Interface',
        'dma': 'DMA (Direct Memory Access)',
        'amt': 'Intel AMT',
        'coexistence': 'Wi-Fi Coexistence'
    }
    
    for keyword, description in dell_keywords.items():
        if keyword in filename_lower:
            features.append(description)
    
    return features

def generate_summary_report(analyzed_files, output_dir):
    """
    Generate batch analysis summary report
    
    Args:
        analyzed_files: List of analyzed documentation files
        output_dir: Output directory
    """
    summary_path = os.path.join(output_dir, f"AD_FD_Batch_Analysis_Summary_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.md")
    
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write("# Dell AD/FD Batch Analysis Summary Report\n\n")
        f.write(f"**Analysis Time**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"**Number of Analyzed Documents**: {len(analyzed_files)}\n")
        f.write(f"**Analysis Scope**: All AD/FD documentation in 25Qx_NUDD, 26Qx_NUDD_test, 27Qx_NUDD_test directories\n\n")
        
        f.write("## 📊 Analysis Statistics\n\n")
        
        # Statistics for various functions
        feature_stats = {}
        platform_stats = {'Intel': 0, 'AMD': 0, 'NVL': 0, 'General': 0}
        directory_stats = {}
        
        for file_info in analyzed_files:
            # Function statistics
            for feature in file_info['features']:
                feature_stats[feature] = feature_stats.get(feature, 0) + 1
            
            # Platform statistics
            filename_lower = file_info['filename'].lower()
            if 'amd' in filename_lower or 'mds' in filename_lower:
                platform_stats['AMD'] += 1
            elif 'nvl' in filename_lower or 'nova' in filename_lower:
                platform_stats['NVL'] += 1
            elif 'intel' in filename_lower or 'iidt' in filename_lower:
                platform_stats['Intel'] += 1
            else:
                platform_stats['General'] += 1
            
            # Directory statistics
            file_path = file_info['path']
            if '25Qx_NUDD' in file_path:
                directory_stats['25Qx_NUDD'] = directory_stats.get('25Qx_NUDD', 0) + 1
            elif '26Qx_NUDD_test' in file_path:
                directory_stats['26Qx_NUDD_test'] = directory_stats.get('26Qx_NUDD_test', 0) + 1
            elif '27Qx_NUDD_test' in file_path:
                directory_stats['27Qx_NUDD_test'] = directory_stats.get('27Qx_NUDD_test', 0) + 1
        
        f.write("### 📁 Directory Distribution\n\n")
        for directory, count in sorted(directory_stats.items()):
            f.write(f"- **{directory}**: {count} documents\n")
        
        f.write("\n### 🎯 Feature Distribution\n\n")
        for feature, count in sorted(feature_stats.items(), key=lambda x: x[1], reverse=True):
            f.write(f"- **{feature}**: {count} documents\n")
        
        f.write("\n### 🖥️ Platform Distribution\n\n")
        for platform, count in platform_stats.items():
            f.write(f"- **{platform}**: {count} documents\n")
        
        f.write("\n## 📋 Analyzed Document List\n\n")
        
        for file_info in analyzed_files:
            f.write(f"### {file_info['filename']}\n")
            f.write(f"- **Path**: `{file_info['path']}`\n")
            f.write(f"- **Report**: `{file_info['report']}`\n")
            if file_info['features']:
                f.write(f"- **Features**: {', '.join(file_info['features'])}\n")
            if file_info['error']:
                f.write(f"- **Bug**: {file_info['error']}\n")
            f.write("\n")
    
    return summary_path

def main():
    """main function"""
    import argparse
    
    # Configure command line parameters
    parser = argparse.ArgumentParser(description='Batch AD/FD AnalyzeTools')
    parser.add_argument('directory', nargs='?', 
                       help='Directory path to analyze (optional, if not specified then use default directory)')
    parser.add_argument('--output', '-o', 
                       help='Output directory (Default: .windsurf/Reports/Batch_Analysis)')
    parser.add_argument('--recursive', '-r', action='store_true',
                       help='Recursive search subdirectories (default enabled)')
    
    args = parser.parse_args()
    
    # Configure output directory
    if args.output:
        output_dir = args.output
    else:
        output_dir = os.path.join(".windsurf", "Reports", "Batch_Analysis")
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Configure directory to search
    if args.directory:
        if not os.path.exists(args.directory):
            print(f"❌ Directory does not exist: {args.directory}")
            return
        nudd_directories = [args.directory]
        print(f"📁 Analyze Directory: {args.directory}")
    else:
        # Use default directory
        nudd_directories = [
            "c:/BEA/AgS2025_Github/25Qx_NUDD",
            "c:/BEA/AgS2025_Github/26Qx_NUDD_test", 
            "c:/BEA/AgS2025_Github/27Qx_NUDD_test"
        ]
        print("📁 Use default directory:")
        for directory in nudd_directories:
            print(f"  - {directory}")
    
    # Find all AD/FD documentation
    ad_fd_files = find_ad_fd_files(nudd_directories)
    print(f"📄 Found {len(ad_fd_files)} AD/FD documents")
    
    if not ad_fd_files:
        print("❌ No AD/FD documentation found")
        return
    
    # Analyze documentation (all documents)
    analyzed_files = []
    
    for i, file_path in enumerate(ad_fd_files, 1):
        print(f"📊 Analyze {i}/{len(ad_fd_files)}: {os.path.basename(file_path)}")
        
        # Extract function features
        filename = os.path.basename(file_path)
        features = extract_dell_features_from_filename(filename)
        
        # Analyze documentation
        report_path = analyze_single_file(file_path, output_dir)
        
        file_info = {
            'filename': filename,
            'path': file_path,
            'features': features,
            'report': os.path.basename(report_path) if report_path else None,
            'error': None if report_path else "Analysis failed"
        }
        
        analyzed_files.append(file_info)
        
        if report_path:
            print(f"✅ Completed: {os.path.basename(report_path)}")
        else:
            print(f"❌ Failed: {filename}")
    
    # Generate summary report
    print("📋 Generating summary report...")
    summary_path = generate_summary_report(analyzed_files, output_dir)
    
    print(f"\n🎉 Batch analysis completed!")
    print(f"📊 Summary report: {os.path.basename(summary_path)}")
    print(f"📁 Detailed report: {output_dir}")

if __name__ == "__main__":
    main()
