#!/usr/bin/env python3
"""
BIOS Technical Knowledge Base - Simplified Version
Provide technical terms and background knowledge dedicated to BIOS engineers
"""

import re
from typing import List, dict

# BIOS technology terms library
BIOS_TECHNOLOGY_TERMS = {
    'UEFI': 'Unified Extensible Firmware Interface - Modern BIOS specification',
    'PCD': 'Platform Configuration Database - Platform configuration data library',
    'DXE': 'Driver Execution Environment - Driver execution environment',
    'PEI': 'Pre-EFI Initialization - EFI initialization pre-phase',
    'SMM': 'System Management Mode - System management mode',
    'SEC': 'Security Phase - Security phase',
    'MM': 'Management Mode - Management phase',
    'ACPI': 'Advanced Configuration and Power Interface - Advanced configuration and power interface',
    'SMBIOS': 'System Management BIOS - System management BIOS',
    'TPM': 'Trusted Platform Module - Trusted platform module',
    'BootGuard': 'Intel hardware security boot technology',
    'Secure Boot': 'Secure boot functions',
    'AGESA': 'AMD Generic Encapsulated Software Architecture - AMD general encapsulated software architecture',
    'FSP': 'Firmware Support Package - Firmware support package',
    'EC': 'Embedded Controller - Embedded controller',
    'SPI': 'Serial Peripheral Interface - Serial peripheral interface',
    'I2C': 'Inter-Integrated Circuit - Inter-integrated circuit bus',
    'USB': 'Universal Serial Bus - Universal serial bus',
    'PCIe': 'PCI Express - PCI express bus',
    'SATA': 'Serial ATA - Serial ATA',
    'NVMe': 'Non-Volatile Memory Express - Non-volatile memory express bus',
    'NVRAM': 'Non-Volatile Random Access Memory - Non-volatile random access memory'
}

# Platform technical knowledge
PLATFORM_TECHNOLOGY = {
    'INTEL': {
        'description': 'Intel platform technology',
        'key_features': ['FSP', 'BootGuard', 'ME', 'Thunderbolt'],
        'common_terms': ['MCH', 'PCH', 'CPU', 'ICH']
    },
    'AMD': {
        'description': 'AMD platform technology',
        'key_features': ['AGESA', 'PSP', 'SMU', 'Infinity Fabric'],
        'common_terms': ['FCH', 'CPU', 'NB', 'SB']
    },
    'NVIDIA': {
        'description': 'NVIDIA platform technology',
        'key_features': ['GPU', 'CUDA', 'NVENC', 'NVDEC'],
        'common_terms': ['GPU', 'VRAM', 'CUDA cores']
    }
}

# BIOS change type
BIOS_CHANGE_TYPES = {
    'Setup_Options': 'BIOS configuration options modify',
    'Security_Changes': 'Security functions change',
    'Boot_Changes': 'Boot process change',
    'PCD_Changes': 'Platform configuration data library change',
    'Interface_Changes': 'Interface change',
    'Validation_Required': 'Validation required',
    'Driver_Changes': 'Driver program change',
    'Firmware_Changes': 'Firmware change'
}

# Verification requirements type
VALIDATION_REQUIREMENTS = {
    'Functional_Testing': 'Functional testing',
    'Boot_Testing': 'Boot testing',
    'Performance_Testing': 'Performance testing',
    'Compatibility_Testing': 'Compatibility testing',
    'Security_Testing': 'Security testing',
    'Stress_Testing': 'Stress testing',
    'Regression_Testing': 'Regression testing'
}

# Risk assessment type
RISK_ASSESSMENT = {
    'Technical_Complexity': 'Technical complexity',
    'Compatibility_Risk': 'Compatibility risk',
    'Performance_Impact': 'Performance impact',
    'Security_Impact': 'Security impact',
    'Schedule_Impact': 'Schedule impact',
    'Resource_Impact': 'Resource impact'
}

# Team collaboration type
TEAM_COLLABORATION = {
    'BIOS': 'BIOS development team',
    'Driver': 'Driver program team',
    'Factory': 'Factory team',
    'Services': 'Service team',
    'Manageability': 'Manageability team',
    'Validation': 'Validation team',
    'Quality': 'Quality assurance team'
}

def get_technology_terms(content_text: str) -> List[dict]:
    """According to content dynamically extract technical terms"""
    matched_terms = []
    content_lower = content_text.lower()
    
    # Common BIOS technical terms pattern (observed from actual documentation)
    common_bios_patterns = [
        r'\b(uefi|bios|pcd|dxe|pei|s3|s4|s5|nvram|acpi|smbios|tpm|bootguard)\b',
        r'\b(mrc|dimm|memrx|ediags|ppr|fspm|fsp|agesa|ec|spi|i2c|usb|pcie|sata|nvme)\b',
        r'\b(secure\s*boot|cold\s*boot|fast\s*boot|boot\s*time|boot\s*impact)\b',
        r'\b(setup\s*option|setup\s*menu|bios\s*setup|uefi\s*setup)\b',
        r'\b(memory\s*healing|memory\s*test|defective\s*memory|memory\s*page)\b',
        r'\b(non-volatile|variable|uefi\s*variable|nvram\s*variable)\b',
        r'\b(verification|re-verification|validation|test|diagnostics)\b',
        r'\b(implementation|architecture|design|workflow|process)\b'
    ]
    
    # Extract terms from content
    extracted_terms = set()
    for pattern in common_bios_patterns:
        matches = re.findall(pattern, content_lower, re.IGNORECASE)
        for match in matches:
            if isinstance(match, tuple):
                match = match[0]  # Take first group
            extracted_terms.add(match.upper())
    
    # Provide context-based description for each term
    for term in sorted(extracted_terms):
        # Find term's context in original text
        context_pattern = rf'.{{0,50}}{re.escape(term)}.{{0,50}}'
        context_matches = re.findall(context_pattern, content_text, re.IGNORECASE)
        
        description = f"Identified technical term: {term}"
        if context_matches:
            # Use first context as description
            context = context_matches[0].strip()
            if len(context) > 100:
                context = context[:100] + "..."
            description = f"{term} - in context: '{context}'"
        
        matched_terms.append({
            'term': term,
            'description': description,
            'category': 'extracted'
        })
    
    return matched_terms

def identify_platform(content_text: str) -> str:
    """Identify platform type"""
    content_lower = content_text.lower()
    
    if 'intel' in content_lower and 'amd' not in content_lower:
        return 'INTEL'
    elif 'amd' in content_lower and 'intel' not in content_lower:
        return 'AMD'
    elif 'nvidia' in content_lower:
        return 'NVIDIA'
    elif 'intel' in content_lower and 'amd' in content_lower:
        return 'MULTI-PLATFORM'
    else:
        return 'UNKNOWN'

def extract_bios_changes(content_text: str) -> dict:
    """Extract BIOS change type"""
    changes = {}
    content_lower = content_text.lower()
    
    for change_type, description in BIOS_CHANGE_TYPES.items():
        keywords = change_type.lower().split('_')
        if any(keyword in content_lower for keyword in keywords):
            changes[change_type] = description
    
    return changes

def extract_validation_requirements(content_text: str) -> List[str]:
    """Extract verification requirements"""
    requirements = []
    content_lower = content_text.lower()
    
    for req_type, description in VALIDATION_REQUIREMENTS.items():
        keywords = req_type.lower().split('_')
        if any(keyword in content_lower for keyword in keywords):
            requirements.append(description)
    
    return requirements

def assess_risks(content_text: str) -> List[str]:
    """Evaluate risks"""
    risks = []
    content_lower = content_text.lower()
    
    for risk_type, description in RISK_ASSESSMENT.items():
        keywords = risk_type.lower().split('_')
        if any(keyword in content_lower for keyword in keywords):
            risks.append(description)
    
    return risks

def analyze_team_tasks(content_text: str) -> dict:
    """Analyze team tasks"""
    tasks = {}
    content_lower = content_text.lower()
    
    for team, description in TEAM_COLLABORATION.items():
        keywords = team.lower().split('_')
        if any(keyword in content_lower for keyword in keywords):
            tasks[team] = description
    
    return tasks

def get_bios_context_summary(content_text: str) -> dict:
    """Get BIOS background summary"""
    return {
        'platform': identify_platform(content_text),
        'technology_terms': get_technology_terms(content_text),
        'bios_changes': extract_bios_changes(content_text),
        'validation_requirements': extract_validation_requirements(content_text),
        'risks': assess_risks(content_text),
        'team_tasks': analyze_team_tasks(content_text)
    }
