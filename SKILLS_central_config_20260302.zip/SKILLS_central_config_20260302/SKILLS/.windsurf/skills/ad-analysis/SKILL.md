---
name: ad-analysis
description: Architecture Document analysis tool for extracting team tasks, technical requirements, and system changes using LLM technology. Use when analyzing AD/FD documents, extracting BIOS requirements, or generating technical reports from architecture documents.
---

# AD Analysis Skill

## Overview

AD Analysis Skill is a specialized tool for deep analysis of Architecture Documents (AD) and Functional Documents (FD), using LLM technology to extract work content, technical requirements, and system change analysis for various teams.

## Function Features

### 🎯 Core Functions
- **Multi-Format Support**: Support DOCX, PDF, PowerPoint (PPTX), TXT, MD format AD/FD documentation
- **Generalized Analysis**: Applicable to all types of architecture documentation, not limited to specific functions or platforms
- **Smart Summary Generation**: Use LLM to intelligently summarize and analyze each section of the documentation
- **Team Task Extraction**: Automatically identify and classify work tasks for various teams (BIOS, Driver, Factory, Services, Manageability, etc.)
- **Technical Change Analysis**: Deep analysis of specific change types and implementation details needed by the system
- **Table Data Parsing**: Extract and analyze all table data in documentation
- **Version Change Tracking**: Analyze documentation version history and specific change content

### 🔧 Analysis Capabilities
- **Smart Section Identification**: Automatically identify section titles and structure
- **Comprehensive Content Detection**: Intelligently identifies and categorizes all technical content types
- **Change Pattern Recognition**: Detects additions, deletions (including strikethrough), and modifications
- **Contextual Analysis**: Understands relationships between different sections and requirements
- **Multi-format Table Parsing**: Extracts and analyzes all table data with contextual understanding
- **Generalized Architecture**: Support any AD/FD documentation without specific configuration

## Usage Method

### Command Line Usage

#### Single Documentation Analysis
```bash
python llm_ad_analyzer.py <file> [output_file]
```

#### Batch Analysis - Analyze Entire Directory
```bash
python llm_ad_analyzer.py --batch <directory>
python llm_ad_analyzer.py --batch <directory> --output-dir <output_directory>
python llm_ad_analyzer.py --batch <directory> --recursive
```

### Parameter Instructions
- `file`: AD documentation to analyze (support DOCX, PDF, PPTX, TXT, MD format)
- `output_file`: Output report documentation (optional, default automatic generate)
- `--batch, -b`: Enable batch analysis pattern
- `--recursive, -r`: Recursive search subdirectories (default enabled in batch mode)
- `--output-dir, -o`: Output directory for batch analysis (Default: .windsurf/Reports/Batch_Analysis)
- `--latest-only, -l`: Only analyze the latest version of each item (default behavior)
- `--all-versions, -a`: Analyze all versions (override --latest-only configuration)

### Usage Examples

#### Single Documentation Analysis
```bash
# Analyze any AD documentation
python llm_ad_analyzer.py "AD_1.3_New_Feature.docx"

# Analyze PDF format AD
python llm_ad_analyzer.py "AD_2.1_Security_Update.pdf"

# Analyze PowerPoint format AD
python llm_ad_analyzer.py "AD_3.0_Platform_Change.pptx"

# Analyze FD (Functional Document)
python llm_ad_analyzer.py "FD_1.0_Feature_Description.docx"

# Analyze text format AD
python llm_ad_analyzer.py "AD_4.0_Requirements.txt"
```

#### Batch Analysis
```bash
# Analyze entire directory of all AD/FD documentation (default only analyzes latest version)
python llm_ad_analyzer.py --batch "c:/path/to/AD/FD/directory"

# Analyze all versions (including old versions)
python llm_ad_analyzer.py --batch "c:/path/to/AD/FD/directory" --all-versions

# Specify output directory
python llm_ad_analyzer.py --batch "c:/path/to/AD/FD/directory" --output-dir "c:/custom/output"

# Recursive search subdirectories
python llm_ad_analyzer.py --batch "c:/path/to/AD/FD/directory" --recursive

# Analyze current directory
python llm_ad_analyzer.py --batch .
```

#### Output Instructions
- Single documentation analysis report automatically saved to `.windsurf/Reports/` directory
- Batch analysis report saved to `.windsurf/Reports/Batch_Analysis/` directory
- Filename includes timestamp to avoid overwriting
- Support Markdown format professional report
- Batch analysis will generate summary report and detailed report

### Supported Documentation Types
- **DOCX**: Word documentation format
- **PDF**: PDF documentation format
- **PPTX**: PowerPoint presentation format
- **TXT**: Plain text documentation format
- **MD**: Markdown documentation format

### 🎯 Applicable Document Types
- **Architecture Documents (AD)**: System architecture and design changes
- **Functional Documents (FD)**: Feature specifications and requirements  
- **Security Specifications**: Security requirements and implementations
- **Boot Configuration Documents**: Boot process and security configurations
- **Network Configuration Documents**: Network boot and connectivity requirements
- **Platform Integration Documents**: Cross-platform and integration requirements
- **Technical Specifications**: Any technical specification documentation
- **Design Documents**: System design and architecture documentation
- **Requirements Documents**: Functional and non-functional requirements

## Usage Guidelines (Agent Behavior)

### Command Priority Guidelines
When users ask for AD analysis:
1. **First Priority**: Use the standard analysis command with the AD file
2. **Alternative**: Use specific output file if user requests custom naming
3. **Fallback**: Use basic file analysis if advanced features fail

### Expected Output Format
- **Report Structure**: Markdown format with metadata header, sections, and bilingual summary
- **File Location**: Reports saved to `.windsurf/Reports/` directory with timestamp
- **Content Organization**: File info → Section summary → Team tasks → BIOS changes → Tables → Recommendations
- **Language**: English main content with Traditional Chinese summary section

### Common User Requests & Commands
| User Request Pattern | Recommended Command |
|---------------------|---------------------|
| "Analyze this AD file" | `python llm_ad_analyzer.py <file>` |
| "Analyze all AD/FD files in directory" | `python llm_ad_analyzer.py --batch <directory>` |
| "What are the team tasks?" | `python llm_ad_analyzer.py <file>` (check Team Tasks Analysis section) |
| "BIOS changes needed" | `python llm_ad_analyzer.py <file>` (check BIOS Technical Changes Analysis section) |
| "Quick analysis" | `python llm_ad_analyzer.py <file>` (standard command is already optimized) |
| "Save as custom name" | `python llm_ad_analyzer.py <file> <custom_name.md>` |
| "Batch analysis with custom output" | `python llm_ad_analyzer.py --batch <directory> --output-dir <custom_path>` |
| "Recursive directory analysis" | `python llm_ad_analyzer.py --batch <directory> --recursive` |
| "Analyze only latest versions" | `python llm_ad_analyzer.py --batch <directory>` (default behavior) |
| "Analyze all versions including old ones" | `python llm_ad_analyzer.py --batch <directory> --all-versions` |

### Batch Analysis Features
- **Smart File Detection**: Automatically identifies AD/FD files by filename patterns
- **Recursive Search**: Searches all subdirectories for AD/FD files
- **Progress Tracking**: Shows real-time progress during batch processing
- **Summary Report**: Generates comprehensive summary with statistics
- **Error Handling**: Continues processing even if some files fail
- **Flexible Output**: Customizable output directory and file organization
- **Version Control**: Intelligently filters to analyze only latest versions by default
- **Advanced Version Filtering**: Option to analyze all versions including historical ones

### Cross-Session Consistency Requirements
- **Default Behavior**: Always use `python llm_ad_analyzer.py <file>` for standard analysis
- **Expected Output**: Consistent Markdown report structure regardless of session
- **File Handling**: Automatic detection of file type and appropriate parsing method
- **Analysis Depth**: Same level of detail for all supported formats (DOCX, PDF, PPTX, TXT, MD)

## Quick Start

### For New Users (Immediate Results)
```bash
# 1. Install dependencies
pip install python-docx PyMuPDF python-pptx

# 2. Analyze your first AD file
python .windsurf/skills/ad-analysis/scripts/llm_ad_analyzer.py "your_ad_file.docx"

# 3. Check the generated report
# Report saved to: .windsurf/Reports/AD_Analysis_Report_YYYY-MM-DD_HH-MM-SS.md
```

### Recommended Commands for Common Scenarios
```bash
# Standard AD analysis (most common)
python .windsurf/skills/ad-analysis/scripts/llm_ad_analyzer.py "architecture_document.docx"

# PDF document analysis
python .windsurf/skills/ad-analysis/scripts/llm_ad_analyzer.py "functional_document.pdf"

# PowerPoint analysis
python .windsurf/skills/ad-analysis/scripts/llm_ad_analyzer.py "architecture_presentation.pptx"

# Custom report name
python .windsurf/skills/ad-analysis/scripts/llm_ad_analyzer.py "ad_file.docx" "My_Analysis.md"
```

## Report Generation Standards Compliance

### Report Generation
This skill follows skill_guides Report Generation Standards:
- **Centralized Directory**: Reports saved to `.windsurf/Reports/`
- **Bilingual Format**: English content + Traditional Chinese summary
- **Timestamped Filenames**: `AD_Analysis_Report_YYYY-MM-DD_HH-MM-SS.md`
- **Metadata Headers**: Standardized metadata with generation info
- **UTF-8 Encoding**: Proper encoding for international characters

### Report Structure
```markdown
---
# AD Analysis Report
**Generated:** YYYY-MM-DD HH:MM:SS
**Source:** filename.ext (FORMAT)
**Analyzer:** LLM AD Analyzer
---

# AD Professional Analysis Report
[English content]

## 📋 Bilingual Summary / Bilingual Summary
[Chinese + English summary]
```

## Output Report Structure

### 📋 Report Format
Generated report contains the following main sections:

1. **Documentation Information**
   - Documentation name, analysis time, number of sections, number of tables

2. **BIOS Engineer Dedicated Summary**
   - AD function analysis
   - BIOS development requirements
   - Technical implementation details
   - Version difference analysis
   - Impact evaluation

3. **Key Discoveries and Suggestions**
   - Main technical requirements
   - Implementation suggestions

## Technical Implementation

### 🏗️ Architecture Design
```
AD Analyzer
├── Content Extractor
│   ├── DOCX paragraph extraction
│   ├── Section identification
│   └── Table parsing
├── Knowledge Library (Knowledge Base)
│   ├── bios_knowledge.py - General BIOS technical knowledge
│   └── dell_integration.py - Dell domain knowledge integration
├── Analysis Engine
│   ├── Team task extraction
│   ├── BIOS change analysis
│   ├── Technical term identification
│   ├── Platform identification
│   └── Dell specific analysis
└── Report Generator
    ├── Markdown formatting
    └── Structured output
```

### 🌐 Universal Document Analysis
This skill provides comprehensive analysis for any technical document by:
- **Content-Agnostic Processing**: Analyzes what's actually in the document, not what we expect
- **Pattern Recognition**: Identifies technical patterns, requirements, and relationships
- **Comprehensive Coverage**: Ensures no technical detail is overlooked through systematic analysis
- **Contextual Reporting**: Reports findings in the context of the document's actual content

### 🧠 Intelligent Analysis Engine
- **Domain-Agnostic Processing**: Works with any technical domain without hard-coded assumptions
- **Pattern-Based Recognition**: Uses pattern matching to identify technical content and relationships
- **Contextual Understanding**: Analyzes content in context rather than keyword matching
- **Adaptive Reporting**: Generates reports based on actual content found, not predefined templates

### 🔍 Analysis Logic

#### Universal Technical Analysis Process
1. **Content Extraction**: Extract all content from document regardless of format
2. **Pattern Recognition**: Identify technical patterns, requirements, and relationships
3. **Contextual Analysis**: Analyze content in context rather than keyword matching
4. **Comprehensive Reporting**: Generate reports based on actual content found

#### Section Identification
- Use regular expressions to identify section titles and structure
- Support multiple section formats (1.1, 2.1, Section Name, etc.)
- Automatically organize section content and relationships

#### Universal Task Extraction
- **Content-Based Analysis**: Identifies tasks based on actual content rather than predefined keywords
- **Team Impact Assessment**: Analyzes which teams are affected based on document content
- **Technical Requirements**: Extracts all technical requirements regardless of domain
- **Implementation Details**: Identifies implementation details and dependencies

#### Change Classification
- **Universal Change Types**: Classifies changes by technical nature (security, boot, interface, etc.)
- **Impact Assessment**: Evaluates impact on systems, components, and teams
- **Dependency Analysis**: Identifies dependencies between different requirements
- **Risk Evaluation**: Assesses technical complexity and implementation risks

## Dependency Requirements

### Required Dependencies
- `python-docx`: DOCX document parsing
- `PyMuPDF`: PDF document parsing (fitz)
- `python-pptx`: PowerPoint document parsing
- `pathlib`: Document path handling
- `datetime`: Timestamp generation

### Install Dependencies
```bash
pip install python-docx PyMuPDF python-pptx
```

### Format Support Instructions
- **DOCX**: Complete support, includes paragraph and table parsing
- **PDF**: Support text content extraction, automatically identify section structure
- **PowerPoint (PPTX)**: Support slide text content extraction
- **TXT/MD**: Support plain text and Markdown documentation, automatic encoding detection

## Output Example

### 📊 Universal Analysis Example
```markdown
### 🔧 Technical Requirements Analysis
- Security: Boot security configurations and restrictions identified
- Network: Network boot protocols and limitations analyzed
- Interface: User interface restrictions and modifications identified
- Implementation: Technical implementation details extracted

### 🔧 Change Impact Analysis
#### Security Changes
- Boot security configuration changes identified
- User interface restrictions for security purposes

#### Boot Configuration Changes  
- Network boot restrictions (all protocols) identified
- Boot option modifications and priorities analyzed
```

## Use Scenario

### 🎯 Universal Applicability
1. **Technical Documentation Analysis**: Comprehensive analysis of any technical document (AD/FD/Specifications)
2. **Requirements Extraction**: Automatically extract all technical requirements and implementation details
3. **Impact Assessment**: Evaluate technical impact on systems, components, and teams
4. **Project Planning**: Support project planning and resource allocation based on comprehensive analysis

### 💼 Universal Application Value
- **Domain-Agnostic Analysis**: Works with any technical domain without hard-coded assumptions
- **Comprehensive Coverage**: Ensures no technical detail is overlooked through systematic analysis  
- **Consistent Quality**: Unified analysis format and structured output for all document types
- **Contextual Insights**: Reports findings in the context of the document's actual content

## Future Extensions

### 🚀 Planned Functions
1. **Multi-Format Support**: Support PDF, TXT and other formats
2. **Smarter Analysis**: Use more advanced NLP technology
3. **Template System**: Support custom analysis templates
4. **Integration with Other Systems**: Integration with Jira, Confluence and other systems

### 🔧 Technical Improvements
1. **Machine Learning**: Use ML models to improve analysis accuracy
2. **Multilingual Support**: Support multilingual AD documentation analysis
3. **Visualization Reports**: Generate charts and visualization reports
4. **API Interface**: Provide REST API interface

## Version History

### v1.3 (2026-02-24)
- ✅ **Smart Content Extraction**: Use regular expressions to intelligently extract function requirements, technical specifications, implementation details
- ✅ **Generalized Architecture**: Completely uninstall hard encoding, applicable to any AD/FD documentation
- ✅ **BIOS Engineer Dedicated**: Focus on technical information needed by BIOS engineers
- ✅ **Content Deduplication**: Fix version differences and impact evaluation repeat issues
- ✅ **Simplify Report Structure**: Re-design report format, more practical and professional

### v1.2 (2026-02-24)
- ✅ **Knowledge Library System**: Add `bios_knowledge.py` general BIOS technical knowledge library
- ✅ **Technical Term Identification**: 30+ BIOS technical terms intelligent matching (UEFI, PCD, DXE, PEI, SMM, AGESA, FSP, Secure Boot, TPM, etc.)
- ✅ **Platform Identification**: Automatically identify Intel/AMD/NVIDIA platform and provide platform specific information
- ✅ **Dell Domain Knowledge Integration**: Add `dell_integration.py` bridge tree, automatically call Dell domain knowledge skill
- ✅ **Dell Specific Analysis**: Intel FSP architecture, Dell PQC signing, ATS process, team structure and other Dell specific insights
- ✅ **Intelligent Analysis Process**: General technical analysis + Dell specific analysis integration process
- ✅ **Architecture Simplify**: Maintain single knowledge source, avoid repeat maintenance

### v1.1 (2026-02-24)
- ✅ **Multi-Format Support**: Add PDF, PowerPoint (PPTX), TXT, MD format support
- ✅ **Smart Format Detection**: Automatically detect documentation type and use mapped parse strategy
- ✅ **PDF Parse**: Use PyMuPDF for PDF text content extraction
- ✅ **PowerPoint Parse**: Use python-pptx for slide text extraction
- ✅ **Text Documentation Support**: Support TXT and MD documentation, including encoding automatic detection
- ✅ **Unified Analysis Process**: All format use same analysis logic and report format

### v1.0 (2026-02-24)
- ✅ Basic AD analysis functions (DOCX format)
- ✅ Section summary and team task extraction
- ✅ BIOS change analysis
- ✅ Table data parsing
- ✅ Markdown report generation

---

**Skill Status**: Active  
**Final Update**: 2026-02-24  
**Maintainer**: LLM AD Analysis Team
