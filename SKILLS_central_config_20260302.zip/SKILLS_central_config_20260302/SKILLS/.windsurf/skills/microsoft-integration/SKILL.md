---
name: microsoft-integration
description: Access Microsoft services via Local Outlook and Graph API (Email, Teams, Calendar). Use when accessing Outlook emails, managing Teams messages, or handling calendar events.
---

# Microsoft Integration Skill

## Overview
The Microsoft Integration skill provides comprehensive access to Microsoft services through two methods:
1. **Local Outlook Integration**: Direct access to local Outlook desktop application (no API keys required)
2. **Microsoft Graph API**: Cloud-based access to Outlook emails, Teams messages, and calendar events

This skill follows the core integration architecture pattern established by other skills in this repository.

## Features
- **Local Outlook Access**: Retrieve emails directly from desktop Outlook application
- **Outlook Email Access**: Cloud-based email access with filtering options
- **Teams Integration**: Access chat lists and messages with search capabilities (**Requires Microsoft Graph API / Path A**)
- **Calendar Events**: Retrieve calendar events with date range filtering
- **Report Generation**: Automatic bilingual report generation following skill_guides standards
- **Dual Authentication**: Support for both local COM access and OAuth2 API authentication

## Troubleshooting

### Unresponsive Search Processes
If a global search (`--folder all`) or a search on a very large mailbox appears to hang or remains unresponsive for several minutes, the Outlook COM object may be locked or blocked by a background indexing task.

In such cases, you can forcefully terminate the Python process and try again:
```powershell
taskkill /F /IM python.exe
```
> [!NOTE]
> This will terminate all running Python processes on the system.

### Search Behavior
- **Duplicate Subjects**: Emails with the same subject are **not** treated as duplicates. Each email has a unique `EntryID` in Outlook and will be listed as a separate result.
- **Search Limit**: The `--limit` parameter applies to the total number of unique items found across all folders.
- **Multi-Stage Search**: Global search first performs a high-speed pass on email subjects, then a second pass on email bodies if the limit has not been reached.

## Setup

### Quick Setup (Recommended for Colleagues)

If you are sharing this skill with colleagues, they can set up their environment in one step:

1. Open PowerShell in the skill directory.
2. Run the setup script:
   ```powershell
   .\scripts\setup_env.ps1
   ```
   This will create a virtual environment (`.venv`) and install all required packages.

3. They can then run operations using the created environment:
   ```powershell
   .\.venv\Scripts\python.exe scripts\outlook_local.py list-folders
   ```

### Manual Installation
If you prefer manual setup, ensure the following dependencies are installed:
```bash
pip install pywin32 toml requests urllib3
```
*Note: `pywin32` is critical for Local Outlook access.*

### Option 1: Local Outlook Integration (Recommended for personal use)
**No API keys required!**

1. Ensure Outlook desktop application is installed
2. Run the setup script (see Quick Setup above) or manually install dependencies (see Manual Installation above).
3. Test with:
   ```bash
   python scripts/outlook_local.py get-emails --limit 5
   ```

### Option 2: Microsoft Graph API (Cloud-based)

#### 1. Microsoft Azure App Registration
1. Go to Azure Portal (https://portal.azure.com)
2. Navigate to "Azure Active Directory" → "App registrations"
3. Click "New registration"
4. Give your app a name (e.g., "Cascade Microsoft Integration")
5. Choose "Accounts in this organizational directory only" (or "consumers" for personal accounts)
6. Click "Register"

#### 2. Configure API Permissions
1. In your app registration, go to "API permissions"
2. Click "Add a permission" → "Microsoft Graph"
3. Select "Application permissions"
4. Add the following permissions:
   - **Mail.Read**: Read mail in all mailboxes
   - **Chat.Read**: Read chat messages
   - **User.Read.All**: Read user profiles
   - **Calendars.Read**: Read calendar events
5. Click "Add permissions"
6. Grant admin consent for your organization

#### 3. Create Client Secret
1. Go to "Certificates & secrets"
2. Click "New client secret"
3. Give it a description and choose expiration
4. Copy the secret value immediately (you won't see it again)

#### 4. Configure the Skill
Edit `config.toml` with your Azure app details:

```toml
[microsoft]
tenant_id = "consumers"  # Use "consumers" for personal accounts
client_id = "your-client-id-here" 
client_secret = "your-client-secret-here"
scope = "https://graph.microsoft.com/.default"
```

**Where to find these values:**
- **tenant_id**: Azure Portal → Azure Active Directory → Overview → Tenant ID
- **client_id**: Your app registration → Overview → Application (client) ID
- **client_secret**: The secret you created in step 3

## Usage

### Local Outlook Integration (Recommended)

#### Email Operations
```bash
# Get recent emails from inbox
python scripts/outlook_local.py get-emails --limit 10

# Get emails with subject filter
python scripts/outlook_local.py get-emails --subject "BIOS" --limit 20

# Get emails since specific date
python scripts/outlook_local.py get-emails --since 2024-01-01 --limit 50

# Search emails
python scripts/outlook_local.py search-emails --query "project update" --limit 25

# Get full email content
python scripts/outlook_local.py get-email-content --entry-id "ENTRY_ID_HERE"

# Generate email analysis report
python scripts/outlook_local.py get-emails --limit 25 --save-report

# Get calendar events
python scripts/outlook_local.py get-calendar --limit 10

# Get calendar events with attachments only
python scripts/outlook_local.py get-calendar --has-attachments --limit 20

# List all Outlook folders
python scripts/outlook_local.py list-folders

# Search emails across all folders
python scripts/outlook_local.py search-emails --query "Congo" --folder all --limit 10

# Download attachments from a meeting or email
python scripts/outlook_local.py download-attachments --entry-id "ENTRY_ID_HERE" --save-path "./meeting_files"
```

### Microsoft Graph API (Cloud-based - Required for Teams Messages)
> [!IMPORTANT]
> Teams chat messages, group chats, and channel messages are NOT accessible via Local Outlook (COM). You must configure the Graph API (Option 2) to use these features.

#### Email Operations
```bash
# Get recent emails from inbox
python scripts/microsoft_tool.py get-emails --folder inbox --limit 10

# Get emails with subject filter
python scripts/microsoft_tool.py get-emails --subject "BIOS" --limit 20

# Get emails since specific date
python scripts/microsoft_tool.py get-emails --since "2024-01-01T00:00:00" --limit 50

# Get full email content
python scripts/microsoft_tool.py get-email-content --message-id "AAMkAD..."

# Generate email analysis report
python scripts/microsoft_tool.py get-emails --folder inbox --limit 25 --save-report
```

#### Teams Operations
```bash
# Get recent Teams chats
python microsoft_tool.py get-teams-chats --limit 20

# Get messages from specific chat
python microsoft_tool.py get-teams-messages --chat-id "19:..." --limit 50

# Search Teams messages
python microsoft_tool.py search-teams --query "BIOS update" --limit 25

# Generate Teams analysis report
python microsoft_tool.py get-teams-chats --limit 30 --save-report
```

#### Calendar Operations
```bash
# Get upcoming calendar events
python microsoft_tool.py get-calendar --start-date "2024-01-01T00:00:00" --end-date "2024-01-31T23:59:59"

# Get next 10 events
python microsoft_tool.py get-calendar --limit 10
```

## Usage Guidelines (Agent Behavior)

### Command Priority Guidelines
When users ask for Microsoft data access:
1. **First Priority**: Use Local Outlook integration for personal email access
2. **Alternative**: Use Microsoft Graph API for cloud-based access or when local Outlook unavailable
3. **Report Generation**: Always use --save-report for comprehensive analysis

### Expected Output Format
- Clear structure with headers and emojis
- Consistent formatting (tables, lists)
- Bilingual summary when using --save-report
- **Email Status Tracking Indicators**:
    - ✅ **Status: Completed** (Outlook Flag Status: 1)
    - 🚩 **Status: Follow-up / Flagged** (Outlook Flag Status: 2)
    - 📁 **Categories**: Displays any Outlook categories assigned to the email.
- Error handling and status indicators
- Automatic report generation when requested

### Common User Requests & Commands
| User Request Pattern | Recommended Command Type |
|---------------------|-------------------------|
| "Show me/analyze emails" | outlook_local.py get-emails --save-report |
| "Search emails/find emails" | outlook_local.py search-emails --save-report |
| "Check my inbox" | outlook_local.py get-emails (without --save-report) |
| "Specific email content" | outlook_local.py get-email-content |
| "Search Teams (Messages)" | microsoft_tool.py search-teams (Requires Graph API) |

### CRITICAL: Command Execution Requirements
- **ALWAYS prefer Local Outlook for personal email access** (no API keys required)
- **NEVER reformat or modify the tool output**
- **ALWAYS use the recommended command**
- **DO NOT create custom summaries**
- **PRESERVE Markdown formatting**

## API Reference

### Local Outlook Methods
- `get_emails(folder, limit, since_date, subject_filter)`: Retrieve emails with attachment status, tracking flags (✅ Completed, 🚩 Follow-up), and categories.
- `get_email_content(entry_id)`: Get full email content by EntryID
- `search_emails(search_query, folder, limit)`: Search emails with recursive support (`folder="all"`), tracking flags, and attachment details.
- `list_folders()`: Recursively list all available Outlook folders.
- `get_calendar_events(start_date, end_date, limit, has_attachments)`: Retrieve calendar events from local Outlook, including attachment names and sizes.
- `download_attachments(entry_id, save_path)`: Download attachments from a mail or calendar item

### Microsoft Graph API Methods
- `get_emails(folder, limit, since, subject_filter)`: Retrieve emails via API
- `get_email_content(message_id)`: Get full email content via API
- `get_teams_chats(limit)`: Get Teams chat list
- `get_teams_messages(chat_id, limit)`: Get chat messages
- `search_teams_messages(search_query, limit)`: Search Teams messages
- `get_calendar_events(start_date, end_date, limit)`: Get calendar events

### Authentication
- **Local Outlook**: Uses Windows COM interface (no authentication required)
- **Microsoft Graph API**: OAuth2 client credentials flow with automatic token caching

## Report Generation

### Compliance with skill_guides
This skill follows the Report Generation Standards from skill_guides/SKILL.md:
- Reports saved to `.windsurf/Reports/` directory
- Bilingual format (English + Traditional Chinese)
- Metadata headers with timestamps
- Timestamped filenames to avoid overwrites

### Report Types
- **Email Analysis**: Comprehensive email analysis with filtering
- **Teams Chat Analysis**: Chat overview and statistics
- **Teams Search Report**: Search results with context
- **Calendar Analysis**: Event summaries and scheduling insights

## Integration Examples

### High-Level Skill Integration
```python
# Example of high-level skill consuming Microsoft integration
from microsoft_integration.scripts.microsoft_tool import MicrosoftTool

class EmailAnalysisSkill:
    def __init__(self):
        self.ms_tool = MicrosoftTool()  # Core integration
    
    def analyze_project_emails(self, project_name):
        # Fetch data using core skill
        emails = self.ms_tool.get_emails(subject_filter=project_name)
        
        # Implement specialized analysis logic locally
        return self._perform_email_analysis(emails)
```

### Configuration Pattern
```toml
# microsoft_integration/config.toml (Centralized Microsoft config)
[microsoft]
tenant_id = "your-tenant-id"
client_id = "your-client-id"
client_secret = "your-client-secret"

# high_level_skill/config.toml (Skill-specific config only)
[analysis]
focus_areas = ["project_updates", "meeting_minutes"]
# NOTE: Do NOT duplicate [microsoft] section here
```

## Error Handling

### Common Issues
1. **Authentication Failures**: Check tenant_id, client_id, and client_secret
2. **Permission Errors**: Ensure proper API permissions are granted in Azure
3. **Rate Limiting**: Microsoft Graph API has rate limits - implement retry logic
4. **Date Format**: Use ISO 8601 format for dates (YYYY-MM-DDTHH:MM:SS)

### Troubleshooting
- Verify Azure app registration settings
- Check API permissions in Azure Portal
- Ensure admin consent is granted
- Validate configuration file syntax

## Security Considerations

### Best Practices
- Store client secrets securely (consider environment variables)
- Use least privilege principle for API permissions
- Regularly rotate client secrets
- Monitor API usage for unusual activity
- Consider using Key Vault for secret management in production

### Data Privacy
- This skill accesses email and chat content
- Ensure compliance with organizational data policies
- Consider implementing data retention policies
- Be aware of GDPR and other privacy regulations

## Dependencies

### Required Python Packages
```bash
# For Local Outlook integration
pip install pywin32

# For Microsoft Graph API
pip install requests toml pathlib

# For both (recommended)
pip install requests toml pathlib pywin32
```

### System Requirements
- **Local Outlook**: Python 3.7+, Outlook desktop application, Windows OS
- **Microsoft Graph API**: Python 3.7+, Microsoft 365 organization account, Azure AD admin access

## Support

For issues related to:
- **Microsoft Graph API**: Check Microsoft Graph documentation
- **Azure AD**: Refer to Azure Active Directory docs
- **Skill functionality**: Check this skill's documentation and examples

## Version History

- **v1.0.0**: Initial release with Microsoft Graph API access
- **v1.1.0**: Added report generation and search capabilities
- **v1.2.0**: Enhanced error handling and bilingual support
- **v1.3.0**: Added Local Outlook integration (no API keys required)
- **v1.4.0**: Dual authentication support and comprehensive documentation update
