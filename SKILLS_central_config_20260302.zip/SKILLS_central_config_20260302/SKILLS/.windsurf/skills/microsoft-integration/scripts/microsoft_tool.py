#!/usr/bin/env python3
"""
Microsoft Integration Tool - Outlook and Teams API access via Microsoft Graph
"""

import argparse
import json
import sys
import os
import requests
import base64
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import toml

try:
    import requests
    import toml
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError as e:
    missing_module = str(e).split("'")[-2] if "'" in str(e) else str(e)
    print(f"\n⚠️  Missing dependency: {missing_module}")
    print(f"Please run the setup script: .\\scripts\\setup_env.ps1")
    print(f"Or install manually: pip install -r ..\\requirements.txt\n")
    sys.exit(1)

# Import centralized configuration loader
skills_dir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(skills_dir))
try:
    from config_loader import load_skill_config_with_central_fallback
except ImportError:
    # Fallback if central config loader not available
    def load_skill_config_with_central_fallback(config_path):
        if not config_path.exists():
            print("Error: config.toml not found. Please run setup script first.")
            sys.exit(1)
        with open(config_path, "rb") as f:
            return tomllib.load(f)


class MicrosoftTool:
    def __init__(self):
        # Load configuration with central config fallback
        config_path = Path(__file__).parent.parent / "config.toml"
        try:
            self.config = load_skill_config_with_central_fallback(config_path)
        except Exception as e:
            print(f"Error loading configuration: {str(e)}")
            sys.exit(1)
        
        # Extract Microsoft Graph configuration
        ms_config = self.config.get('microsoft', {})
        self.tenant_id = ms_config.get('tenant_id', '')
        self.client_id = ms_config.get('client_id', '')
        self.client_secret = ms_config.get('client_secret', '')
        self.scope = ms_config.get('scope', 'https://graph.microsoft.com/.default')
        
        # Extract API configuration
        api_config = self.config.get('api', {})
        self.timeout = api_config.get('timeout', 30)
        self.max_retries = api_config.get('max_retries', 3)
        self.per_page = api_config.get('per_page', 25)
        
        # Initialize access token
        self.access_token = None
        self.token_expires_at = None
        
        # Graph API base URL
        self.graph_url = f"https://graph.microsoft.com/v1.0"
    
    def get_access_token(self) -> str:
        """Get Microsoft Graph API access token using OAuth2 client credentials flow"""
        if self.access_token and self.token_expires_at and datetime.now() < self.token_expires_at:
            return self.access_token
        
        # Request new token
        token_url = f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token"
        
        data = {
            'grant_type': 'client_credentials',
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'scope': self.scope
        }
        
        try:
            response = requests.post(token_url, data=data, timeout=self.timeout)
            response.raise_for_status()
            
            token_data = response.json()
            self.access_token = token_data['access_token']
            
            # Set token expiration (subtract 5 minutes for safety)
            expires_in = token_data.get('expires_in', 3600)
            self.token_expires_at = datetime.now() + timedelta(seconds=expires_in - 300)
            
            return self.access_token
            
        except requests.exceptions.RequestException as e:
            print(f"Error getting access token: {str(e)}")
            return None
    
    def _make_request(self, endpoint: str, method: str = 'GET', params: Dict = None, data: Dict = None) -> Optional[Dict]:
        """Make authenticated request to Microsoft Graph API"""
        token = self.get_access_token()
        if not token:
            return None
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
        
        url = f"{self.graph_url}/{endpoint}"
        
        try:
            response = requests.request(method, url, headers=headers, params=params, 
                                     json=data, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            print(f"API request failed: {str(e)}")
            return None
    
    def get_emails(self, folder: str = 'inbox', limit: int = 25, 
                   since: Optional[str] = None, subject_filter: Optional[str] = None) -> Optional[Dict]:
        """Get emails from specified folder"""
        params = {
            '$top': min(limit, self.per_page),
            '$select': 'id,subject,from,toRecipients,ccRecipients,bccRecipients,body,receivedDateTime,hasAttachments',
            '$orderby': 'receivedDateTime desc'
        }
        
        # Add date filter
        if since:
            params['$filter'] = f"receivedDateTime ge {since}"
        
        # Add subject filter
        if subject_filter:
            date_filter = params.get('$filter', '')
            subject_filter_expr = f"contains(subject,'{subject_filter}')"
            if date_filter:
                params['$filter'] = f"{date_filter} and {subject_filter_expr}"
            else:
                params['$filter'] = subject_filter_expr
        
        endpoint = f"me/mailFolders/{folder}/messages"
        return self._make_request(endpoint, params=params)
    
    def get_email_content(self, message_id: str) -> Optional[Dict]:
        """Get full email content including body"""
        endpoint = f"me/messages/{message_id}"
        params = {
            '$select': 'id,subject,from,toRecipients,ccRecipients,bccRecipients,body,bodyType,receivedDateTime,hasAttachments,attachments',
            '$expand': 'attachments'
        }
        return self._make_request(endpoint, params=params)
    
    def get_teams_chats(self, limit: int = 25) -> Optional[Dict]:
        """Get Teams chats"""
        params = {
            '$top': min(limit, self.per_page),
            '$select': 'id,topic,createdDateTime,lastUpdatedDateTime,chatType',
            '$orderby': 'lastUpdatedDateTime desc'
        }
        
        endpoint = "me/chats"
        return self._make_request(endpoint, params=params)
    
    def get_teams_messages(self, chat_id: str, limit: int = 25) -> Optional[Dict]:
        """Get messages from a specific Teams chat"""
        params = {
            '$top': min(limit, self.per_page),
            '$select': 'id,from,messageType,createdDateTime,lastModifiedDateTime,body',
            '$orderby': 'createdDateTime desc'
        }
        
        endpoint = f"me/chats/{chat_id}/messages"
        return self._make_request(endpoint, params=params)
    
    def search_teams_messages(self, search_query: str, limit: int = 25) -> Optional[Dict]:
        """Search Teams messages"""
        params = {
            '$top': min(limit, self.per_page),
            '$select': 'id,from,messageType,createdDateTime,lastModifiedDateTime,body',
            '$orderby': 'createdDateTime desc'
        }
        
        data = {
            "requests": [
                {
                    "entityTypes": ["chatMessage"],
                    "query": {
                        "queryString": search_query
                    }
                }
            ]
        }
        
        endpoint = "search/query"
        return self._make_request(endpoint, method='POST', data=data)
    
    def get_calendar_events(self, start_date: Optional[str] = None, 
                           end_date: Optional[str] = None, limit: int = 25) -> Optional[Dict]:
        """Get calendar events"""
        params = {
            '$top': min(limit, self.per_page),
            '$select': 'id,subject,start,end,organizer,attendees,bodyPreview',
            '$orderby': 'start/dateTime asc'
        }
        
        # Add date range filter
        if start_date and end_date:
            params['$filter'] = f"start/dateTime ge '{start_date}' and end/dateTime le '{end_date}'"
        
        endpoint = "me/events"
        return self._make_request(endpoint, params=params)
    
    def save_report(self, content: str, report_name: str, description: str = "") -> str:
        """Save report following skill_guides Report Generation Standards"""
        from pathlib import Path
        from datetime import datetime
        
        # Save to .windsurf/Reports/ directory (not .windsurf/skills/Reports/)
        reports_dir = Path(__file__).parent.parent.parent.parent / "Reports"
        reports_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        filename = f"{report_name}_{timestamp}.md"
        filepath = reports_dir / filename
        
        # Add metadata header per standards
        report_header = f"""---
# {report_name} Report
**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Description:** {description}
**Skill:** MicrosoftTool
---

"""
        
        full_content = report_header + content
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(full_content)
        
        return f"✅ Report saved to: {filepath}"


def main():
    parser = argparse.ArgumentParser(description='Microsoft Integration Tool')
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Email commands
    email_parser = subparsers.add_parser('get-emails', help='Get emails')
    email_parser.add_argument('--folder', default='inbox', help='Email folder (default: inbox)')
    email_parser.add_argument('--limit', type=int, default=25, help='Number of emails to retrieve')
    email_parser.add_argument('--since', help='Get emails since date (format: YYYY-MM-DDTHH:MM:SS)')
    email_parser.add_argument('--subject', help='Filter by subject (contains)')
    email_parser.add_argument('--save-report', action='store_true', help='Save analysis report')
    
    # Email content command
    content_parser = subparsers.add_parser('get-email-content', help='Get full email content')
    content_parser.add_argument('--message-id', required=True, help='Email message ID')
    
    # Teams commands
    teams_parser = subparsers.add_parser('get-teams-chats', help='Get Teams chats')
    teams_parser.add_argument('--limit', type=int, default=25, help='Number of chats to retrieve')
    teams_parser.add_argument('--save-report', action='store_true', help='Save analysis report')
    
    teams_msg_parser = subparsers.add_parser('get-teams-messages', help='Get Teams chat messages')
    teams_msg_parser.add_argument('--chat-id', required=True, help='Teams chat ID')
    teams_msg_parser.add_argument('--limit', type=int, default=25, help='Number of messages to retrieve')
    
    search_parser = subparsers.add_parser('search-teams', help='Search Teams messages')
    search_parser.add_argument('--query', required=True, help='Search query')
    search_parser.add_argument('--limit', type=int, default=25, help='Number of results to retrieve')
    search_parser.add_argument('--save-report', action='store_true', help='Save analysis report')
    
    # Calendar command
    calendar_parser = subparsers.add_parser('get-calendar', help='Get calendar events')
    calendar_parser.add_argument('--start-date', help='Start date (format: YYYY-MM-DDTHH:MM:SS)')
    calendar_parser.add_argument('--end-date', help='End date (format: YYYY-MM-DDTHH:MM:SS)')
    calendar_parser.add_argument('--limit', type=int, default=25, help='Number of events to retrieve')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    tool = MicrosoftTool()
    
    if args.command == 'get-emails':
        result = tool.get_emails(
            folder=args.folder,
            limit=args.limit,
            since=args.since,
            subject_filter=args.subject
        )
        
        if result and 'value' in result:
            emails = result['value']
            print(f"\n📧 Found {len(emails)} emails in {args.folder}")
            
            for email in emails:
                print(f"\n📬 Subject: {email.get('subject', 'No Subject')}")
                print(f"👤 From: {email.get('from', {}).get('emailAddress', {}).get('name', 'Unknown')}")
                print(f"📅 Received: {email.get('receivedDateTime', 'Unknown')}")
                print(f"📎 Attachments: {'Yes' if email.get('hasAttachments') else 'No'}")
                
                # Show preview of body
                body = email.get('body', {}).get('content', '')
                if body:
                    # Remove HTML tags for preview
                    import re
                    clean_body = re.sub(r'<[^>]+>', '', body)[:200]
                    print(f"📝 Preview: {clean_body}...")
                
                print("-" * 50)
            
            if args.save_report:
                # Generate report content
                report_content = f"""# Microsoft Outlook Email Analysis Report

## 📊 Summary
- **Total Emails Found**: {len(emails)}
- **Folder**: {args.folder}
- **Date Range**: {args.since or 'All time'}
- **Subject Filter**: {args.subject or 'None'}

## 📧 Email Details

"""
                
                for i, email in enumerate(emails, 1):
                    report_content += f"""### Email {i}: {email.get('subject', 'No Subject')}

**From:** {email.get('from', {}).get('emailAddress', {}).get('name', 'Unknown')} ({email.get('from', {}).get('emailAddress', {}).get('address', 'Unknown')})
**Received:** {email.get('receivedDateTime', 'Unknown')}
**Attachments:** {'Yes' if email.get('hasAttachments') else 'No'}

**Body Preview:**
{email.get('body', {}).get('content', '')[:500]}...

---

"""
                
                # Add bilingual summary
                report_content += f"""## 📋 BilingualSummary / Bilingual Summary

🇹🇼 **Traditional Chinese**:
- Found {len(emails)} emails in {args.folder} folder
- Date range: {args.since or 'All time'}
- Subject filter: {args.subject or 'None'}

🇺🇸 **English Summary**:
- Found {len(emails)} emails in {args.folder} folder
- Date range: {args.since or 'All time'}
- Subject filter: {args.subject or 'None'}

"""
                
                save_result = tool.save_report(
                    report_content, 
                    "microsoft_outlook_emails",
                    f"Email analysis from {args.folder} folder"
                )
                print(f"\n{save_result}")
        
        else:
            print("❌ Failed to retrieve emails")
    
    elif args.command == 'get-email-content':
        result = tool.get_email_content(args.message_id)
        
        if result:
            print(f"\n📧 Email Content")
            print(f"Subject: {result.get('subject', 'No Subject')}")
            print(f"From: {result.get('from', {}).get('emailAddress', {}).get('name', 'Unknown')}")
            print(f"Received: {result.get('receivedDateTime', 'Unknown')}")
            
            # Show recipients
            to_recipients = result.get('toRecipients', [])
            if to_recipients:
                print("To:")
                for recipient in to_recipients:
                    print(f"  - {recipient.get('emailAddress', {}).get('name', 'Unknown')} ({recipient.get('emailAddress', {}).get('address', 'Unknown')})")
            
            # Show body
            body = result.get('body', {}).get('content', '')
            print(f"\n📝 Body:\n{body}")
            
            # Show attachments
            attachments = result.get('attachments', [])
            if attachments:
                print(f"\n📎 Attachments ({len(attachments)}):")
                for attachment in attachments:
                    print(f"  - {attachment.get('name', 'Unknown')} ({attachment.get('contentType', 'Unknown')})")
        
        else:
            print("❌ Failed to retrieve email content")
    
    elif args.command == 'get-teams-chats':
        result = tool.get_teams_chats(limit=args.limit)
        
        if result and 'value' in result:
            chats = result['value']
            print(f"\n💬 Found {len(chats)} Teams chats")
            
            for chat in chats:
                print(f"\n💭 Chat ID: {chat.get('id', 'Unknown')}")
                print(f"📝 Topic: {chat.get('topic', 'No Topic')}")
                print(f"📅 Created: {chat.get('createdDateTime', 'Unknown')}")
                print(f"🔄 Last Updated: {chat.get('lastUpdatedDateTime', 'Unknown')}")
                print(f"📊 Type: {chat.get('chatType', 'Unknown')}")
                print("-" * 50)
            
            if args.save_report:
                # Generate report content
                report_content = f"""# Microsoft Teams Chat Analysis Report

## 📊 Summary
- **Total Chats Found**: {len(chats)}
- **Analysis Date**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 💬 Chat Details

"""
                
                for i, chat in enumerate(chats, 1):
                    report_content += f"""### Chat {i}: {chat.get('topic', 'No Topic')}

**Chat ID:** {chat.get('id', 'Unknown')}
**Type:** {chat.get('chatType', 'Unknown')}
**Created:** {chat.get('createdDateTime', 'Unknown')}
**Last Updated:** {chat.get('lastUpdatedDateTime', 'Unknown')}

---

"""
                
                # Add bilingual summary
                report_content += f"""## 📋 BilingualSummary / Bilingual Summary

🇹🇼 **Traditional Chinese**:
- Found {len(chats)} Teams chats
- Analysis time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

🇺🇸 **English Summary**:
- Found {len(chats)} Teams chats
- Analysis time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

"""
                
                save_result = tool.save_report(
                    report_content, 
                    "microsoft_teams_chats",
                    "Teams chat analysis"
                )
                print(f"\n{save_result}")
        
        else:
            print("❌ Failed to retrieve Teams chats")
    
    elif args.command == 'get-teams-messages':
        result = tool.get_teams_messages(chat_id=args.chat_id, limit=args.limit)
        
        if result and 'value' in result:
            messages = result['value']
            print(f"\n💬 Found {len(messages)} messages in chat {args.chat_id}")
            
            for message in messages:
                print(f"\n📨 Message ID: {message.get('id', 'Unknown')}")
                print(f"👤 From: {message.get('from', {}).get('user', {}).get('displayName', 'Unknown')}")
                print(f"📅 Created: {message.get('createdDateTime', 'Unknown')}")
                print(f"📝 Type: {message.get('messageType', 'Unknown')}")
                
                # Show message body
                body = message.get('body', {}).get('content', '')
                if body:
                    # Remove HTML tags for preview
                    import re
                    clean_body = re.sub(r'<[^>]+>', '', body)[:300]
                    print(f"💬 Message: {clean_body}...")
                
                print("-" * 50)
        
        else:
            print("❌ Failed to retrieve Teams messages")
    
    elif args.command == 'search-teams':
        result = tool.search_teams_messages(search_query=args.query, limit=args.limit)
        
        if result and 'value' in result:
            hits = result['value'][0].get('hitsContainers', [{}])[0].get('hits', [])
            print(f"\n🔍 Found {len(hits)} results for '{args.query}'")
            
            for hit in hits:
                resource = hit.get('resource', {})
                print(f"\n📨 Message ID: {resource.get('id', 'Unknown')}")
                print(f"👤 From: {resource.get('from', {}).get('user', {}).get('displayName', 'Unknown')}")
                print(f"📅 Created: {resource.get('createdDateTime', 'Unknown')}")
                
                # Show message body
                body = resource.get('body', {}).get('content', '')
                if body:
                    import re
                    clean_body = re.sub(r'<[^>]+>', '', body)[:300]
                    print(f"💬 Message: {clean_body}...")
                
                print("-" * 50)
            
            if args.save_report:
                # Generate report content
                report_content = f"""# Microsoft Teams Search Report

## 📊 Summary
- **Search Query**: {args.query}
- **Total Results**: {len(hits)}
- **Search Date**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 🔍 Search Results

"""
                
                for i, hit in enumerate(hits, 1):
                    resource = hit.get('resource', {})
                    report_content += f"""### Result {i}

**Message ID:** {resource.get('id', 'Unknown')}
**From:** {resource.get('from', {}).get('user', {}).get('displayName', 'Unknown')}
**Created:** {resource.get('createdDateTime', 'Unknown')}

**Message:**
{resource.get('body', {}).get('content', '')[:500]}...

---

"""
                
                # Add bilingual summary
                report_content += f"""## 📋 BilingualSummary / Bilingual Summary

🇹🇼 **Traditional Chinese**:
- Search query: {args.query}
- Found {len(hits)} results
- Search time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

🇺🇸 **English Summary**:
- Search query: {args.query}
- Found {len(hits)} results
- Search time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

"""
                
                save_result = tool.save_report(
                    report_content, 
                    "microsoft_teams_search",
                    f"Teams search for '{args.query}'"
                )
                print(f"\n{save_result}")
        
        else:
            print("❌ Failed to search Teams messages")
    
    elif args.command == 'get-calendar':
        result = tool.get_calendar_events(
            start_date=args.start_date,
            end_date=args.end_date,
            limit=args.limit
        )
        
        if result and 'value' in result:
            events = result['value']
            print(f"\n📅 Found {len(events)} calendar events")
            
            for event in events:
                print(f"\n📝 Subject: {event.get('subject', 'No Subject')}")
                print(f"👤 Organizer: {event.get('organizer', {}).get('emailAddress', {}).get('name', 'Unknown')}")
                print(f"📅 Start: {event.get('start', {}).get('dateTime', 'Unknown')}")
                print(f"📅 End: {event.get('end', {}).get('dateTime', 'Unknown')}")
                
                # Show attendees
                attendees = event.get('attendees', [])
                if attendees:
                    print(f"👥 Attendees ({len(attendees)}):")
                    for attendee in attendees[:5]:  # Show first 5
                        print(f"  - {attendee.get('emailAddress', {}).get('name', 'Unknown')}")
                    if len(attendees) > 5:
                        print(f"  ... and {len(attendees) - 5} more")
                
                print("-" * 50)
        
        else:
            print("❌ Failed to retrieve calendar events")


if __name__ == '__main__':
    main()
