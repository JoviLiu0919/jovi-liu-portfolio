#!/usr/bin/env python3
"""
Local Outlook Integration - Direct access to Outlook desktop application
Uses win32com to interact with local Outlook instance
"""

import argparse
import datetime as dt
from datetime import datetime
import win32com.client
import pythoncom
from pathlib import Path
import sys
import os
import re
import toml
from typing import List, Dict, Optional
from pathlib import Path

# Set stdout encoding to utf-8 to avoid UnicodeEncodeError in Windows terminals
if sys.platform == 'win32':
    import io
    if hasattr(sys.stdout, 'buffer'):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    if hasattr(sys.stderr, 'buffer'):
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

try:
    import win32com.client
    import pythoncom
    import toml
    COM_AVAILABLE = True
except ImportError as e:
    COM_AVAILABLE = False
    missing_module = str(e).split("'")[-2] if "'" in str(e) else str(e)
    print(f"\n⚠️  Missing dependency: {missing_module}")
    print(f"Please run the setup script: .\\scripts\\setup_env.ps1")
    print(f"Or install manually: pip install -r ..\\requirements.txt\n")


class LocalOutlookTool:
    def __init__(self):
        # Load configuration
        config_path = Path(__file__).parent.parent / "config.toml"
        try:
            with open(config_path, 'r') as f:
                self.config = toml.load(f)
        except FileNotFoundError:
            self.config = {}
        
        # Extract email configuration
        email_config = self.config.get('email', {})
        self.default_folder = email_config.get('default_folder', 'inbox')
        self.max_body_length = email_config.get('max_body_length', 1000)
        
        # Initialize Outlook application
        self.outlook = None
        
    def get_timezone_info(self):
        """Get system and Outlook timezone information"""
        try:
            # System timezone
            system_time = dt.datetime.now()
            system_tz = system_time.astimezone().tzinfo
            
            print(f"🕐 System Time: {system_time}")
            print(f"🌍 System Timezone: {system_tz}")
            
            if self.connect():
                # Outlook timezone info
                try:
                    # Get current time in Outlook
                    outlook_time = self.namespace.CreateRecipient("User").Session.CurrentUser
                    print(f"📧 Outlook connected successfully")
                    
                    # Try to get timezone from Outlook
                    application = self.outlook.Application
                    if hasattr(application, 'TimeZone'):
                        outlook_tz = application.TimeZone
                        print(f"📧 Outlook Timezone: {outlook_tz}")
                    
                except Exception as e:
                    print(f"📧 Could not get Outlook timezone: {e}")
                    
        except Exception as e:
            print(f"❌ Error getting timezone info: {e}")
            
        return system_tz
        
    def connect(self) -> bool:
        """Connect to local Outlook application"""
        if not COM_AVAILABLE:
            print("❌ COM not available. Install pywin32: pip install pywin32")
            return False
        
        try:
            pythoncom.CoInitialize()
            self.outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
            self.namespace = self.outlook  # Set namespace for easier access
            return True
        except Exception as e:
            print(f"❌ Failed to connect to Outlook: {str(e)}")
            return False
    
    def get_folder(self, folder_name: str, parent=None):
        """Get Outlook folder by name, searching recursively if needed"""
        if not self.connect():
            return None
            
        try:
            # Standard numeric folders
            if folder_name.lower() == 'inbox':
                return self.outlook.GetDefaultFolder(6)
            elif folder_name.lower() == 'sent':
                return self.outlook.GetDefaultFolder(5)
            elif folder_name.lower() == 'drafts':
                return self.outlook.GetDefaultFolder(16)
            elif folder_name.lower() == 'deleted':
                return self.outlook.GetDefaultFolder(3)
            
            # Start search from root if no parent provided
            if parent is None:
                parent = self.outlook.GetDefaultFolder(6).Parent # Default store root
            
            # Search children
            for i in range(1, parent.Folders.Count + 1):
                folder = parent.Folders.Item(i)
                if folder.Name.lower() == folder_name.lower():
                    return folder
                
                # Recursive search
                result = self.get_folder(folder_name, parent=folder)
                if result:
                    return result
            
            return None
                
        except Exception as e:
            print(f"❌ Failed to get folder '{folder_name}': {str(e)}")
            return None

    def list_folders(self, parent=None, indent=0, results=None) -> List[Dict]:
        """Recursively list all Outlook folders"""
        if results is None:
            results = []
            if not self.connect():
                return []
            parent = self.outlook.GetDefaultFolder(6).Parent # Root folder of default store
            
        try:
            for i in range(1, parent.Folders.Count + 1):
                folder = parent.Folders.Item(i)
                results.append({
                    'name': folder.Name,
                    'indent': indent,
                    'id': str(folder.EntryID)
                })
                # Recurse into subfolders
                self.list_folders(folder, indent + 1, results)
        except Exception as e:
            pass
            
        return results
    
    def get_emails(self, folder: str = 'inbox', limit: int = 25, since_date: Optional[dt.datetime] = None,
                   subject_filter: Optional[str] = None) -> List[Dict]:
        """Get emails from specified folder"""
        if not self.connect():
            return []
        
        folder_obj = self.get_folder(folder)
        if not folder_obj:
            return []
        
        emails = []
        items = folder_obj.Items
        items.Sort("[ReceivedTime]", True)  # Sort by received time, newest first
        
        count = 0
        for item in items:
            if count >= limit:
                break
            
            try:
                # Check date filter
                if since_date:
                    try:
                        # Handle timezone-aware datetime comparison
                        received_time = item.ReceivedTime
                        if hasattr(received_time, 'date'):
                            # COM datetime object
                            received_date = datetime(received_time.year, received_time.month, received_time.day)
                        else:
                            # String or other format
                            received_date = received_time
                        
                        if received_date < since_date.date():
                            break
                    except Exception as date_error:
                        # If date comparison fails, skip the filter
                        pass
                
                # Check subject filter
                if subject_filter and subject_filter.lower() not in item.Subject.lower():
                    continue
                
                email_data = {
                    'subject': item.Subject or 'No Subject',
                    'from': {
                        'name': item.SenderName,
                        'email': item.SenderEmailAddress
                    },
                    'to': [],
                    'cc': [],
                    'received_date': item.ReceivedTime.strftime('%Y-%m-%d %H:%M:%S') if item.ReceivedTime else 'Unknown',
                    'body': item.Body[:self.max_body_length] if item.Body else '',
                    'has_attachments': item.Attachments.Count > 0,
                    'attachments': [],
                    'flag_status': item.FlagStatus if hasattr(item, 'FlagStatus') else 0,
                    'categories': item.Categories if hasattr(item, 'Categories') else '',
                    'entry_id': item.EntryID
                }
                
                # Add attachments info
                if item.Attachments.Count > 0:
                    for attachment in item.Attachments:
                        email_data['attachments'].append({
                            'name': attachment.FileName,
                            'size': attachment.Size
                        })
                
                # Add recipients
                if item.To:
                    for recipient in item.To.split(';'):
                        email_data['to'].append({'name': recipient.strip(), 'email': recipient.strip()})
                
                if item.CC:
                    for recipient in item.CC.split(';'):
                        email_data['cc'].append({'name': recipient.strip(), 'email': recipient.strip()})
                
                emails.append(email_data)
                count += 1
                
            except Exception as e:
                print(f"⚠️  Error processing email: {str(e)}")
                continue
        
        return emails
    
    def get_email_content(self, entry_id: str) -> Optional[Dict]:
        """Get full email content by EntryID"""
        if not self.connect():
            return None
        
        try:
            item = self.outlook.GetItemFromID(entry_id)
            
            email_data = {
                'subject': item.Subject or 'No Subject',
                'from': {
                    'name': item.SenderName,
                    'email': item.SenderEmailAddress
                },
                'to': [],
                'cc': [],
                'bcc': [],
                'received_date': item.ReceivedTime.strftime('%Y-%m-%d %H:%M:%S') if item.ReceivedTime else 'Unknown',
                'body': item.Body or '',
                'html_body': item.HTMLBody or '',
                'has_attachments': item.Attachments.Count > 0,
                'attachments': [],
                'flag_status': item.FlagStatus if hasattr(item, 'FlagStatus') else 0,
                'categories': item.Categories if hasattr(item, 'Categories') else '',
                'entry_id': item.EntryID
            }
            
            # Add recipients
            if item.To:
                for recipient in item.To.split(';'):
                    email_data['to'].append({'name': recipient.strip(), 'email': recipient.strip()})
            
            if item.CC:
                for recipient in item.CC.split(';'):
                    email_data['cc'].append({'name': recipient.strip(), 'email': recipient.strip()})
            
            if item.BCC:
                for recipient in item.BCC.split(';'):
                    email_data['bcc'].append({'name': recipient.strip(), 'email': recipient.strip()})
            
            # Add attachments info
            for attachment in item.Attachments:
                email_data['attachments'].append({
                    'name': attachment.FileName,
                    'size': attachment.Size,
                    'type': attachment.Type
                })
            
            return email_data
            
        except Exception as e:
            print(f"❌ Failed to get email content: {str(e)}")
            return None
    
    def search_emails(self, search_query: str, folder: str = 'inbox', limit: int = 25, search_body: bool = True) -> List[Dict]:
        """Search emails in folder (optimized with multi-stage filtering)"""
        if not self.connect():
            return []
        
        emails = []
        
        try:
            # Escape single quotes in search query for DASL
            escaped_query = search_query.replace("'", "''")
            
            # Stage 1: Subject search (Always indexed, fast)
            subject_filter = f"@SQL=\"urn:schemas:httpmail:subject\" LIKE '%{escaped_query}%'"
            
            # Stage 2: Body search (Slower on large folders)
            body_filter = f"@SQL=\"urn:schemas:httpmail:textdescription\" LIKE '%{escaped_query}%'"

            def run_search(target_folder, filter_str, results_list, current_limit):
                if len(results_list) >= current_limit: return
                try:
                    restricted = target_folder.Items.Restrict(filter_str)
                    # Sort for consistent results, but might be slow on large restricted sets
                    try:
                        restricted.Sort("[ReceivedTime]", True)
                    except:
                        pass # Sorting might not be supported or fail for some restricted collections

                    for i in range(1, min(restricted.Count, current_limit - len(results_list) + 1)):
                        item = restricted.Item(i)
                        # Avoid duplicates
                        if any(e['entry_id'] == item.EntryID for e in results_list): continue
                        
                        results_list.append({
                            'subject': getattr(item, 'Subject', 'No Subject'),
                            'from': {'name': getattr(item, 'SenderName', 'Unknown'), 'email': getattr(item, 'SenderEmailAddress', 'Unknown')},
                            'received_date': item.ReceivedTime.strftime('%Y-%m-%d %H:%M:%S') if hasattr(item, 'ReceivedTime') and item.ReceivedTime else 'Unknown',
                            'body_preview': (getattr(item, 'Body', ''))[:200] + '...' if hasattr(item, 'Body') else '',
                            'has_attachments': item.Attachments.Count > 0 if hasattr(item, 'Attachments') else False,
                            'attachments': [{'name': att.FileName, 'size': att.Size} for att in item.Attachments] if hasattr(item, 'Attachments') and item.Attachments.Count > 0 else [],
                            'flag_status': getattr(item, 'FlagStatus', 0),
                            'categories': getattr(item, 'Categories', ''),
                            'entry_id': getattr(item, 'EntryID', '')
                        })
                        if len(results_list) >= current_limit: break
                except Exception as search_stage_err:
                    # print(f"⚠️  Error in search stage for folder {getattr(target_folder, 'Name', 'Unknown')}: {search_stage_err}")
                    pass # Silently fail for individual folder search errors

            if folder.lower() == 'all':
                print(f"🔍 Performing high-speed global search for '{search_query}'...")
                
                def search_recursive_multi_stage(current_folder, filter_str):
                    if len(emails) >= limit: return
                    run_search(current_folder, filter_str, emails, limit)
                    for i in range(1, current_folder.Folders.Count + 1):
                        if len(emails) >= limit: break
                        search_recursive_multi_stage(current_folder.Folders.Item(i), filter_str)

                # Stage 1: Search subjects in all folders
                root = self.outlook.GetDefaultFolder(6).Parent
                search_recursive_multi_stage(root, subject_filter)
                
                # Stage 2: Search body if limit not reached and search_body is True
                if len(emails) < limit and search_body:
                    print("⏳ No more matches in subjects. Searching email contents (this may be slower)...")
                    search_recursive_multi_stage(root, body_filter)
            else:
                folder_obj = self.get_folder(folder)
                if folder_obj:
                    run_search(folder_obj, subject_filter, emails, limit)
                    if len(emails) < limit and search_body:
                        run_search(folder_obj, body_filter, emails, limit)
        
        except Exception as e:
            print(f"❌ Search failed: {str(e)}")
        
        return emails
    
    def get_calendar_events(self, start_date: Optional[dt.datetime] = None, 
                           end_date: Optional[dt.datetime] = None, limit: int = 25,
                           has_attachments: bool = False) -> List[Dict]:
        """Get calendar events from local Outlook"""
        if not self.connect():
            return []
        
        try:
            # Get calendar folder
            calendar = self.outlook.GetDefaultFolder(9)  # 9 = olFolderCalendar
            
            # Optimal way for recurring items: Sort and IncludeRecurrences on base Items, then Restrict
            items = calendar.Items
            items.IncludeRecurrences = True
            items.Sort("[Start]", False)
            
            if start_date and end_date:
                # Use Outlook's built-in filtering
                start_str = start_date.strftime('%m/%d/%Y %I:%M %p')
                end_str = end_date.strftime('%m/%d/%Y %I:%M %p')
                
                # Use Start for the upper bound as it's more reliable for finding events occurring in range
                restriction = f"[Start] >= '{start_str}' AND [Start] <= '{end_str}'"
                
                try:
                    subset = items.Restrict(restriction)
                    # If restrict returns items, use it. Otherwise fallback to sorted items.
                    if subset.Count > 0:
                        items = subset
                except:
                    pass
            
            events = []
            count = 0
            for item in items:
                # Manual filtering for attachments as [HasAttachments] is not supported for calendar Restrict
                if has_attachments:
                    try:
                        if item.Attachments.Count == 0:
                            continue
                    except:
                        continue
                
                if count >= limit:
                    break
                
                try:
                    item_start = item.Start
                    if item_start:
                        # Convert to datetime for comparison (handling potential timezone issues)
                        # COM datetime.datetime objects can be compared with dt.datetime
                        item_start_naive = item_start.replace(tzinfo=None)
                        
                        if start_date and item_start_naive < start_date:
                            continue
                        if end_date and item_start_naive > end_date:
                            # Since it's sorted ascending, we can break if we exceed end_date
                            break
                except Exception as filter_error:
                    # If date comparison fails, skip the filter but keep the item
                    pass
                
                try:
                    event_data = {
                        'subject': item.Subject or 'No Subject',
                        'start': item.Start.strftime('%Y-%m-%d %H:%M:%S') if item.Start else 'Unknown',
                        'end': item.End.strftime('%Y-%m-%d %H:%M:%S') if item.End else 'Unknown',
                        'location': item.Location or 'No Location',
                        'organizer': item.Organizer if hasattr(item, 'Organizer') else 'Unknown',
                        'body': item.Body[:500] if item.Body else '',
                        'is_all_day': item.AllDayEvent if hasattr(item, 'AllDayEvent') else False,
                        'required_attendees': '',
                        'optional_attendees': '',
                        'meeting_status': '',
                        'response_status': '',
                        'has_attachments': item.Attachments.Count > 0,
                        'attachments': [],
                        'entry_id': item.EntryID
                    }
                    
                    # Add attachments info
                    if item.Attachments.Count > 0:
                        for attachment in item.Attachments:
                            event_data['attachments'].append({
                                'name': attachment.FileName,
                                'size': attachment.Size
                            })
                    
                    # Get meeting status and response
                    if hasattr(item, 'MeetingStatus'):
                        event_data['meeting_status'] = item.MeetingStatus
                    
                    # Get your response status
                    if hasattr(item, 'ResponseStatus'):
                        event_data['response_status'] = item.ResponseStatus
                    
                    # Check if meeting is cancelled
                    if hasattr(item, 'Subject'):
                        subject = item.Subject or ''
                        if subject.startswith('Canceled:') or subject.startswith('Cancelled:'):
                            event_data['is_cancelled'] = True
                        else:
                            event_data['is_cancelled'] = False
                    else:
                        event_data['is_cancelled'] = False
                    
                    # Get attendees if available
                    if hasattr(item, 'RequiredAttendees') and item.RequiredAttendees:
                        event_data['required_attendees'] = item.RequiredAttendees
                    if hasattr(item, 'OptionalAttendees') and item.OptionalAttendees:
                        event_data['optional_attendees'] = item.OptionalAttendees
                    
                    events.append(event_data)
                    count += 1
                    
                except Exception as e:
                    print(f"⚠️  Error processing calendar event: {str(e)}")
                    continue
            
            return events
            
        except Exception as e:
            print(f"❌ Failed to retrieve calendar events: {str(e)}")
            return []
    
    def download_attachments(self, entry_id: str, save_path: str) -> List[str]:
        """Download attachments from a mail or calendar item"""
        if not self.connect():
            return []
        
        try:
            item = self.outlook.GetItemFromID(entry_id)
            if item.Attachments.Count == 0:
                print("ℹ️  No attachments found for this item.")
                return []
            
            save_dir = Path(save_path).resolve()
            save_dir.mkdir(parents=True, exist_ok=True)
            
            downloaded_files = []
            for attachment in item.Attachments:
                file_path = save_dir / attachment.FileName
                attachment.SaveAsFile(str(file_path))
                downloaded_files.append(str(file_path))
                print(f"✅ Saved attachment: {attachment.FileName}")
            
            return downloaded_files
            
        except Exception as e:
            print(f"❌ Failed to download attachments: {str(e)}")
            return []
    
    def save_report(self, content: str, report_name: str, description: str = "") -> str:
        from pathlib import Path
        from datetime import datetime
        
        # Save to .windsurf/Reports/ directory
        reports_dir = Path(__file__).parent.parent.parent.parent / "Reports"
        reports_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        filename = f"{report_name}_{timestamp}.md"
        filepath = reports_dir / filename
        
        # Add metadata header per standards
        report_header = f"""---
# {report_name} Report
**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Description:** {description}
**Skill:** LocalOutlookTool
---

"""
        
        full_content = report_header + content
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(full_content)
        
        return f"✅ Report saved to: {filepath}"


def main():
    parser = argparse.ArgumentParser(description='Local Outlook Integration Tool')
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Email commands
    email_parser = subparsers.add_parser('get-emails', help='Get emails from local Outlook')
    email_parser.add_argument('--folder', default='inbox', help='Email folder (default: inbox)')
    email_parser.add_argument('--limit', type=int, default=25, help='Number of emails to retrieve')
    email_parser.add_argument('--since', help='Get emails since date (format: YYYY-MM-DD)')
    email_parser.add_argument('--subject', help='Filter by subject (contains)')
    email_parser.add_argument('--save-report', action='store_true', help='Save analysis report')
    
    # Email content command
    content_parser = subparsers.add_parser('get-email-content', help='Get full email content')
    content_parser.add_argument('--entry-id', required=True, help='Email EntryID')
    
    # Search command
    search_parser = subparsers.add_parser('search-emails', help='Search emails')
    search_parser.add_argument('--query', required=True, help='Search query')
    search_parser.add_argument('--folder', default='inbox', help='Email folder (default: inbox, use "all" for global search)')
    search_parser.add_argument('--limit', type=int, default=25, help='Number of results')
    search_parser.add_argument('--save-report', action='store_true', help='Save analysis report')
    
    # Folder commands
    subparsers.add_parser('list-folders', help='List all Outlook folders')
    
    # Calendar command
    calendar_parser = subparsers.add_parser('get-calendar', help='Get calendar events from local Outlook')
    calendar_parser.add_argument('--start-date', help='Start date (format: YYYY-MM-DD)')
    calendar_parser.add_argument('--end-date', help='End date (format: YYYY-MM-DD)')
    calendar_parser.add_argument('--limit', type=int, default=25, help='Number of events to retrieve')
    calendar_parser.add_argument('--has-attachments', action='store_true', help='Only show events with attachments')
    calendar_parser.add_argument('--save-report', action='store_true', help='Save analysis report')
    
    # Download attachments command
    download_parser = subparsers.add_parser('download-attachments', help='Download attachments from item')
    download_parser.add_argument('--entry-id', required=True, help='Item EntryID')
    download_parser.add_argument('--save-path', required=True, help='Directory to save attachments')
    
    # Timezone check command
    subparsers.add_parser('check-timezone', help='Check system and Outlook timezone information')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    tool = LocalOutlookTool()
    
    if args.command == 'get-emails':
        # Parse since date
        since_date = None
        if args.since:
            try:
                since_date = datetime.strptime(args.since, '%Y-%m-%d')
            except ValueError:
                print("❌ Invalid date format. Use YYYY-MM-DD")
                sys.exit(1)
        
        emails = tool.get_emails(
            folder=args.folder,
            limit=args.limit,
            since_date=since_date,
            subject_filter=args.subject
        )
        
        if emails:
            print(f"\n📧 Found {len(emails)} emails in {args.folder}")
            
            for email in emails:
                print(f"\n📬 Subject: {email['subject']}")
                print(f"👤 From: {email['from']['name']} ({email['from']['email']})")
                print(f"📅 Received: {email['received_date']}")
                
                # Show status if flagged
                if email.get('flag_status') == 1:
                    print("✅ Status: Completed")
                elif email.get('flag_status') == 2:
                    print("🚩 Status: Follow-up / Flagged")
                
                if email.get('categories'):
                    print(f"📁 Categories: {email['categories']}")
                
                print(f"📎 Attachments: {'Yes' if email['has_attachments'] else 'No'}")
                if email['has_attachments'] and email['attachments']:
                    for att in email['attachments']:
                        print(f"  - {att['name']} ({att['size']} bytes)")
                print(f"🆔 Entry ID: {email['entry_id']}")
                print(f"📝 Preview: {email['body'][:100]}...")
                print("-" * 50)
            
            if args.save_report:
                # Generate report content
                report_content = f"""# Local Outlook Email Analysis Report

## 📊 Summary
- **Total Emails Found**: {len(emails)}
- **Folder**: {args.folder}
- **Date Range**: {args.since or 'All time'}
- **Subject Filter**: {args.subject or 'None'}

## 📧 Email Details

"""
                
                for i, email in enumerate(emails, 1):
                    report_content += f"""### Email {i}: {email['subject']}

**From:** {email['from']['name']} ({email['from']['email']})
**Received:** {email['received_date']}
**Attachments:** {'Yes' if email['has_attachments'] else 'No'}
**Status:** {'Completed' if email.get('flag_status') == 1 else 'Follow-up' if email.get('flag_status') == 2 else 'None'}

**Body Preview:**
{email['body'][:500]}...

---

"""
                
                # Add bilingual summary
                report_content += f"""## 📋 BilingualSummary / Bilingual Summary

🇹🇼 **Traditional Chinese**:
- Found {len(emails)} emails in {args.folder} folder
- Date range: {args.since or 'All time'}
- Subject filter: {args.subject or 'None'}

🇺🇸 **English Summary**:
- Found {len(emails)} emails in {args.folder} folder
- Date range: {args.since or 'All time'}
- Subject filter: {args.subject or 'None'}

"""
                
                save_result = tool.save_report(
                    report_content, 
                    "local_outlook_emails",
                    f"Local Outlook email analysis from {args.folder} folder"
                )
                print(f"\n{save_result}")
        
        else:
            print("❌ No emails found or failed to retrieve emails")
    
    elif args.command == 'get-email-content':
        email = tool.get_email_content(args.entry_id)
        
        if email:
            print(f"\n📧 Email Content")
            print(f"Subject: {email['subject']}")
            print(f"From: {email['from']['name']} ({email['from']['email']})")
            print(f"Received: {email['received_date']}")
            
            # Show status if flagged
            if email.get('flag_status') == 1:
                print("✅ Status: Completed")
            elif email.get('flag_status') == 2:
                print("🚩 Status: Follow-up / Flagged")
            
            if email.get('categories'):
                print(f"📁 Categories: {email['categories']}")
                
            # Show recipients
            if email['to']:
                print("To:")
                for recipient in email['to']:
                    print(f"  - {recipient['name']} ({recipient['email']})")
            
            if email['cc']:
                print("CC:")
                for recipient in email['cc']:
                    print(f"  - {recipient['name']} ({recipient['email']})")
            
            # Show body
            print(f"\n📝 Body:\n{email['body']}")
            
            # Show attachments
            if email['attachments']:
                print(f"\n📎 Attachments ({len(email['attachments'])}):")
                for attachment in email['attachments']:
                    print(f"  - {attachment['name']} ({attachment['size']} bytes)")
        
        else:
            print("❌ Failed to retrieve email content")
    
    elif args.command == 'search-emails':
        emails = tool.search_emails(
            search_query=args.query,
            folder=args.folder,
            limit=args.limit
        )
        
        if emails:
            print(f"\n🔍 Found {len(emails)} results for '{args.query}' in {args.folder}")
            
            for email in emails:
                print(f"\n📬 Subject: {email['subject']}")
                print(f"👤 From: {email['from']['name']} ({email['from']['email']})")
                print(f"📅 Received: {email['received_date']}")
                
                # Show status if flagged
                if email.get('flag_status') == 1:
                    print("✅ Status: Completed")
                elif email.get('flag_status') == 2:
                    print("🚩 Status: Follow-up / Flagged")
                
                if email.get('categories'):
                    print(f"📁 Categories: {email['categories']}")
                
                print(f"📎 Attachments: {'Yes' if email['has_attachments'] else 'No'}")
                if email['has_attachments'] and email['attachments']:
                    for att in email['attachments']:
                        print(f"  - {att['name']} ({att['size']} bytes)")
                print(f"🆔 Entry ID: {email['entry_id']}")
                print(f"📝 Preview: {email['body_preview']}")
                print("-" * 50)
            
            if args.save_report:
                # Generate report content
                report_content = f"""# Local Outlook Email Search Report

## 📊 Summary
- **Search Query**: {args.query}
- **Total Results**: {len(emails)}
- **Folder**: {args.folder}
- **Search Date**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 🔍 Search Results

"""
                
                for i, email in enumerate(emails, 1):
                    report_content += f"""### Result {i}: {email['subject']}

**From:** {email['from']['name']} ({email['from']['email']})
**Received:** {email['received_date']}
**Status:** {'Completed' if email.get('flag_status') == 1 else 'Follow-up' if email.get('flag_status') == 2 else 'None'}

**Preview:**
{email['body_preview']}

---

"""
                
                # Add bilingual summary
                report_content += f"""## 📋 BilingualSummary / Bilingual Summary

🇹🇼 **Traditional Chinese**:
- Search query: {args.query}
- Found {len(emails)} results
- Folder: {args.folder}
- Search time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

🇺🇸 **English Summary**:
- Search query: {args.query}
- Found {len(emails)} results
- Folder: {args.folder}
- Search time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

"""
                
                save_result = tool.save_report(
                    report_content, 
                    "local_outlook_search",
                    f"Local Outlook search for '{args.query}'"
                )
                print(f"\n{save_result}")
        
        else:
            print("❌ No search results found")
    
    elif args.command == 'get-calendar':
        # Parse dates
        start_date = None
        end_date = None

        if args.start_date:
            try:
                start_date = dt.datetime.strptime(args.start_date, '%Y-%m-%d')
            except ValueError:
                print("❌ Invalid start date format. Use YYYY-MM-DD")
                sys.exit(1)

        if args.end_date:
            try:
                end_date = dt.datetime.strptime(args.end_date, '%Y-%m-%d')
                # Set to end of day
                end_date = end_date.replace(hour=23, minute=59, second=59)
            except ValueError:
                print("❌ Invalid end date format. Use YYYY-MM-DD")
                sys.exit(1)
        
        events = tool.get_calendar_events(
            start_date=start_date,
            end_date=end_date,
            limit=args.limit,
            has_attachments=args.has_attachments
        )
        
        if events:
            print(f"\nCalendar events found: {len(events)}")
            
            for event in events:
                try:
                    print(f"\nSubject: {event['subject']}")
                    print(f"Start: {event['start']}")
                    print(f"End: {event['end']}")
                    print(f"Location: {event['location']}")
                    print(f"Organizer: {event['organizer']}")
                except UnicodeEncodeError:
                    # Fallback for terminals that don't support UTF-8 characters
                    print(f"\nSubject: {event['subject'].encode('ascii', 'ignore').decode('ascii')}")
                    print(f"Start: {event['start']}")
                    print(f"End: {event['end']}")
                    print(f"Location: {event['location'].encode('ascii', 'ignore').decode('ascii')}")
                    print(f"Organizer: {event['organizer'].encode('ascii', 'ignore').decode('ascii')}")
                
                # Show meeting status
                if event['meeting_status']:
                    print(f"Meeting Status: {event['meeting_status']}")
                
                # Show your response status
                if event['response_status']:
                    print(f"Your Response: {event['response_status']}")
                
                # Show cancellation status
                if event.get('is_cancelled', False):
                    print("⚠️  CANCELLED MEETING")
                
                if event['is_all_day']:
                    print("All Day Event")
                
                print(f"Has Attachments: {'Yes' if event['has_attachments'] else 'No'}")
                if event['has_attachments'] and event['attachments']:
                    for att in event['attachments']:
                        print(f"  - {att['name']} ({att['size']} bytes)")
                
                print(f"Entry ID: {event['entry_id']}")
                
                try:
                    if event['required_attendees']:
                        print(f"Required: {event['required_attendees']}")
                    
                    if event['optional_attendees']:
                        print(f"Optional: {event['optional_attendees']}")
                except UnicodeEncodeError:
                    if event['required_attendees']:
                        print(f"Required: {event['required_attendees'].encode('ascii', 'ignore').decode('ascii')}")
                    
                    if event['optional_attendees']:
                        print(f"Optional: {event['optional_attendees'].encode('ascii', 'ignore').decode('ascii')}")
                
                # Show body preview
                if event['body']:
                    try:
                        preview = event['body'][:200].encode('ascii', 'ignore').decode('ascii')
                        print(f"Preview: {preview}...")
                    except:
                        print("Preview: [Content contains special characters]")
                
                print("-" * 50)
            
            if args.save_report:
                # Generate report content
                report_content = f"""# Local Outlook Calendar Analysis Report

## 📊 Summary
- **Total Events Found**: {len(events)}
- **Date Range**: {args.start_date or 'All time'} to {args.end_date or 'All time'}
- **Analysis Date**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 📅 Calendar Events

"""
                
                for i, event in enumerate(events, 1):
                    report_content += f"""### Event {i}: {event['subject']}

**Start:** {event['start']}
**End:** {event['end']}
**Location:** {event['location']}
**Organizer:** {event['organizer']}
**All Day:** {'Yes' if event['is_all_day'] else 'No'}
**Has Attachments:** {'Yes' if event['has_attachments'] else 'No'}
**Entry ID:** `{event['entry_id']}`

"""
                    if event['required_attendees']:
                        report_content += f"**Required Attendees:** {event['required_attendees']}\n"
                    
                    if event['optional_attendees']:
                        report_content += f"**Optional Attendees:** {event['optional_attendees']}\n"
                    
                    if event['body']:
                        report_content += f"**Details:** {event['body'][:300]}...\n"
                    
                    report_content += "---\n\n"
                
                # Add bilingual summary
                report_content += f"""## 📋 BilingualSummary / Bilingual Summary

🇹🇼 **Traditional Chinese**:
- Found {len(events)} calendar events
- Date range: {args.start_date or 'All time'} to {args.end_date or 'All time'}
- Analysis time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

🇺🇸 **English Summary**:
- Found {len(events)} calendar events
- Date range: {args.start_date or 'All time'} to {args.end_date or 'All time'}
- Analysis time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

"""
                
                save_result = tool.save_report(
                    report_content, 
                    "local_outlook_calendar",
                    f"Local Outlook calendar analysis"
                )
                print(f"\n{save_result}")
        
        else:
            print("❌ No calendar events found")
    
    elif args.command == 'download-attachments':
        downloaded = tool.download_attachments(args.entry_id, args.save_path)
        if downloaded:
            print(f"\n✅ Total {len(downloaded)} attachments downloaded to {args.save_path}")
        else:
            print("\n❌ No attachments were downloaded.")

    elif args.command == 'check-timezone':
        tool.get_timezone_info()
        
    elif args.command == 'list-folders':
        folders = tool.list_folders()
        if folders:
            print(f"\n📂 Available Outlook Folders:")
            for folder in folders:
                indent = "  " * folder['indent']
                print(f"{indent}- {folder['name']}")
        else:
            print("❌ No folders found")


if __name__ == '__main__':
    main()
