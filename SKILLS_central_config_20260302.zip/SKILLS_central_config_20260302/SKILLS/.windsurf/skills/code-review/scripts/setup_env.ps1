# Code Review Skill Setup Script
# This script sets up the environment for the code review skill

Write-Host "Setting up Code Review Skill environment..." -ForegroundColor Green

# Check if Python is installed
try {
    $pythonVersion = python --version 2>$null
    Write-Host "Found Python: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "Error: Python is not installed or not in PATH" -ForegroundColor Red
    exit 1
}

# Create virtual environment if it doesn't exist
if (-not (Test-Path ".venv")) {
    Write-Host "Creating virtual environment..." -ForegroundColor Yellow
    python -m venv .venv
} else {
    Write-Host "Virtual environment already exists" -ForegroundColor Green
}

# Activate virtual environment
Write-Host "Activating virtual environment..." -ForegroundColor Yellow
& .\.venv\Scripts\Activate.ps1

# Install required packages
Write-Host "Installing required packages..." -ForegroundColor Yellow
pip install requests urllib3 toml

# Create config file if it doesn't exist
if (-not (Test-Path "config.toml")) {
    Write-Host "Creating config.toml file..." -ForegroundColor Yellow
    @"
[review]
focus_areas = ["security", "performance", "code_quality"]
severity_threshold = "medium"
auto_approve = false
require_tests = true

[security]
check_vulnerabilities = true
scan_dependencies = true
buffer_overflow_check = true

[quality]
naming_conventions = "ags"
documentation_required = true
test_coverage_threshold = 80

[platform]
bios_specific = true
uefi_standards = true
hardware_abstraction = true

# GitHub configuration is handled by github_integration skill
# Please configure GitHub token in ../github_integration/config.toml
"@ | Out-File -FilePath "config.toml" -Encoding utf8
    Write-Host "Created config.toml. Please configure GitHub token in ../github_integration/config.toml" -ForegroundColor Yellow
} else {
    Write-Host "config.toml already exists" -ForegroundColor Green
}

# Create scripts directory if it doesn't exist
if (-not (Test-Path "scripts")) {
    New-Item -ItemType Directory -Path "scripts" -Force
    Write-Host "Created scripts directory" -ForegroundColor Green
}

Write-Host "Setup completed successfully!" -ForegroundColor Green
Write-Host "Please update config.toml with your GitHub token before using the skill." -ForegroundColor Yellow
Write-Host "To activate the virtual environment, run: .\.venv\Scripts\Activate.ps1" -ForegroundColor Cyan
