#!/usr/bin/env python3
"""
Code Review Tool - Comprehensive code analysis and review system
"""

import argparse
import json
import sys
import os
import re
from datetime import datetime
from pathlib import Path
import toml

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

try:
    from github_integration.scripts.github_tool import GitHubTool
except ImportError:
    print("Error: GitHub integration not found. Please ensure github_integration skill is properly installed.")
    sys.exit(1)

import requests
import urllib3

# Disable SSL verification warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class CodeReviewTool:
    def __init__(self):
        # Load configuration
        config_path = Path(__file__).parent.parent / "config.toml"
        try:
            with open(config_path, 'r') as f:
                self.config = toml.load(f)
        except FileNotFoundError:
            print("Error: config.toml not found. Please run setup script first.")
            sys.exit(1)
        except Exception as e:
            print(f"Error loading config.toml: {str(e)}")
            sys.exit(1)
        
        # Initialize GitHub tool
        self.github_tool = GitHubTool()
        
        # Review configuration
        self.review_config = self.config.get('review', {})
        self.security_config = self.config.get('security', {})
        self.quality_config = self.config.get('quality', {})
        self.platform_config = self.config.get('platform', {})

    def review_pr(self, repo, pr_number, focus=None, detailed=False, output=None):
        """Review a pull request comprehensively"""
        print(f"Reviewing PR #{pr_number} in {repo}...")
        
        # Get PR details
        pr_data = self.github_tool.get_pr(repo, pr_number)
        if isinstance(pr_data, str) and pr_data.startswith("Error"):
            return pr_data
        
        # Get PR diff
        pr_diff = self.github_tool.get_pr_diff(repo, pr_number)
        if isinstance(pr_diff, str) and pr_diff.startswith("Error"):
            return pr_diff
        
        # Get PR files
        pr_files = self.github_tool.get_pr_files(repo, pr_number)
        if isinstance(pr_files, str) and pr_files.startswith("Error"):
            return pr_files
        
        # Perform review
        review_result = {
            "pr_info": {
                "number": pr_data.get("number"),
                "title": pr_data.get("title"),
                "author": pr_data.get("user", {}).get("login"),
                "state": pr_data.get("state"),
                "created_at": pr_data.get("created_at"),
                "updated_at": pr_data.get("updated_at")
            },
            "review_date": datetime.now().isoformat(),
            "findings": []
        }
        
        # Analyze diff for issues
        diff_analysis = self._analyze_diff(pr_diff, focus)
        review_result["findings"].extend(diff_analysis)
        
        # Analyze files individually
        if isinstance(pr_files, list):
            for file_info in pr_files:
                file_analysis = self._analyze_file(repo, file_info, focus)
                review_result["findings"].extend(file_analysis)
        
        # Generate summary
        review_result["summary"] = self._generate_summary(review_result["findings"])
        
        # Output results
        if output:
            self._save_review(review_result, output)
        else:
            self._print_review(review_result, detailed)
        
        return review_result

    def review_commit(self, repo, commit_sha, focus=None):
        """Review a specific commit"""
        print(f"Reviewing commit {commit_sha} in {repo}...")
        
        # Get commit details
        commit_data = self.github_tool.get_commit(repo, commit_sha)
        if isinstance(commit_data, str) and commit_data.startswith("Error"):
            return commit_data
        
        # Get commit diff
        commit_diff = self.github_tool.get_commit_diff(repo, commit_sha)
        if isinstance(commit_diff, str) and commit_diff.startswith("Error"):
            return commit_diff
        
        # Perform review
        review_result = {
            "commit_info": {
                "sha": commit_data.get("sha"),
                "message": commit_data.get("commit", {}).get("message"),
                "author": commit_data.get("commit", {}).get("author", {}).get("name"),
                "date": commit_data.get("commit", {}).get("author", {}).get("date")
            },
            "review_date": datetime.now().isoformat(),
            "findings": []
        }
        
        # Analyze diff
        diff_analysis = self._analyze_diff(commit_diff, focus)
        review_result["findings"].extend(diff_analysis)
        
        # Analyze files
        if isinstance(commit_data.get("files"), list):
            for file_info in commit_data["files"]:
                file_analysis = self._analyze_file(repo, file_info, focus)
                review_result["findings"].extend(file_analysis)
        
        # Generate summary
        review_result["summary"] = self._generate_summary(review_result["findings"])
        
        self._print_review(review_result)
        return review_result

    def _analyze_diff(self, diff_text, focus=None):
        """Analyze diff content for issues"""
        findings = []
        lines = diff_text.split('\n')
        
        for i, line in enumerate(lines):
            # Security checks
            if not focus or 'security' in focus:
                findings.extend(self._check_security_issues(line, i, lines))
            
            # Code quality checks
            if not focus or 'quality' in focus:
                findings.extend(self._check_code_quality(line, i, lines))
            
            # Performance checks
            if not focus or 'performance' in focus:
                findings.extend(self._check_performance_issues(line, i, lines))
            
            # BIOS/UEFI specific checks
            if not focus or 'bios' in focus:
                findings.extend(self._check_bios_issues(line, i, lines))
        
        return findings

    def _analyze_file(self, repo, file_info, focus=None):
        """Analyze individual file"""
        findings = []
        filename = file_info.get("filename", "")
        patch = file_info.get("patch", "")
        
        # File type specific analysis
        if filename.endswith(('.c', '.h')):
            findings.extend(self._analyze_c_file(filename, patch, focus))
        elif filename.endswith(('.bat', '.cmd')):
            findings.extend(self._analyze_batch_file(filename, patch, focus))
        elif filename.endswith('.inf'):
            findings.extend(self._analyze_inf_file(filename, patch, focus))
        
        return findings

    def _check_security_issues(self, line, line_num, all_lines):
        """Check for security vulnerabilities"""
        findings = []
        
        # Buffer overflow risks
        if any(func in line for func in ['strcpy', 'strcat', 'sprintf', 'gets']):
            findings.append({
                "type": "security",
                "severity": "high",
                "issue": "Potentially unsafe string function",
                "line": line_num + 1,
                "code": line.strip(),
                "recommendation": "Use safer alternatives like strncpy, strncat, snprintf"
            })
        
        # Hardcoded credentials
        if re.search(r'(password|passwd|pwd)\s*=\s*["\'][^"\']+["\']', line, re.IGNORECASE):
            findings.append({
                "type": "security",
                "severity": "critical",
                "issue": "Hardcoded credential detected",
                "line": line_num + 1,
                "code": line.strip(),
                "recommendation": "Remove hardcoded credentials and use secure configuration"
            })
        
        return findings

    def _check_code_quality(self, line, line_num, all_lines):
        """Check for code quality issues"""
        findings = []
        
        # AGS naming conventions
        if line.startswith('+') and 'function' in line.lower():
            # Check function naming
            func_match = re.search(r'(\w+)\s*\(', line)
            if func_match:
                func_name = func_match.group(1)
                if not re.match(r'^[A-Z][a-zA-Z0-9]*$', func_name):
                    findings.append({
                        "type": "quality",
                        "severity": "medium",
                        "issue": "Function name doesn't follow AGS PascalCase convention",
                        "line": line_num + 1,
                        "code": line.strip(),
                        "recommendation": f"Rename function to {func_name.title().replace('_', '')}"
                    })
        
        # TODO comments
        if 'TODO' in line or 'FIXME' in line:
            findings.append({
                "type": "quality",
                "severity": "low",
                "issue": "TODO/FIXME comment found",
                "line": line_num + 1,
                "code": line.strip(),
                "recommendation": "Address TODO items or create proper tickets"
            })
        
        return findings

    def _check_performance_issues(self, line, line_num, all_lines):
        """Check for performance issues"""
        findings = []
        
        # Inefficient loops
        if 'for' in line and 'strlen(' in line:
            findings.append({
                "type": "performance",
                "severity": "medium",
                "issue": "strlen() in loop condition - inefficient",
                "line": line_num + 1,
                "code": line.strip(),
                "recommendation": "Calculate string length once before loop"
            })
        
        # Memory allocation in loops
        if 'malloc' in line and any('for' in all_lines[i] for i in range(max(0, line_num-5), line_num)):
            findings.append({
                "type": "performance",
                "severity": "medium",
                "issue": "Memory allocation inside loop",
                "line": line_num + 1,
                "code": line.strip(),
                "recommendation": "Move allocation outside loop or use memory pool"
            })
        
        return findings

    def _check_bios_issues(self, line, line_num, all_lines):
        """Check for BIOS/UEFI specific issues"""
        findings = []
        
        # Platform-specific checks
        if 'PlatformBin' in line and 'ModelList' in line:
            findings.append({
                "type": "platform",
                "severity": "low",
                "issue": "Platform model list modification",
                "line": line_num + 1,
                "code": line.strip(),
                "recommendation": "Verify platform compatibility and SSID mapping"
            })
        
        # Firmware update paths
        if 'FWUpdate' in line and '.bin' in line:
            findings.append({
                "type": "platform",
                "severity": "medium",
                "issue": "Firmware binary path change",
                "line": line_num + 1,
                "code": line.strip(),
                "recommendation": "Ensure firmware version compatibility and testing"
            })
        
        return findings

    def _analyze_c_file(self, filename, patch, focus):
        """Analyze C/C++ file"""
        findings = []
        
        # Check for include guards
        if filename.endswith('.h') and '#ifndef' not in patch:
            findings.append({
                "type": "quality",
                "severity": "medium",
                "issue": "Header file missing include guards",
                "file": filename,
                "recommendation": "Add #ifndef/#define/#endif guards"
            })
        
        return findings

    def _analyze_batch_file(self, filename, patch, focus):
        """Analyze batch file"""
        findings = []
        
        # Check for unsafe operations
        if 'del ' in patch or 'rmdir ' in patch:
            findings.append({
                "type": "security",
                "severity": "medium",
                "issue": "File deletion operation in batch script",
                "file": filename,
                "recommendation": "Add proper error checking and confirmation"
            })
        
        return findings

    def _analyze_inf_file(self, filename, patch, focus):
        """Analyze INF file"""
        findings = []
        
        # Check for driver signing
        if 'DriverVer' in patch:
            findings.append({
                "type": "platform",
                "severity": "low",
                "issue": "Driver version change detected",
                "file": filename,
                "recommendation": "Ensure driver signing and compatibility"
            })
        
        return findings

    def _generate_summary(self, findings):
        """Generate review summary"""
        summary = {
            "total_issues": len(findings),
            "by_severity": {},
            "by_type": {},
            "critical_issues": []
        }
        
        for finding in findings:
            severity = finding.get("severity", "unknown")
            ftype = finding.get("type", "unknown")
            
            summary["by_severity"][severity] = summary["by_severity"].get(severity, 0) + 1
            summary["by_type"][ftype] = summary["by_type"].get(ftype, 0) + 1
            
            if severity in ["critical", "high"]:
                summary["critical_issues"].append(finding)
        
        return summary

    def _print_review(self, review_result, detailed=False):
        """Print review results"""
        print("\n" + "="*60)
        print(f"CODE REVIEW REPORT")
        print("="*60)
        
        # Basic info
        if "pr_info" in review_result:
            info = review_result["pr_info"]
            print(f"PR #{info['number']}: {info['title']}")
            print(f"Author: {info['author']}")
            print(f"State: {info['state']}")
        elif "commit_info" in review_result:
            info = review_result["commit_info"]
            print(f"Commit: {info['sha'][:8]}")
            print(f"Author: {info['author']}")
            print(f"Message: {info['message'][:50]}...")
        
        print(f"Review Date: {review_result['review_date']}")
        
        # Summary
        summary = review_result.get("summary", {})
        print(f"\nSUMMARY:")
        print(f"Total Issues: {summary.get('total_issues', 0)}")
        
        if summary.get("by_severity"):
            print("By Severity:")
            for severity, count in summary["by_severity"].items():
                print(f"  {severity.title()}: {count}")
        
        if summary.get("by_type"):
            print("By Type:")
            for ftype, count in summary["by_type"].items():
                print(f"  {ftype.title()}: {count}")
        
        # Critical issues
        critical = summary.get("critical_issues", [])
        if critical:
            print(f"\nCRITICAL ISSUES ({len(critical)}):")
            for issue in critical:
                print(f"  Line {issue.get('line', '?')}: {issue.get('issue')}")
                print(f"    Recommendation: {issue.get('recommendation')}")
        
        # All findings (if detailed)
        if detailed and review_result.get("findings"):
            print(f"\nDETAILED FINDINGS:")
            for i, finding in enumerate(review_result["findings"], 1):
                print(f"\n{i}. {finding.get('type', 'unknown').title()} - {finding.get('severity', 'unknown').title()}")
                print(f"   Issue: {finding.get('issue')}")
                if finding.get('line'):
                    print(f"   Line: {finding.get('line')}")
                if finding.get('code'):
                    print(f"   Code: {finding.get('code')}")
                print(f"   Recommendation: {finding.get('recommendation')}")

    def _save_review(self, review_result, output_file):
        """Save review to file"""
        with open(output_file, 'w') as f:
            json.dump(review_result, f, indent=2)
        print(f"Review saved to {output_file}")


def main():
    parser = argparse.ArgumentParser(description="Code Review Tool")
    tool = CodeReviewTool()
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # PR review
    pr_parser = subparsers.add_parser("review-pr", help="Review pull request")
    pr_parser.add_argument("--repo", required=True, help="Repository name")
    pr_parser.add_argument("--number", required=True, type=int, help="PR number")
    pr_parser.add_argument("--focus", help="Focus areas (comma-separated)")
    pr_parser.add_argument("--detailed", action="store_true", help="Show detailed findings")
    pr_parser.add_argument("--output", help="Output file")
    
    # Commit review
    commit_parser = subparsers.add_parser("review-commit", help="Review commit")
    commit_parser.add_argument("--repo", required=True, help="Repository name")
    commit_parser.add_argument("--sha", required=True, help="Commit SHA")
    commit_parser.add_argument("--focus", help="Focus areas (comma-separated)")
    
    # File review
    files_parser = subparsers.add_parser("review-files", help="Review specific files")
    files_parser.add_argument("--repo", required=True, help="Repository name")
    files_parser.add_argument("--files", required=True, help="Comma-separated file list")
    files_parser.add_argument("--focus", help="Focus areas (comma-separated)")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    try:
        if args.command == "review-pr":
            focus = args.focus.split(',') if args.focus else None
            tool.review_pr(args.repo, args.number, focus, args.detailed, args.output)
        
        elif args.command == "review-commit":
            focus = args.focus.split(',') if args.focus else None
            tool.review_commit(args.repo, args.sha, focus)
        
        elif args.command == "review-files":
            focus = args.focus.split(',') if args.focus else None
            print("File review not yet implemented")
        
        else:
            print(f"Unknown command: {args.command}")
    
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
