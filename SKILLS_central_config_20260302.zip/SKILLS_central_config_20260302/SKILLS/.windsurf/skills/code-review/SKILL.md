---
name: code-review
description: Comprehensive code review skill using GitHub integration to fetch, analyze, and review code changes. Use when performing PR reviews, checking code quality, or analyzing pull requests for security and compliance issues.
---

# Code Review Skill

Start here to perform comprehensive code reviews on GitHub pull requests. This skill integrates with github_integration for data fetching and implements specialized analysis logic for code quality, security, and platform compliance.

## 📚 Compliance with skill_guides

This skill follows all guidelines specified in `.windsurf/skills/skill-guides/SKILL.md`:
- **Core Integration Architecture**: Uses github_integration for GitHub data fetching
- **Zero-Temp-File Policy**: All processing done in memory
- **Report Generation Standards**: Saves bilingual reports to `.windsurf/Reports/`
- **Cross-Session Consistency**: Ensures consistent behavior across sessions

## Interaction Rules (Agent Instructions)

*   **Verification First**: Always fetch and analyze the actual code before providing feedback
*   **Technical Rigor**: Focus on technical correctness over social comfort
*   **Context Awareness**: Consider the specific codebase, platform, and project requirements
*   **Constructive Feedback**: Provide specific, actionable suggestions with examples
*   **Security Focus**: Prioritize security vulnerabilities and best practices

## Setup

1.  **Install Dependencies** (One-time):
    ```powershell
    cd .windsurf/code_review
    .\scripts\setup_env.ps1
    ```
2.  **Configuration**:
    - Configure GitHub token in `github_integration/config.toml`
    - Ensure `code_review/config.toml` has your review preferences and analysis settings

## Code Review Workflow

### 1. Pull Request Review

```powershell
# Review a specific pull request
python scripts/code_review.py review-pr --repo CDC_AgS_2025 --number 1733

# Review with specific focus areas
python scripts/code_review.py review-pr --repo CDC_AgS_2025 --number 1733 --focus security,performance

# Generate detailed review report
python scripts/code_review.py review-pr --repo CDC_AgS_2025 --number 1733 --detailed --output pr_review.md
```

### 2. Commit Review

```powershell
# Review a specific commit
python scripts/code_review.py review-commit --repo CBF_DellFeaturesPkg --sha f294d2d732b85d26a870436e2e6ca7abaaddb209

# Review multiple commits
python scripts/code_review.py review-commits --repo CDC_AgS_2025 --range main..feature-branch
```

### 3. File Review

```powershell
# Review specific files
python scripts/code_review.py review-files --repo CDC_AgS_2025 --files "builda.bat,Include/PlatformConfig.h"

# Review files from PR
python scripts/code_review.py review-pr-files --repo CDC_AgS_2025 --number 1733
```

### 4. Automated Analysis

```powershell
# Run comprehensive code analysis
python scripts/code_review.py analyze --repo CDC_AgS_2025 --path "DellPkgs/DellPlatformPkgs/NB/GhostriderPtlPkg"

# Security-focused analysis
python scripts/code_review.py security-scan --repo CDC_AgS_2025 --path "DellPkgs"

# Performance analysis
python scripts/code_review.py performance-scan --repo CDC_AgS_2025 --files "*.c,*.h"
```

## Review Categories

### Security Review

- **Buffer Overflow Prevention**: Check for unsafe string operations
- **Input Validation**: Verify proper input sanitization
- **Memory Management**: Ensure proper allocation/deallocation
- **Access Control**: Validate permission checks
- **Cryptographic Practices**: Review encryption and hashing

### Code Quality Review

- **Naming Conventions**: AGS-specific naming standards
- **Code Structure**: Function organization and modularity
- **Error Handling**: Proper error checking and recovery
- **Documentation**: Code comments and API documentation
- **Testing**: Unit test coverage and quality

### Performance Review

- **Algorithm Efficiency**: Time and space complexity
- **Resource Usage**: Memory and CPU utilization
- **I/O Operations**: File handling and network calls
- **Caching Strategies**: Data caching and reuse
- **Scalability**: Performance under load

### BIOS/UEFI Specific Review

- **Platform Compatibility**: Cross-platform support
- **Firmware Updates**: Secure update mechanisms
- **Hardware Interaction**: Safe hardware access
- **Boot Process**: Critical path optimization
- **Memory Management**: BIOS-specific memory handling

## Review Templates

### BIOS Code Review Template

```powershell
# Generate BIOS-specific review
python scripts/code_review.py review-bios --repo CDC_AgS_2025 --pr 1733 --template bios
```

**Focus Areas**:
- Platform initialization
- Hardware abstraction
- Firmware update mechanisms
- Memory map management
- Boot sequence integrity

### Security Review Template

```powershell
# Generate security-focused review
python scripts/code_review.py review-security --repo CBF_DellFeaturesPkg --commit f294d2d7
```

**Focus Areas**:
- Buffer overflow prevention
- Input validation
- Cryptographic practices
- Access control
- Secure coding standards

## Automated Checks

### Static Analysis

```powershell
# Run static analysis
python scripts/code_review.py static-analysis --repo CDC_AgS_2025 --path "DellPkgs"

# Check for common vulnerabilities
python scripts/code_review.py vulnerability-scan --repo CDC_AgS_2025
```

### Code Style Analysis

```powershell
# Check coding standards
python scripts/code_review.py style-check --repo CDC_AgS_2025 --standard ags

# AGS-specific naming conventions
python scripts/code_review.py naming-check --repo CDC_AgS_2025
```

### Dependency Analysis

```powershell
# Analyze dependencies
python scripts/code_review.py dependency-analysis --repo CDC_AgS_2025

# Check for circular dependencies
python scripts/code_review.py circular-deps --repo CDC_AgS_2025
```

## Review Reports

### Generate Comprehensive Report

```powershell
# Full review report with recommendations
python scripts/code_review.py generate-report --repo CDC_AgS_2025 --pr 1733 --format markdown

# Executive summary report
python scripts/code_review.py exec-summary --repo CDC_AgS_2025 --range main..develop
```

### Report Sections

1. **Executive Summary**: High-level findings and risk assessment
2. **Security Analysis**: Vulnerabilities and security recommendations
3. **Code Quality**: Style, structure, and maintainability
4. **Performance**: Optimization opportunities
5. **Platform Specific**: BIOS/UEFI specific considerations
6. **Action Items**: Prioritized list of recommended changes

## Integration with GitHub

### Auto-Review PRs

```powershell
# Set up automatic PR reviews
python scripts/code_review.py auto-review --repo CDC_AgS_2025 --trigger "pull_request opened"

# Configure review thresholds
python scripts/code_review.py configure --repo CDC_AgS_2025 --security-threshold high --quality-threshold medium
```

### Review Comments

```powershell
# Add review comments to PR
python scripts/code_review.py comment-pr --repo CDC_AgS_2025 --number 1733 --file review_comments.json

# Approve or request changes
python scripts/code_review.py approve-pr --repo CDC_AgS_2025 --number 1733 --message "LGTM after addressing security comments"
```

## Custom Rules and Policies

### Define Review Rules

```powershell
# Create custom review rules
python scripts/code_review.py define-rules --repo CDC_AgS_2025 --rules-file ags_rules.json

# Validate against custom rules
python scripts/code_review.py validate-rules --repo CDC_AgS_2025 --commit f294d2d7
```

### Rule Categories

- **Must-Have**: Critical security and functionality requirements
- **Should-Have**: Best practices and code quality standards
- **Nice-to-Have**: Optimization and improvement suggestions

## Batch Operations

### Multi-Repository Review

```powershell
# Review across multiple repositories
python scripts/code_review.py batch-review --repos "CDC_AgS_2025,CBF_DellFeaturesPkg,CDC_Edk2_2025" --focus security

# Generate organization-wide report
python scripts/code_review.py org-review --owner CSG-Firmware-Engineering --focus bios
```

### Historical Analysis

```powershell
# Analyze code quality trends
python scripts/code_review.py trend-analysis --repo CDC_AgS_2025 --period 30d

# Compare branches
python scripts/code_review.py compare-branches --repo CDC_AgS_2025 --branch1 main --branch2 develop
```

## Configuration

### Review Preferences

```toml
[review]
focus_areas = ["security", "performance", "code_quality"]
severity_threshold = "medium"
auto_approve = false
require_tests = true

[security]
check_vulnerabilities = true
scan_dependencies = true
buffer_overflow_check = true

[quality]
naming_conventions = "ags"
documentation_required = true
test_coverage_threshold = 80

[platform]
bios_specific = true
uefi_standards = true
hardware_abstraction = true

# GitHub configuration is handled by github_integration skill
# See ../github_integration/config.toml for GitHub settings
```

## Best Practices

### Review Process

1. **Understand Context**: Review related code and documentation
2. **Check Requirements**: Verify against specifications and requirements
3. **Security First**: Prioritize security vulnerabilities
4. **Test Changes**: Ensure functionality is preserved
5. **Document Findings**: Provide clear, actionable feedback

### Feedback Guidelines

- **Specific**: Point to exact lines and issues
- **Constructive**: Provide solutions, not just problems
- **Prioritized**: Rank issues by severity and impact
- **Educational**: Explain why changes are needed
- **Respectful**: Professional and collaborative tone

## Troubleshooting

### Common Issues

- **Access Denied**: Check GitHub token permissions
- **Large Files**: Use chunked analysis for big files
- **Complex PRs**: Break down into smaller reviews
- **Missing Context**: Fetch related files and commits

### Debug Mode

```powershell
# Enable debug logging
python scripts/code_review.py review-pr --repo CDC_AgS_2025 --number 1733 --debug

# Verbose output
python scripts/code_review.py analyze --repo CDC_AgS_2025 --verbose
```

## Integration with Other Skills

- **jira_integration**: Link review findings to Jira tickets
- **confluence_integration**: Document review standards and procedures
- **github_integration**: Fetch code and manage PR workflows
- **deep_research**: Research coding standards and best practices
