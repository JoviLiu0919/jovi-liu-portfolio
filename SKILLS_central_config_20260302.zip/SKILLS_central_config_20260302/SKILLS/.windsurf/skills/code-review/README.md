# Code Review Skill

A comprehensive code review system that integrates with GitHub to provide automated and manual code analysis for BIOS/UEFI development projects.

## Features

- **Pull Request Analysis**: Automated review of GitHub PRs with security, quality, and performance checks
- **Commit Review**: Detailed analysis of individual commits
- **File Analysis**: Targeted review of specific files and changes
- **Security Scanning**: Vulnerability detection and security best practices
- **Code Quality Analysis**: Style, structure, and maintainability checks
- **BIOS/UEFI Specific**: Platform-specific review rules and guidelines
- **Customizable Rules**: Configurable review policies and thresholds

## Quick Start

### 1. Setup Environment

```powershell
cd .windsurf/code_review
.\scripts\setup_env.ps1
```

### 2. Configure GitHub Token

Code Review uses GitHub Integration for GitHub operations. Configure your GitHub token in the `github_integration` skill:

```powershell
# Edit github_integration/config.toml
[github]
token = "ghp_your_actual_token_here"
base_url = "https://githubcsg.cec.delllabs.net/api/v3"
owner = "CSG-Firmware-Engineering"
```

**Note**: Code Review automatically uses the GitHub configuration from `github_integration/config.toml`. No separate GitHub configuration is needed in `code_review/config.toml`.

### 3. Basic Usage

```powershell
# Review a pull request
python scripts/code_review.py review-pr --repo CDC_AgS_2025 --number 1733

# Review a commit
python scripts/code_review.py review-commit --repo CBF_DellFeaturesPkg --sha f294d2d732b85d26a870436e2e6ca7abaaddb209

# Review with specific focus
python scripts/code_review.py review-pr --repo CDC_AgS_2025 --number 1733 --focus security,performance
```

## Directory Structure

```
code_review/
├── SKILL.md                 # Complete skill documentation
├── README.md               # This file
├── requirements.txt        # Python dependencies
├── config.toml            # Configuration file
├── scripts/
│   ├── code_review.py     # Main review tool
│   └── setup_env.ps1      # Environment setup script
└── .venv/                 # Virtual environment
```

## Review Categories

### Security Review

- **Buffer Overflow Prevention**: Detects unsafe string functions
- **Input Validation**: Checks for proper input sanitization
- **Memory Management**: Verifies safe allocation/deallocation
- **Hardcoded Credentials**: Identifies hardcoded passwords/tokens
- **Access Control**: Validates permission checks

### Code Quality Review

- **Naming Conventions**: AGS-specific PascalCase standards
- **Code Structure**: Function organization and modularity
- **Error Handling**: Proper error checking and recovery
- **Documentation**: Code comments and API documentation
- **TODO/FIXME**: Tracks unresolved items

### Performance Review

- **Algorithm Efficiency**: Time and space complexity analysis
- **Resource Usage**: Memory and CPU utilization
- **Loop Optimization**: Inefficient patterns in loops
- **Memory Allocation**: Allocation patterns and potential leaks

### BIOS/UEFI Specific Review

- **Platform Compatibility**: Cross-platform support
- **Firmware Updates**: Secure update mechanisms
- **Hardware Interaction**: Safe hardware access patterns
- **Platform Configuration**: Model lists and SSID mapping
- **Driver Signing**: Version and compatibility checks

## Configuration

### Review Settings

```toml
[review]
focus_areas = ["security", "performance", "code_quality"]
severity_threshold = "medium"
auto_approve = false
require_tests = true

[security]
check_vulnerabilities = true
scan_dependencies = true
buffer_overflow_check = true

[quality]
naming_conventions = "ags"
documentation_required = true
test_coverage_threshold = 80

[platform]
bios_specific = true
uefi_standards = true
hardware_abstraction = true
```

## Advanced Usage

### Detailed Review Reports

```powershell
# Generate comprehensive report
python scripts/code_review.py review-pr --repo CDC_AgS_2025 --number 1733 --detailed --output review_report.json
```

### Focus-Specific Reviews

```powershell
# Security-focused review
python scripts/code_review.py review-pr --repo CDC_AgS_2025 --number 1733 --focus security

# Performance-focused review
python scripts/code_review.py review-pr --repo CDC_AgS_2025 --number 1733 --focus performance

# Code quality review
python scripts/code_review.py review-pr --repo CDC_AgS_2025 --number 1733 --focus quality
```

## Integration with GitHub

The code review skill integrates seamlessly with the GitHub integration skill to:

- Fetch pull request details and diffs
- Retrieve commit information and file changes
- Analyze code changes across multiple repositories
- Provide context-aware feedback based on project history

## Example Output

```
============================================================
CODE REVIEW REPORT
============================================================
PR #1733: Compal/SlatePtlOne/PIMS-403974/Sev2/Verifybios_test
Author: odm-jim-tsou
State: open
Review Date: 2026-02-05T10:51:00

SUMMARY:
Total Issues: 3
By Severity:
  Medium: 2
  Low: 1
By Type:
  Platform: 2
  Quality: 1

CRITICAL ISSUES (0):
None found.

DETAILED FINDINGS:
1. Platform - Medium
   Issue: Platform model list modification
   Line: 466
   Code: +@set PLATFORM_BIN_MODEL_LIST[%PLATFORM_BIN_CURRENT_INDEX%]=Dell Pro 7 13 P713260
   Recommendation: Verify platform compatibility and SSID mapping
```

## Best Practices

### Review Process

1. **Understand Context**: Review related code and documentation
2. **Security First**: Prioritize security vulnerabilities
3. **Quality Standards**: Follow AGS coding conventions
4. **Platform Awareness**: Consider BIOS/UEFI specific requirements
5. **Constructive Feedback**: Provide actionable recommendations

### Feedback Guidelines

- **Specific**: Point to exact lines and issues
- **Constructive**: Provide solutions, not just problems
- **Prioritized**: Rank issues by severity and impact
- **Educational**: Explain why changes are needed
- **Professional**: Maintain collaborative tone

## Troubleshooting

### Common Issues

- **Access Denied**: Check GitHub token permissions
- **Large Files**: Use chunked analysis for big files
- **Complex PRs**: Break down into smaller reviews
- **Missing Context**: Fetch related files and commits

### Debug Mode

```powershell
# Enable debug logging
python scripts/code_review.py review-pr --repo CDC_AgS_2025 --number 1733 --debug
```

## Integration with Other Skills

- **github_integration**: Fetch code and manage PR workflows
- **jira_integration**: Link review findings to tickets
- **confluence_integration**: Document review standards
- **deep_research**: Research coding standards and best practices

## Contributing

To extend the code review skill:

1. Add new analysis methods to the `CodeReviewTool` class
2. Update configuration options in `config.toml`
3. Enhance review templates and focus areas
4. Add support for new file types and languages
5. Improve integration with other development tools

## License

This skill is part of the BEA LLM Skills framework and follows the same licensing terms.
