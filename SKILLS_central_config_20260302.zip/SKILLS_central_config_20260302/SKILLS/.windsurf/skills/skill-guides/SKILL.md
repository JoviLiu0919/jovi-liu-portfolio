---
name: skill-guides
description: Global guidelines for developing and maintaining Agent Skills. Use when creating new skills, modifying existing ones, or ensuring compliance with Agent Skills specification.
---

# Skill Development Guidelines

These rules MUST be followed when creating, modifying, or using any skill within this repository.

## 1. Core Integration Architecture
- **confluence_integration**, **jira_integration**, and **github_integration** are the core skills responsible for REST API access to Confluence, JIRA, and GitHub.
- These core skills provide robust scripts (e.g., `confluence_tool.py`, `jira_tool.py`, `github_tool.py`) meant to be consumed by other "high-level" skills.
- **code_review** is a high-level analysis skill that consumes data from core integration skills.

## 2. Priority of Data Access
- Any task requiring JIRA, Confluence, or GitHub access MUST prioritize using the existing tools in `confluence_integration`, `jira_integration`, and `github_integration`.
- **Pre-modification Protocol**: If a required feature is missing or a bug is found in the core scripts, you MUST notify the user before making changes to their `.py` files and seek confirmation.

## 3. High-Level Skill Design
- **Minimize Local Scripts**: New skills should avoid creating redundant scripts whenever possible.
- **Logic vs. Data**: High-level skills (e.g., for data analysis, web crawling, format analysis, or code review) may have their own scripts for specialized logic, but **all underlying data fetching** from JIRA, Confluence, or GitHub must go through the core integration skills.
- **Example Pattern**: `code_review` skill uses `github_integration` for data fetching but implements its own analysis logic.

## 4. Maintenance and Extensibility
- **Rule of DRY**: Avoid duplicating functions. When modifying core scripts, prioritize modularity, class structures, and clear APIs to ensure future reuse and extensibility.
- **Post-Task Review**: After completing a task, review the relevant `SKILL.md` files to see if updates are needed or if new logic should be formally integrated into the core scripts.

## 5. Zero-Temp-File Policy
- **Workflow Architecture**: If a task seems to require generating temporary files (e.g., `.json`, `.xml`, `.py` debug scripts), you MUST first attempt to re-architect the skill or command to handle data in-memory (e.g., using variables, piped outputs, or proper API expansion).
- **Cleanliness**: If temporary files are absolutely unavoidable for deep debugging, they MUST be deleted immediately after the analysis or task is complete.

## 6. Interaction Rules
- Always validate user-provided Page IDs, JQL queries, or names before execution.
- Request explicit confirmation for Create, Update, or Delete operations on remote servers.

## 7. GitHub Integration Patterns
- **Core GitHub Access**: All GitHub API interactions MUST use `github_integration` core skill via `github_tool.py`.
- **Configuration Centralization**: GitHub configurations (token, base_url, owner) MUST be centralized in `github_integration/config.toml`. High-level skills should NOT duplicate GitHub configuration sections.
- **Code Review Architecture**: `code_review` skill demonstrates proper high-level skill design:
  - Uses `github_integration` for data fetching (PRs, commits, diffs)
  - Implements specialized analysis logic locally
  - Follows TOML configuration pattern from core skills
  - Maintains separation of concerns (data vs. analysis)
  - Uses centralized GitHub configuration from `github_integration`

## 8. Skill Integration Examples

### GitHub + Code Review Pattern
```python
# High-level skill consuming core integration
from github_integration.scripts.github_tool import GitHubTool

class AnalysisSkill:
    def __init__(self):
        # GitHubTool automatically uses centralized config from github_integration/config.toml
        self.github_tool = GitHubTool()  # Core integration
    
    def analyze_pr(self, repo, pr_number):
        # Fetch data using core skill
        pr_data = self.github_tool.get_pr(repo, pr_number)
        pr_diff = self.github_tool.get_pr_diff(repo, pr_number)
        
        # Implement specialized analysis logic locally
        return self._perform_analysis(pr_data, pr_diff)
```

### Configuration Pattern
```toml
# github_integration/config.toml (Centralized GitHub config)
[github]
base_url = "https://githubcsg.cec.delllabs.net/api/v3"
owner = "CSG-Firmware-Engineering"
token = "ghp_your_token_here"

# high_level_skill/config.toml (Skill-specific config only)
[analysis]
focus_areas = ["security", "performance"]
# NOTE: Do NOT duplicate [github] section here
```

### Configuration Consistency
- Core skills use TOML configuration (`config.toml`)
- High-level skills should follow same pattern
- Maintain consistent structure across skills

## 10. Skill Development Best Practices

### Configuration Management
- **TOML Standard**: Use `config.toml` for all skill configurations
- **Section Organization**: Group related settings in logical sections
- **Environment Variables**: Support both config file and environment variable overrides
- **Default Values**: Provide sensible defaults for all configuration options
- **GitHub Configuration Unification**: All GitHub-related configurations (token, base_url, owner) MUST be centralized in `github_integration/config.toml`. Other skills consuming GitHub data should NOT duplicate GitHub configuration sections.

### Error Handling & Robustness
- **Graceful Degradation**: Skills should handle missing dependencies gracefully
- **Clear Error Messages**: Provide actionable error messages with resolution suggestions
- **Validation**: Validate inputs and configurations before processing
- **Fallback Mechanisms**: Implement fallback options when primary methods fail

### Documentation Standards
- **Comprehensive SKILL.md**: Include setup, usage, and integration examples
- **Code Comments**: Document complex logic and integration points
- **README.md**: Provide quick start guide and basic usage examples
- **API Documentation**: Document public interfaces and integration patterns

### Testing & Validation
- **Integration Testing**: Test with real data from core integration skills
- **Error Scenarios**: Test error handling and edge cases
- **Configuration Validation**: Test with various configuration scenarios
- **Cross-Skill Compatibility**: Ensure compatibility with other skills

### PowerShell Syntax Guidelines
- **Windows Compatibility**: Use `;` instead of `&&` for command chaining in Windows PowerShell
- **Cross-Platform**: For cross-platform compatibility, prefer separate command lines or use `;`
- **Example**: `cd directory; python script.py` instead of `cd directory && python script.py`

## 11. Core Agent Behaviors (CRITICAL FOR NEW SESSIONS)

### Context Preservation & Consistency
- **Stateless Architecture**: You are stateless. Any new SOP (e.g., "Check comments if summary is vague") MUST be documented in the relevant `SKILL.md`. Relying on memory is forbidden.
- **Cross-Session Consistency**: All skills MUST produce identical results regardless of session or user. This requires:
  - **Default Behavior Documentation**: Specify recommended commands and expected outputs in `SKILL.md`
  - **Usage Guidelines**: Document when to use specific commands and what parameters to include
  - **Expected Output Format**: Describe the structure and format of outputs for consistency
- **New Session Readiness**: New users or sessions should achieve the same results by following the documented procedures

### Intelligent Analysis Requirements
- **Completeness over Speed**: If a tool's summary is insufficient (e.g., "No solution found" but the ticket is Closed), you MUST proactively fetch raw data (e.g., `get-comments`, `get-page-content`) to perform manual AI analysis. Do not report "No Data" without digging deeper.
- **Tool Fallback**: If a specialized command fails (e.g., `scan-pipeline`), fall back to basic commands (e.g., `get-page`) and read the raw content yourself. You are the intelligence layer; the script is just a helper.

### Documentation Standards for Consistency
- **Usage Guidelines Section**: Each skill MUST include a "Usage Guidelines (Agent Behavior)" section that specifies:
  - Priority order of commands for common requests
  - When to use specific parameters and options
  - Expected output formats and structure
  - Common user request patterns and recommended responses
- **Quick Start Section**: Include recommended commands for new users to achieve immediate results
- **Command Mapping**: Document common user requests and their corresponding recommended commands

### Report Generation Standards
- **Centralized Report Directory**: All skills MUST save markdown reports to `.windsurf/Reports/` directory
- **Bilingual Report Format**: Reports MUST be saved in bilingual format (English + Traditional Chinese)
- **File Naming Convention**: Use descriptive names with timestamps, e.g., `github_repository_analysis_2026-02-05.md`
- **Report Structure**: Each report MUST include:
  - English main content with proper Markdown formatting
  - Bilingual summary section (🇹🇼 Chinese + 🇺🇸 English)
  - Analysis timestamp
  - Clear section headers with emojis
- **Automatic Report Saving**: Skills should automatically save comprehensive reports when generating analysis
- **Report Overwrite Policy**: Use timestamp-based filenames to avoid overwriting previous reports

### Example Consistency Framework
```markdown
## Usage Guidelines (Agent Behavior)

### Command Priority Guidelines
When users ask for specific types of operations:
1. **First Priority**: Use the most comprehensive command available
2. **Alternative**: Use specialized commands for specific needs
3. **Fallback**: Use basic commands for simple requests

### Expected Output Format
- Clear structure with headers and sections
- Consistent formatting (tables, lists, emojis)
- Bilingual summary when appropriate
- Error handling and status indicators

### Common User Requests & Commands
| User Request Pattern | Recommended Command Type |
|---------------------|-------------------------|
| "Show me/analyze/list" | Comprehensive analysis command |
| "Quick/simple/fast" | Basic overview command |
| "Detailed/in-depth" | Advanced analysis command |
```

## 12. Mandatory Skill Requirements

### Report Generation Compliance
- **ALL SKILLS MUST read and follow skill_guides/SKILL.md** before implementing any functionality
- **Report Generation Standards Compliance**: All skills that generate reports MUST:
  - Read skill_guides/SKILL.md to understand Report Generation Standards
  - Implement save_report() method following the centralized pattern
  - Save reports to `.windsurf/Reports/` directory (NOT `.windsurf/skills/Reports/`)
  - Use bilingual format (English + Traditional Chinese)
  - Include proper metadata headers with timestamps
  - Use timestamped filenames to avoid overwrites

### Implementation Checklist for New Skills
Before implementing any new skill:
1. **Read skill_guides/SKILL.md** completely
2. **Follow Core Integration Architecture** (Section 1)
3. **Implement Report Generation** if skill generates analysis
4. **Use Zero-Temp-File Policy** (Section 5)
5. **Document Usage Guidelines** (Section 11)
6. **Follow Report Generation Standards** (Section 7)

### Reference Implementation Pattern
```python
# Every skill that generates reports should include:
from pathlib import Path
from datetime import datetime

def save_report(self, content, report_name, description=""):
    """Save report following skill_guides Report Generation Standards"""
    # Read skill_guides for compliance
    reports_dir = Path(__file__).parent.parent.parent.parent / "Reports")
    reports_dir.mkdir(exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    filename = f"{report_name}_{timestamp}.md"
    filepath = reports_dir / filename
    
    # Add metadata header per standards
    report_header = f"""---
# {report_name} Report
**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Description:** {description}
**Skill:** {self.__class__.__name__}
---

"""
    
    full_content = report_header + content
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(full_content)
    
    return f"✅ Report saved to: {filepath}"
```
