#!/usr/bin/env python3
"""
GitHub PR Fetcher for CBDCIT Submission Skill

Fetches detailed data from GitHub Enterprise PR URL, including:
- PR basic info (title, body, state, merge commit SHA)
- Git commit message (from merge commit)
- Submodule links (parsed from PR body Submodule Link Workflow)
- Changed files (for Feature Customizations analysis)
"""

import re
import sys
from pathlib import Path
from typing import Optional

import requests
import urllib3
import toml

# Import central configuration loader
sys.path.append(str(Path(__file__).parent.parent.parent.parent))
from config_loader import load_skill_config_with_central_fallback

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class GitHubPRFetcher:
    """Fetches PR details from GitHub Enterprise"""

    def __init__(self, config_path: Optional[Path] = None):
        if config_path is None:
            config_path = Path(__file__).parent.parent / "config.toml"

        # Use central configuration loader
        self.config = load_skill_config_with_central_fallback(config_path)

        github_config = self.config.get('github', {})
        self.base_url = github_config.get('base_url', '')
        self.owner = github_config.get('owner', '')
        self.token = github_config.get('token', '')

        api_config = self.config.get('api', {})
        self.timeout = api_config.get('timeout', 30)

        self.headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github.v3+json"
        }

    def _make_request(self, method, url, params=None):
        """Send HTTP request to GitHub API"""
        response = requests.request(
            method, url,
            headers=self.headers,
            params=params,
            verify=False,
            timeout=self.timeout
        )
        if response.status_code in (200, 201):
            return response.json()
        else:
            raise Exception(f"GitHub API Error: {response.status_code} - {response.text[:500]}")

    def parse_pr_url(self, pr_url: str) -> dict:
        """
        Parse PR URL to extract owner, repo, pull_number
        
        Supported format:
        https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/1521
        """
        pattern = r'https?://[^/]+/([^/]+)/([^/]+)/pull/(\d+)'
        match = re.match(pattern, pr_url)
        if not match:
            raise ValueError(f"Cannot parse PR URL: {pr_url}")

        return {
            'owner': match.group(1),
            'repo': match.group(2),
            'pull_number': int(match.group(3)),
            'pr_url': pr_url
        }

    def get_pr_details(self, owner: str, repo: str, pull_number: int) -> dict:
        """Get PR details"""
        url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pull_number}"
        return self._make_request("GET", url)

    def get_pr_commits(self, owner: str, repo: str, pull_number: int) -> list:
        """Get all commits for a PR"""
        url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pull_number}/commits"
        commits = []
        page = 1
        while True:
            result = self._make_request("GET", url, params={"per_page": 100, "page": page})
            if not result:
                break
            commits.extend(result)
            if len(result) < 100:
                break
            page += 1
        return commits

    def get_pr_files(self, owner: str, repo: str, pull_number: int) -> list:
        """Get list of changed files for a PR"""
        url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pull_number}/files"
        files = []
        page = 1
        while True:
            result = self._make_request("GET", url, params={"per_page": 100, "page": page})
            if not result:
                break
            files.extend(result)
            if len(result) < 100:
                break
            page += 1
        return files

    def get_pr_comments(self, owner: str, repo: str, pull_number: int) -> list:
        """Get all comments (issue comments) for a PR"""
        url = f"{self.base_url}/repos/{owner}/{repo}/issues/{pull_number}/comments"
        comments = []
        page = 1
        while True:
            result = self._make_request("GET", url, params={"per_page": 100, "page": page})
            if not result:
                break
            comments.extend(result)
            if len(result) < 100:
                break
            page += 1
        return comments

    def get_commit_details(self, owner: str, repo: str, sha: str) -> dict:
        """Get details for a specific commit"""
        url = f"{self.base_url}/repos/{owner}/{repo}/commits/{sha}"
        return self._make_request("GET", url)

    def get_merge_commit_sha(self, pr_data: dict) -> Optional[str]:
        """Get merge commit SHA from PR data"""
        return pr_data.get('merge_commit_sha')

    def extract_commit_message(self, pr_data: dict, commits: list) -> str:
        """
        Extract git commit message
        
        Priority:
        1. If PR is squash merged, use merge commit message
        2. Otherwise use last commit message
        3. Fallback to PR body
        """
        # Try to get merge commit message
        merge_sha = self.get_merge_commit_sha(pr_data)
        if merge_sha:
            try:
                owner = pr_data.get('base', {}).get('repo', {}).get('owner', {}).get('login', self.owner)
                repo = pr_data.get('base', {}).get('repo', {}).get('name', '')
                merge_commit = self.get_commit_details(owner, repo, merge_sha)
                message = merge_commit.get('commit', {}).get('message', '')
                if message:
                    return message
            except Exception:
                pass

        # Fallback: use last commit message
        if commits:
            last_commit = commits[-1]
            message = last_commit.get('commit', {}).get('message', '')
            if message:
                return message

        # Final fallback: PR body
        return pr_data.get('body', '') or ''

    def extract_commit_title(self, commit_message: str) -> str:
        """Extract title (first line) from commit message"""
        if not commit_message:
            return ''
        lines = commit_message.strip().split('\n')
        return lines[0].strip()

    def extract_systems_affected(self, commit_message: str) -> list:
        """
        Extract [Systems Affected] from commit message
        
        Format examples:
        [Systems Affected]: all
        [Systems Affected]: PTL, LNL
        Systems Affected: ARL
        [Systems Affected]
        All
        """
        # Pattern 1: Same-line format with colon (e.g., "[Systems Affected]: all")
        same_line_patterns = [
            r'\[Systems?\s*Affected\]\s*:\s*(.+)',
            r'Systems?\s*Affected\s*:\s*(.+)',
        ]
        for pattern in same_line_patterns:
            match = re.search(pattern, commit_message, re.IGNORECASE)
            if match:
                value = match.group(1).strip()
                if value.lower() == 'all':
                    return ['all']
                # Split multiple chipsets
                chipsets = [c.strip() for c in re.split(r'[,;/\s]+', value) if c.strip()]
                return chipsets

        # Pattern 2: Multi-line format (e.g., "[Systems Affected]\nAll")
        multi_line_patterns = [
            r'\[Systems?\s*Affected\]\s*\n\s*(.+)',
            r'Systems?\s*Affected\s*\n\s*(.+)',
        ]
        for pattern in multi_line_patterns:
            match = re.search(pattern, commit_message, re.IGNORECASE)
            if match:
                value = match.group(1).strip()
                # Skip if next line is another section header
                if value.startswith('[') or value.startswith('*'):
                    continue
                if value.lower() == 'all':
                    return ['all']
                chipsets = [c.strip() for c in re.split(r'[,;/\s]+', value) if c.strip()]
                return chipsets

        return []

    def extract_submodule_links(self, pr_body: str, pr_comments: list = None) -> list:
        """
        Extract Submodule Link Workflow links from PR body and comments
        
        Search patterns:
        - Full PR links (e.g., https://githubcsg.cec.delllabs.net/.../pull/XXX)
        - Markdown PR links (e.g., [#278](https://.../pull/278))
        - Searches both PR body and PR comments (Submodule Link Workflow is often in comments)
        """
        submodule_links = []
        pr_link_pattern = r'https?://[^\s)>\]]+/pull/\d+'

        # Collect all text sources to search
        text_sources = []
        if pr_body:
            text_sources.append(pr_body)
        if pr_comments:
            for comment in pr_comments:
                body = comment.get('body', '') if isinstance(comment, dict) else str(comment)
                if body:
                    text_sources.append(body)

        for text in text_sources:
            # Find Submodule Link Workflow sections
            submodule_section = False
            for line in text.split('\n'):
                line_lower = line.lower()
                if 'submodule' in line_lower and ('link' in line_lower or 'workflow' in line_lower or 'pr' in line_lower):
                    submodule_section = True
                elif submodule_section and line.strip().startswith('# ') and 'submodule' not in line_lower:
                    submodule_section = False

                if submodule_section:
                    # Find full PR URLs and markdown-style PR links
                    links = re.findall(pr_link_pattern, line)
                    for link in links:
                        # Filter out workflow run links, compare links, etc.
                        if '/pull/' in link and '/actions/' not in link and '/compare/' not in link:
                            if link not in submodule_links:
                                submodule_links.append(link)

        # Fallback: If nothing found in submodule sections, search all text for PR links
        if not submodule_links:
            for text in text_sources:
                all_links = re.findall(pr_link_pattern, text)
                for link in all_links:
                    if '/pull/' in link and '/actions/' not in link and '/compare/' not in link:
                        if link not in submodule_links:
                            submodule_links.append(link)

        return submodule_links

    def get_submodule_sha(self, submodule_pr_url: str) -> dict:
        """
        Get merge commit SHA for a submodule PR
        
        Returns:
            dict: {
                'repo': 'CBF_DellFeaturesPkg',
                'sha': 'f69f1965...',
                'pr_url': 'https://...',
                'pr_number': 278
            }
        """
        parsed = self.parse_pr_url(submodule_pr_url)
        pr_data = self.get_pr_details(parsed['owner'], parsed['repo'], parsed['pull_number'])

        merge_sha = self.get_merge_commit_sha(pr_data)
        if not merge_sha:
            # If no merge SHA, try getting the last commit SHA
            commits = self.get_pr_commits(parsed['owner'], parsed['repo'], parsed['pull_number'])
            if commits:
                merge_sha = commits[-1].get('sha', '')

        return {
            'repo': parsed['repo'],
            'sha': merge_sha or 'N/A',
            'pr_url': submodule_pr_url,
            'pr_number': parsed['pull_number']
        }

    def post_pr_comment(self, owner: str, repo: str, pull_number: int, body: str) -> dict:
        """Post a comment on a GitHub PR"""
        url = f"{self.base_url}/repos/{owner}/{repo}/issues/{pull_number}/comments"
        response = requests.post(
            url,
            headers=self.headers,
            json={"body": body},
            verify=False,
            timeout=self.timeout
        )
        if response.status_code in (200, 201):
            return response.json()
        else:
            raise Exception(f"GitHub API Error: {response.status_code} - {response.text[:500]}")

    def analyze_feature_customizations(self, files: list) -> list:
        """
        Analyze Feature Customizations
        
        Check if code changes touch the following paths:
        - DellPkgs/DellPlatformPkgs/DT
        - DellPkgs/DellPlatformPkgs/NB
        - DellPkgs/DellPlatformPkgs/PW
        
        Returns:
            list: List of changed platform path files
        """
        platform_paths = self.config.get('platform_paths', {}).get(
            'customization_paths',
            [
                "DellPkgs/DellPlatformPkgs/DT",
                "DellPkgs/DellPlatformPkgs/NB",
                "DellPkgs/DellPlatformPkgs/PW",
            ]
        )

        customization_files = []
        for file_info in files:
            filename = file_info.get('filename', '')
            for platform_path in platform_paths:
                if filename.startswith(platform_path):
                    customization_files.append({
                        'filename': filename,
                        'platform_path': platform_path,
                        'status': file_info.get('status', 'modified'),
                        'additions': file_info.get('additions', 0),
                        'deletions': file_info.get('deletions', 0),
                    })
                    break

        return customization_files

    def fetch_complete_pr_data(self, pr_url: str) -> dict:
        """
        Fetch complete PR data as material for CBDCIT ticket
        
        Args:
            pr_url: PR URL
            
        Returns:
            dict: Complete PR data containing all fields needed for CBDCIT
        """
        # 1. Parse PR URL
        parsed = self.parse_pr_url(pr_url)
        owner = parsed['owner']
        repo = parsed['repo']
        pull_number = parsed['pull_number']

        print(f"Fetching PR data: {owner}/{repo}#{pull_number}...")

        # 2. Get PR details
        pr_data = self.get_pr_details(owner, repo, pull_number)
        print(f"  PR Title: {pr_data.get('title', 'N/A')}")
        print(f"  PR State: {pr_data.get('state', 'N/A')}")
        print(f"  Merged: {pr_data.get('merged', False)}")

        # 3. Get PR commits
        commits = self.get_pr_commits(owner, repo, pull_number)
        print(f"  Commits Count: {len(commits)}")

        # 4. Extract commit message
        commit_message = self.extract_commit_message(pr_data, commits)
        commit_title = self.extract_commit_title(commit_message)
        print(f"  Commit Title: {commit_title}")

        # 5. Extract Systems Affected
        systems_affected = self.extract_systems_affected(commit_message)
        print(f"  Systems Affected: {systems_affected}")

        # 6. Get merge commit SHA (ToT SHA)
        merge_sha = self.get_merge_commit_sha(pr_data)
        print(f"  ToT Merge SHA: {merge_sha or 'N/A'}")

        # 7. Get PR changed files
        files = self.get_pr_files(owner, repo, pull_number)
        print(f"  Changed Files: {len(files)}")

        # 8. Extract submodule links (from PR body + comments)
        pr_body = pr_data.get('body', '') or ''
        pr_comments = self.get_pr_comments(owner, repo, pull_number)
        print(f"  PR Comments: {len(pr_comments)}")
        submodule_links = self.extract_submodule_links(pr_body, pr_comments)
        print(f"  Submodule Links: {len(submodule_links)}")

        # 9. Get submodule SHAs
        submodule_shas = []
        for sub_link in submodule_links:
            try:
                sub_data = self.get_submodule_sha(sub_link)
                submodule_shas.append(sub_data)
                print(f"    Submodule: {sub_data['repo']} SHA: {sub_data['sha'][:7]}")
            except Exception as e:
                print(f"    Submodule fetch failed ({sub_link}): {e}")
                submodule_shas.append({
                    'repo': sub_link,
                    'sha': 'ERROR',
                    'pr_url': sub_link,
                    'pr_number': 0
                })

        # 10. Analyze Feature Customizations
        customization_files = self.analyze_feature_customizations(files)
        print(f"  Feature Customization Files: {len(customization_files)}")

        # 11. Assemble complete data
        result = {
            'pr_url': pr_url,
            'owner': owner,
            'repo': repo,
            'pull_number': pull_number,
            'title': pr_data.get('title', ''),
            'body': pr_body,
            'state': pr_data.get('state', ''),
            'merged': pr_data.get('merged', False),
            'merge_commit_sha': merge_sha,
            'base_branch': pr_data.get('base', {}).get('ref', ''),
            'head_branch': pr_data.get('head', {}).get('ref', ''),
            'author': pr_data.get('user', {}).get('login', ''),
            'commit_message': commit_message,
            'commit_title': commit_title,
            'systems_affected': systems_affected,
            'commits': commits,
            'files': files,
            'submodule_links': submodule_links,
            'submodule_shas': submodule_shas,
            'customization_files': customization_files,
            'chipset_database': self.config.get('chipset_database', {}),
        }

        return result


if __name__ == "__main__":
    import json

    if len(sys.argv) < 2:
        print("Usage: python github_pr_fetcher.py <PR_URL>")
        print("Example: python github_pr_fetcher.py https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/1521")
        sys.exit(1)

    pr_url = sys.argv[1]
    fetcher = GitHubPRFetcher()
    data = fetcher.fetch_complete_pr_data(pr_url)

    # Output summary
    print("\n" + "=" * 60)
    print("PR Data Summary")
    print("=" * 60)
    print(f"Repo: {data['repo']}")
    print(f"PR #{data['pull_number']}: {data['title']}")
    print(f"Commit Title: {data['commit_title']}")
    print(f"Systems Affected: {data['systems_affected']}")
    print(f"ToT SHA: {data['merge_commit_sha']}")
    print(f"Submodules: {len(data['submodule_shas'])}")
    for sub in data['submodule_shas']:
        print(f"  - {sub['repo']}: {sub['sha']}")
    print(f"Customization Files: {len(data['customization_files'])}")
