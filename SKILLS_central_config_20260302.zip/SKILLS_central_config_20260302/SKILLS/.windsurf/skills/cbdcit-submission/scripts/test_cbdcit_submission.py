#!/usr/bin/env python3
"""
CBDCIT Submission Skill - Test Suite

Tests all core functionality using mock data, no actual API connection required.
"""

import sys
import io
import json
from pathlib import Path

# Force UTF-8 encoding for Windows console
if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except AttributeError:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

if sys.stderr.encoding and sys.stderr.encoding.lower() != 'utf-8':
    try:
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# Ensure scripts directory is in Python path
scripts_dir = Path(__file__).parent
if str(scripts_dir) not in sys.path:
    sys.path.insert(0, str(scripts_dir))

from cbdcit_ticket_builder import CBDCITTicketBuilder


# =============================================================================
# Mock Data
# =============================================================================

SAMPLE_PR_DATA = {
    'pr_url': 'https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/1521',
    'owner': 'CSG-Firmware-Engineering',
    'repo': 'CDC_AgS_2025',
    'pull_number': 1521,
    'title': '[SlatePtl] Fix PIMS-123456: Update PCD token for PTL platform',
    'body': '''## Description
Fix PIMS-123456: Update PCD token for PTL platform

## Submodule Link Workflow
- DellFeaturesPkg: https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CBF_DellFeaturesPkg/pull/278

## Systems Affected
PTL, LNL
''',
    'state': 'closed',
    'merged': True,
    'merge_commit_sha': '4178578db7e3713e9f02ed1af4899daf5274a60e',
    'base_branch': 'main',
    'head_branch': 'feature/slate-ptl-pcd-fix',
    'author': 'test_user',
    'commit_message': '''[SlatePtl] Fix PIMS-123456: Update PCD token for PTL platform

[Description]
Fix the PCD token configuration for PTL platform to resolve
boot failure issue reported in PIMS-123456.

[Systems Affected]: PTL, LNL

[Impact]
- SlatePtlOnePkg: PCD token update
- BladePtlOnePkg: No impact

Signed-off-by: Test User <test_user@dell.com>
''',
    'commit_title': '[SlatePtl] Fix PIMS-123456: Update PCD token for PTL platform',
    'systems_affected': ['PTL', 'LNL'],
    'commits': [
        {
            'sha': 'abc123def456',
            'commit': {
                'message': '[SlatePtl] Fix PIMS-123456: Update PCD token for PTL platform'
            }
        }
    ],
    'files': [
        {
            'filename': 'DellPkgs/DellPlatformPkgs/NB/SlatePtlOnePkg/SlatePtl.dsc',
            'status': 'modified',
            'additions': 5,
            'deletions': 2,
        },
        {
            'filename': 'DellPkgs/DellPlatformPkgs/NB/SlatePtlOnePkg/Include/PcdToken.h',
            'status': 'modified',
            'additions': 10,
            'deletions': 3,
        },
        {
            'filename': 'DellPkgs/DellFeaturesPkg/Common/SomeFeature.c',
            'status': 'modified',
            'additions': 20,
            'deletions': 5,
        },
    ],
    'submodule_links': [
        'https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CBF_DellFeaturesPkg/pull/278'
    ],
    'submodule_shas': [
        {
            'repo': 'CBF_DellFeaturesPkg',
            'sha': 'f69f1965d50c01b8e95bc10b27e0d4a69b09b35b',
            'pr_url': 'https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CBF_DellFeaturesPkg/pull/278',
            'pr_number': 278,
        }
    ],
    'customization_files': [
        {
            'filename': 'DellPkgs/DellPlatformPkgs/NB/SlatePtlOnePkg/SlatePtl.dsc',
            'platform_path': 'DellPkgs/DellPlatformPkgs/NB',
            'status': 'modified',
            'additions': 5,
            'deletions': 2,
        },
        {
            'filename': 'DellPkgs/DellPlatformPkgs/NB/SlatePtlOnePkg/Include/PcdToken.h',
            'platform_path': 'DellPkgs/DellPlatformPkgs/NB',
            'status': 'modified',
            'additions': 10,
            'deletions': 3,
        },
    ],
    'chipset_database': {
        'CDC_AgS_2025': ['PTL', 'LNL', 'ARL', 'MTL', 'RPL'],
        'CDC_AgS_2024': ['LNL', 'ARL', 'RPL', 'MTL', 'ADL'],
    },
}

SAMPLE_PR_DATA_ALL_SYSTEMS = {
    **SAMPLE_PR_DATA,
    'systems_affected': ['all'],
    'commit_message': '''[Common] Update AGESA module

[Systems Affected]: all

Signed-off-by: Another User <another_user@dell.com>
''',
}

SAMPLE_PR_DATA_NO_CUSTOMIZATION = {
    **SAMPLE_PR_DATA,
    'customization_files': [],
    'files': [
        {
            'filename': 'DellPkgs/DellFeaturesPkg/Common/SomeFeature.c',
            'status': 'modified',
            'additions': 20,
            'deletions': 5,
        },
    ],
}


# =============================================================================
# Test Functions
# =============================================================================

def test_build_summary():
    """Test Summary building"""
    print("Test 1: build_summary")
    builder = CBDCITTicketBuilder(SAMPLE_PR_DATA)
    summary = builder.build_summary()
    assert summary == '[SlatePtl] Fix PIMS-123456: Update PCD token for PTL platform', \
        f"Summary mismatch: {summary}"
    print(f"  ✅ Summary: {summary}")


def test_build_type():
    """Test Type building"""
    print("Test 2: build_type")
    builder = CBDCITTicketBuilder(SAMPLE_PR_DATA)
    assert builder.build_type() == "Change"
    print("  ✅ Type: Change")


def test_build_priority():
    """Test Priority building"""
    print("Test 3: build_priority")
    builder = CBDCITTicketBuilder(SAMPLE_PR_DATA)
    assert builder.build_priority() == "Medium"
    assert builder.build_priority("High") == "High"
    print("  ✅ Default: Medium, Override: High")


def test_build_affected_systems_specific():
    """Test Affected Systems - specific chipsets"""
    print("Test 4: build_affected_systems (specific chipsets)")
    builder = CBDCITTicketBuilder(SAMPLE_PR_DATA)
    result = builder.build_affected_systems()
    assert result['repo'] == 'CDC_AgS_2025'
    assert 'PTL' in result['resolved_chipsets']
    assert 'LNL' in result['resolved_chipsets']
    assert len(result['resolved_chipsets']) == 2
    print(f"  ✅ Repo: {result['repo']}")
    print(f"  ✅ Resolved: {result['resolved_chipsets']}")


def test_build_affected_systems_all():
    """Test Affected Systems - all"""
    print("Test 5: build_affected_systems (all)")
    builder = CBDCITTicketBuilder(SAMPLE_PR_DATA_ALL_SYSTEMS)
    result = builder.build_affected_systems()
    assert result['resolved_chipsets'] == ['PTL', 'LNL', 'ARL', 'MTL', 'RPL']
    print(f"  ✅ All chipsets: {result['resolved_chipsets']}")


def test_build_affected_systems_override():
    """Test Affected Systems - manual override"""
    print("Test 6: build_affected_systems (override)")
    builder = CBDCITTicketBuilder(SAMPLE_PR_DATA)
    result = builder.build_affected_systems(override_chipsets=['ARL'])
    assert result['resolved_chipsets'] == ['ARL']
    print(f"  ✅ Override: {result['resolved_chipsets']}")


def test_build_list_of_deliverables():
    """Test List of Deliverables"""
    print("Test 7: build_list_of_deliverables")
    builder = CBDCITTicketBuilder(SAMPLE_PR_DATA)
    deliverables = builder.build_list_of_deliverables()
    assert 'CDC_AgS_2025 main: SHA-1: 4178578db7e3713e9f02ed1af4899daf5274a60e' in deliverables
    assert 'CBF_DellFeaturesPkg: SHA-1: f69f1965d50c01b8e95bc10b27e0d4a69b09b35b' in deliverables
    print(f"  ✅ Deliverables:\n    {deliverables.replace(chr(10), chr(10) + '    ')}")


def test_build_feature_customizations():
    """Test Feature Customizations - with changes"""
    print("Test 8: build_feature_customizations (with changes)")
    builder = CBDCITTicketBuilder(SAMPLE_PR_DATA)
    customizations = builder.build_feature_customizations()
    assert '[NB]' in customizations
    assert 'SlatePtl.dsc' in customizations
    assert 'PcdToken.h' in customizations
    print(f"  ✅ Customizations:\n    {customizations.replace(chr(10), chr(10) + '    ')}")


def test_build_feature_customizations_none():
    """Test Feature Customizations - no changes"""
    print("Test 9: build_feature_customizations (no changes)")
    builder = CBDCITTicketBuilder(SAMPLE_PR_DATA_NO_CUSTOMIZATION)
    customizations = builder.build_feature_customizations()
    assert 'N/A' in customizations
    print(f"  ✅ No customizations: {customizations}")


def test_build_description():
    """Test Description"""
    print("Test 10: build_description")
    builder = CBDCITTicketBuilder(SAMPLE_PR_DATA)
    desc = builder.build_description()
    assert '[SlatePtl]' in desc
    assert 'PIMS-123456' in desc
    assert 'Systems Affected' in desc
    print(f"  ✅ Description length: {len(desc)} chars")


def test_build_complete_ticket():
    """Test complete ticket building"""
    print("Test 11: build_ticket (complete)")
    builder = CBDCITTicketBuilder(SAMPLE_PR_DATA)
    ticket = builder.build_ticket()

    assert ticket['summary'] != ''
    assert ticket['type'] == 'Change'
    assert ticket['priority'] == 'Medium'
    assert ticket['affected_systems']['repo'] == 'CDC_AgS_2025'
    assert ticket['list_of_deliverables'] != ''
    assert ticket['link_to_code_review'] == SAMPLE_PR_DATA['pr_url']
    assert ticket['description'] != ''

    print("  ✅ All fields present and valid")

    # Show preview
    preview = builder.format_ticket_preview(ticket)
    print(f"\n{preview}")


def test_extract_systems_affected():
    """Test Systems Affected extraction"""
    print("Test 12: extract_systems_affected")
    from github_pr_fetcher import GitHubPRFetcher

    # Don't initialize API, only test parsing functionality
    class MockFetcher:
        def extract_systems_affected(self, msg):
            return GitHubPRFetcher.extract_systems_affected(self, msg)

    fetcher = MockFetcher()

    # Test various formats (including multi-line)
    tests = [
        ("[Systems Affected]: all", ['all']),
        ("[Systems Affected]: PTL, LNL", ['PTL', 'LNL']),
        ("Systems Affected: ARL", ['ARL']),
        ("[System Affected]: PTL", ['PTL']),
        ("No systems info here", []),
        ("[Systems Affected]\nAll", ['all']),
        ("[Systems Affected]\nPTL, LNL", ['PTL', 'LNL']),
        ("some text\n[Systems Affected]\nAll\n\n[Cherry Pick Info]\nN/A", ['all']),
    ]

    for msg, expected in tests:
        result = fetcher.extract_systems_affected(msg)
        assert result == expected, f"Failed for '{msg}': got {result}, expected {expected}"
        print(f"  ✅ '{msg}' -> {result}")


def test_parse_pr_url():
    """Test PR URL parsing"""
    print("Test 13: parse_pr_url")
    from github_pr_fetcher import GitHubPRFetcher

    class MockFetcher:
        def parse_pr_url(self, url):
            return GitHubPRFetcher.parse_pr_url(self, url)

    fetcher = MockFetcher()

    url = 'https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/1521'
    result = fetcher.parse_pr_url(url)
    assert result['owner'] == 'CSG-Firmware-Engineering'
    assert result['repo'] == 'CDC_AgS_2025'
    assert result['pull_number'] == 1521
    print(f"  ✅ Owner: {result['owner']}")
    print(f"  ✅ Repo: {result['repo']}")
    print(f"  ✅ PR#: {result['pull_number']}")


# =============================================================================
# Main
# =============================================================================

def run_all_tests():
    """Run all tests"""
    print("=" * 70)
    print("CBDCIT Submission Skill - Test Suite")
    print("=" * 70)
    print()

    tests = [
        test_build_summary,
        test_build_type,
        test_build_priority,
        test_build_affected_systems_specific,
        test_build_affected_systems_all,
        test_build_affected_systems_override,
        test_build_list_of_deliverables,
        test_build_feature_customizations,
        test_build_feature_customizations_none,
        test_build_description,
        test_build_complete_ticket,
        test_extract_systems_affected,
        test_parse_pr_url,
    ]

    passed = 0
    failed = 0

    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"  ❌ FAILED: {e}")
        print()

    print("=" * 70)
    print(f"Test Results: {passed}/{passed + failed} passed")
    if failed > 0:
        print(f"  {failed} test(s) failed")
    else:
        print("  All tests passed!")
    print("=" * 70)

    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
