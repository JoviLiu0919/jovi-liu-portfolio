#!/usr/bin/env python3
"""
CBDCIT Submission Tool - Main execution script

Automatically fetches data from GitHub PR, assembles and creates Jira CBDCIT ticket.

Usage:
    # Preview mode (does not actually create ticket)
    python scripts/cbdcit_submit.py <PR_URL>
    
    # Actually create ticket
    python scripts/cbdcit_submit.py <PR_URL> --push
    
    # Specify priority
    python scripts/cbdcit_submit.py <PR_URL> --push --priority High
    
    # Manually specify chipsets
    python scripts/cbdcit_submit.py <PR_URL> --push --chipsets "PTL,LNL"
    
    # Discover CBDCIT fields
    python scripts/cbdcit_submit.py --discover-fields
    
    # Test connection
    python scripts/cbdcit_submit.py --test-connection
"""

import argparse
import json
import sys
from pathlib import Path

# Ensure scripts directory is in Python path
scripts_dir = Path(__file__).parent
if str(scripts_dir) not in sys.path:
    sys.path.insert(0, str(scripts_dir))

from github_pr_fetcher import GitHubPRFetcher
from cbdcit_ticket_builder import CBDCITTicketBuilder
from jira_cbdcit_submitter import JiraCBDCITSubmitter


def main():
    parser = argparse.ArgumentParser(
        description="CBDCIT Submission Tool - Automatically create Jira CBDCIT tickets"
    )
    parser.add_argument(
        "pr_url",
        nargs="?",
        help="GitHub PR URL (e.g., https://githubcsg.cec.delllabs.net/.../pull/1521)"
    )
    parser.add_argument(
        "--push",
        action="store_true",
        help="Actually create CBDCIT ticket (default is preview mode)"
    )
    parser.add_argument(
        "--priority",
        default=None,
        choices=["Highest", "High", "Medium", "Low", "Lowest"],
        help="Manually specify Priority (default Medium)"
    )
    parser.add_argument(
        "--chipsets",
        default=None,
        help="Manually specify chipsets, comma-separated (e.g., 'PTL,LNL')"
    )
    parser.add_argument(
        "--feature-customizations",
        default=None,
        help="Manually specify Feature Customizations content"
    )
    parser.add_argument(
        "--config",
        default=None,
        help="Specify config.toml path"
    )
    parser.add_argument(
        "--discover-fields",
        action="store_true",
        help="Discover available fields for CBDCIT project"
    )
    parser.add_argument(
        "--test-connection",
        action="store_true",
        help="Test GitHub and Jira connections"
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results in JSON format"
    )

    args = parser.parse_args()

    # Set config path
    config_path = None
    if args.config:
        config_path = Path(args.config)

    # Test connection mode
    if args.test_connection:
        test_connections(config_path)
        return

    # Discover fields mode
    if args.discover_fields:
        discover_fields(config_path)
        return

    # PR URL is required
    if not args.pr_url:
        parser.print_help()
        print("\nError: Please provide a GitHub PR URL")
        sys.exit(1)

    # Parse chipsets argument
    chipsets = None
    if args.chipsets:
        chipsets = [c.strip() for c in args.chipsets.split(',') if c.strip()]

    # Execute main workflow
    run_submission(
        pr_url=args.pr_url,
        push=args.push,
        priority=args.priority,
        chipsets=chipsets,
        feature_customizations=args.feature_customizations,
        config_path=config_path,
        output_json=args.json,
    )


def test_connections(config_path=None):
    """Test GitHub and Jira connections"""
    print("=" * 60)
    print("Connection Test")
    print("=" * 60)

    # Test GitHub
    print("\n[1/2] Testing GitHub connection...")
    try:
        fetcher = GitHubPRFetcher(config_path)
        # Try to get user info
        url = f"{fetcher.base_url}/user"
        response = fetcher._make_request("GET", url)
        print(f"  GitHub connection successful: {response.get('login', 'Unknown')}")
    except Exception as e:
        print(f"  GitHub connection failed: {e}")

    # Test Jira
    print("\n[2/2] Testing Jira connection...")
    try:
        submitter = JiraCBDCITSubmitter(config_path)
        submitter.test_connection()
    except Exception as e:
        print(f"  Jira connection failed: {e}")

    print("\n" + "=" * 60)


def discover_fields(config_path=None):
    """Discover CBDCIT project fields"""
    print("Discovering CBDCIT project fields...")
    submitter = JiraCBDCITSubmitter(config_path)
    fields = submitter.discover_cbdcit_fields()

    if not fields:
        print("Unable to retrieve field information")
        return

    print(f"\nFound {len(fields)} fields with values:")
    print("-" * 80)
    print(f"{'Field ID':<30} {'Field Name':<30} {'Type':<15}")
    print("-" * 80)

    for field_id, info in sorted(fields.items(), key=lambda x: x[1]['name']):
        print(f"{field_id:<30} {info['name']:<30} {info['value_type']:<15}")


def run_submission(pr_url, push=False, priority=None, chipsets=None,
                   feature_customizations=None, config_path=None, output_json=False):
    """
    Execute CBDCIT submission main workflow
    
    Steps:
    1. Fetch complete PR data from GitHub
    2. Assemble CBDCIT ticket content
    3. Preview or create ticket
    """
    print("=" * 70)
    print("CBDCIT Submission Tool")
    print("=" * 70)
    print(f"PR URL: {pr_url}")
    print(f"Mode: {'PUSH (actually create)' if push else 'PREVIEW (preview only)'}")
    print()

    # Step 1: Fetch PR data
    print("[Step 1/3] Fetching PR data from GitHub...")
    print("-" * 50)
    try:
        fetcher = GitHubPRFetcher(config_path)
        pr_data = fetcher.fetch_complete_pr_data(pr_url)
    except Exception as e:
        print(f"\nFailed to fetch PR data: {e}")
        sys.exit(1)

    # Step 2: Assemble CBDCIT ticket
    print(f"\n[Step 2/3] Assembling CBDCIT ticket content...")
    print("-" * 50)
    builder = CBDCITTicketBuilder(pr_data)
    ticket = builder.build_ticket(
        priority=priority,
        chipsets=chipsets,
        feature_customizations=feature_customizations,
    )

    # Show preview
    preview = builder.format_ticket_preview(ticket)
    print(preview)

    # JSON output
    if output_json:
        # Remove non-serializable data
        json_ticket = {k: v for k, v in ticket.items()}
        print("\n--- JSON Output ---")
        print(json.dumps(json_ticket, indent=2, ensure_ascii=False))

    # Step 3: Create or preview
    if push:
        print(f"\n[Step 3/3] Creating CBDCIT ticket...")
        print("-" * 50)
        try:
            submitter = JiraCBDCITSubmitter(config_path)
            result = submitter.create_ticket(ticket, dry_run=False)

            if result['success']:
                print(f"\n{'=' * 70}")
                print(f"CBDCIT ticket created successfully!")
                print(f"  Key: {result['key']}")
                print(f"  URL: {result['url']}")
                print(f"{'=' * 70}")

                # Post CBDCIT link as comment on the PR
                try:
                    parsed = fetcher.parse_pr_url(pr_url)
                    comment_body = f"CBDCIT submitted: [{result['key']}]({result['url']})"
                    fetcher.post_pr_comment(
                        parsed['owner'], parsed['repo'], parsed['pull_number'],
                        comment_body
                    )
                    print(f"\nPR comment posted: {comment_body}")
                except Exception as e:
                    print(f"\nWarning: Failed to post PR comment: {e}")

            else:
                print(f"\nCreation failed: {result.get('error', 'Unknown error')}")
                sys.exit(1)

        except Exception as e:
            print(f"\nFailed to create CBDCIT ticket: {e}")
            sys.exit(1)
    else:
        print(f"\n[Step 3/3] Preview mode - ticket will NOT be created")
        print("-" * 50)
        print("To actually create the ticket, add the --push flag:")
        print(f"  python scripts/cbdcit_submit.py \"{pr_url}\" --push")

        # Also do a dry-run to validate Jira field format
        try:
            submitter = JiraCBDCITSubmitter(config_path)
            submitter.create_ticket(ticket, dry_run=True)
        except Exception as e:
            print(f"\nJira preview failed (possible connection issue): {e}")


if __name__ == "__main__":
    main()
