#!/usr/bin/env python3
"""
Jira CBDCIT Submitter

Creates CBDCIT tickets using Jira REST API.
Integrates atlassian-python-api and direct REST API calls.
"""

import json
import sys
import io
from pathlib import Path
from typing import Optional

# Force UTF-8 encoding
if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except AttributeError:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

if sys.stderr.encoding and sys.stderr.encoding.lower() != 'utf-8':
    try:
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib
    except ImportError:
        import toml as tomllib

# Import central configuration loader
sys.path.append(str(Path(__file__).parent.parent.parent.parent))
from config_loader import load_skill_config_with_central_fallback

from atlassian import Jira


# CBDCIT Jira custom field IDs
CBDCIT_FIELDS = {
    'affected_systems': 'customfield_26305',   # Affected Systems - AgS (multi-select)
    'list_of_deliverables': 'customfield_26301', # List of Deliverables (text)
    'link_to_code_review': 'customfield_26303',  # Link to Code Review (text)
    'feature_customizations': 'customfield_26304', # Feature Customizations (text)
}

# Mapping: chipset keyword -> Jira option {id, value} for Affected Systems - AgS
# Organized by repo (CDC_AgS_2025 uses 26Qx options, CDC_AgS_2024 uses 24Qx/25Qx options)
AFFECTED_SYSTEMS_OPTIONS = {
    'CDC_AgS_2026': {
        # TODO: Update option IDs when 27Qx options are created in Jira.
        #       Currently using 26Qx options as temporary mapping.
        'PTL': {'id': '176713', 'value': '26Q1 - PTL Platform'},
        'TWL': {'id': '176714', 'value': '26Q1 - TWL Platform'},
        'WCL': {'id': '176715', 'value': '26Q1 - WCL Platform'},
        'LNL': {'id': '188712', 'value': '26Q2 - LNL Platform'},
        'ARL': {'id': '188713', 'value': '26Q2 - ARL Platform'},
        'NVL': {'id': '188714', 'value': '26Q4 - NVL Platform'},
    },
    'CDC_AgS_2025': {
        'PTL': {'id': '176713', 'value': '26Q1 - PTL Platform'},
        'TWL': {'id': '176714', 'value': '26Q1 - TWL Platform'},
        'WCL': {'id': '176715', 'value': '26Q1 - WCL Platform'},
        'LNL': {'id': '188712', 'value': '26Q2 - LNL Platform'},
        'ARL': {'id': '188713', 'value': '26Q2 - ARL Platform'},
        'NVL': {'id': '188714', 'value': '26Q4 - NVL Platform'},
    },
    'CDC_AgS_2024': {
        'LNL': {'id': '164316', 'value': '25Q1 - LNL Platform'},
        'ARL': {'id': '164317', 'value': '25Q1 - ARL Platform'},
        'RPL': {'id': '168315', 'value': '25Q1 - RPL Platform'},
        'MTL': {'id': '145313', 'value': '24Q1 - MTL Platform'},
        'ADL': {'id': '130437', 'value': '21Q4 - ADL'},
    },
}


class JiraCBDCITSubmitter:
    """Creates Jira CBDCIT tickets"""

    def __init__(self, config_path: Optional[Path] = None):
        if config_path is None:
            config_path = Path(__file__).parent.parent / "config.toml"

        # Use central configuration loader
        self.config = load_skill_config_with_central_fallback(config_path)

        jira_config = self.config.get('jira', {})
        self.jira_url = jira_config.get('url', '')
        self.jira_token = jira_config.get('token', '')
        self.project_key = jira_config.get('project_key', 'CBDCIT')
        self.issue_type = jira_config.get('issue_type', 'Change')

        self._client = None

    @property
    def client(self) -> Jira:
        """Lazy-load Jira client with Bearer token authentication"""
        if self._client is None:
            import requests as req
            session = req.Session()
            session.headers['Authorization'] = f'Bearer {self.jira_token}'
            self._client = Jira(
                url=self.jira_url,
                session=session,
            )
        return self._client

    def test_connection(self) -> bool:
        """Test Jira connection"""
        try:
            myself = self.client.myself()
            print(f"Jira connection successful: {myself.get('displayName', 'Unknown')}")
            return True
        except Exception as e:
            print(f"Jira connection failed: {e}", file=sys.stderr)
            return False

    def get_current_user(self) -> str:
        """Get current logged-in username (Reporter)"""
        try:
            myself = self.client.myself()
            return myself.get('name', '') or myself.get('key', '')
        except Exception:
            return ''

    def discover_cbdcit_fields(self) -> dict:
        """
        Discover available fields for CBDCIT project
        
        Used to find custom field IDs for CBDCIT project
        """
        try:
            # Search for an existing CBDCIT ticket to analyze fields
            results = self.client.jql(
                f"project = {self.project_key} ORDER BY created DESC",
                limit=1
            )
            issues = results.get('issues', [])
            if not issues:
                print("No existing CBDCIT ticket found for field analysis")
                return {}

            issue_key = issues[0]['key']
            issue = self.client.issue(issue_key)
            fields = issue.get('fields', {})

            # Get all field definitions
            all_fields = self.client.get_all_fields()
            id_to_name = {f['id']: f['name'] for f in all_fields}

            # List fields with values
            field_info = {}
            for field_id, value in fields.items():
                if value is not None:
                    field_name = id_to_name.get(field_id, field_id)
                    field_info[field_id] = {
                        'name': field_name,
                        'value_type': type(value).__name__,
                        'sample_value': str(value)[:100] if value else 'None'
                    }

            return field_info

        except Exception as e:
            print(f"Field discovery failed: {e}", file=sys.stderr)
            return {}

    def build_jira_fields(self, ticket_data: dict) -> dict:
        """
        Convert ticket data to Jira API field format
        
        Maps ticket data to actual CBDCIT Jira custom fields:
        - customfield_26305: Affected Systems - AgS (multi-select)
        - customfield_26301: List of Deliverables (text)
        - customfield_26303: Link to Code Review (text)
        - customfield_26304: Feature Customizations (text)
        - description: Only the commit message description
        
        Args:
            ticket_data: Data produced by CBDCITTicketBuilder.build_ticket()
            
        Returns:
            dict: Jira API formatted fields
        """
        fields = {
            "project": {"key": self.project_key},
            "summary": ticket_data['summary'],
            "issuetype": {"name": self.issue_type},
            "priority": {"name": ticket_data['priority']},
            "description": self._build_description(ticket_data),
        }

        # List of Deliverables
        deliverables = ticket_data.get('list_of_deliverables', '')
        if deliverables:
            fields[CBDCIT_FIELDS['list_of_deliverables']] = deliverables

        # Link to Code Review
        pr_url = ticket_data.get('link_to_code_review', '')
        if pr_url:
            fields[CBDCIT_FIELDS['link_to_code_review']] = pr_url

        # Feature Customizations
        customizations = ticket_data.get('feature_customizations', '')
        if customizations and 'N/A' not in customizations:
            fields[CBDCIT_FIELDS['feature_customizations']] = customizations

        # Affected Systems - AgS (multi-select with option IDs)
        affected_options = self._resolve_affected_systems(ticket_data)
        if affected_options:
            fields[CBDCIT_FIELDS['affected_systems']] = affected_options

        return fields

    def _resolve_affected_systems(self, ticket_data: dict) -> list:
        """
        Resolve chipset names to Jira Affected Systems option IDs
        
        Returns:
            list: [{"id": "176713"}, {"id": "176714"}, ...]
        """
        affected = ticket_data.get('affected_systems', {})
        repo = affected.get('repo', '')
        resolved_chipsets = affected.get('resolved_chipsets', [])

        if not resolved_chipsets:
            return []

        # Get option mapping for this repo
        repo_options = AFFECTED_SYSTEMS_OPTIONS.get(repo, {})
        if not repo_options:
            print(f"  Warning: No Affected Systems mapping for repo '{repo}'", file=sys.stderr)
            return []

        options = []
        for chipset in resolved_chipsets:
            opt = repo_options.get(chipset.upper())
            if opt:
                options.append({"id": opt['id']})
                print(f"  Affected System: {chipset} -> {opt['value']}")
            else:
                print(f"  Warning: No Jira option found for chipset '{chipset}' in {repo}", file=sys.stderr)

        return options

    def _build_description(self, ticket_data: dict) -> str:
        """
        Build Jira description field content
        
        Only contains the commit message description (Purpose/Impact summary).
        Other fields (Deliverables, Feature Customizations, etc.) go into their
        dedicated custom fields.
        """
        desc = ticket_data.get('description', '')
        if not desc:
            return ''

        # Extract just the description/purpose part from commit message
        # The full commit message includes title + detailed description
        lines = desc.strip().split('\n')
        
        # Skip the title line (first line) - it's already in Summary
        if len(lines) > 1:
            body = '\n'.join(lines[1:]).strip()
            # Remove [Systems Affected], [Cherry Pick Info] sections from description
            cleaned_lines = []
            skip_section = False
            for line in body.split('\n'):
                if line.strip().startswith('[Systems Affected]') or line.strip().startswith('[Cherry Pick Info]'):
                    skip_section = True
                    continue
                if skip_section and (line.strip() == '' or line.strip().startswith('[')):
                    if line.strip().startswith('['):
                        skip_section = True
                    else:
                        skip_section = False
                    continue
                if not skip_section:
                    cleaned_lines.append(line)
            return '\n'.join(cleaned_lines).strip()
        
        return desc.strip()

    def create_ticket(self, ticket_data: dict, dry_run: bool = True) -> dict:
        """
        Create CBDCIT ticket
        
        Args:
            ticket_data: Data produced by CBDCITTicketBuilder.build_ticket()
            dry_run: If True, only preview without actually creating
            
        Returns:
            dict: Creation result {'key': 'CBDCIT-XXXX', 'url': '...', 'success': True}
        """
        fields = self.build_jira_fields(ticket_data)

        if dry_run:
            print("\n" + "=" * 60)
            print("DRY RUN MODE - ticket will NOT be actually created")
            print("=" * 60)
            print(f"\nProject: {fields['project']['key']}")
            print(f"Issue Type: {fields['issuetype']['name']}")
            print(f"Summary: {fields['summary']}")
            print(f"Priority: {fields['priority']['name']}")
            # Affected Systems
            ags = fields.get(CBDCIT_FIELDS['affected_systems'], [])
            if ags:
                ags_ids = [a['id'] for a in ags]
                print(f"\nAffected Systems - AgS: {len(ags)} option(s) selected")
                for a in ags:
                    # Find display name
                    for repo_opts in AFFECTED_SYSTEMS_OPTIONS.values():
                        for chip, opt in repo_opts.items():
                            if opt['id'] == a['id']:
                                print(f"  - {opt['value']}")
            # List of Deliverables
            deliv = fields.get(CBDCIT_FIELDS['list_of_deliverables'], '')
            if deliv:
                print(f"\nList of Deliverables:\n  {deliv}")
            # Feature Customizations
            fc = fields.get(CBDCIT_FIELDS['feature_customizations'], '')
            if fc:
                print(f"\nFeature Customizations:\n  {fc[:300]}")
            # Link to Code Review
            lcr = fields.get(CBDCIT_FIELDS['link_to_code_review'], '')
            if lcr:
                print(f"\nLink to Code Review: {lcr}")
            # Description
            print(f"\nDescription: {fields['description'][:300]}")
            if len(fields['description']) > 300:
                print(f"... (total {len(fields['description'])} chars)")
            print("\n" + "=" * 60)

            return {
                'key': 'DRY-RUN',
                'url': f"{self.jira_url}/browse/DRY-RUN",
                'success': True,
                'dry_run': True,
                'fields': fields,
            }

        # Actually create ticket
        try:
            print("Creating CBDCIT ticket...")
            result = self.client.create_issue(fields=fields)
            issue_key = result.get('key', '')
            issue_url = f"{self.jira_url}/browse/{issue_key}"

            print(f"\nCBDCIT ticket created successfully!")
            print(f"  Key: {issue_key}")
            print(f"  URL: {issue_url}")

            return {
                'key': issue_key,
                'url': issue_url,
                'success': True,
                'dry_run': False,
            }

        except Exception as e:
            print(f"\nCBDCIT ticket creation failed: {e}", file=sys.stderr)
            return {
                'key': '',
                'url': '',
                'success': False,
                'error': str(e),
                'dry_run': False,
            }

    def update_ticket_fields(self, issue_key: str, ticket_data: dict) -> bool:
        """
        Update additional fields on a CBDCIT ticket
        
        Some custom fields may need to be updated separately after creation
        
        Args:
            issue_key: CBDCIT ticket key (e.g., CBDCIT-4508)
            ticket_data: Ticket data
            
        Returns:
            bool: Whether the update was successful
        """
        try:
            # Update based on actual CBDCIT custom field IDs
            # Use discover_cbdcit_fields() first to find correct field IDs
            print(f"Updating additional fields for {issue_key}...")

            # Example: Update Link to Code Review field (if it's a custom field)
            # self.client.update_issue_field(issue_key, {
            #     'customfield_XXXXX': ticket_data.get('link_to_code_review', '')
            # })

            return True

        except Exception as e:
            print(f"Field update failed: {e}", file=sys.stderr)
            return False


if __name__ == "__main__":
    submitter = JiraCBDCITSubmitter()

    if len(sys.argv) > 1 and sys.argv[1] == '--discover':
        print("Discovering CBDCIT project fields...")
        fields = submitter.discover_cbdcit_fields()
        for field_id, info in sorted(fields.items()):
            print(f"  {field_id}: {info['name']} ({info['value_type']})")
    elif len(sys.argv) > 1 and sys.argv[1] == '--test':
        submitter.test_connection()
    else:
        print("Usage:")
        print("  python jira_cbdcit_submitter.py --test      # Test Jira connection")
        print("  python jira_cbdcit_submitter.py --discover   # Discover CBDCIT fields")
