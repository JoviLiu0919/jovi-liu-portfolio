#!/usr/bin/env python3
"""
CBDCIT Ticket Builder

Builds all Jira CBDCIT ticket field contents from GitHub PR data.
Produces structured ticket data for Jira API ticket creation.
"""

import re
from typing import Optional


class CBDCITTicketBuilder:
    """Builds CBDCIT ticket content from PR data"""

    def __init__(self, pr_data: dict):
        self.pr_data = pr_data
        self.chipset_database = pr_data.get('chipset_database', {})

    def build_summary(self) -> str:
        """
        (1) Summary: Git commit message title from the PR
        """
        return self.pr_data.get('commit_title', '') or self.pr_data.get('title', '')

    def build_type(self) -> str:
        """
        Details - Type: Change
        """
        return "Change"

    def build_priority(self, override: Optional[str] = None) -> str:
        """
        Details - Priority: Medium (Default Medium, can be manually adjusted)
        """
        return override or "Medium"

    def build_affected_systems(self, override_chipsets: Optional[list] = None) -> dict:
        """
        Details - Affected Systems - AgS:
        
        a. First identify which GitHub repo the PR was merged into
        b. Scan git commit message for [Systems Affected]
           - If "all", select all supported chipsets for that repo
           - If specific chipsets, select the corresponding chipset fields
        
        Returns:
            dict: {
                'repo': 'CDC_AgS_2025',
                'systems_affected_raw': ['all'] or ['PTL', 'LNL'],
                'resolved_chipsets': ['PTL', 'LNL', 'ARL', ...],
                'all_supported_chipsets': ['PTL', 'LNL', 'ARL', 'MTL', 'RPL'],
            }
        """
        repo = self.pr_data.get('repo', '')
        systems_affected = self.pr_data.get('systems_affected', [])

        # Get all supported chipsets for this repo
        all_supported = self.chipset_database.get(repo, [])

        if override_chipsets:
            resolved = override_chipsets
        elif not systems_affected:
            # No Systems Affected info found, default to empty
            resolved = []
        elif 'all' in [s.lower() for s in systems_affected]:
            # all -> select all supported chipsets
            resolved = list(all_supported)
        else:
            # Specific chipsets -> match against supported list
            resolved = []
            for chipset in systems_affected:
                chipset_upper = chipset.upper()
                # Try exact match
                if chipset_upper in [c.upper() for c in all_supported]:
                    for c in all_supported:
                        if c.upper() == chipset_upper:
                            resolved.append(c)
                            break
                else:
                    # Try partial match
                    for c in all_supported:
                        if chipset_upper in c.upper() or c.upper() in chipset_upper:
                            resolved.append(c)
                            break
                    else:
                        # Cannot match, keep original value
                        resolved.append(chipset)

        return {
            'repo': repo,
            'systems_affected_raw': systems_affected,
            'resolved_chipsets': resolved,
            'all_supported_chipsets': all_supported,
        }

    def build_list_of_deliverables(self) -> str:
        """
        Details - List of Deliverables: List all merged SHAs (ToT + submodule)
        
        Example:
            AgS_2025 main: SHA-1: 4178578db7e3713e9f02ed1af4899daf5274a60e
            DellFeaturesPkg: SHA-1: f69f1965d50c01b8e95bc10b27e0d4a69b09b35b
        """
        lines = []

        # ToT SHA
        repo = self.pr_data.get('repo', '')
        base_branch = self.pr_data.get('base_branch', 'main')
        merge_sha = self.pr_data.get('merge_commit_sha', 'N/A')
        lines.append(f"{repo} {base_branch}: SHA-1: {merge_sha}")

        # Submodule SHAs
        for sub in self.pr_data.get('submodule_shas', []):
            sub_repo = sub.get('repo', 'Unknown')
            sub_sha = sub.get('sha', 'N/A')
            lines.append(f"{sub_repo}: SHA-1: {sub_sha}")

        return '\n'.join(lines)

    def build_feature_customizations(self, override: Optional[str] = None) -> str:
        """
        Details - Feature Customizations:
        
        If code changes touch files under DellPlatformPkgs/DT, NB, PW paths,
        describe what customization changes are needed based on the modifications.
        
        Returns:
            str: Feature customizations description
        """
        if override:
            return override

        customization_files = self.pr_data.get('customization_files', [])
        if not customization_files:
            return "N/A - No platform-specific customization files changed."

        # Group by platform path
        by_platform = {}
        for f in customization_files:
            platform = f.get('platform_path', 'Unknown')
            if platform not in by_platform:
                by_platform[platform] = []
            by_platform[platform].append(f)

        lines = []
        for platform, files in sorted(by_platform.items()):
            # Extract platform type (DT/NB/PW)
            platform_type = platform.split('/')[-1] if '/' in platform else platform
            lines.append(f"[{platform_type}] Platform Customization Changes:")
            for f in files:
                filename = f.get('filename', '')
                status = f.get('status', 'modified')
                additions = f.get('additions', 0)
                deletions = f.get('deletions', 0)
                # Simplify path display
                short_name = filename.replace(platform + '/', '')
                lines.append(f"  - {short_name} ({status}, +{additions}/-{deletions})")

        return '\n'.join(lines)

    def build_link_to_code_review(self) -> str:
        """
        Details - Link to Code Review: PR URL
        """
        return self.pr_data.get('pr_url', '')

    def build_description(self) -> str:
        """
        (3) Description: Full Git commit message from the PR
        """
        return self.pr_data.get('commit_message', '')

    def build_ticket(self, priority: Optional[str] = None,
                     chipsets: Optional[list] = None,
                     feature_customizations: Optional[str] = None) -> dict:
        """
        Assemble complete CBDCIT ticket data
        
        Args:
            priority: Manually specify priority (default Medium)
            chipsets: Manually specify chipset list (overrides auto-detection)
            feature_customizations: Manually specify feature customizations content
            
        Returns:
            dict: Complete CBDCIT ticket data
        """
        affected_systems = self.build_affected_systems(chipsets)

        ticket = {
            'summary': self.build_summary(),
            'type': self.build_type(),
            'priority': self.build_priority(priority),
            'affected_systems': affected_systems,
            'list_of_deliverables': self.build_list_of_deliverables(),
            'feature_customizations': self.build_feature_customizations(feature_customizations),
            'link_to_code_review': self.build_link_to_code_review(),
            'description': self.build_description(),
        }

        return ticket

    def format_ticket_preview(self, ticket: dict) -> str:
        """
        Format ticket preview for user confirmation
        """
        lines = []
        lines.append("=" * 70)
        lines.append("CBDCIT Ticket Preview")
        lines.append("=" * 70)
        lines.append("")

        # Summary
        lines.append(f"[Summary]")
        lines.append(f"  {ticket['summary']}")
        lines.append("")

        # Details
        lines.append(f"[Details]")
        lines.append(f"  Type: {ticket['type']}")
        lines.append(f"  Priority: {ticket['priority']}")
        lines.append("")

        # Affected Systems
        affected = ticket['affected_systems']
        lines.append(f"  Affected Systems - AgS:")
        lines.append(f"    Repo: {affected['repo']}")
        lines.append(f"    Systems Affected (raw): {affected['systems_affected_raw']}")
        lines.append(f"    Resolved Chipsets: {affected['resolved_chipsets']}")
        if affected['all_supported_chipsets']:
            lines.append(f"    All Supported Chipsets: {affected['all_supported_chipsets']}")
        lines.append("")

        # List of Deliverables
        lines.append(f"  List of Deliverables:")
        for line in ticket['list_of_deliverables'].split('\n'):
            lines.append(f"    {line}")
        lines.append("")

        # Feature Customizations
        lines.append(f"  Feature Customizations:")
        for line in ticket['feature_customizations'].split('\n'):
            lines.append(f"    {line}")
        lines.append("")

        # Link to Code Review
        lines.append(f"  Link to Code Review:")
        lines.append(f"    {ticket['link_to_code_review']}")
        lines.append("")

        # Description
        lines.append(f"[Description]")
        desc = ticket['description']
        if len(desc) > 500:
            lines.append(f"  {desc[:500]}...")
            lines.append(f"  (... total {len(desc)} chars)")
        else:
            for line in desc.split('\n'):
                lines.append(f"  {line}")
        lines.append("")

        lines.append("=" * 70)

        return '\n'.join(lines)
