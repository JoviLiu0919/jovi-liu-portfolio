---
name: cbdcit-submission
description: Automatically create Jira CBDCIT tickets by fetching data from GitHub PRs and populating all required fields. Use when a PR is merged to ToT and you need to create CBDCIT submission tickets.
---

# CBDCIT Submission Skill

Used when a user has confirmed a PR is merged into ToT (Top of Tree) and needs to create a Jira CBDCIT ticket.
Automatically fetches detailed data from the GitHub PR, scans git commit message, assembles and creates the CBDCIT ticket.

## Compliance with skill_guides

- **Core Integration Architecture**: Integrates github_integration and jira_integration skills
- **Zero-Temp-File Policy**: All processing done in memory
- **Cross-Session Consistency**: Centralized configuration via config.toml

## Interaction Rules (Agent Instructions)

### Trigger Conditions
Triggered when user provides a PR URL and requests CBDCIT ticket creation. Common trigger phrases:
- "Create CBDCIT ticket" + PR URL
- "CBDCIT submission" + PR URL
- "Submit CBDCIT" + PR URL

### Execution Flow

**CRITICAL**: Must strictly follow this workflow:

1. **Parse PR URL** → Identify repo and PR number
2. **Fetch PR data** → Use GitHub API to get complete data
3. **Scan commit message** → Extract Summary, Systems Affected, Description
4. **Get SHAs** → ToT merge commit SHA + submodule SHAs
5. **Analyze Feature Customizations** → Scan DellPlatformPkgs path changes
6. **Assemble ticket preview** → Display full ticket content for user confirmation
7. **Wait for user confirmation** → **MUST** get user confirmation before creating
8. **Create CBDCIT ticket** → Call Jira API to create
9. **Post PR comment** → Automatically comment on the PR with CBDCIT ticket URL

### Confirmation (CRITICAL)
- **MUST** display full preview and get user confirmation before creating ticket
- User can adjust Priority, Chipsets, Feature Customizations before confirming
- Only execute creation after user explicitly says "confirm" or "create"

### Read-Only Operations
The following operations do not require confirmation:
- Fetching PR data
- Previewing ticket content
- Testing connections
- Discovering fields

## Usage

### Basic Usage
```
User: CBDCIT submission https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/1521
```

### Command Format
```
(CBDCIT submission) + (PR URL)
```

### CLI Tool Usage

```powershell
# Preview mode (does not actually create)
python scripts/cbdcit_submit.py <PR_URL>

# Actually create ticket
python scripts/cbdcit_submit.py <PR_URL> --push

# Specify Priority
python scripts/cbdcit_submit.py <PR_URL> --push --priority High

# Manually specify chipsets
python scripts/cbdcit_submit.py <PR_URL> --push --chipsets "PTL,LNL"

# Test connections
python scripts/cbdcit_submit.py --test-connection

# Discover CBDCIT fields
python scripts/cbdcit_submit.py --discover-fields
```

## CBDCIT Ticket Field Descriptions

### (1) Summary
- **Source**: Git commit message title (first line)
- **Example**: `[SlatePtl] Fix PIMS-123456: Update PCD token for PTL platform`

### (2) Details

#### Type
- **Default**: Change
- **Description**: CBDCIT ticket type

#### Priority
- **Default**: Medium
- **Options**: Highest, High, Medium, Low, Lowest
- **Description**: Can be manually adjusted

#### Affected Systems - AgS
- **Logic**:
  1. Identify which GitHub repo the PR was merged into (e.g., CDC_AgS_2025)
  2. Scan commit message for `[Systems Affected]`
  3. If `all` → select all supported chipsets for that repo
  4. If specific chipsets → select corresponding items
- **Can be manually adjusted**
- **Chipset Database**: Defined in config.toml under `[chipset_database]`

#### List of Deliverables
- **Content**: Lists all merged SHAs (ToT + submodule)
- **Format**:
  ```
  AgS_2025 main: SHA-1: 4178578db7e3713e9f02ed1af4899daf5274a60e
  DellFeaturesPkg: SHA-1: f69f1965d50c01b8e95bc10b27e0d4a69b09b35b
  ```
- **ToT SHA**: Obtained from PR merge commit
- **Submodule SHA**: Tracked from Submodule Link Workflow links in PR body

#### Feature Customizations
- **Condition**: Required when code changes touch the following paths
  - `DellPkgs/DellPlatformPkgs/DT`
  - `DellPkgs/DellPlatformPkgs/NB`
  - `DellPkgs/DellPlatformPkgs/PW`
- **Content**: Describes what customization changes are needed based on path modifications
- **Can be manually adjusted**

#### Link to Code Review
- **Content**: PR URL

### (3) Description
- **Source**: Full Git commit message

### (4) Reporter
- **Source**: Jira access token account owner (automatic)

## Configuration

### config.toml

```toml
[github]
base_url = "https://githubcsg.cec.delllabs.net/api/v3"
owner = "CSG-Firmware-Engineering"
token = "YOUR_GITHUB_TOKEN"

[jira]
url = "https://jira.cpg.dell.com"
token = "YOUR_JIRA_TOKEN"
project_key = "CBDCIT"
issue_type = "Change"

[chipset_database]
CDC_AgS_2025 = ["PTL", "LNL", "ARL", "MTL", "RPL"]
CDC_AgS_2024 = ["LNL", "ARL", "RPL", "MTL", "ADL"]

[platform_paths]
customization_paths = [
    "DellPkgs/DellPlatformPkgs/DT",
    "DellPkgs/DellPlatformPkgs/NB",
    "DellPkgs/DellPlatformPkgs/PW",
]
```

### Token Configuration
- **GitHub Token**: Obtain from GitHub Enterprise Settings > Developer settings > Personal access tokens
- **Jira Token**: Obtain from Jira Profile > Personal Access Tokens
- Or directly use existing tokens from `github_integration` and `jira_integration` skills

## Submodule Processing Logic

1. Scan PR body for **Submodule Link Workflow** section
2. Extract submodule PR links (e.g., `CBF_DellFeaturesPkg/pull/278`)
3. Automatically follow submodule PR to get merge commit SHA
4. Add submodule SHA to List of Deliverables

## References

- **PR Example**: https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/1521
- **CBDCIT Example**: https://jira.cpg.dell.com/browse/CBDCIT-4508
- **GitHub Integration Skill**: `.windsurf/skills/github-integration/`
- **Jira Integration Skill**: `.windsurf/skills/jira-integration/`

## Testing

```powershell
# Run test suite (no API connection required)
python scripts/test_cbdcit_submission.py
```
