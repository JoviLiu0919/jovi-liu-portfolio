#!/usr/bin/env python3
"""
Dell GitHub API Integration Module
Supports Dell GitHub Enterprise Server
"""

import requests
import json
from typing import Dict, Any, List, Optional
from urllib.parse import urljoin
from pathlib import Path
import time

# Import central configuration loader
import sys
sys.path.append(str(Path(__file__).parent.parent.parent.parent))
from config_loader import load_skill_config_with_central_fallback

class DellGitHubAPI:
    """
    Dell GitHub Enterprise Server API client
    """
    
    def __init__(self, config_path: Optional[Path] = None):
        """Initialize GitHub API client"""
        if config_path is None:
            config_path = Path(__file__).parent.parent / "config.toml"
        
        # Use central configuration loader
        self.config = load_skill_config_with_central_fallback(config_path)
        
        github_config = self.config.get('github', {})
        self.base_url = github_config.get('url', 'https://githubcsg.cec.delllabs.net')
        self.token = github_config.get('token', '')
        self.timeout = github_config.get('timeout', 30)
        self.session = requests.Session()
        
        # Set up authentication
        if self.token:
            self.session.headers.update({
                'Authorization': f'token {self.token}',
                'Accept': 'application/vnd.github.v3+json',
                'User-Agent': 'Dell-AGS-Standards-Checker/1.0'
            })
        
        # Rate limiting
        self.rate_limit_remaining = 5000
        self.rate_limit_reset = time.time() + 3600
    
    def _handle_rate_limit(self, response: requests.Response) -> None:
        """Handle GitHub API rate limiting"""
        if 'X-RateLimit-Remaining' in response.headers:
            self.rate_limit_remaining = int(response.headers['X-RateLimit-Remaining'])
        if 'X-RateLimit-Reset' in response.headers:
            self.rate_limit_reset = int(response.headers['X-RateLimit-Reset'])
        
        if self.rate_limit_remaining < 10:
            sleep_time = max(0, self.rate_limit_reset - time.time())
            if sleep_time > 0:
                print(f"Rate limit approaching. Sleeping for {sleep_time:.0f} seconds...")
                time.sleep(sleep_time)
    
    def _make_request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        """Make authenticated request to GitHub API"""
        url = urljoin(self.base_url, endpoint)
        
        try:
            response = self.session.request(method, url, timeout=self.timeout, **kwargs)
            self._handle_rate_limit(response)
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            raise Exception(f"GitHub API request failed: {str(e)}")
    
    def get_pull_request(self, owner: str, repo: str, pr_number: int) -> Dict[str, Any]:
        """Get pull request information"""
        endpoint = f"/api/v3/repos/{owner}/{repo}/pulls/{pr_number}"
        response = self._make_request('GET', endpoint)
        return response.json()
    
    def get_pull_request_files(self, owner: str, repo: str, pr_number: int) -> List[Dict[str, Any]]:
        """Get list of files changed in pull request"""
        endpoint = f"/api/v3/repos/{owner}/{repo}/pulls/{pr_number}/files"
        response = self._make_request('GET', endpoint)
        return response.json()
    
    def get_pull_request_diff(self, owner: str, repo: str, pr_number: int) -> str:
        """Get pull request diff as text"""
        endpoint = f"/api/v3/repos/{owner}/{repo}/pulls/{pr_number}"
        
        # Temporarily set Accept header for diff format
        original_headers = self.session.headers.copy()
        self.session.headers.update({
            'Accept': 'application/vnd.github.v3.diff'
        })
        
        try:
            response = self._make_request('GET', endpoint)
            return response.text
        finally:
            # Restore original headers
            self.session.headers = original_headers
    
    def get_file_content(self, owner: str, repo: str, path: str, ref: str = 'main') -> str:
        """Get file content"""
        endpoint = f"/api/v3/repos/{owner}/{repo}/contents/{path}"
        params = {'ref': ref}
        response = self._make_request('GET', endpoint, params=params)
        data = response.json()
        
        if data.get('encoding') == 'base64':
            return base64.b64decode(data['content']).decode('utf-8')
        return data.get('content', '')
    
    def create_pull_request_comment(self, owner: str, repo: str, pr_number: int, 
                                  body: str) -> Dict[str, Any]:
        """Create a comment on pull request"""
        endpoint = f"/api/v3/repos/{owner}/{repo}/pulls/{pr_number}/comments"
        data = {'body': body}
        response = self._make_request('POST', endpoint, json=data)
        return response.json()
    
    def create_pull_request_review(self, owner: str, repo: str, pr_number: int,
                                 body: str, event: str = 'REQUEST_CHANGES',
                                 comments: List[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Create a pull request review"""
        endpoint = f"/api/v3/repos/{owner}/{repo}/pulls/{pr_number}/reviews"
        data = {
            'body': body,
            'event': event
        }
        if comments:
            data['comments'] = comments
        
        response = self._make_request('POST', endpoint, json=data)
        return response.json()
    
    def create_issue_comment(self, owner: str, repo: str, issue_number: int,
                            body: str) -> Dict[str, Any]:
        """Create an issue comment (works for PRs too)"""
        endpoint = f"/api/v3/repos/{owner}/{repo}/issues/{issue_number}/comments"
        data = {'body': body}
        
        response = self._make_request('POST', endpoint, json=data)
        return response.json()
    
    def update_pull_request_review_state(self, owner: str, repo: str, pr_number: int,
                                       review_id: int, event: str) -> Dict[str, Any]:
        """Update pull request review state"""
        endpoint = f"/api/v3/repos/{owner}/{repo}/pulls/{pr_number}/reviews/{review_id}"
        data = {'event': event}
        response = self._make_request('PUT', endpoint, json=data)
        return response.json()
    
    def get_repository_info(self, owner: str, repo: str) -> Dict[str, Any]:
        """Get repository information"""
        endpoint = f"/api/v3/repos/{owner}/{repo}"
        response = self._make_request('GET', endpoint)
        return response.json()
    
    def get_commit_info(self, owner: str, repo: str, sha: str) -> Dict[str, Any]:
        """Get commit information"""
        endpoint = f"/api/v3/repos/{owner}/{repo}/commits/{sha}"
        response = self._make_request('GET', endpoint)
        return response.json()
    
    def test_authentication(self) -> bool:
        """Test if the current token is valid"""
        try:
            response = self._make_request('GET', '/api/v3/user')
            return response.status_code == 200
        except Exception:
            return False

def load_github_config(config_path: str = None) -> Dict[str, Any]:
    """Load GitHub configuration from TOML file or environment"""
    config = {
        'github': {
            'url': 'https://githubcsg.cec.delllabs.net',
            'token': '',
            'timeout': 30
        }
    }
    
    # Default config path
    if not config_path:
        config_path = Path(__file__).parent.parent / "config.toml"
    
    # Try to load from TOML file
    if config_path and config_path.exists():
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                content = f.read()
                # Simple TOML parsing for our specific structure
                if 'token' in content:
                    for line in content.split('\n'):
                        if 'token' in line and '=' in line and not line.strip().startswith('#'):
                            token_value = line.split('=')[1].strip().strip('"').strip("'")
                            if token_value:
                                config['github']['token'] = token_value
                                break
                
                if 'url' in content:
                    for line in content.split('\n'):
                        if 'url' in line and '=' in line and not line.strip().startswith('#'):
                            url_value = line.split('=')[1].strip().strip('"').strip("'")
                            if url_value:
                                config['github']['url'] = url_value
                                break
                
                if 'timeout' in content:
                    for line in content.split('\n'):
                        if 'timeout' in line and '=' in line and not line.strip().startswith('#'):
                            timeout_value = line.split('=')[1].strip()
                            try:
                                config['github']['timeout'] = int(timeout_value)
                            except ValueError:
                                pass
                            break
        except Exception as e:
            print(f"Warning: Could not parse config file: {e}")
    
    # Override with environment variables
    import os
    if os.getenv('DELL_GITHUB_TOKEN'):
        config['github']['token'] = os.getenv('DELL_GITHUB_TOKEN')
    if os.getenv('DELL_GITHUB_URL'):
        config['github']['url'] = os.getenv('DELL_GITHUB_URL')
    
    return config

def main():
    """Test GitHub API integration"""
    print("=== Dell GitHub API Integration Test ===")
    
    try:
        github_api = DellGitHubAPI(config_path)
        
        print(f"GitHub Enterprise URL: {github_api.base_url}")
        print(f"Timeout: {github_api.timeout}s")
        
        # Test authentication
        if github_api.test_authentication():
            print("Authentication successful")
        else:
            print("Authentication failed")
            print("Please check your token configuration")
            return
        
        # Test API calls
        try:
            print("\nTesting API calls...")
            
            # Get user info
            user_info = github_api._make_request('GET', '/api/v3/user').json()
            print(f"User: {user_info.get('login', 'Unknown')}")
            
            # Test repository access
            repo_info = github_api.get_repository_info('CSG-Firmware-Engineering', 'CDC_AgS_2025')
            print(f"Repository: {repo_info.get('name', 'Unknown')}")
            print(f"   Description: {repo_info.get('description', 'No description')}")
            
        except Exception as e:
            print(f"API test failed: {str(e)}")
    
    except Exception as e:
        print(f"Failed to initialize GitHub API: {str(e)}")

if __name__ == "__main__":
    main()
