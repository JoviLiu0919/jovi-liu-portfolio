#!/usr/bin/env python3
"""
Enhanced Dell UEFI BIOS Coding Standards v3.3 Implementation
Complete implementation based on Dell AgS standards
"""

import re
import os
from typing import List, Dict, Any, Set

class DellUEFIStandards:
    """
    Complete Dell UEFI BIOS Coding Standards v3.3 implementation
    """
    
    def __init__(self):
        """Initialize with Dell UEFI BIOS Coding Standards v3.3 rules"""
        
        # Dell UEFI BIOS Coding Standards v3.3 - Naming Conventions
        self.naming_standards = {
            'functions': {
                'pattern': r'^[A-Z][a-zA-Z0-9]*$',
                'description': 'Pascal case - First letter capital, no underscores',
                'examples': {
                    'valid': ['InitializeHardware', 'GetSystemInfo', 'ValidateConfiguration'],
                    'invalid': ['initialize_hardware', '_getSystemInfo', 'initializeHardware_', 'szBuffer']
                },
                'severity': 'medium'
            },
            'global_variables': {
                'pattern': r'^g[A-Z][a-zA-Z0-9]*$',
                'description': 'Global variables: lowercase g + Pascal case',
                'examples': {
                    'valid': ['gSystemConfiguration', 'gHardwareInfo', 'gPlatformData'],
                    'invalid': ['SystemConfiguration', 'g_system_config', 'gSystemInfo_']
                },
                'severity': 'medium'
            },
            'module_variables': {
                'pattern': r'^m[A-Z][a-zA-Z0-9]*$',
                'description': 'Module variables: lowercase m + Pascal case',
                'examples': {
                    'valid': ['mModuleInfo', 'mLocalData', 'mContext'],
                    'invalid': ['moduleInfo', 'm_module_info', 'mLocalData_']
                },
                'severity': 'medium'
            },
            'macros': {
                'pattern': r'^[A-Z][A-Z0-9_]*$',
                'description': 'Macros: UPPER_CASE with underscores',
                'examples': {
                    'valid': ['MAX_BUFFER_SIZE', 'PLATFORM_ID_LENGTH', 'DEBUG_PRINT_ENABLED'],
                    'invalid': ['max_buffer_size', 'MaxBufferSize', 'MAX_BUFFER-SIZE']
                },
                'severity': 'medium'
            },
            'constants': {
                'pattern': r'^[A-Z][A-Z0-9_]*$',
                'description': 'Constants: UPPER_CASE with underscores',
                'examples': {
                    'valid': ['DEFAULT_TIMEOUT', 'MAX_RETRY_COUNT', 'SUCCESS_STATUS'],
                    'invalid': ['defaultTimeout', 'Default_Timeout', 'DEFAULT-TIMEOUT']
                },
                'severity': 'medium'
            },
            'files': {
                'pattern': r'^[A-Z][a-zA-Z0-9]*\.(c|h|inf|dec|asl)$',
                'description': 'Files: Pascal case + valid extensions',
                'examples': {
                    'valid': ['HardwareManager.c', 'SystemInfo.h', 'Platform.inf'],
                    'invalid': ['hardware_manager.c', 'Hardware-Manager.c', 'hardware manager.c']
                },
                'severity': 'high'
            }
        }
        
        # Dell UEFI BIOS Coding Standards v3.3 - Code Style
        self.style_standards = {
            'goto_usage': {
                'rule': 'goto should be used sparingly and only for error handling',
                'pattern': r'\bgoto\s+',
                'allowed_contexts': ['Error', 'Exit', 'Cleanup', 'Fail'],
                'severity': 'low',
                'description': 'Use goto only for error exit paths'
            },
            'commented_code': {
                'rule': 'Commented out code should be deleted',
                'patterns': [
                    r'//\s*(if|for|while|return|switch)\s*\(',
                    r'//\s*\w+\s*\(',
                    r'//\s*\{.*\}'
                ],
                'severity': 'low',
                'description': 'Remove commented code instead of keeping it'
            },
            'line_length': {
                'rule': 'Lines should not exceed 120 characters',
                'max_length': 120,
                'severity': 'low',
                'description': 'Keep lines under 120 characters for readability'
            },
            'indentation': {
                'rule': 'Use 2-space indentation',
                'pattern': r'^(?!\s{0,1}[^ ]).*',
                'severity': 'low',
                'description': 'Use 2 spaces for indentation'
            }
        }
        
        # Dell UEFI BIOS Coding Standards v3.3 - UEFI Specific
        self.uefi_standards = {
            'return_types': {
                'valid_types': [
                    'EFI_STATUS', 'BOOLEAN', 'UINTN', 'UINT8', 'UINT16', 'UINT32', 'UINT64',
                    'INT8', 'INT16', 'INT32', 'INT64', 'CHAR8', 'CHAR16', 'VOID*'
                ],
                'description': 'Use standard UEFI data types',
                'severity': 'medium'
            },
            'status_codes': {
                'pattern': r'EFI_\w+',
                'valid_codes': [
                    'EFI_SUCCESS', 'EFI_LOAD_ERROR', 'EFI_INVALID_PARAMETER',
                    'EFI_UNSUPPORTED', 'EFI_BAD_BUFFER_SIZE', 'EFI_NOT_READY'
                ],
                'description': 'Use standard EFI status codes',
                'severity': 'medium'
            },
            'function_parameters': {
                'directions': ['IN', 'OUT', 'OPTIONAL'],
                'pattern': r'\b(IN|OUT|OPTIONAL)\b',
                'description': 'Use IN/OUT/OPTIONAL for parameter directions',
                'severity': 'medium'
            }
        }
        
        # Dell UEFI BIOS Coding Standards v3.3 - Documentation
        self.documentation_standards = {
            'function_comments': {
                'pattern': r'^/\*\*[\s\S]*?\*/',
                'required_tags': ['@param', '@retval', '@brief'],
                'description': 'Use Doxygen-style comments for functions',
                'severity': 'low'
            },
            'file_headers': {
                'required_info': ['file name', 'description', 'copyright'],
                'description': 'File headers should contain basic information',
                'severity': 'low'
            }
        }
        
        # Forbidden patterns (Dell-specific)
        self.forbidden_patterns = {
            'hungarian_notation': {
                'pattern': r'^[a-z][a-z]*[A-Z]',
                'description': 'Hungarian notation not allowed',
                'examples': ['szBuffer', 'hWnd', 'dwValue', 'nCount'],
                'severity': 'medium'
            },
            'leading_underscore': {
                'pattern': r'^_',
                'description': 'Leading underscores not allowed',
                'severity': 'medium'
            },
            'trailing_underscore': {
                'pattern': r'_$',
                'description': 'Trailing underscores not allowed',
                'severity': 'medium'
            },
            'camel_case': {
                'pattern': r'^[a-z][a-zA-Z0-9]*[A-Z]',
                'description': 'Camel case not allowed (use Pascal case)',
                'severity': 'medium'
            }
        }
        
        # Allowed exceptions
        self.allowed_exceptions = {
            'local_variables': ['i', 'j', 'k', 'n', 'm', 'x', 'y', 'z', 'temp', 'cnt'],
            'standard_functions': ['main', 'printf', 'scanf', 'memcpy', 'memset'],
            'legacy_macros': ['TRUE', 'FALSE', 'NULL', 'MAX_PATH']
        }

    def check_function_naming(self, line: str, line_num: int) -> List[Dict[str, Any]]:
        """Check function naming according to Dell standards"""
        findings = []
        
        # Skip comments and preprocessor directives
        if line.strip().startswith(('//', '#', '/*', '*')):
            return findings
            
        # Find function definitions
        func_pattern = r'([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)\s*\{?'
        func_match = re.search(func_pattern, line)
        
        if func_match:
            func_name = func_match.group(1)
            
            # Skip if it's a known exception
            if func_name in self.allowed_exceptions['standard_functions']:
                return findings
            
            # Check Pascal case
            standard = self.naming_standards['functions']
            if not re.match(standard['pattern'], func_name):
                findings.append({
                    'type': 'naming_violation',
                    'severity': standard['severity'],
                    'issue': f"Function '{func_name}' must use Pascal case",
                    'line': line_num + 1,
                    'code': line.strip(),
                    'recommendation': f"Rename to '{self._to_pascal_case(func_name)}'",
                    'standard': f'Dell UEFI BIOS Coding Standards v3.3 - {standard["description"]}',
                    'examples': standard['examples']
                })
            
            # Check forbidden patterns
            for forbidden_name, forbidden_info in self.forbidden_patterns.items():
                if re.match(forbidden_info['pattern'], func_name):
                    findings.append({
                        'type': 'naming_violation',
                        'severity': forbidden_info['severity'],
                        'issue': f"Function '{func_name}' uses {forbidden_info['description']}",
                        'line': line_num + 1,
                        'code': line.strip(),
                        'recommendation': f"Rename to '{self._to_pascal_case(func_name)}'",
                        'standard': f'Dell UEFI BIOS Coding Standards v3.3 - {forbidden_info["description"]}'
                    })
        
        return findings

    def check_variable_naming(self, line: str, line_num: int) -> List[Dict[str, Any]]:
        """Check variable naming according to Dell standards"""
        findings = []
        
        # Skip comments and preprocessor directives
        if line.strip().startswith(('//', '#', '/*', '*')):
            return findings
        
        # Find variable declarations
        var_patterns = [
            r'(extern\s+)?(UINT|UINT8|UINT16|UINT32|UINT64|BOOLEAN|CHAR|VOID|EFI_\w+)\s+(\*?\s*)(\w+)',
            r'(extern\s+)?\w+\s+\*?\s*(\w+)',
        ]
        
        for pattern in var_patterns:
            matches = re.finditer(pattern, line)
            for match in matches:
                if len(match.groups()) >= 4:
                    var_name = match.groups()[-1]
                    
                    # Skip if it's a function definition
                    if '(' in line[match.start():]:
                        continue
                    
                    # Skip allowed exceptions
                    if var_name in self.allowed_exceptions['local_variables']:
                        continue
                    
                    # Check global variables
                    if 'extern' in line:
                        standard = self.naming_standards['global_variables']
                        if not re.match(standard['pattern'], var_name):
                            findings.append({
                                'type': 'naming_violation',
                                'severity': standard['severity'],
                                'issue': f"Global variable '{var_name}' must follow pattern: {standard['description']}",
                                'line': line_num + 1,
                                'code': line.strip(),
                                'recommendation': f"Rename to 'g{self._to_pascal_case(var_name)}'",
                                'standard': f'Dell UEFI BIOS Coding Standards v3.3 - {standard["description"]}',
                                'examples': standard['examples']
                            })
                    
                    # Check module variables (static)
                    elif 'static' in line.lower():
                        standard = self.naming_standards['module_variables']
                        if not re.match(standard['pattern'], var_name):
                            findings.append({
                                'type': 'naming_violation',
                                'severity': standard['severity'],
                                'issue': f"Module variable '{var_name}' must follow pattern: {standard['description']}",
                                'line': line_num + 1,
                                'code': line.strip(),
                                'recommendation': f"Rename to 'm{self._to_pascal_case(var_name)}'",
                                'standard': f'Dell UEFI BIOS Coding Standards v3.3 - {standard["description"]}',
                                'examples': standard['examples']
                            })
                    
                    # Check other variables for Pascal case
                    else:
                        if not re.match(self.naming_standards['functions']['pattern'], var_name):
                            findings.append({
                                'type': 'naming_violation',
                                'severity': 'medium',
                                'issue': f"Variable '{var_name}' should use Pascal case",
                                'line': line_num + 1,
                                'code': line.strip(),
                                'recommendation': f"Rename to '{self._to_pascal_case(var_name)}'",
                                'standard': 'Dell UEFI BIOS Coding Standards v3.3 - Variable naming'
                            })
        
        return findings

    def check_macro_naming(self, line: str, line_num: int) -> List[Dict[str, Any]]:
        """Check macro naming according to Dell standards"""
        findings = []
        
        if not line.strip().startswith('#define'):
            return findings
        
        # Extract macro name
        macro_match = re.search(r'#define\s+(\w+)', line)
        if macro_match:
            macro_name = macro_match.group(1)
            
            # Skip allowed exceptions
            if macro_name in self.allowed_exceptions['legacy_macros']:
                return findings
            
            # Check UPPER_CASE pattern
            standard = self.naming_standards['macros']
            if not re.match(standard['pattern'], macro_name):
                findings.append({
                    'type': 'naming_violation',
                    'severity': standard['severity'],
                    'issue': f"Macro '{macro_name}' must follow pattern: {standard['description']}",
                    'line': line_num + 1,
                    'code': line.strip(),
                    'recommendation': f"Rename to '{macro_name.upper()}'",
                    'standard': f'Dell UEFI BIOS Coding Standards v3.3 - {standard["description"]}',
                    'examples': standard['examples']
                })
        
        return findings

    def check_uefi_types(self, line: str, line_num: int) -> List[Dict[str, Any]]:
        """Check UEFI-specific types and patterns"""
        findings = []
        
        # Check for non-standard types (basic check)
        non_standard_pattern = r'\b(int|long|short|char|float|double)\s+'
        if re.search(non_standard_pattern, line) and not line.strip().startswith('//'):
            findings.append({
                'type': 'uefi_violation',
                'severity': 'medium',
                'issue': 'Use standard UEFI types instead of C standard types',
                'line': line_num + 1,
                'code': line.strip(),
                'recommendation': 'Replace with UEFI types (UINT32, INT32, CHAR8, etc.)',
                'standard': 'Dell UEFI BIOS Coding Standards v3.3 - UEFI Data Types'
            })
        
        return findings

    def check_code_style(self, line: str, line_num: int) -> List[Dict[str, Any]]:
        """Check code style according to Dell standards"""
        findings = []
        
        # Check goto usage
        if 'goto' in line and not line.strip().startswith('//'):
            goto_standard = self.style_standards['goto_usage']
            if not any(context in line for context in goto_standard['allowed_contexts']):
                findings.append({
                    'type': 'style_violation',
                    'severity': goto_standard['severity'],
                    'issue': goto_standard['rule'],
                    'line': line_num + 1,
                    'code': line.strip(),
                    'recommendation': 'Use goto only for error handling with proper context',
                    'standard': f'Dell UEFI BIOS Coding Standards v3.3 - {goto_standard["description"]}'
                })
        
        # Check line length
        if len(line.rstrip()) > self.style_standards['line_length']['max_length']:
            findings.append({
                'type': 'style_violation',
                'severity': 'low',
                'issue': f'Line exceeds {self.style_standards["line_length"]["max_length"]} characters',
                'line': line_num + 1,
                'code': line.strip(),
                'recommendation': 'Break long lines for better readability',
                'standard': f'Dell UEFI BIOS Coding Standards v3.3 - {self.style_standards["line_length"]["description"]}'
            })
        
        return findings

    def _to_pascal_case(self, name: str) -> str:
        """Convert a name to Pascal case following Dell standards"""
        # Remove prefixes first
        clean_name = name
        if clean_name.startswith(('g', 'm')):
            clean_name = clean_name[1:]
        
        # Remove leading/trailing underscores
        clean_name = clean_name.strip('_')
        
        # Split by underscores and capitalize each word
        words = re.split(r'[_]+', clean_name)
        pascal_case = ''.join(word.capitalize() for word in words if word)
        
        # Add back prefix if original had it
        if name.startswith('g'):
            return 'g' + pascal_case
        elif name.startswith('m'):
            return 'm' + pascal_case
        else:
            return pascal_case

    def check_file_naming(self, file_path: str) -> List[Dict[str, Any]]:
        """Check file naming according to Dell standards"""
        findings = []
        
        file_name = os.path.basename(file_path)
        
        # Check for spaces
        if ' ' in file_name:
            findings.append({
                'type': 'naming_violation',
                'severity': 'high',
                'issue': f"File name '{file_name}' contains spaces (not allowed)",
                'file': file_path,
                'recommendation': f"Remove spaces or use underscores: '{file_name.replace(' ', '_')}'",
                'standard': 'Dell UEFI BIOS Coding Standards v3.3 - File Names'
            })
        
        # Check for invalid characters (simple check)
        invalid_chars = [' ', '-', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '+', '=', '[', ']', '{', '}', '|', '\\', ':', ';', '"', '\'', '<', '>', ',', '.', '?', '/', '`', '~']
        for char in invalid_chars:
            if char in file_name and char not in ['_', '.']:
                findings.append({
                    'type': 'naming_violation',
                    'severity': 'medium',
                    'issue': f"File name '{file_name}' contains invalid character '{char}'",
                    'file': file_path,
                    'recommendation': "Use only alphanumeric characters, underscores, and dots",
                    'standard': 'Dell UEFI BIOS Coding Standards v3.3 - File Names'
                })
                break
        
        # Check Pascal case for main file name (before extension)
        if '.' in file_name:
            base_name = file_name.split('.')[0]
            if not re.match(r'^[A-Z][a-zA-Z0-9]*$', base_name):
                findings.append({
                    'type': 'naming_violation',
                    'severity': 'medium',
                    'issue': f"File name '{base_name}' must use Pascal case",
                    'file': file_path,
                    'recommendation': f"Rename to '{self._to_pascal_case(base_name)}.{file_name.split('.')[1]}'",
                    'standard': 'Dell UEFI BIOS Coding Standards v3.3 - File Names'
                })
        
        return findings

    def get_standards_summary(self) -> Dict[str, Any]:
        """Get summary of all Dell UEFI BIOS Coding Standards"""
        return {
            'version': '3.3',
            'categories': {
                'naming_conventions': self.naming_standards,
                'code_style': self.style_standards,
                'uefi_specific': self.uefi_standards,
                'documentation': self.documentation_standards
            },
            'forbidden_patterns': self.forbidden_patterns,
            'allowed_exceptions': self.allowed_exceptions
        }
