#!/usr/bin/env python3
"""
Enhanced AGS Coding Standards Checker
Based on Dell UEFI BIOS Coding Standards v3.3
"""

import re
import os
from typing import List, Dict, Any
from pathlib import Path

# Import enhanced Dell UEFI standards
from dell_uefi_standards import DellUEFIStandards
from pr_diff_parser import PRDiffParser
from dell_comment_generator import DellGitCommentGenerator

class AGSStandardsChecker:
    """
    Dell UEFI BIOS Coding Standards v3.3 compliance checker
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """Initialize checker with configuration"""
        self.config = config or self._get_default_config()
        
        # Initialize enhanced Dell UEFI standards
        self.dell_standards = DellUEFIStandards()
        self.diff_parser = PRDiffParser()
        self.comment_generator = DellGitCommentGenerator()
        
        # Patterns are now handled by dell_uefi_standards module

    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            'standards': {
                'version': '3.3',
                'strictness': 'moderate',
                'include_suggestions': True
            },
            'checks': {
                'naming_conventions': True,
                'macro_standards': True,
                'file_naming': True,
                'code_style': True,
                'uefi_types': True
            }
        }

    def check_file(self, file_path: str) -> List[Dict[str, Any]]:
        """Check an entire file for AGS standards compliance"""
        findings = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            
            # Check file naming
            if self.config.get('checks', {}).get('file_naming', True):
                file_findings = self.dell_standards.check_file_naming(file_path)
                findings.extend(file_findings)
            
            # Check each line
            for line_num, line in enumerate(lines):
                line_findings = self.check_line(line.rstrip('\n'), line_num, file_path)
                findings.extend(line_findings)
                
        except Exception as e:
            findings.append({
                'type': 'error',
                'severity': 'high',
                'issue': f'Failed to read file: {str(e)}',
                'file': file_path,
                'line': 0,
                'recommendation': 'Check file permissions and encoding'
            })
        
        return findings

    def check_line(self, line: str, line_num: int, file_path: str = None) -> List[Dict[str, Any]]:
        """Check a single line for Dell coding standards violations using enhanced standards"""
        findings = []
        
        # Add file path to findings if provided
        def add_file_path(finding):
            if file_path and 'file' not in finding:
                finding['file'] = file_path
            return finding
        
        # Use enhanced Dell UEFI standards
        if self.config.get('checks', {}).get('naming_conventions', True):
            findings.extend([add_file_path(f) for f in self.dell_standards.check_function_naming(line, line_num)])
            findings.extend([add_file_path(f) for f in self.dell_standards.check_variable_naming(line, line_num)])
        
        if self.config.get('checks', {}).get('macro_standards', True):
            findings.extend([add_file_path(f) for f in self.dell_standards.check_macro_naming(line, line_num)])
        
        if self.config.get('checks', {}).get('code_style', True):
            findings.extend([add_file_path(f) for f in self.dell_standards.check_code_style(line, line_num)])
        
        if self.config.get('checks', {}).get('uefi_types', True):
            findings.extend([add_file_path(f) for f in self.dell_standards.check_uefi_types(line, line_num)])
        
        return findings

    def _check_dell_specific_rules(self, line: str, line_num: int) -> List[Dict[str, Any]]:
        """Check Dell-specific coding rules"""
        findings = []
        
        # Check for goto usage (should be limited)
        if 'goto ' in line and not line.strip().startswith('//'):
            findings.append({
                'type': 'style_violation',
                'severity': 'low',
                'issue': 'Use of goto statement (should be limited)',
                'line': line_num + 1,
                'code': line.strip(),
                'recommendation': 'Consider using structured control flow instead',
                'standard': 'Dell UEFI BIOS Coding Standards v3.3 - The goto statement'
            })
        
        # Check for commented out code (should be deleted)
        if '//' in line and not line.strip().startswith('//'):
            # This is a heuristic - might need refinement
            code_like = any(keyword in line for keyword in ['if', 'for', 'while', 'return', '(', ')', '{', '}'])
            if code_like:
                findings.append({
                    'type': 'style_violation',
                    'severity': 'low',
                    'issue': 'Code appears to be commented out (should be deleted)',
                    'line': line_num + 1,
                    'code': line.strip(),
                    'recommendation': 'Delete commented out code instead of keeping it',
                    'standard': 'Dell UEFI BIOS Coding Standards v3.3 - Abuse of Comments'
                })
        
        return findings

    def generate_summary_report(self, findings: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate a summary report of all findings"""
        summary = {
            'total_issues': len(findings),
            'severity_breakdown': {
                'high': len([f for f in findings if f.get('severity') == 'high']),
                'medium': len([f for f in findings if f.get('severity') == 'medium']),
                'low': len([f for f in findings if f.get('severity') == 'low']),
            },
            'type_breakdown': {
                'naming_violation': len([f for f in findings if f.get('type') == 'naming_violation']),
                'style_violation': len([f for f in findings if f.get('type') == 'style_violation']),
                'error': len([f for f in findings if f.get('type') == 'error']),
            },
            'standards_referenced': list(set([f.get('standard', 'Unknown') for f in findings])),
        }
        
        return summary

    def parse_pr_diff(self, diff_input: str, input_format: str = "text") -> List[Dict[str, Any]]:
        """
        Parse PR diff from various formats
        
        Args:
            diff_input: Raw diff text or JSON data
            input_format: "text" for git diff format, "json" for GitHub API format
            
        Returns:
            List of code changes in AGS checker format
        """
        try:
            if input_format == "text":
                file_diffs = self.diff_parser.parse_diff_text(diff_input)
            elif input_format == "json":
                import json
                diff_data = json.loads(diff_input)
                file_diffs = self.diff_parser.parse_github_diff_json(diff_data)
            else:
                raise ValueError(f"Unsupported input format: {input_format}")
            
            # Filter to UEFI files only
            uefi_file_diffs = self.diff_parser.filter_uefi_files(file_diffs)
            
            # Extract code changes
            code_changes = self.diff_parser.extract_code_changes(uefi_file_diffs)
            
            return code_changes
            
        except Exception as e:
            return [{
                'error': f'Failed to parse PR diff: {str(e)}',
                'type': 'parse_error'
            }]

    def check_pr_from_diff(self, diff_input: str, input_format: str = "text", 
                           severity_threshold: str = "medium") -> Dict[str, Any]:
        """
        Check PR directly from diff input
        
        Args:
            diff_input: Raw diff text or JSON data
            input_format: "text" for git diff format, "json" for GitHub API format
            severity_threshold: Filter issues by severity
            
        Returns:
            PR check results with findings and comments
        """
        # Parse the diff
        code_changes = self.parse_pr_diff(diff_input, input_format)
        
        # Check for parse errors
        if code_changes and code_changes[0].get('type') == 'parse_error':
            return {
                'error': code_changes[0]['error'],
                'summary': {'files_checked': 0, 'total_issues': 0},
                'findings': [],
                'compliance_score': 0
            }
        
        # Use existing PR check method
        return self.check_pr_changes(code_changes, severity_threshold)

    def check_pr_changes(self, pr_diff: List[Dict[str, Any]], severity_threshold: str = "medium") -> Dict[str, Any]:
        """
        Check only code changes in a PR for AGS standards compliance
        pr_diff: List of file changes with 'filename', 'added_lines', 'removed_lines'
        """
        all_findings = []
        pr_summary = {
            'files_checked': 0,
            'total_issues': 0,
            'severity_breakdown': {'high': 0, 'medium': 0, 'low': 0},
            'file_findings': {}
        }
        
        for file_change in pr_diff:
            filename = file_change.get('filename', '')
            added_lines = file_change.get('added_lines', [])
            
            if not added_lines:  # Skip if no new code to check
                continue
                
            pr_summary['files_checked'] += 1
            file_findings = []
            
            # Check file naming
            if self.config.get('checks', {}).get('file_naming', True):
                naming_findings = self.dell_standards.check_file_naming(filename)
                file_findings.extend(naming_findings)
            
            # Check only added lines (code changes)
            for line_info in added_lines:
                line_num = line_info.get('line_number', 0)
                line_content = line_info.get('content', '')
                
                line_findings = self.check_line(line_content, line_num, filename)
                
                # Filter by severity threshold
                filtered_findings = self._filter_by_severity(line_findings, severity_threshold)
                file_findings.extend(filtered_findings)
            
            if file_findings:
                pr_summary['file_findings'][filename] = file_findings
                all_findings.extend(file_findings)
        
        # Update summary
        pr_summary['total_issues'] = len(all_findings)
        pr_summary['severity_breakdown'] = {
            'high': len([f for f in all_findings if f.get('severity') == 'high']),
            'medium': len([f for f in all_findings if f.get('severity') == 'medium']),
            'low': len([f for f in all_findings if f.get('severity') == 'low']),
        }
        
        return {
            'summary': pr_summary,
            'findings': all_findings,
            'compliance_score': self._calculate_compliance_score(all_findings)
        }

    def _filter_by_severity(self, findings: List[Dict[str, Any]], threshold: str) -> List[Dict[str, Any]]:
        """Filter findings by severity threshold"""
        severity_levels = {'high': 3, 'medium': 2, 'low': 1}
        threshold_level = severity_levels.get(threshold, 2)
        
        return [f for f in findings if severity_levels.get(f.get('severity', 'low'), 1) >= threshold_level]

    def _calculate_compliance_score(self, findings: List[Dict[str, Any]]) -> int:
        """Calculate compliance score (0-100)"""
        if not findings:
            return 100
            
        weighted_issues = (
            len([f for f in findings if f.get('severity') == 'high']) * 10 +
            len([f for f in findings if f.get('severity') == 'medium']) * 5 +
            len([f for f in findings if f.get('severity') == 'low']) * 1
        )
        
        return max(0, 100 - weighted_issues)

    def generate_git_comments(self, pr_results: Dict[str, Any], comment_style: str = "dell") -> List[str]:
        """
        Generate Git comments for PR using enhanced Dell comment generator
        
        Args:
            pr_results: PR check results
            comment_style: "dell", "concise", or "detailed"
            
        Returns:
            List of formatted Git comments
        """
        return self.comment_generator.generate_pr_comments(pr_results, comment_style)
