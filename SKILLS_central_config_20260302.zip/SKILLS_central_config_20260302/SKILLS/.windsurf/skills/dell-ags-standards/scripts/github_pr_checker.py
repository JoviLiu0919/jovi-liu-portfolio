#!/usr/bin/env python3
"""
Enhanced PR AGS Checker with Direct GitHub Integration
Supports direct access to Dell GitHub Enterprise Server
"""

import sys
import os
import json
import argparse
import re
from pathlib import Path
from typing import Dict, List, Any, Tuple

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import central configuration loader
sys.path.append(str(Path(__file__).parent.parent.parent.parent))
from config_loader import load_skill_config_with_central_fallback

from ags_checker import AGSStandardsChecker
from dell_github_api import DellGitHubAPI

class GitHubPRChecker:
    """
    Enhanced PR checker with direct GitHub integration
    """
    
    def __init__(self, config_path: str = None):
        """Initialize GitHub PR checker"""
        config_path = config_path or str(Path(__file__).parent.parent / "config.toml")
        self.config = load_skill_config_with_central_fallback(Path(config_path))
        self.github_api = DellGitHubAPI(Path(config_path))
        self.ags_checker = AGSStandardsChecker(self.config)
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load AGS checker configuration"""
        config_path = config_path or Path(__file__).parent.parent / "config.toml"
        
        # Default config
        config = {
            'standards': {
                'version': '3.3',
                'strictness': 'moderate',
                'include_suggestions': True
            },
            'checks': {
                'naming_conventions': True,
                'macro_standards': True,
                'file_naming': True,
                'code_style': True,
                'uefi_types': True
            },
            'output': {
                'severity_threshold': 'medium',
                'auto_push_comment': False
            },
            'git_comment': {
                'enable_format_check': True,
                'comment_style': 'dell',
                'max_comments_per_pr': 10,
                'include_suggestions': True
            }
        }
        
        # Try to load from TOML file (basic parsing)
        if config_path.exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # Simple TOML parsing for our specific structure
                    if 'severity_threshold' in content:
                        for line in content.split('\n'):
                            if 'severity_threshold' in line and '=' in line and not line.strip().startswith('#'):
                                threshold = line.split('=')[1].strip().strip('"')
                                config['output']['severity_threshold'] = threshold
                                break
                    
                    if 'auto_push_comment' in content:
                        for line in content.split('\n'):
                            if 'auto_push_comment' in line and '=' in line and not line.strip().startswith('#'):
                                auto_push = line.split('=')[1].strip().strip('"').lower() == 'true'
                                config['output']['auto_push_comment'] = auto_push
                                break
                                
                    if 'comment_style' in content:
                        for line in content.split('\n'):
                            if 'comment_style' in line and '=' in line and not line.strip().startswith('#'):
                                style = line.split('=')[1].strip().strip('"')
                                config['git_comment']['comment_style'] = style
                                break
            except Exception as e:
                print(f"Warning: Could not parse config.toml: {e}")
                print("Using default configuration")
        
        return config
    
    def authenticate(self) -> bool:
        """Authenticate with GitHub"""
        print("=== GitHub Authentication ===")
        
        # Check if token is available
        token = self.github_config.get('github', {}).get('token', '')
        if not token:
            print("ERROR: No GitHub token found in config")
            return False
        
        # Initialize GitHub API with token
        self.github_api = DellGitHubAPI(self.github_config)
        
        # Test authentication
        if self.github_api.test_authentication():
            print("Existing token is valid")
            print("GitHub authentication successful")
            return True
        else:
            print("ERROR: GitHub token is invalid")
            return False
    
    def parse_pr_url(self, pr_url: str) -> Tuple[str, str, int]:
        """Parse PR URL to extract owner, repo, and PR number"""
        # Support various URL formats:
        # https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/1751
        # https://github.com/owner/repo/pull/123
        # owner/repo/pull/123
        
        patterns = [
            r'https?://[^/]+/([^/]+)/([^/]+)/pull/(\d+)',
            r'([^/]+)/([^/]+)/pull/(\d+)'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, pr_url)
            if match:
                return match.group(1), match.group(2), int(match.group(3))
        
        raise ValueError(f"Invalid PR URL format: {pr_url}")
    
    def check_github_pr(self, pr_url: str, severity_threshold: str = None, 
                        comment_style: str = None, comment_type: str = 'review', 
                        dry_run: bool = False) -> Dict[str, Any]:
        """
        Check GitHub PR directly
        
        Args:
            pr_url: GitHub PR URL
            severity_threshold: Override severity threshold
            comment_style: Override comment style
            dry_run: Don't post comments, just check
            
        Returns:
            Check results
        """
        if not self.github_api:
            raise Exception("Not authenticated with GitHub")
        
        # Parse PR URL
        try:
            owner, repo, pr_number = self.parse_pr_url(pr_url)
        except ValueError as e:
            raise Exception(f"Failed to parse PR URL: {str(e)}")
        
        print(f"Checking PR #{pr_number} in {owner}/{repo}")
        print()
        
        # Override config with parameters
        if severity_threshold:
            self.config['output']['severity_threshold'] = severity_threshold
        if comment_style:
            self.config['git_comment']['comment_style'] = comment_style
        
        # Get PR information
        try:
            pr_info = self.github_api.get_pull_request(owner, repo, pr_number)
            pr_diff = self.github_api.get_pull_request_diff(owner, repo, pr_number)
            
            print(f"PR Title: {pr_info.get('title', 'Unknown')}")
            print(f"Author: {pr_info.get('user', {}).get('login', 'Unknown')}")
            print(f"State: {pr_info.get('state', 'Unknown')}")
            print(f"Files changed: {pr_info.get('changed_files', 0)}")
            print(f"Additions: {pr_info.get('additions', 0)}")
            print(f"Deletions: {pr_info.get('deletions', 0)}")
            print()
            
        except Exception as e:
            raise Exception(f"Failed to get PR information: {str(e)}")
        
        # Check PR using Dell UEFI BIOS Coding Standards
        try:
            results = self.ags_checker.check_pr_from_diff(pr_diff, "text", 
                                                          self.config['output']['severity_threshold'])
            
            if 'error' in results:
                raise Exception(f"PR check failed: {results['error']}")
            
            # Display results
            summary = results.get('summary', {})
            findings = results.get('findings', [])
            compliance_score = results.get('compliance_score', 0)
            
            print("=== AGS Standards Check Results ===")
            print(f"Files Checked: {summary.get('files_checked', 0)}")
            print(f"Total Issues: {summary.get('total_issues', 0)}")
            print(f"Compliance Score: {compliance_score}/100")
            
            severity_breakdown = summary.get('severity_breakdown', {})
            print(f"High Severity: {severity_breakdown.get('high', 0)}")
            print(f"Medium Severity: {severity_breakdown.get('medium', 0)}")
            print(f"Low Severity: {severity_breakdown.get('low', 0)}")
            print()
            
            # Generate comments with severity threshold info
            comments = self.ags_checker.generate_git_comments(results, 
                                                              self.config['git_comment']['comment_style'])
            
            print("=== Generated Comments ===")
            for i, comment in enumerate(comments, 1):
                print(f"--- Comment {i} ---")
                try:
                    print(comment)
                except UnicodeEncodeError:
                    # Fallback for systems that can't display emoji
                    safe_comment = comment.replace('📊', '[SUMMARY]').replace('⚠️', '[WARNING]').replace('✅', '[VALID]').replace('❌', '[INVALID]').replace('🔒', '[GPG]').replace('🎯', '[ACTION]').replace('🔧', '[FIX]').replace('📝', '[FORMAT]').replace('📁', '[FILE]').replace('🔴', '[HIGH]').replace('🟡', '[MEDIUM]').replace('🟢', '[LOW]').replace('📋', '[THRESHOLD]')
                    print(safe_comment)
                print()
            
            # Post comments if enabled and not dry run
            if self.config['output']['auto_push_comment'] and not dry_run:
                self._post_comments_to_pr(owner, repo, pr_number, comments, results, comment_type)
            elif self.config['output']['auto_push_comment'] and dry_run:
                print("=== Dry Run Mode - Comments Not Posted ===")
                print("Would post comments to PR if not in dry run mode")
            else:
                print("=== Auto Push Comment Disabled ===")
                print("Comments generated for manual review")
            
            return results
            
        except Exception as e:
            raise Exception(f"Failed to check PR: {str(e)}")
    
    def _post_comments_to_pr(self, owner: str, repo: str, pr_number: int, 
                            comments: List[str], results: Dict[str, Any], 
                            comment_type: str = 'review') -> None:
        """Post comments to PR using either review or comment format"""
        try:
            print("=== Posting Comments to PR ===")
            
            # Combine all comments into one body
            combined_body = '\n\n---\n\n'.join(comments)
            
            if comment_type == 'comment':
                # Post as regular issue comment (doesn't show "reviewed")
                comment = self.github_api.create_issue_comment(
                    owner, repo, pr_number, combined_body
                )
                print(f"Comment posted successfully")
                print(f"Comment ID: {comment.get('id', 'Unknown')}")
                print(f"URL: {comment.get('html_url', 'Unknown')}")
            else:
                # Post as review (shows "reviewed")
                review = self.github_api.create_pull_request_review(
                    owner, repo, pr_number, combined_body, 'COMMENT'
                )
                print(f"Review posted successfully")
                print(f"Review ID: {review.get('id', 'Unknown')}")
                print(f"URL: {review.get('html_url', 'Unknown')}")
            
        except Exception as e:
            print(f"Failed to post comments: {str(e)}")

def main():
    """Main function"""
    parser = argparse.ArgumentParser(description='Check GitHub PR against Dell AgS standards')
    parser.add_argument('pr_url', nargs='?', help='GitHub PR URL')
    parser.add_argument('--config', help='Configuration file path')
    parser.add_argument('--severity-threshold', choices=['high', 'medium', 'low'], 
                       help='Override severity threshold')
    parser.add_argument('--comment-style', choices=['dell', 'concise', 'detailed'], 
                       help='Override comment style')
    parser.add_argument('--comment-type', choices=['review', 'comment'], default='review',
                       help='Choose between review (shows "reviewed") or comment (normal comment)')
    parser.add_argument('--dry-run', action='store_true', 
                       help='Check only, do not post comments')
    parser.add_argument('--authenticate-only', action='store_true',
                       help='Only perform authentication, do not check PR')
    
    args = parser.parse_args()
    
    # Initialize checker
    checker = GitHubPRChecker(args.config)
    
    # Authenticate
    if not checker.authenticate():
        sys.exit(1)
    
    # If only authentication requested, exit
    if args.authenticate_only:
        print("Authentication successful")
        sys.exit(0)
    
    # Check if PR URL provided
    if not args.pr_url:
        print("Error: PR URL is required unless using --authenticate-only")
        parser.print_help()
        sys.exit(1)
    
    # Check PR
    try:
        results = checker.check_github_pr(
            args.pr_url, 
            args.severity_threshold,
            args.comment_style,
            args.comment_type,
            args.dry_run
        )
        
        # Return appropriate exit code
        compliance_score = results.get('compliance_score', 0)
        if compliance_score >= 90:
            print("PR PASSES Dell UEFI BIOS Coding Standards check")
            sys.exit(0)
        elif compliance_score >= 70:
            print("PR needs minor fixes to meet Dell UEFI BIOS Coding Standards")
            sys.exit(1)
        else:
            print("PR has significant Dell UEFI BIOS Coding Standards violations")
            sys.exit(2)
            
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(3)

if __name__ == "__main__":
    main()
