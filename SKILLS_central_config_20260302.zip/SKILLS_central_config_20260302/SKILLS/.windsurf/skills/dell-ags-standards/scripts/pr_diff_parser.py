#!/usr/bin/env python3
"""
Enhanced PR Diff Parser for Dell UEFI BIOS Coding Standards
Automatically parses GitHub PR diffs and extracts code changes
"""

import re
import json
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass

@dataclass
class DiffLine:
    """Represents a single line in a diff"""
    line_number: int
    content: str
    type: str  # 'added', 'removed', 'context'
    original_line_number: int = None

@dataclass
class FileDiff:
    """Represents a file's diff"""
    filename: str
    added_lines: List[DiffLine]
    removed_lines: List[DiffLine]
    context_lines: List[DiffLine]
    file_type: str = 'unknown'

class PRDiffParser:
    """
    Enhanced PR diff parser for Dell UEFI BIOS Coding Standards checking
    """
    
    def __init__(self):
        """Initialize the diff parser"""
        # Patterns for parsing git diff format
        self.diff_patterns = {
            'file_header': re.compile(r'^diff --git a/(.*) b/(.*)$'),
            'index_line': re.compile(r'^index [a-f0-9]+\.\.[a-f0-9]+.*$'),
            'mode_line': re.compile(r'^new file mode \d+$|^deleted file mode \d+$|^old mode \d+$|^new mode \d+$'),
            'hunk_header': re.compile(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(.*)$'),
            'added_line': re.compile(r'^\+(.*)$'),
            'removed_line': re.compile(r'^-(.*)$'),
            'context_line': re.compile(r'^ (.*)$'),
            'no_newline': re.compile(r'^\\ No newline at end of file$')
        }
        
        # File extensions for Dell BIOS/UEFI code
        self.uefi_extensions = {
            '.c': 'source',
            '.h': 'header', 
            '.inf': 'inf',
            '.dec': 'dec',
            '.asl': 'asl',
            '.uni': 'uni',
            '.vfr': 'vfr',
            '.cif': 'cif',
            '.fdf': 'fdf'  # Flash Definition File
        }
    
    def parse_diff_text(self, diff_text: str) -> List[FileDiff]:
        """
        Parse git diff text and extract file changes
        
        Args:
            diff_text: Raw git diff output
            
        Returns:
            List of FileDiff objects
        """
        lines = diff_text.split('\n')
        file_diffs = []
        current_file = None
        current_hunk = None
        
        i = 0
        while i < len(lines):
            line = lines[i]
            
            # Check for file header
            file_match = self.diff_patterns['file_header'].match(line)
            if file_match:
                # Save previous file if exists
                if current_file:
                    file_diffs.append(current_file)
                
                # Start new file
                filename = file_match.group(1)
                file_type = self._get_file_type(filename)
                current_file = FileDiff(
                    filename=filename,
                    added_lines=[],
                    removed_lines=[],
                    context_lines=[],
                    file_type=file_type
                )
                current_hunk = None
                i += 1
                continue
            
            # Check for hunk header
            hunk_match = self.diff_patterns['hunk_header'].match(line)
            if hunk_match and current_file:
                current_hunk = {
                    'old_start': int(hunk_match.group(1)),
                    'old_count': int(hunk_match.group(2) or 1),
                    'new_start': int(hunk_match.group(3)),
                    'new_count': int(hunk_match.group(4) or 1),
                    'context': hunk_match.group(5).strip()
                }
                i += 1
                continue
            
            # Process diff lines
            if current_file and current_hunk:
                diff_line = self._parse_diff_line(line, current_hunk)
                if diff_line:
                    if diff_line.type == 'added':
                        current_file.added_lines.append(diff_line)
                    elif diff_line.type == 'removed':
                        current_file.removed_lines.append(diff_line)
                    elif diff_line.type == 'context':
                        current_file.context_lines.append(diff_line)
            
            i += 1
        
        # Add last file
        if current_file:
            file_diffs.append(current_file)
        
        return file_diffs
    
    def parse_github_diff_json(self, diff_data: Dict[str, Any]) -> List[FileDiff]:
        """
        Parse GitHub API diff response
        
        Args:
            diff_data: GitHub API response data
            
        Returns:
            List of FileDiff objects
        """
        file_diffs = []
        
        # Handle different GitHub API formats
        if 'files' in diff_data:
            # GitHub Pull Request API format
            for file_info in diff_data['files']:
                filename = file_info.get('filename', '')
                patch = file_info.get('patch', '')
                
                if patch:
                    file_diff = self._parse_patch_to_file_diff(filename, patch)
                    if file_diff:
                        file_diffs.append(file_diff)
        
        elif 'diff' in diff_data:
            # Single diff format
            diff_text = diff_data['diff']
            file_diffs = self.parse_diff_text(diff_text)
        
        return file_diffs
    
    def _parse_patch_to_file_diff(self, filename: str, patch: str) -> FileDiff:
        """Parse a patch string into FileDiff object"""
        file_type = self._get_file_type(filename)
        file_diff = FileDiff(
            filename=filename,
            added_lines=[],
            removed_lines=[],
            context_lines=[],
            file_type=file_type
        )
        
        lines = patch.split('\n')
        current_hunk = None
        line_number = 0
        
        for line in lines:
            # Check for hunk header
            hunk_match = self.diff_patterns['hunk_header'].match(line)
            if hunk_match:
                current_hunk = {
                    'old_start': int(hunk_match.group(1)),
                    'old_count': int(hunk_match.group(2) or 1),
                    'new_start': int(hunk_match.group(3)),
                    'new_count': int(hunk_match.group(4) or 1),
                    'context': hunk_match.group(5).strip()
                }
                line_number = current_hunk['new_start']
                continue
            
            # Process diff lines
            if current_hunk:
                diff_line = self._parse_diff_line(line, current_hunk, line_number)
                if diff_line:
                    if diff_line.type == 'added':
                        file_diff.added_lines.append(diff_line)
                        line_number += 1
                    elif diff_line.type == 'removed':
                        file_diff.removed_lines.append(diff_line)
                    elif diff_line.type == 'context':
                        file_diff.context_lines.append(diff_line)
                        line_number += 1
        
        return file_diff
    
    def _parse_diff_line(self, line: str, hunk: Dict[str, Any], line_number: int = None) -> DiffLine:
        """Parse a single diff line"""
        # Skip metadata lines
        if any(line.startswith(prefix) for prefix in ['diff --git', 'index ', 'new file', 'deleted file', 'old mode', 'new mode', ' similarity']):
            return None
        
        # Check for no newline marker
        if self.diff_patterns['no_newline'].match(line):
            return None
        
        # Parse line type
        if self.diff_patterns['added_line'].match(line):
            content = self.diff_patterns['added_line'].match(line).group(1)
            return DiffLine(
                line_number=line_number or 0,
                content=content,
                type='added'
            )
        elif self.diff_patterns['removed_line'].match(line):
            content = self.diff_patterns['removed_line'].match(line).group(1)
            return DiffLine(
                line_number=line_number or 0,
                content=content,
                type='removed'
            )
        elif self.diff_patterns['context_line'].match(line):
            content = self.diff_patterns['context_line'].match(line).group(1)
            return DiffLine(
                line_number=line_number or 0,
                content=content,
                type='context'
            )
        
        return None
    
    def _get_file_type(self, filename: str) -> str:
        """Determine file type from extension"""
        for ext, file_type in self.uefi_extensions.items():
            if filename.endswith(ext):
                return file_type
        return 'other'
    
    def filter_uefi_files(self, file_diffs: List[FileDiff]) -> List[FileDiff]:
        """Filter to only UEFI/BIOS related files"""
        return [f for f in file_diffs if f.file_type != 'other']
    
    def extract_code_changes(self, file_diffs: List[FileDiff]) -> List[Dict[str, Any]]:
        """
        Extract code changes in format suitable for AGS checker
        
        Returns:
            List of dicts with 'filename' and 'added_lines'
        """
        code_changes = []
        
        for file_diff in file_diffs:
            # Skip if no added lines
            if not file_diff.added_lines:
                continue
            
            # Convert to AGS checker format
            added_lines = [
                {
                    'line_number': line.line_number,
                    'content': line.content
                }
                for line in file_diff.added_lines
            ]
            
            code_changes.append({
                'filename': file_diff.filename,
                'added_lines': added_lines,
                'removed_lines': [
                    {
                        'line_number': line.line_number,
                        'content': line.content
                    }
                    for line in file_diff.removed_lines
                ],
                'file_type': file_diff.file_type
            })
        
        return code_changes
    
    def create_sample_diff(self) -> str:
        """Create a sample diff for testing"""
        return """diff --git a/DellPkgs/DellPlatformPkgs/HardwareManager.c b/DellPkgs/DellPlatformPkgs/HardwareManager.c
index abc123..def456 100644
--- a/DellPkgs/DellPlatformPkgs/HardwareManager.c
+++ b/DellPkgs/DellPlatformPkgs/HardwareManager.c
@@ -44,6 +44,9 @@ EFI_STATUS InitializeHardware (
   IN EFI_SYSTEM_TABLE  *SystemTable
   )
 {
+  UINT32 system_config;
+  extern UINT32 gSystemConfiguration;
+  BOOLEAN is_initialized = FALSE;
   
   //
   // Initialize hardware components
@@ -55,6 +58,8 @@ EFI_STATUS InitializeHardware (
   return Status;
 }
 
+EFI_STATUS get_system_info(VOID) {
+  return gSystemConfiguration;
+}
+
diff --git a/DellPkgs/DellPlatformPkgs/SystemInfo.h b/DellPkgs/DellPlatformPkgs/SystemInfo.h
index 789abc..def012 100644
--- a/DellPkgs/DellPlatformPkgs/SystemInfo.h
+++ b/DellPkgs/DellPlatformPkgs/SystemInfo.h
@@ -10,5 +10,7 @@
 #ifndef _SYSTEM_INFO_H_
 #define _SYSTEM_INFO_H_
 
+extern UINT32 GlobalVariable;
+#define max_buffer_size 256
 
 #endif
"""

def main():
    """Test the PR diff parser"""
    parser = PRDiffParser()
    
    # Test with sample diff
    sample_diff = parser.create_sample_diff()
    file_diffs = parser.parse_diff_text(sample_diff)
    
    print("=== PR Diff Parser Test ===")
    print(f"Found {len(file_diffs)} files with changes")
    print()
    
    for file_diff in file_diffs:
        print(f"File: {file_diff.filename}")
        print(f"Type: {file_diff.file_type}")
        print(f"Added lines: {len(file_diff.added_lines)}")
        print(f"Removed lines: {len(file_diff.removed_lines)}")
        print()
        
        # Show added lines
        if file_diff.added_lines:
            print("Added lines:")
            for line in file_diff.added_lines:
                print(f"  +{line.line_number}: {line.content}")
            print()
    
    # Extract code changes for AGS checker
    code_changes = parser.extract_code_changes(file_diffs)
    print("=== Code Changes for AGS Checker ===")
    print(json.dumps(code_changes, indent=2))

if __name__ == "__main__":
    main()
