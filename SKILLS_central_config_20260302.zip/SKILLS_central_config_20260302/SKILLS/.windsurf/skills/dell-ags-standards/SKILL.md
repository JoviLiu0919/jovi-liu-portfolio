---
name: dell-ags-standards
description: Dell UEFI BIOS Coding Standards compliance checker based on Dell UEFI BIOS Coding Standards v3.3. Use when checking code compliance, validating naming conventions, or ensuring BIOS code follows Dell standards.
---

# Dell UEFI BIOS Coding Standards Skill

Dedicated skill for checking whether Dell UEFI BIOS code complies with Dell UEFI BIOS Coding Standards v3.3 specification.

## 📚 Function Features

### **Complete Standard Support**
- **Dell UEFI BIOS Coding Standards v3.3** Complete Implementation
- **Pascal case naming specification** Strict Check
- **UEFI specific rules** Comprehensive Coverage
- **Dell specific conventions** Precise Verify

### **Check Items**
- **Function naming** - Pascal case, no underscore prefixes/suffixes
- **Variable naming** - Global variable `g` prefix, Module variable `m` prefix
- **Macro naming** - UPPER_CASE format
- **File naming** - Pascal case, no spaces
- **Code style** - goto limitations, Comment specification
- **UEFI types** - Standard UEFI data types used

### **Integration Capabilities**
- **GitHub Integration** - Direct access to Dell GitHub Enterprise Server
- **Automatic Review** - Automatic check PR code changes
- **Git Comments** - Automatic generate Dell format Git comments
- **Standalone Run** - Can be used independently for standard checks
- **API Calls** - Provide API for other skills to call
- **Report Generation** - Detailed compliance reports
- **Batch Check** - Support entire project checks

## Configuration

### 1. Environment Configuration
```powershell
cd .windsurf/skills/dell-ags-standards
.\scripts\setup_env.ps1
```

### 2. Configure configuration file
Edit `config.toml` file:

```toml
[standards]
# Dell UEFI BIOS Coding Standards Version
version = "3.3"
# Check strictness level (strict, moderate, lenient)
strictness = "moderate"
# Whether to include suggestion checks
include_suggestions = true

[checks]
# Enabled check items
naming_conventions = true
macro_standards = true
file_naming = true
code_style = true
uefi_types = true

[output]
# Output format (json, markdown, xml)
format = "json"
# Whether to include detailed suggestions
include_recommendations = true
# Severity threshold
severity_threshold = "medium"

[git_comment]
# Git comment Configuration
enable_format_check = true
comment_style = "dell"  # concise, detailed, dell
max_comments_per_pr = 10
include_suggestions = true
comment_type = "review"  # review (shows "reviewed") or comment (normal comment)
```

## Usage

### 1. GitHub PR Automatic Review (Main Functions)

```powershell
# Configure GitHub token (Environment Variable)
$env:DELL_GITHUB_TOKEN = "your_personal_access_token"

# Check PR and automatically push comment (Default is review type)
python scripts/github_pr_checker.py "https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/1751"

# Push general comment (does not display "reviewed")
python scripts/github_pr_checker.py "https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/1751" --comment-type comment

# Push review (displays "reviewed")
python scripts/github_pr_checker.py "https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/1751" --comment-type review

# Dry run mode (does not push comment)
python scripts/github_pr_checker.py "https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/1751" --dry-run

# Specify severity threshold
python scripts/github_pr_checker.py "https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/1751" --severity-threshold high

# Only test verify
python scripts/github_pr_checker.py --authenticate-only
```

### 2. Independent Check

```powershell
# Check single file
python scripts/ags_checker.py check-file --file "PlatformManager.c"

# Check entire directory
python scripts/ags_checker.py check-directory --path "DellPkgs/DellPlatformPkgs"

# Generate compliance report
python scripts/ags_checker.py generate-report --path "DellPkgs" --output "compliance_report.md"
```

### 3. API Calls (for other skills to use)

```python
from ags_checker import AGSStandardsChecker

# Initialize checker
checker = AGSStandardsChecker()

# Check single line
findings = checker.check_line(line_text, line_number)

# Check file
file_findings = checker.check_file(file_path)

# Check directory
directory_findings = checker.check_directory(directory_path)

# Generate summary report
summary = checker.generate_summary(all_findings)
```

### 3. Batch Check

```powershell
# Check multiple save libraries
python scripts/ags_checker.py batch-check --repos "CDC_AgS_2025,CBF_DellFeaturesPkg"

# Scan entire organization
python scripts/ags_checker.py org-scan --owner "CSG-Firmware-Engineering"

# Regular check schedule
python scripts/ags_checker.py scheduled-check --schedule "weekly"
```

## Dell UEFI BIOS Coding Standards v3.3

### **Naming Specification**

#### **Function Naming**
```c
// ✅ correct - Pascal case
EFI_STATUS
InitializeHardware (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  );

// ❌ Bug - No Pascal case
void initialize_hardware(void);

// ❌ Bug - Leading underscore
UINT32 _get_system_info(void);
```

#### **Variable Naming**
```c
// ✅ correct - Global variable with g prefix
extern UINT32 gSystemConfiguration;

// ✅ correct - Module variable with m prefix
STATIC UINT32 mModuleInfo;

// ❌ Bug - Global variable without prefix
extern UINT32 SystemConfig;
```

#### **Macro Naming**
```c
// ✅ correct - UPPER_CASE
#define MAX_BUFFER_SIZE 256
#define PLATFORM_ID_LENGTH 32

// ❌ Bug - Not uppercase
#define max_buffer_size 256
```

#### **File Naming**
```
// ✅ correct - Pascal case
PlatformManager.c
HardwareInfo.h
SystemConfig.inf

// ❌ Bug - Contains spaces or lowercase
platform manager.c
hardware_info.h
```

### **Code Style**

#### **goto Statements**
```c
// ✅ correct - Limited use
if (ErrorCondition) {
    goto ErrorExit;
}

// ❌ Bug - Excessive use
goto Label1;
goto Label2;
goto Label3;
```

#### **Comment Specification**
```c
// ✅ correct - Doxygen style
/**
  Brief description of function
  @param[in]  Parameter1 Description of parameter1
  @param[out] Parameter2 Description of parameter2
  @retval EFI_SUCCESS  Operation completed successfully
**/

// ❌ Bug - Commented-out code should be deleted
// if (old_condition) {
//     do_something();
// }
```

## Check Results

### **Issue Classification**
- **high** - Serious violation of standard, must fix
- **medium** - Medium violation, suggestion fix
- **low** - Minor violation, optional fix

### **Report Format**
```json
{
  "compliance_score": 85,
  "total_issues": 12,
  "severity_breakdown": {
    "high": 2,
    "medium": 7,
    "low": 3
  },
  "findings": [
    {
      "type": "naming_violation",
      "severity": "medium",
      "issue": "Function 'initialize_hardware' must use Pascal case",
      "line": 45,
      "file": "PlatformManager.c",
      "recommendation": "Rename to 'InitializeHardware'",
      "standard": "Dell UEFI BIOS Coding Standards v3.3 - Naming"
    }
  ]
}
```

## Integration with Other Skills

### **Code Review Skill Integration**
```python
# Called in code_review.py
from dell_ags_standards.scripts.ags_checker import AGSStandardsChecker

class CodeReviewTool:
    def __init__(self):
        self.ags_checker = AGSStandardsChecker()
    
    def _check_code_quality(self, line, line_num, all_lines):
        findings = []
        
        # Use AGS standard check
        ags_findings = self.ags_checker.check_line(line, line_num)
        findings.extend(ags_findings)
        
        return findings
```

### **PR Format Check Skill Integration**
```python
# Check if PR file naming conforms to AGS standard
from dell_ags_standards.scripts.ags_checker import AGSStandardsChecker

def check_pr_file_names(pr_files):
    checker = AGSStandardsChecker()
    for file_info in pr_files:
        file_name = file_info['filename']
        findings = checker.check_file_naming(file_name)
        if findings:
            report_file_naming_issues(findings)
```

## Troubleshooting

### **Common Issues**

#### **1. PDF Standard Documentation Cannot Read**
```
ERROR: Cannot read Dell UEFI BIOS Coding Standards v3.3.pdf
```
**Solution**: Install PyMuPDF: `pip install PyMuPDF`

#### **2. Checker Initialization Failed**
```
ERROR: Failed to initialize AGS standards checker
```
**Solution**: Check config.toml configuration and PDF documentation path

#### **3. Memory Usage Too High**
```
WARNING: High memory usage during large directory scan
```
**Solution**: Use `--chunk-size` parameter to handle in batches

### **Debug Pattern**
```powershell
# Enable detailed output
python scripts/ags_checker.py check-file --file "test.c" --debug

# Display check process
python scripts/ags_checker.py check-directory --path "src" --verbose
```

## Advanced Configuration

### **Customize Check Rules**
```toml
[custom_rules]
# Customize naming rules
custom_naming = true
# Allowed exception cases
allowed_exceptions = ["legacy_function", "compatibility_macro"]
# Project specific rules
project_specific = true
```

### **Integration CI/CD**
```yaml
# GitHub Actions Example
- name: Check AGS Standards
  run: |
    python .windsurf/skills/dell-ags-standards/scripts/ags_checker.py check-directory --path "src"
```

---

*Finally Update: 2026-02-06*
*Version: 1.0*
*Based on: Dell UEFI BIOS Coding Standards v3.3*
