
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from confluence_tool import load_config, get_client
from bs4 import BeautifulSoup

def probe_project_page(c, page_id):
    print(f"\n--- Probing Project Page {page_id} Storage ---")
    page = c.get_page_by_id(page_id, expand="body.storage,body.view")
    
    # Check Storage for Page Properties
    storage = page['body']['storage']['value']
    if "ac:name=\"page-properties\"" in storage:
        print(" [INFO] Found 'page-properties' macro.")
    else:
        print(" [INFO] 'page-properties' macro NOT found.")
        
    # Print first 500 chars of storage to see structure
    print(f"\n--- Storage Preview ---\n{storage[:1000]}")
    
    # Check View for Table Headers
    print(f"\n--- View Table Headers ---")
    soup = BeautifulSoup(page['body']['view']['value'], 'html.parser')
    for tbl in soup.find_all('table'):
        rows = tbl.find_all('tr')
        if rows:
            headers = [th.get_text(strip=True) for th in rows[0].find_all(['th', 'td'])]
            print(f"  Table Headers: {headers}")

    # Check Children
    children = c.get_page_by_id(page_id, expand="children.page")
    child_list = children.get('children', {}).get('page', {}).get('results', [])
    if child_list:
        print(f"\n--- Children Found ({len(child_list)}) ---")
        for child in child_list[:5]:
            print(f"  - {child['title']} (ID: {child['id']})")
    else:
        print("\n--- No Children Found ---")

def main():
    config = load_config(Path("config.toml"))
    c = get_client(config)
    probe_project_page(c, "898823992")

if __name__ == "__main__":
    main()
