
import re
from bs4 import BeautifulSoup
from typing import List, Dict, Optional, Set

class ConfluenceParser:
    @staticmethod
    def get_cell_status(cell) -> Dict:
        """
        Identifies the visual status/health of a cell based on color (style/class) or text.
        Returns a dict with 'text', 'color' (RED/YELLOW/GREEN), and 'is_green'.
        """
        if cell is None:
            return {"text": "N/A", "color": "GREEN", "is_green": True}
            
        text = cell.get_text(strip=True)
        lower = text.lower()
        style = cell.get('style', '').lower()
        classes = cell.get('class', [])
        
        # Check colors in style, class, or text keywords
        is_red = 'red' in style or '#ff0000' in style or 'gh-red' in classes or 'red' in lower
        is_yellow = 'yellow' in style or '#ffff00' in style or 'yellow' in lower
        is_green = 'green' in style or '#00ff00' in style or 'green' in lower or lower in ['done', 'healthy', 'pass']
        
        color = "GREEN"
        if is_red: color = "RED"
        elif is_yellow: color = "YELLOW"
        
        return {
            "text": text,
            "is_red": is_red,
            "is_yellow": is_yellow,
            "is_green": is_green or (not is_red and not is_yellow), # Default to green
            "color": color
        }

    @staticmethod
    def extract_links(cell) -> Set[str]:
        """
        Extracts linked page titles from a Confluence cell (body.view format).
        Handles both <a> tags and Confluence ri:page tags.
        """
        links = set()
        if cell is None: return links
        
        cell_str = str(cell)
        # 1. Look for ri:content-title (storage format or rendered ri tags)
        referenced_pages = re.findall(r'ri:content-title="([^"]+)"', cell_str)
        for t in referenced_pages:
            links.add(t)
            
        # 2. Look for standard <a> tags
        soup = BeautifulSoup(cell_str, 'html.parser')
        for a in soup.find_all('a'):
            title = a.get('title', '')
            if title:
                links.add(title)
            else:
                href = a.get('href', '')
                if '/display/' in href:
                    parts = href.split('/')
                    if len(parts) > 0:
                        links.add(parts[-1].replace('+', ' '))
                else:
                    text = a.get_text(strip=True)
                    if text: links.add(text)
        return links

    @staticmethod
    def find_table_by_headers(soup, required_keywords: List[str]) -> Optional[Dict]:
        """
        Finds a table containing all required keywords in its header.
        Returns {'table': element, 'headers': list, 'indices': dict} or None.
        """
        tables = soup.find_all('table')
        for tbl in tables:
            rows = tbl.find_all('tr')
            if not rows: continue
            
            headers = [th.get_text(strip=True).lower() for th in rows[0].find_all(['th', 'td'])]
            
            matches = {}
            found_all = True
            for kw in required_keywords:
                found_kw = False
                for idx, h in enumerate(headers):
                    if kw.lower() in h:
                        matches[kw] = idx
                        found_kw = True
                        break
                if not found_kw:
                    found_all = False
                    break
            
            if found_all:
                return {
                    'table': tbl,
                    'headers': headers,
                    'indices': matches
                }
        return None
