# Check if python is installed
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "Python is not installed. Please install Python 3.9+."
    Exit 1
}

# Create venv if it doesn't exist
if (-not (Test-Path .venv)) {
    Write-Host "Creating virtual environment..."
    python -m venv .venv
}

# upgrade pip
& .\.venv\Scripts\python -m pip install --upgrade pip

# Install dependencies
Write-Host "Installing dependencies..."
& .\.venv\Scripts\pip install -r requirements.txt

Write-Host "Setup complete."
