
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from confluence_tool import load_config, get_client
from bs4 import BeautifulSoup

def probe_page(c, page_id, label):
    print(f"\n--- Probing {label} ({page_id}) ---")
    try:
        page = c.get_page_by_id(page_id, expand="body.view,children.page")
        if not page:
            print("  Page not found or no permission.")
            return

        print(f"  Title: {page.get('title')}")
        
        # 1. Analyze Tables
        soup = BeautifulSoup(page['body']['view']['value'], 'html.parser')
        tables = soup.find_all('table')
        if tables:
            print(f"  Found {len(tables)} tables.")
            for i, tbl in enumerate(tables[:3]): # Check first 3 tables
                rows = tbl.find_all('tr')
                if rows:
                    headers = [th.get_text(strip=True) for th in rows[0].find_all(['th', 'td'])]
                    print(f"    Table {i+1} Headers: {headers[:10]}...")
        else:
            print("  No tables found.")

        # 2. Analyze Children (for ODM section)
        children = page.get('children', {}).get('page', {}).get('results', [])
        if children:
            print(f"  Found {len(children)} child pages.")
            print(f"  First 5 children: {[child['title'] for child in children[:5]]}")
        else:
            print("  No child pages found.")
            
    except Exception as e:
        print(f"  Error: {e}")

def main():
    config = load_config(Path("config.toml"))
    c = get_client(config)
    
    # 2. NPI Platform Status - Check Storage for Macros
    # probe_page(c, "414008847", "NPI Platform Status") 
    print("\n--- Probing NPI Status Storage ---")
    page = c.get_page_by_id("414008847", expand="body.storage")
    if page:
        storage = page['body']['storage']['value']
        print(f"Content Length: {len(storage)}")
        if "ac:name=\"jira\"" in storage: print("Found Jira Macro")
        if "ac:name=\"detailssummary\"" in storage: print("Found Page Properties Report (detailssummary)")
    
    # 4. ODM External Section - Probe Child (Compal)
    # The previous probe showed 'Compal Bios Section' is a child. We need to find ITS children.
    print("\n--- Probing Compal Logic ---")
    # First get ID of Compal Bios Section (by searching children of 251433709)
    parent = c.get_page_by_id("251433709", expand="children.page")
    compal_id = None
    for child in parent['children']['page']['results']:
        if "Compal" in child['title']:
            compal_id = child['id']
            break
            
    if compal_id:
        # Probe Compal Section's children (Specific Projects?)
        probe_page(c, compal_id, f"Compal Section ({compal_id})")
    else:
        print("Compal section not found.")

if __name__ == "__main__":
    main()
