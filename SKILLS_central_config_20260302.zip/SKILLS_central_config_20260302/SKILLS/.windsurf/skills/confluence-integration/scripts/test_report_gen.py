
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from confluence_tool import generate_meeting_report

# Mock PIMS data
mock_pims = [
    {
        "key": "PIMS-123",
        "platform_risk": "HIGH",
        "source": "SWDM",
        "status": "Blocked",
        "days_in_state": 10,
        "summary": "Critical Bug",
        "assignee": "Dev A"
    },
    {
        "key": "PIMS-456",
        "platform_risk": "LOW",
        "source": "List",
        "status": "In Progress",
        "days_in_state": 2,
        "summary": "Minor Bug",
        "assignee": "Dev B"
    }
]

# Mock client (not used in generation part heavily, but needed for signature)
class MockClient:
    pass

output_file = "test_report.md"
print(f"Testing generation to {output_file}...")
try:
    generate_meeting_report(MockClient(), mock_pims, output_file=output_file)
    if Path(output_file).exists():
        print("SUCCESS: File created.")
        with open(output_file, 'r', encoding='utf-8') as f:
            print(f"Content Preview:\n{f.read()[:200]}")
    else:
        print("FAILURE: File not created.")
except Exception as e:
    print(f"FAILURE: Exception {e}")
