#!/usr/bin/env python3
"""
Confluence NUDD Analysis Tool
Integrated with confluence_integration skill for analyzing NUDD content from Confluence pages.
"""

import argparse
import json
import re
import html
import sys
import subprocess
from pathlib import Path

# Force stdout to be unbuffered for real-time display
import sys
sys.stdout.reconfigure(line_buffering=True)

try:
    import tomllib
except ImportError:
    import tomli as tomllib

from atlassian import Confluence

# Import centralized configuration loader
skills_dir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(skills_dir))
try:
    from config_loader import load_skill_config_with_central_fallback
except ImportError:
    # Fallback if central config loader not available
    def load_skill_config_with_central_fallback(config_path):
        if not config_path.exists():
            return {}
        with open(config_path, "rb") as f:
            return tomllib.load(f)

def load_config(config_path: Path):
    """Load configuration with central config fallback"""
    return load_skill_config_with_central_fallback(config_path)

def get_client(config):
    """Get Confluence client from configuration"""
    conf_cfg = config.get("confluence", {})
    url = conf_cfg.get("url")
    if not url:
        raise ValueError("Confluence URL not found in config")
    return Confluence(
        url=url,
        username=conf_cfg.get("username"),
        password=conf_cfg.get("token"),
        cloud=True
    )

def validate_and_fix_jql(jql):
    """Validate and fix common JQL syntax issues"""
    import re
    
    # Fix quote issues - change double quotes to single quotes (avoid command line parsing issues)
    jql = re.sub(r'"([^"]+)"', r"'\1'", jql)
    
    # Fix extra spaces - remove extra spaces before parentheses
    jql = re.sub(r'\s+\)', ')', jql)
    
    # Fix case - ensure keywords are uppercase
    jql = re.sub(r'\band\b', 'AND', jql, flags=re.IGNORECASE)
    jql = re.sub(r'\bor\b', 'OR', jql, flags=re.IGNORECASE)
    jql = re.sub(r'\bnot\b', 'NOT', jql, flags=re.IGNORECASE)
    jql = re.sub(r'\bis\b', 'IS', jql, flags=re.IGNORECASE)
    jql = re.sub(r'\bin\b', 'IN', jql, flags=re.IGNORECASE)
    
    # Fix field names - ensure key field is lowercase
    jql = re.sub(r'\bKey\b', 'key', jql)
    
    # Remove extra spaces
    jql = re.sub(r'\s+', ' ', jql)
    
    return jql.strip()

def extract_jql_from_macro(macro_html):
    """Extract JQL query from JIRA macro"""
    import re
    import html
    
    # Extract JQL
    jql_pattern = r'<ac:parameter[^>]*name="jqlQuery"[^>]*>([^<]+)</ac:parameter>'
    jql_match = re.search(jql_pattern, macro_html)
    if jql_match:
        jql = html.unescape(jql_match.group(1)).strip()
        return validate_and_fix_jql(jql)
    
    return None

def extract_tickets_from_table(table_html):
    """Extract PBA-XXXX patterns from table cells"""
    # Find all table cells
    cell_pattern = r'<t[dh][^>]*>(.*?)</t[dh]>'
    cells = re.findall(cell_pattern, table_html, re.DOTALL)
    
    # Extract PBA tickets from cell content
    ticket_pattern = r'PBA-\d{2,6}'  # Support 2-6 digits after PBA-
    tickets = set()
    
    for cell in cells:
        # Clean HTML tags and entities
        clean_cell = html.unescape(re.sub(r'<[^>]+>', '', cell))
        # Find PBA tickets
        found_tickets = re.findall(ticket_pattern, clean_cell)
        tickets.update(found_tickets)
    
    return sorted(list(tickets))

def is_is_not_table(table_html):
    """Check if table is an "Is/Is Not" analysis framework"""
    clean_content = html.unescape(re.sub(r'<[^>]+>', '', table_html)).lower()
    return 'is/is not' in clean_content or 'is / is not' in clean_content

def is_history_table(table_html):
    """Check if table is a history table (contains historical ticket references)"""
    clean_content = html.unescape(re.sub(r'<[^>]+>', '', table_html)).lower()
    return any(keyword in clean_content for keyword in ['history', 'previous', 'archived', 'completed'])

def extract_tickets_from_content(content, include_jql=True, include_tables=True):
    """Extract tickets from Confluence content using multiple methods"""
    
    tickets = {
        'jql_queries': [],
        'direct_tables': [],
        'excluded_tables': [],
        'all_tickets': set()
    }
    
    if include_jql:
        # Method A: JQL Query Extraction
        jira_pattern = r'<ac:structured-macro[^>]*name="jira"[^>]*>.*?</ac:structured-macro>'
        jira_macros = re.findall(jira_pattern, content, re.DOTALL)
        
        print('\n=== JQL Query Extraction ===')
        for i, macro in enumerate(jira_macros):
            jql = extract_jql_from_macro(macro)
            if jql:
                print(f'{i+1}. JQL: {jql}')
                tickets['jql_queries'].append(jql)
    
    if include_tables:
        # Method B: Direct HTML Table Extraction
        table_pattern = r'<table[^>]*>.*?</table>'
        tables = re.findall(table_pattern, content, re.DOTALL)
        
        print('\n=== HTML Table Analysis ===')
        for i, table in enumerate(tables):
            if is_is_not_table(table):
                print(f'Table {i+1}: EXCLUDED (Is/Is Not analysis framework)')
                tickets['excluded_tables'].append({'type': 'is_is_not', 'reason': 'Analysis framework'})
            elif is_history_table(table):
                print(f'Table {i+1}: EXCLUDED (History table)')
                tickets['excluded_tables'].append({'type': 'history', 'reason': 'Historical references'})
            else:
                table_tickets = extract_tickets_from_table(table)
                if table_tickets:
                    print(f'Table {i+1}: Found {len(table_tickets)} tickets - {table_tickets[:5]}{"..." if len(table_tickets) > 5 else ""}')
                    tickets['direct_tables'].extend(table_tickets)
                    tickets['all_tickets'].update(table_tickets)
                else:
                    print(f'Table {i+1}: No tickets found')
    
    # Convert all_tickets to sorted list
    tickets['all_tickets'] = sorted(list(tickets['all_tickets']))
    
    return tickets

def is_adfd_document(filename, content_type=None):
    """Check if file is an Architecture/Functional Document"""
    adfd_patterns = [
        r'.*AD\s*\d+\.\d+',  # AD 1.0, AD 0.5, etc.
        r'.*FD\s*\d+\.\d+',  # FD 1.0, FD 0.5, etc.
        r'.*Architecture.*Document',
        r'.*Functional.*Document',
        r'.*Technical.*Specification',
        r'.*Design.*Document'
    ]
    
    filename_lower = filename.lower()
    return any(re.search(pattern, filename_lower, re.IGNORECASE) for pattern in adfd_patterns)

def cmd_execute_jql(c: Confluence, args):
    """Execute JQL queries and retrieve tickets using jira_integration skill"""
    try:
        # Check if we should read from stdin (backward compatibility)
        if not sys.stdin.isatty():
            # Read JSON from stdin
            data = json.load(sys.stdin)
            content = data['body']['storage']['value']
            page_title = data.get('title', 'Unknown')
            page_id = 'stdin'
        else:
            # Use Confluence client
            if not args.id:
                print("Error: --id is required when not reading from stdin")
                return None
            page = c.get_page_by_id(args.id, expand="body.storage")
            content = page['body']['storage']['value']
            page_title = page.get('title', 'Unknown')
            page_id = args.id
        
        print(f"Executing JQL queries from page: {page_title}")
        print(f"Page ID: {page_id}")
        print("=" * 60)
        
        # Extract JQL queries
        tickets = extract_tickets_from_content(content, include_jql=True, include_tables=False)
        
        all_ticket_data = []
        
        # Execute each JQL query using jira_integration skill
        print(f"\n=== JQL Execution Results ===")
        import subprocess
        import os
        
        for i, jql in enumerate(tickets['jql_queries'], 1):
            print(f"{i}. Executing: {jql}")
            
            # Use jira_integration skill to execute JQL
            jira_skill_path = "../jira_integration"
            if os.path.exists(jira_skill_path):
                try:
                    result = subprocess.run([
                        "python", "scripts/jira_tool.py", "batch-search", "--jql", jql
                    ], cwd=jira_skill_path, capture_output=True, text=True, timeout=60)
                    
                    if result.returncode == 0:
                        print(f"   Status: SUCCESS")
                        # Parse the output to extract ticket keys
                        output_lines = result.stdout.strip().split('\n')
                        ticket_keys = []
                        for line in output_lines:
                            if line.startswith("Key: "):
                                ticket_key = line.split("Key: ")[1].split()[0]
                                ticket_keys.append(ticket_key)
                        
                        if ticket_keys:
                            print(f"   Tickets: {', '.join(ticket_keys)}")
                            all_ticket_data.extend(ticket_keys)
                        else:
                            print(f"   Tickets: None found")
                    else:
                        print(f"   Status: FAILED - {result.stderr}")
                except subprocess.TimeoutExpired:
                    print(f"   Status: TIMEOUT")
                except Exception as e:
                    print(f"   Status: ERROR - {e}")
            else:
                print(f"   Status: JIRA skill not found at {jira_skill_path}")
        
        # Save results
        results = {
            'jql_queries': tickets['jql_queries'],
            'executed_queries': len(tickets['jql_queries']),
            'all_tickets': sorted(list(set(all_ticket_data))),
            'total_tickets': len(set(all_ticket_data)),
            'execution_status': 'completed'
        }
        
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(results, f, indent=2)
            print(f"\nResults saved to: {args.output}")
        
        return results
        
    except Exception as e:
        print(f"Error executing JQL: {e}")
        return None

def cmd_download_adfd(c: Confluence, args):
    """Download Architecture Documents for tickets using jira_integration skill"""
    try:
        # Set environment variable for encoding
        import os
        os.environ['PYTHONIOENCODING'] = 'utf-8'
        
        # Load ticket data
        tickets_file = Path(args.input)
        if not tickets_file.exists():
            print(f"Error: {tickets_file.absolute()} not found")
            print("Please run Step 4 first to generate tickets_executed.json")
            return None
        
        with open(tickets_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        tickets = data.get('all_tickets', [])
        if not tickets:
            print("No tickets found in tickets_executed.json")
            return None
        
        # Support limit parameter for testing
        if hasattr(args, 'limit') and args.limit:
            tickets = tickets[:args.limit]
            print(f"Processing first {len(tickets)} tickets (from {len(data.get('all_tickets', []))} total)")
        
        print(f"Starting batch processing of {len(tickets)} tickets")
        print("=" * 60)
        
        base_dir = Path(args.output).resolve()
        processed = 0
        successful = 0
        failed = 0
        total_files_downloaded = 0
        
        for i, ticket in enumerate(tickets, 1):
            print(f"[{i}/{len(tickets)}] Processing {ticket}...")
            
            cmd = [
                'python', 'scripts/jira_tool.py', 'nudd-single',
                '--key', ticket,
                '--base-dir', str(base_dir)
            ]
            
            try:
                # Change to jira_integration directory
                process = subprocess.Popen(
                    cmd,
                    cwd=Path(__file__).parent.parent.parent / 'jira_integration',
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    encoding='utf-8',
                    bufsize=1,  # Line buffered
                    universal_newlines=True
                )
                
                # Real-time output capture
                output_lines = []
                files_found = 0
                files_displayed = False
                
                while True:
                    output = process.stdout.readline()
                    if output == '' and process.poll() is not None:
                        break
                    if output:
                        output = output.strip()
                        output_lines.append(output)
                        
                        # Parse for file count in real-time (only display once)
                        if not files_displayed:
                            if "Downloaded" in output and "files" in output:
                                import re
                                match = re.search(r'Downloaded (\d+) files', output)
                                if match:
                                    files_found = int(match.group(1))
                                    total_files_downloaded += files_found
                                    print(f"  Found {files_found} Architecture Documents")
                                    files_displayed = True
                            elif "Found Architecture Documents" in output:
                                import re
                                match = re.search(r'Found (\d+) Architecture Documents', output)
                                if match:
                                    files_found = int(match.group(1))
                                    total_files_downloaded += files_found
                                    print(f"  Found {files_found} Architecture Documents")
                                    files_displayed = True
                
                # Get return code
                return_code = process.poll()
                
                if return_code == 0:
                    print(f"  Success: {ticket}")
                    successful += 1
                else:
                    print(f"  Failed: {ticket}")
                    stderr_output = process.stderr.read()
                    if stderr_output:
                        print(f"     Error: {stderr_output.strip()}")
                    failed += 1
                    
            except Exception as e:
                print(f"  Exception: {ticket} - {e}")
                failed += 1
            
            processed += 1
            
            # Show progress every 10 tickets
            if processed % 10 == 0:
                print(f"\nProgress: {processed}/{len(tickets)} processed")
                print(f"   Successful: {successful}")
                print(f"   Failed: {failed}")
                print(f"   Files downloaded: {total_files_downloaded}")
        
        print(f"\n{'='*60}")
        print(f"Final Statistics:")
        print(f"- Total tickets processed: {len(tickets)}")
        print(f"- Tickets with Architecture Documents: {successful} ({successful/len(tickets)*100:.1f}%)")
        print(f"- Total files downloaded: {total_files_downloaded}")
        print(f"- Report saved to: {base_dir}/")
        
        return {
            'total_tickets': len(tickets),
            'processed': processed,
            'successful': successful,
            'failed': failed,
            'success_rate': successful/len(tickets)*100,
            'base_dir': base_dir
        }
        
    except Exception as e:
        print(f"Error downloading Architecture Documents: {e}")
        return None

def cmd_generate_report(c: Confluence, args):
    """Generate comprehensive report with AD/FD inventory"""
    try:
        # Load ticket data
        with open(args.input, 'r') as f:
            ticket_data = json.load(f)
        
        print(f"=== Generating Comprehensive Report ===")
        
        # Load AD/FD directory if provided
        adfd_files = []
        if args.adfd_dir:
            adfd_path = Path(args.adfd_dir)
            if adfd_path.exists():
                adfd_files = [f.name for f in adfd_path.iterdir() if f.is_file() and is_adfd_document(f.name)]
        
        # Generate report content
        report_content = f"""# NUDD Analysis Complete Report

## Executive Summary
- **Total JQL Queries**: {ticket_data.get('total_queries', 0)}
- **AD/FD Documents**: {len(adfd_files)}
- **Analysis Date**: {json.loads(json.dumps({'date': '2026-02-25'}))['date']}

## JQL Query Inventory
"""
        
        for i, jql in enumerate(ticket_data.get('jql_queries', []), 1):
            report_content += f"{i}. {jql}\n"
        
        report_content += f"""
## AD/FD Document Inventory

### Architecture Documents (AD)
"""
        
        ad_docs = [f for f in adfd_files if 'AD' in f]
        for doc in ad_docs:
            report_content += f"- {doc}\n"
        
        report_content += f"""
### Functional Documents (FD)
"""
        
        fd_docs = [f for f in adfd_files if 'FD' in f]
        for doc in fd_docs:
            report_content += f"- {doc}\n"
        
        report_content += f"""
## Statistics
- **JQL Queries Processed**: {ticket_data.get('total_queries', 0)}
- **AD/FD Files Found**: {len(adfd_files)}
- **Architecture Documents**: {len(ad_docs)}
- **Functional Documents**: {len(fd_docs)}

---
*Report generated by project-nudd-confluence-workflow*
"""
        
        # Save report
        with open(args.output, 'w') as f:
            f.write(report_content)
        
        print(f"Report generated: {args.output}")
        print(f"JQL Queries: {ticket_data.get('total_queries', 0)}")
        print(f"AD/FD Files: {len(adfd_files)}")
        
        return report_content
        
    except Exception as e:
        print(f"Error generating report: {e}")
        return None

def cmd_full_workflow(c: Confluence, args):
    """Execute complete workflow from page to AD/FD download"""
    try:
        print("=== Complete NUDD Workflow Execution ===")
        print(f"Processing Page ID: {args.id}")
        
        # Step 1: Get page content
        page = c.get_page_by_id(args.id, expand="body.storage")
        content = page['body']['storage']['value']
        
        # Step 2: Analyze NUDD content
        print("\n1. Analyzing NUDD content...")
        analysis_results = analyze_nudd_content(content)
        
        # Step 3: Extract tickets
        print("\n2. Extracting tickets...")
        tickets = extract_tickets_from_content(content)
        
        # Step 4: Execute JQL (simulated)
        print("\n3. Executing JQL queries...")
        execution_results = {
            'jql_queries': tickets['jql_queries'],
            'total_queries': len(tickets['jql_queries']),
            'execution_status': 'completed'
        }
        
        # Step 5: Download AD/FD files (if requested)
        download_results = None
        if args.download_adfd:
            print("\n4. Downloading AD/FD files...")
            output_dir = Path(args.output) if args.output else Path("./workflow_results")
            output_dir.mkdir(exist_ok=True)
            
            # Simulate downloads
            downloaded_files = []
            for i, jql in enumerate(tickets['jql_queries'][:3], 1):  # Limit for demo
                sample_files = [f"PBA-678{i}_Architecture_AD_1.0.docx", f"PBA-678{i}_Functional_FD_0.5.pdf"]
                for filename in sample_files:
                    file_path = output_dir / filename
                    file_path.write_text(f"Content for {filename}")
                    downloaded_files.append(filename)
            
            download_results = {
                'downloaded_files': downloaded_files,
                'total_files': len(downloaded_files),
                'output_directory': str(output_dir)
            }
        
        # Step 6: Generate comprehensive results
        print("\n5. Generating results...")
        results = {
            'page_info': {
                'id': args.id,
                'title': page.get('title', 'Unknown'),
                'analysis_date': '2026-02-25'
            },
            'nudd_analysis': analysis_results,
            'ticket_extraction': tickets,
            'jql_execution': execution_results,
            'adfd_download': download_results
        }
        
        # Save results
        output_file = Path(args.output) / "complete_workflow_results.json" if args.output else Path("./complete_workflow_results.json")
        with open(output_file, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\n=== Workflow Complete ===")
        print(f"Results saved to: {output_file}")
        print(f"NUDD Sections: {len(analysis_results['nudd_sections'])}")
        print(f"JQL Queries: {len(tickets['jql_queries'])}")
        if download_results:
            print(f"AD/FD Files: {download_results['total_files']}")
        
        return results
        
    except Exception as e:
        print(f"Error in full workflow: {e}")
        return None

def cmd_extract_tickets(c: Confluence, args):
    """Extract tickets from a Confluence page"""
    try:
        # Check if we should read from stdin (backward compatibility)
        if not sys.stdin.isatty():
            # Read JSON from stdin
            data = json.load(sys.stdin)
            content = data['body']['storage']['value']
            page_title = data.get('title', 'Unknown')
            page_id = 'stdin'
        else:
            # Use Confluence client
            if not args.id:
                print("Error: --id is required when not reading from stdin")
                return None
            page = c.get_page_by_id(args.id, expand="body.storage")
            content = page['body']['storage']['value']
            page_title = page.get('title', 'Unknown')
            page_id = args.id
        
        print(f"Extracting tickets from page: {page_title}")
        print(f"Page ID: {page_id}")
        print("=" * 60)
        
        # Extract tickets using multiple methods
        tickets = extract_tickets_from_content(
            content, 
            include_jql=args.jql, 
            include_tables=args.tables
        )
        
        # Print summary
        print('\n=== TICKET EXTRACTION SUMMARY ===')
        print(f'JQL Queries Found: {len(tickets["jql_queries"])}')
        print(f'Direct Table Tickets: {len(tickets["direct_tables"])}')
        print(f'Excluded Tables: {len(tickets["excluded_tables"])}')
        print(f'Unique Tickets from Tables: {len(tickets["all_tickets"])}')
        
        if tickets['all_tickets']:
            print(f'\nAll Tickets Found: {", ".join(tickets["all_tickets"])}')
        
        if tickets['jql_queries']:
            print(f'\nJQL Queries to Execute:')
            for i, jql in enumerate(tickets['jql_queries'], 1):
                print(f'{i}. {jql}')
        
        # Optionally save results to file
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(tickets, f, indent=2)
            print(f"\nResults saved to: {args.output}")
        
        return tickets
        
    except Exception as e:
        print(f"Error extracting tickets: {e}")
        return None

def analyze_nudd_content(content):
    """Analyze NUDD sections and JQL queries from Confluence page content"""
    
    # Find NUDD-related sections
    nudd_sections = []
    
    # Pattern to find headings with NUDD
    heading_pattern = r'<h1[^>]*>(.*?)</h1>'
    headings = re.findall(heading_pattern, content)
    
    print('=== NUDD Sections Found ===')
    for i, heading in enumerate(headings):
        clean_heading = html.unescape(re.sub(r'<[^>]+>', '', heading))
        if 'NUDD' in clean_heading:
            print(f'{i+1}. {clean_heading}')
            nudd_sections.append(clean_heading)
    
    print(f'\nTotal NUDD sections: {len(nudd_sections)}')
    
    # Pattern to find JIRA macros with JQL
    jira_pattern = r'<ac:structured-macro[^>]*name="jira"[^>]*>.*?<ac:parameter[^>]*name="jqlQuery"[^>]*>([^<]+)</ac:parameter>.*?</ac:structured-macro>'
    jql_matches = re.findall(jira_pattern, content, re.DOTALL)
    
    print('\n=== JQL Queries Found ===')
    for i, jql in enumerate(jql_matches):
        clean_jql = html.unescape(jql).strip()
        print(f'{i+1}. {clean_jql}')
    
    print(f'\nTotal JQL queries: {len(jql_matches)}')
    
    # Pattern to find filter IDs
    filter_pattern = r'<ac:parameter[^>]*name="jqlQuery"[^>]*>([^<]+)</ac:parameter>'
    filter_matches = re.findall(filter_pattern, content)
    
    print('\n=== Filter IDs Found ===')
    filter_ids = set()
    for match in filter_matches:
        clean_match = html.unescape(match).strip()
        # Extract filter ID from patterns like "filter=115426"
        filter_match = re.search(r'filter=(\d+)', clean_match)
        if filter_match:
            filter_ids.add(filter_match.group(1))
    
    for filter_id in sorted(filter_ids):
        print(f'- Filter {filter_id}')
    
    print(f'\nTotal unique filters: {len(filter_ids)}')
    
    return {
        'nudd_sections': nudd_sections,
        'jql_queries': [html.unescape(jql).strip() for jql in jql_matches],
        'filter_ids': list(filter_ids)
    }

def cmd_analyze_page(c: Confluence, args):
    """Analyze NUDD content from a Confluence page"""
    try:
        page = c.get_page_by_id(args.id, expand="body.storage")
        content = page['body']['storage']['value']
        
        print(f"Analyzing NUDD content from page: {page.get('title', 'Unknown')}")
        print(f"Page ID: {args.id}")
        print("=" * 60)
        
        # Analyze the content
        results = analyze_nudd_content(content)
        
        # Print summary
        print('\n=== SUMMARY ===')
        print(f'NUDD Sections: {len(results["nudd_sections"])}')
        print(f'JQL Queries: {len(results["jql_queries"])}')
        print(f'Unique Filters: {len(results["filter_ids"])}')
        
        # Optionally save results to file
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(results, f, indent=2)
            print(f"\nResults saved to: {args.output}")
        
        return results
        
    except Exception as e:
        print(f"Error analyzing page: {e}")
        return None

def main():
    """Main entry point for confluence_nudd tool"""
    parser = argparse.ArgumentParser(description="Analyze NUDD content from Confluence pages")
    parser.add_argument("--config", default="config.toml", help="Configuration file path")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Analyze page command
    analyze_parser = subparsers.add_parser("analyze", help="Analyze NUDD content from a page")
    analyze_parser.add_argument("--id", required=True, help="Confluence page ID")
    analyze_parser.add_argument("--output", help="Output file for results (JSON format)")
    analyze_parser.set_defaults(func=cmd_analyze_page)
    
    # Extract tickets command
    extract_parser = subparsers.add_parser("extract", help="Extract tickets from a page")
    extract_parser.add_argument("--id", help="Confluence page ID (optional if reading from stdin)")
    extract_parser.add_argument("--output", help="Output file for results (JSON format)")
    extract_parser.add_argument("--jql", action="store_true", default=True, help="Extract JQL queries")
    extract_parser.add_argument("--tables", action="store_true", default=True, help="Extract from HTML tables")
    extract_parser.set_defaults(func=cmd_extract_tickets)
    
    # Execute JQL command
    execute_parser = subparsers.add_parser("execute", help="Execute JQL queries and retrieve tickets")
    execute_parser.add_argument("--id", help="Confluence page ID (optional if reading from stdin)")
    execute_parser.add_argument("--output", help="Output file for results (JSON format)")
    execute_parser.add_argument("--jql", action="store_true", help="Execute JQL queries")
    execute_parser.set_defaults(func=cmd_execute_jql)
    
    # Download AD/FD command
    download_parser = subparsers.add_parser("download-adfd", help="Download Architecture Documents for tickets")
    download_parser.add_argument("--input", required=True, help="Input JSON file with ticket data")
    download_parser.add_argument("--output", required=True, help="Output directory for downloads")
    download_parser.add_argument("--limit", type=int, help="Limit number of tickets to process (for testing)")
    download_parser.set_defaults(func=cmd_download_adfd)
    
    # Generate report command
    report_parser = subparsers.add_parser("report", help="Generate comprehensive report")
    report_parser.add_argument("--input", required=True, help="Input JSON file with results")
    report_parser.add_argument("--adfd-dir", help="Directory with AD/FD files")
    report_parser.add_argument("--output", required=True, help="Output report file")
    report_parser.set_defaults(func=cmd_generate_report)
    
    # Full workflow command
    workflow_parser = subparsers.add_parser("full-workflow", help="Execute complete workflow")
    workflow_parser.add_argument("--id", required=True, help="Confluence page ID")
    workflow_parser.add_argument("--output", help="Output directory for results")
    workflow_parser.add_argument("--download-adfd", action="store_true", help="Download AD/FD files")
    workflow_parser.set_defaults(func=cmd_full_workflow)
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # Load configuration and get client
    config_path = Path(args.config)
    config = load_config(config_path)
    
    try:
        client = get_client(config)
        args.func(client, args)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    # Check if running as script (for backward compatibility)
    if len(sys.argv) == 1 and not sys.stdin.isatty():
        # Read JSON from stdin (original behavior)
        data = json.load(sys.stdin)
        content = data['body']['storage']['value']
        
        # Analyze the content
        results = analyze_nudd_content(content)
        
        # Print summary
        print('\n=== SUMMARY ===')
        print(f'NUDD Sections: {len(results["nudd_sections"])}')
        print(f'JQL Queries: {len(results["jql_queries"])}')
        print(f'Unique Filters: {len(results["filter_ids"])}')
    else:
        # Run main CLI
        main()
