
import sys
import tomllib
from pathlib import Path
from atlassian import Confluence
from bs4 import BeautifulSoup

# Import centralized configuration loader
skills_dir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(skills_dir))
try:
    from config_loader import load_skill_config_with_central_fallback
except ImportError:
    # Fallback if central config loader not available
    def load_skill_config_with_central_fallback(config_path):
        if not config_path.exists():
            return {}
        with open(config_path, "rb") as f:
            return tomllib.load(f)

def load_config(config_path: Path):
    """Load configuration with central config fallback"""
    return load_skill_config_with_central_fallback(config_path)

def probe_page(page_id):
    config = load_config(Path("config.toml"))
    conf_cfg = config.get("confluence", {})
    c = Confluence(
        url=conf_cfg.get("url"),
        username=conf_cfg.get("username"),
        password=conf_cfg.get("password"),
        token=conf_cfg.get("token"),
        verify_ssl=conf_cfg.get("verify_ssl", True)
    )
    
    print(f"Fetching page {page_id} (view)...")
    page = c.get_page_by_id(page_id, expand="body.view")
    content = page.get('body', {}).get('view', {}).get('value', '')
    
    soup = BeautifulSoup(content, 'html.parser')
    tables = soup.find_all('table')
    
    print(f"Found {len(tables)} tables.")
    for i, tbl in enumerate(tables):
        headers = []
        rows = tbl.find_all('tr')
        if rows:
            headers = [th.get_text(strip=True) for th in rows[0].find_all(['th', 'td'])]
        print(f"Table {i+1} Headers: {headers}")

if __name__ == "__main__":
    probe_page(sys.argv[1])
