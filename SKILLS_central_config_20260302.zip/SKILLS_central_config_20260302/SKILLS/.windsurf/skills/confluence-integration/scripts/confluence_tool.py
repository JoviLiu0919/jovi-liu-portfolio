#!/usr/bin/env python3
"""
Confluence Tool
CLI for Confluence operations using atlassian-python-api.
Includes built-in macro generation capabilities.
"""

import argparse
import json
import sys
import uuid
import html
import re
import logging
import subprocess
from pathlib import Path
from typing import Optional, List, Dict, Union

try:
    import tomllib
except ImportError:
    import tomli as tomllib

from atlassian import Confluence

# Import centralized configuration loader
skills_dir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(skills_dir))
try:
    from config_loader import load_skill_config_with_central_fallback
except ImportError:
    # Fallback if central config loader not available
    def load_skill_config_with_central_fallback(config_path):
        if not config_path.exists():
            return {}
        with open(config_path, "rb") as f:
            return tomllib.load(f)

# Internal imports
try:
    from .confluence_macros import ConfluenceMacros
    from .confluence_parser import ConfluenceParser
except ImportError:
    # If run as a script directly
    from confluence_macros import ConfluenceMacros
    from confluence_parser import ConfluenceParser

# --- Confluence Tool Logic ---

def load_config(config_path: Path):
    """Load configuration with central config fallback"""
    return load_skill_config_with_central_fallback(config_path)

def get_client(config):
    conf_cfg = config.get("confluence", {})
    return Confluence(
        url=conf_cfg.get("url"),
        username=conf_cfg.get("username"),
        password=conf_cfg.get("password"),
        token=conf_cfg.get("token"),
        verify_ssl=conf_cfg.get("verify_ssl", True)
    )

def cmd_search(c: Confluence, args):
    results = c.get_all_pages_from_space(args.space, start=0, limit=args.limit)
    print(json.dumps(results, indent=2))

def should_use_storage_format(operation_type: str, format_param: str = None) -> str:
    """
    Smart format detection logic.
    Returns 'storage', 'view', or 'auto' based on operation type and parameters.
    """
    if format_param:
        return format_param.lower()
    
    storage_operations = ['macro', 'update', 'create', 'fix', 'inspect', 'grep']
    if any(op in operation_type.lower() for op in storage_operations):
        return 'storage'
    
    return 'view'  # Default to view format

def detect_macros_in_content(content: str) -> bool:
    """
    Detect if content contains Confluence macros that need storage format.
    Returns True if macros are detected.
    """
    macro_patterns = [
        r'<ac:structured-macro',
        r'<ri:page',
        r'<ac:parameter',
        r'<ac:rich-text-body',
        r'table-excerpt',
        r'view-file',
        r'code-block',
        r'info-panel',
        r'jira'
    ]
    
    for pattern in macro_patterns:
        if re.search(pattern, content, re.IGNORECASE):
            return True
    return False

def extract_page_id_from_url(url: str) -> Optional[str]:
    """
    Extract page ID from Confluence URL.
    Supports multiple URL formats:
    - https://confluence.cpg.dell.com/pages/1135567034/SKILLS+for+Windsurf+editor
    - https://confluence.cpg.dell.com/display/CBDSE/SKILLS+for+Windsurf+editor?pageId=1135567034
    - https://confluence.cpg.dell.com/wiki/pages/viewpage.action?pageId=1135567034
    """
    if not url:
        return None
    
    # Format 1: /pages/1135567034/title
    if "/pages/" in url:
        parts = url.split("/pages/")
        if len(parts) > 1:
            page_part = parts[1].split("/")[0]
            if page_part.isdigit():
                return page_part
    
    # Format 2: ?pageId=1135567034
    if "pageId=" in url:
        return url.split("pageId=")[1].split("&")[0]
    
    # Format 3: /wiki/pages/viewpage.action?pageId=1135567034
    if "/viewpage.action" in url and "pageId=" in url:
        return url.split("pageId=")[1].split("&")[0]
    
    return None

def get_page_with_smart_format(c: Confluence, page_id: str, operation_type: str = 'get', format_param: str = None):
    """
    Smart page retrieval that tries view format first, falls back to storage if needed.
    """
    # Determine initial format
    format_type = should_use_storage_format(operation_type, format_param)
    expand_param = f"body.{format_type}"
    
    try:
        page = c.get_page_by_id(page_id, expand=expand_param)
        if not page:
            return None
            
        # If using view format, check if we need storage format for macros
        if format_type == 'view':
            content = safe_get(page, 'body.view.value', "")
            if detect_macros_in_content(content) and operation_type in ['get', 'analyze']:
                print(f"Detected macros in page {page_id}, switching to storage format...", file=sys.stderr)
                # Retry with storage format
                page = c.get_page_by_id(page_id, expand="body.storage")
        
        return page
        
    except Exception as e:
        # If view format fails, try storage format as fallback
        if format_type == 'view':
            print(f"View format failed for page {page_id}, trying storage format: {e}", file=sys.stderr)
            return c.get_page_by_id(page_id, expand="body.storage")
        raise

def cmd_get(c: Confluence, args):
    # Check if input is a URL or page ID
    input_value = args.id
    page_id = None
    
    # Try to extract page ID from URL
    if input_value.startswith('http'):
        page_id = extract_page_id_from_url(input_value)
        if not page_id:
            print(f"ERROR: Could not extract page ID from URL: {input_value}", file=sys.stderr)
            sys.exit(1)
        print(f"Extracted page ID {page_id} from URL", file=sys.stderr)
    else:
        page_id = input_value
    
    page = get_page_with_smart_format(c, page_id, 'get', getattr(args, 'format', None))
    if page:
        print(json.dumps(page, indent=2))
    else:
        print(f"ERROR: Page {page_id} not found.", file=sys.stderr)
        sys.exit(1)

def cmd_create(c: Confluence, args):
    status = c.create_page(
        space=args.space,
        title=args.title,
        body=args.body,
        parent_id=args.parent_id,
        type='page',
        representation='storage'
    )
    print(json.dumps(status, indent=2))

# Safely get nested dict values.
def safe_get(obj, path, default=None):
    if not obj: return default
    keys = path.split('.')
    for k in keys:
        if isinstance(obj, dict):
            obj = obj.get(k)
        else:
            return default
    return obj if obj is not None else default

def cmd_update(c: Confluence, args):
    try:
        # First get the page to get the current version
        page = c.get_page_by_id(args.id)
        if not page:
             print(f"ERROR: Page {args.id} not found.", file=sys.stderr)
             sys.exit(1)
             
        title = args.title or page['title']
        status = c.update_page(
            page_id=args.id,
            title=title,
            body=args.body,
            parent_id=args.parent_id,
            type='page',
            representation='storage',
            minor_edit=args.minor
        )
        print(json.dumps(status, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to update page {args.id}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_clone(c: Confluence, args):
    try:
        # 1. Get source page
        print(f"Fetching source page {args.id}...", file=sys.stderr)
        source = c.get_page_by_id(args.id, expand='body.storage')
        if not source:
            print(f"ERROR: Source page {args.id} not found.", file=sys.stderr)
            sys.exit(1)
            
        # 2. Create new page
        print(f"Creating clone '{args.title}' in space '{args.space}'...", file=sys.stderr)
        new_page = c.create_page(
            space=args.space,
            title=args.title,
            body=source['body']['storage']['value'],
            parent_id=args.parent_id,
            representation='storage'
        )
        print(json.dumps(new_page, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to clone page: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_analyze_macros(c: Confluence, args):
    try:
        page = c.get_page_by_id(args.id, expand="body.storage")
        if not page:
            print(f"ERROR: Page {args.id} not found.", file=sys.stderr)
            sys.exit(1)
            
        body = safe_get(page, "body.storage.value", "")
        import re
        macros = re.findall(r'<ac:structured-macro [^>]*?ac:name="table-excerpt-include"[^>]*?>.*?</ac:structured-macro>', body, re.DOTALL)
        excerpts = re.findall(r'<ac:structured-macro [^>]*?ac:name="table-excerpt"[^>]*?>.*?</ac:structured-macro>', body, re.DOTALL)
        
        print(f"Found {len(macros)} table-excerpt-include macros:")
        for i, m in enumerate(macros):
            print(f"-- Include Macro {i+1} --")
            # Parse key details
            name_match = re.search(r'ac:name="name">(.*?)</ac:parameter>', m)
            page_match = re.search(r'ri:content-title="(.*?)"', m)
            space_match = re.search(r'ri:space-key="(.*?)"', m)
            
            excerpt_name = name_match.group(1) if name_match else "UNKNOWN"
            page_title = page_match.group(1) if page_match else "CURRENT_PAGE"
            space_key = space_match.group(1) if space_match else "CURRENT_SPACE"
            
            print(f"Excerpt Name: {excerpt_name}")
            print(f"Source Page: {page_title}")
            print(f"Source Space: {space_key}")
            print("XML Content:")
            print(m)
            print("----------------")

        print(f"\nFound {len(excerpts)} table-excerpt macros:")
        for i, m in enumerate(excerpts):
            print(f"-- Excerpt Macro {i+1} --")
            print(m)
            print("----------------")
    except Exception as e:
        print(f"ERROR: Failed to analyze macros for {args.id}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_fix_macros(c: Confluence, args):
    try:
        page = c.get_page_by_id(args.id, expand="body.storage")
        body = page.get("body", {}).get("storage", {}).get("value", "")
        
        import re
        
        def replace_macro(match):
            macro_content = match.group(0)
            
            target_space = "CSEI"
            target_title = "SWDM TODAY" # Default fallback
            
            # Extract excerpt name
            name_match = re.search(r'ac:name="name">(.*?)</ac:parameter>', macro_content)
            if name_match:
                excerpt_name = name_match.group(1)
                # content-title mapping based on analysis
                if excerpt_name == 'All_Status_Table':
                    target_title = 'NPI Platform Status'
                elif excerpt_name == 'Jarvis_Sustain_Status':
                    target_title = '00-ER Weekly report'
                elif excerpt_name == 'PIMS_Analyze_Pool':
                    target_title = 'PIMS Analyzer Raw Data'
            
            # Check if it already points to the correct place
            current_page_match = re.search(r'ri:content-title="(.*?)"', macro_content)
            if current_page_match and current_page_match.group(1) == target_title:
                return macro_content
            
            link_xml = f'<ac:parameter ac:name="page"><ac:link><ri:page ri:content-title="{target_title}" ri:space-key="{target_space}" /></ac:link></ac:parameter>'
            
            if '<ac:parameter ac:name="page">' in macro_content:
                macro_content = re.sub(r'<ac:parameter ac:name="page">.*?</ac:parameter>', link_xml, macro_content, flags=re.DOTALL)
            else:
                macro_content = macro_content.replace('</ac:structured-macro>', f'{link_xml}</ac:structured-macro>')
                
            return macro_content

        new_body = re.sub(r'<ac:structured-macro [^>]*?ac:name="table-excerpt-include"[^>]*?>.*?</ac:structured-macro>', replace_macro, body, flags=re.DOTALL)
        
        if new_body != body:
            c.update_page(args.id, page.get('title'), new_body, representation='storage', minor_edit=True)
            print(f"Fixed macros in page {args.id}")
        else:
            print(f"No macros needed fixing in page {args.id}")

    except Exception as e:
        print(f"ERROR: Failed to fix macros for {args.id}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_macro(c: Confluence, args):
    try:
        macros = ConfluenceMacros()
        method_name = args.name
        
        if not hasattr(macros, method_name):
            print(f"ERROR: Macro '{method_name}' not found.", file=sys.stderr)
            sys.exit(1)
            
        method = getattr(macros, method_name)
        
        if args.args:
            import json
            kwargs = json.loads(args.args)
        else:
            kwargs = {}
            
        result = method(**kwargs)
        print(result)
        
    except Exception as e:
        print(f"ERROR: Failed to generate macro '{args.name}': {e}", file=sys.stderr)
        sys.exit(1)

# Helper for Upsert Logic

def upsert_page(c: Confluence, space: str, title: str, body: str, parent_id: str = None, type: str = 'page', **kwargs):
    """
    Creates a page if it doesn't exist, or updates it if it does (by title).
    """
    try:
        # Check if exists
        page = c.get_page_by_title(space, title)
        if page:
            print(f"Updating existing page: '{title}' (ID: {page['id']})", file=sys.stderr)
            return c.update_page(
                page_id=page['id'],
                title=title,
                body=body,
                parent_id=parent_id,
                type=type,
                representation='storage',
                minor_edit=True
            )
        else:
            print(f"Creating new page: '{title}'", file=sys.stderr)
            return c.create_page(
                space=space,
                title=title,
                body=body,
                parent_id=parent_id,
                type=type,
                representation='storage'
            )
    except Exception as e:
        print(f"ERROR in upsert_page: {e}", file=sys.stderr)
        raise

def cmd_generate_test_page(c: Confluence, args):
    try:
        macros = ConfluenceMacros()
        html_blocks = []
        
        def add_demo(title, result):
            html_blocks.append(f"<h2>{title}</h2><div>{result}</div><hr/>")
            
        add_demo("Handy Tip", macros.add_handy_tip("tip1", "This is a useful tip for everyone."))
        add_demo("Status Macro", macros.add_status("COMPLETE", "Green"))
        add_demo("Jira Macro (JQL)", macros.add_jira_macro("project = CPSE AND status = 'In Progress'"))
        add_demo("Panel Macro", macros.add_panel_macro("This is an info panel.", panel_type="info", title="Info"))
        add_demo("Table Macro", macros.add_table(["Col A", "Col B"], [["Val1", "Val2"], ["Val3", "Val4"]]))
        add_demo("Pivot Table (Placeholder)", macros.add_pivot_table_macro("<table>...</table>", "Col A", "Col B", "Count"))
        
        full_body = "".join(html_blocks)
        
        status = upsert_page(c, args.space, args.title, full_body)
        print(json.dumps(status, indent=2))
        
    except Exception as e:
        print(f"ERROR: Failed to generate test page: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_comment(c: Confluence, args):
    try:
        status = c.add_comment(args.id, args.body)
        print(json.dumps(status, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to add comment to {args.id}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_upload_attachment(c: Confluence, args):
    try:
        file_path = Path(args.file)
        if not file_path.exists():
            print(f"ERROR: File not found: {args.file}", file=sys.stderr)
            sys.exit(1)
            
        print(f"Uploading {args.file} to page {args.id}...")
        status = c.attach_file(
            filename=str(file_path),
            page_id=args.id,
            title=args.name,
            comment=args.comment
        )
        print(json.dumps(status, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to upload attachment to {args.id}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_download_attachment(c: Confluence, args):
    try:
        attachments = c.get_attachments_from_content(args.id)
        target = None
        for a in attachments['results']:
            if a['title'] == args.filename:
                target = a
                break
        
        if not target:
            print(f"ERROR: Attachment '{args.filename}' not found on page {args.id}", file=sys.stderr)
            sys.exit(1)
            
        download_link = target['_links']['download']
        full_url = c.url + download_link
        
        print(f"Downloading {args.filename} from {full_url}...")
        response = c.session.get(full_url)
        response.raise_for_status()
        content = response.content
        
        out_path = Path(args.out) if args.out else Path(args.filename)
        out_path.write_bytes(content)
        print(f"Saved to {out_path}")
        
    except Exception as e:
        print(f"ERROR: Failed to download attachment: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_list_attachments(c: Confluence, args):
    try:
        attachments = c.get_attachments_from_content(args.id)
        for a in attachments['results']:
            print(f"Name: {a['title']}")
            print(f"ID: {a['id']}")
            print(f"Size: {a['extensions']['fileSize']} bytes")
            print(f"Type: {a['metadata']['mediaType']}")
            print(f"Download: {a['_links']['download']}")
            print("-" * 20)
    except Exception as e:
        print(f"ERROR: Failed to list attachments: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_verify_attachment_cycle(c: Confluence, args):
    import hashlib
    import os
    try:
        page_id = args.id
        test_filename = f"verify_cycle_{uuid.uuid4().hex[:8]}.bin"
        print(f"Starting Attachment Verification Cycle on Page {page_id}")
        
        # 1. Generate Random Data
        print(f"1. Generating random data for {test_filename}...")
        random_data = os.urandom(1024) # 1KB
        original_hash = hashlib.sha256(random_data).hexdigest()
        print(f"   Original Hash: {original_hash}")
        
        temp_upload_path = Path(test_filename)
        temp_upload_path.write_bytes(random_data)
        
        try:
            # 2. Upload
            print(f"2. Uploading {test_filename}...")
            c.attach_file(filename=str(temp_upload_path), page_id=page_id, title=test_filename, comment="Automated Verification")
            
            # 3. Download
            print(f"3. Searching for attachment to download...")
            attachments = c.get_attachments_from_content(page_id)
            target = None
            for a in attachments['results']:
                if a['title'] == test_filename:
                    target = a
                    break
            
            if not target:
                raise Exception("Uploaded attachment not found in list!")
                
            download_link = target['_links']['download']
            full_url = c.url + download_link
            print(f"4. Downloading from {full_url}...")
            
            response = c.session.get(full_url)
            response.raise_for_status()
            downloaded_content = response.content
            downloaded_hash = hashlib.sha256(downloaded_content).hexdigest()
            print(f"   Downloaded Hash: {downloaded_hash}")
            
            # 4. Compare
            if original_hash == downloaded_hash:
                print("SUCCESS: Hashes match. Attachment cycle verified.")
            else:
                print("FAILURE: Hashes do NOT match.")
                sys.exit(1)
                
        finally:
            # Cleanup temp file
            if temp_upload_path.exists():
                temp_upload_path.unlink()
                
    except Exception as e:
        print(f"ERROR: Verification cycle failed: {e}", file=sys.stderr)
        sys.exit(1)

# --- Scan Logic ---

def cmd_scan_dashboard(c: Confluence, args):
    """
    Scans a dashboard page for linked pages and analyzes their health.
    Uses view format for better performance on large pages.
    """
    try:
        print(f"Fetching dashboard {args.dashboard_id}...")
        format_type = should_use_storage_format('scan-dashboard')
        expand_param = f"body.{format_type}"
        page = c.get_page_by_id(args.dashboard_id, expand=expand_param)
        if not page:
            print(f"ERROR: Dashboard {args.dashboard_id} not found.", file=sys.stderr)
            sys.exit(1)
            
        if format_type == 'view':
            content = safe_get(page, 'body.view.value', "")
        else:
            content = safe_get(page, 'body.storage.value', "")
        
        # Extract Page Titles from <ri:page ri:content-title="...">
        titles = set(re.findall(r'ri:content-title="([^"]+)"', content))
        
        if args.filter:
            pattern = re.compile(args.filter)
            titles = {t for t in titles if pattern.search(t)}
            
        print(f"Found {len(titles)} linked pages: {titles}")
        
        results = {}
        
        for title in titles:
            print(f"\nAnalyzing Page: {title}...")
            
            # Resolve ID
            cql = f'title = "{title}"'
            search_res = c.cql(cql, limit=1)
            results_list = search_res.get('results', [])
            if not results_list:
                print(f"  [WARN] Could not find page '{title}'. Skipping.")
                continue

            page_id = safe_get(results_list[0], 'content.id') or results_list[0].get('id')
            if not page_id:
                print(f"  [WARN] Could not resolve ID for '{title}'. Skipping.")
                continue
                
            print(f"  Resolved ID: {page_id}")
            
            sub_page = c.get_page_by_id(page_id, expand='body.storage')
            if not sub_page:
                 results[title] = "ERROR"
                 continue
                 
            sub_content = safe_get(sub_page, 'body.storage.value', "")
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(sub_content, 'html.parser')
            
            # Use ConfluenceParser to check for non-green markers
            non_green_count = 0
            tables = soup.find_all('table')
            for tbl in tables:
                for row in tbl.find_all('tr'):
                    for cell in row.find_all(['td', 'th']):
                        status = ConfluenceParser.get_cell_status(cell)
                        if status['is_red'] or status['is_yellow']:
                            non_green_count += 1
                            
            if non_green_count == 0:
                results[title] = "OK"
                print("  Status: OK (All Green)")
            else:
                results[title] = f"ISSUES ({non_green_count})"
                print(f"  Status: ISSUES Found ({non_green_count})")

        # Summary
        print("\n\n=== Project Status Summary ===")
        for title, status in sorted(results.items()):
            print(f"{title}: {status}")

    except Exception as e:
        print(f"ERROR: Failed to scan dashboard: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_scan_pipeline(c: Confluence, args):
    """
    Scans SWDM pipeline page for PIMS issues and deep analyzes them using jira_tool.
    Uses view format for better performance on large pages.
    """
    try:
        from bs4 import BeautifulSoup
        
        print(f"1. Fetching dashboard {args.page_id}...")
        format_type = should_use_storage_format('scan-pipeline')
        expand_param = f"body.{format_type}"
        page = c.get_page_by_id(args.page_id, expand=expand_param)
        if not page:
             print(f"ERROR: Page {args.page_id} not found.", file=sys.stderr)
             sys.exit(1)
        
        if format_type == 'view':
            content = safe_get(page, 'body.view.value', "")
        else:
            content = safe_get(page, 'body.storage.value', "")
        soup = BeautifulSoup(content, 'html.parser')
        
        # 2. Find 'NPI Non-Green Table' using ConfluenceParser
        tbl_info = ConfluenceParser.find_table_by_headers(soup, ['platform', 'status'])
        
        if not tbl_info:
            print("ERROR: Could not find 'NPI Non-Green Table'.", file=sys.stderr)
            sys.exit(1)
            
        target_table = tbl_info['table']
        indices = tbl_info['indices']
        headers = tbl_info['headers']
        
        target_platform_idx = indices.get('platform', -1)
        target_bios_status_idx = -1
        target_sw_status_idx = -1
        target_bios_reason_idx = -1
        target_sw_reason_idx = -1
        
        for idx, h in enumerate(headers):
            if 'bios' in h and 'status' in h: target_bios_status_idx = idx
            elif 'sw' in h and 'status' in h: target_sw_status_idx = idx
            if 'bios' in h and ('reason' in h or 'remark' in h or 'manager' in h): target_bios_reason_idx = idx
            elif 'sw' in h and ('reason' in h or 'remark' in h or 'manager' in h): target_sw_reason_idx = idx

        print(f"Found Target Table.")
        platform_results = []
        
        # 3. Iterate rows
        rows = target_table.find_all('tr')
        for row in rows[1:]:
            cells = row.find_all(['td', 'th'])
            if len(cells) <= max(target_platform_idx, target_bios_status_idx, target_sw_status_idx):
                continue
                
            platform_name = cells[target_platform_idx].get_text(strip=True)
            
            # Capture BIOS and SW Status using ConfluenceParser
            bios_data = ConfluenceParser.get_cell_status(cells[target_bios_status_idx] if target_bios_status_idx != -1 else None)
            sw_data = ConfluenceParser.get_cell_status(cells[target_sw_status_idx] if target_sw_status_idx != -1 else None)
            
            if not bios_data['is_green'] or not sw_data['is_green']:
                print(f"\n[!] Non-Green Project Found: {platform_name} (BIOS: {bios_data['color']}, SW: {sw_data['color']})")
                
                bios_links = ConfluenceParser.extract_links(cells[target_bios_reason_idx] if target_bios_reason_idx != -1 else None)
                sw_links = ConfluenceParser.extract_links(cells[target_sw_reason_idx] if target_sw_reason_idx != -1 else None)
                
                platform_pims_data = {"bios": [], "sw": []}
                
                if not bios_data['is_green']:
                    for link in bios_links:
                        if "Issue Manager" in link:
                            print(f"    -> Crawling BIOS Issue Manager: {link}")
                            res = analyze_issue_manager(c, link)
                            if res: platform_pims_data["bios"].extend(res.get("bios", []))
                
                if not sw_data['is_green']:
                    for link in sw_links:
                        if "Issue Manager" in link:
                            print(f"    -> Crawling SW Issue Manager: {link}")
                            res = analyze_issue_manager(c, link)
                            if res: platform_pims_data["sw"].extend(res.get("sw", []))

                # Risk Analysis Logic
                risk_level = "LOW"
                risk_reasons = []
                
                if bios_data['is_red']:
                    risk_level = "HIGH"
                    risk_reasons.append("BIOS Status is RED")
                elif bios_data['is_yellow']:
                    risk_level = "MEDIUM"
                    risk_reasons.append("BIOS Status is YELLOW")
                    
                if sw_data['is_red']:
                    risk_level = "HIGH"
                    risk_reasons.append("SW Status is RED")
                elif sw_data['is_yellow'] and risk_level != "HIGH":
                    risk_level = "MEDIUM"
                    risk_reasons.append("SW Status is YELLOW")
                
                all_pims = platform_pims_data["bios"] + platform_pims_data["sw"]
                for p in all_pims:
                    p_st = p.get('status', '').lower()
                    if any(kw in p_st for kw in ['stuck', 'blocked', 'fail', 'error', 'hold']):
                        risk_level = "HIGH"
                        risk_reasons.append(f"PIMS {p['key']} is {p['status']}")
                
                platform_results.append({
                    "platform": platform_name,
                    "bios_status": bios_data['text'],
                    "bios_color": bios_data['color'],
                    "sw_status": sw_data['text'],
                    "sw_color": sw_data['color'],
                    "pims": platform_pims_data,
                    "risk": risk_level,
                    "risk_desc": "; ".join(risk_reasons) if risk_reasons else "None"
                })

        if not platform_results:
            print("\nNo Non-Green projects found to report.")
            return

        print("\n\n" + "="*80)
        print(" SWDM TODAY SUMMARY REPORT")
        print("="*80 + "\n")
        
        print("| Platform | BIOS | SW | Risk | BIOS PIMS | SW PIMS |")
        print("|---|---|---|---|---|---|")
        
        def format_pims(plist):
            summary = []
            for p in plist:
                p_link = f"[{p['key']}](https://jira.cpg.dell.com/browse/{p['key']})"
                summary.append(f"{p_link}: {p['status']} ({p['assignee']})")
            return "<br>".join(summary) if summary else "None"

        for res in platform_results:
            bios_pims_col = format_pims(res['pims']['bios'])
            sw_pims_col = format_pims(res['pims']['sw'])
            risk_desc = res['risk_desc'].replace('|', '-')
            print(f"| **{res['platform']}** | {res['bios_color']}<br><small>{res['bios_status']}</small> | {res['sw_color']}<br><small>{res['sw_status']}</small> | **{res['risk']}**<br><small>{risk_desc}</small> | {bios_pims_col} | {sw_pims_col} |")

        print("\n" + "="*80)
        
        # Actionable Categorization
        focus_today = []
        stuck_items = []
        moving_items = []
        
        for res in platform_results:
            is_platform_critical = (res['risk'] == 'HIGH')
            
            all_pims = res['pims']['bios'] + res['pims']['sw']
            for p in all_pims:
                status = p.get('status', 'Unknown')
                days = p.get('days_in_state', 0)
                
                # Logic for Categorization
                # 1. Focus Today: Critical, Blocked, or Long delay
                if is_platform_critical or \
                   any(kw in status.lower() for kw in ['fail', 'error', 'block', 'hold', 'stuck']) or \
                   days > 7:
                    p['reason'] = f"Status: {status}, Days: {days}, Platform Risk: {res['risk']}"
                    focus_today.append(p)
                # 2. Stuck Items: Moderate delay
                elif days > 3:
                     p['reason'] = f"Days: {days}"
                     stuck_items.append(p)
                # 3. Moving
                else:
                     moving_items.append(p)
                     
        print("\n\n=== MEETING PREP ACTIONS ===")
        
        def print_category(title, items):
            print(f"\n### {title} ({len(items)})")
            if not items:
                print("None")
                return
            print(f"| Key | Summary | Assignee | Status | Days | Reason |")
            print(f"|---|---|---|---|---|---|")
            for i in items:
                summary = i.get('summary', '')[:50] + "..."
                print(f"| [{i['key']}](https://jira.cpg.dell.com/browse/{i['key']}) | {summary} | {i['assignee']} | {i['status']} | {i['days_in_state']} | {i.get('reason','')} |")

        print_category("FOCUS TODAY (Critical / Red Project / >7 Days / Blocked)", focus_today)
        print_category("STUCK ITEMS (>3 Days in State)", stuck_items)
        print_category("MOVING (Active)", moving_items)


    except Exception as e:
         import traceback
         traceback.print_exc()
         print(f"ERROR: Failed to scan pipeline: {e}", file=sys.stderr)
         sys.exit(1)

def parse_swdm_dashboard(c, page_id):
    """
    Parses SWDM metrics page and returns list of PIMS dictionaries.
    """
    from bs4 import BeautifulSoup
    pims_list = []
    
    print(f"Fetching SWDM Dashboard {page_id}...")
    page = c.get_page_by_id(page_id, expand="body.view")
    if not page: return []
    
    content = safe_get(page, 'body.view.value', "")
    soup = BeautifulSoup(content, 'html.parser')
    
    tbl_info = ConfluenceParser.find_table_by_headers(soup, ['platform', 'status'])
    if not tbl_info: return []
    
    target_table = tbl_info['table']
    indices = tbl_info['indices']
    headers = tbl_info['headers']
    
    target_platform_idx = indices.get('platform', -1)
    target_bios_status_idx = -1
    target_sw_status_idx = -1
    target_bios_reason_idx = -1
    target_sw_reason_idx = -1
    
    for idx, h in enumerate(headers):
        if 'bios' in h and 'status' in h: target_bios_status_idx = idx
        elif 'sw' in h and 'status' in h: target_sw_status_idx = idx
        if 'bios' in h and ('reason' in h or 'remark' in h or 'manager' in h): target_bios_reason_idx = idx
        elif 'sw' in h and ('reason' in h or 'remark' in h or 'manager' in h): target_sw_reason_idx = idx

    rows = target_table.find_all('tr')
    for row in rows[1:]:
        cells = row.find_all(['td', 'th'])
        if len(cells) <= max(target_platform_idx, target_bios_status_idx, target_sw_status_idx): continue
            
        platform_name = cells[target_platform_idx].get_text(strip=True)
        bios_data = ConfluenceParser.get_cell_status(cells[target_bios_status_idx] if target_bios_status_idx != -1 else None)
        sw_data = ConfluenceParser.get_cell_status(cells[target_sw_status_idx] if target_sw_status_idx != -1 else None)
        
        # Determine Platform Risk
        platform_risk = "LOW"
        if bios_data['is_red'] or sw_data['is_red']: platform_risk = "HIGH"
        elif (bios_data['is_yellow'] or sw_data['is_yellow']) and platform_risk != "HIGH": platform_risk = "MEDIUM"
        
        # If Non-Green, crawl Issue Managers
        if not bios_data['is_green'] or not sw_data['is_green']:
             # Crawl lists
             to_crawl = []
             if not bios_data['is_green']:
                 to_crawl.extend(ConfluenceParser.extract_links(cells[target_bios_reason_idx] if target_bios_reason_idx != -1 else None))
             if not sw_data['is_green']:
                 to_crawl.extend(ConfluenceParser.extract_links(cells[target_sw_reason_idx] if target_sw_reason_idx != -1 else None))
             
             for link in to_crawl:
                 if "Issue Manager" in link:
                     res = analyze_issue_manager(c, link)
                     if res:
                         for p in res.get("bios", []) + res.get("sw", []):
                             p['platform_risk'] = platform_risk
                             p['source'] = f"SWDM: {platform_name}"
                             pims_list.append(p)
                             
    return pims_list

def parse_pims_list_page(c, page_id):
    """
    Parses Table 4 (PIMS_Key) from the BSE PIMS list page.
    """
    from bs4 import BeautifulSoup
    pims_list = []
    
    print(f"Fetching PIMS List Page {page_id}...")
    page = c.get_page_by_id(page_id, expand="body.view")
    if not page: return []
    
    content = safe_get(page, 'body.view.value', "")
    soup = BeautifulSoup(content, 'html.parser')
    
    # Logic: Find table with 'PIMS_Key' in header
    tables = soup.find_all('table')
    target_table = None
    key_idx = -1
    
    candidate_table = None
    candidate_key_idx = -1
    
    for tbl in tables:
        rows = tbl.find_all('tr')
        if not rows: continue
        headers = [th.get_text(strip=True).lower() for th in rows[0].find_all(['th', 'td'])]
        
        for i, h in enumerate(headers):
            h_clean = h.lower().replace("_", "").replace(" ", "")
            if 'pimskey' in h_clean:
                # High priority match
                target_table = tbl
                key_idx = i
                break
            elif 'jiraticket' in h_clean and not candidate_table:
                # Lower priority candidate
                candidate_table = tbl
                candidate_key_idx = i
                
        if target_table: break
        
    if not target_table and candidate_table:
        target_table = candidate_table
        key_idx = candidate_key_idx
    
    if not target_table:
        print("  [WARN] Could not find table with 'PIMS_Key' header.")
        return []
        
    rows = target_table.find_all('tr')
    print(f"  Found PIMS Table with {len(rows)-1} rows.")
    
    import re
    for row in rows[1:]:
        cells = row.find_all(['td', 'th'])
        if len(cells) <= key_idx: continue
        
        cell_text = cells[key_idx].get_text(strip=True)
        # Extract PIMS-XXXX
        keys = re.findall(r'PIMS-\d+', cell_text)
        for k in keys:
            # We fetch details later, just store key for now
            pims_list.append({
                "key": k,
                "platform_risk": "MEDIUM", # Default for manual list
                "source": "BSE Watchlist"
            })
            
    return pims_list

def generate_meeting_report(c, pims_candidates, output_file=None):
    """
    Take a list of candidates, fetch stats, bucketize, and print/save report.
    """
    # Deduplicate by Key
    unique_map = {}
    for p in pims_candidates:
        k = p['key']
        if k not in unique_map:
            unique_map[k] = p
        else:
            # Merge info: if existing is High risk, keep it. Append source.
            if p['platform_risk'] == 'HIGH': unique_map[k]['platform_risk'] = 'HIGH'
            unique_map[k]['source'] += f", {p['source']}"

    print(f"\nAnalyzing {len(unique_map)} unique PIMS tickets...")
    
    analyzed_pims = []
    for k, data in unique_map.items():
        print(f"  Fetching stats for {k}...", end='\r')
        details = fetch_pims_details(k)
        if details:
            details.update(data) # Add risk/source info
            analyzed_pims.append(details)
        else:
            # Fallback if fetch fails
            data.update({"status": "Unknown", "summary": "Fetch Failed", "assignee": "?", "days_in_state": 0})
            analyzed_pims.append(data)
            
    print(f"  Analysis Complete.                    \n")
    
    # Categorization
    focus_today = []
    stuck_items = []
    moving_items = []
    
    for p in analyzed_pims:
        status = p.get('status', 'Unknown')
        days = p.get('days_in_state', 0)
        risk = p.get('platform_risk', 'LOW')
        
        # Logic matches previous agreed rules
        is_critical = (risk == 'HIGH')
        
        if is_critical or \
           any(kw in status.lower() for kw in ['fail', 'error', 'block', 'hold', 'stuck']) or \
           days > 7:
            p['reason'] = f"St: {status}, Day: {days}, Risk: {risk}"
            focus_today.append(p)
        elif days > 3:
             p['reason'] = f"Days: {days}"
             stuck_items.append(p)
        else:
             moving_items.append(p)
             
    lines = []
    lines.append("\n" + "="*80)
    lines.append(" === MEETING PREP SUMMARY REPORT ===")
    lines.append("="*80)
    
    def add_category(title, items):
        lines.append(f"\n### {title} ({len(items)})")
        if not items:
            lines.append("None")
            return
        lines.append(f"| Key | Summary | Assignee | Status | Days | Source | Reason |")
        lines.append(f"|---|---|---|---|---|---|---|")
        for i in items:
            summary = i.get('summary', '')[:40] + "..."
            src = i.get('source', '')[:20]
            lines.append(f"| [{i['key']}](https://jira.cpg.dell.com/browse/{i['key']}) | {summary} | {i['assignee']} | {i['status']} | {i['days_in_state']} | {src} | {i.get('reason','')} |")

    add_category("FOCUS TODAY (Critical / Red Project / >7 Days / Blocked)", focus_today)
    add_category("STUCK ITEMS (>3 Days in State)", stuck_items)
    add_category("MOVING (Active)", moving_items)
    
    if output_file:
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write("\n".join(lines))
            print(f"\n[SUCCESS] Report saved to {output_file}")
            print(f"Summary: {len(focus_today)} Focus, {len(stuck_items)} Stuck, {len(moving_items)} Moving.")
        except Exception as e:
            print(f"\n[ERROR] Failed to write report to {output_file}: {e}")
            # Fallback output
            for l in lines: print(l)
    else:
        for l in lines: print(l)


# -----------------------------------------------------------------------------
# PROJECT INTELLIGENCE HUB
# -----------------------------------------------------------------------------

def parse_npi_status_page(c, page_id):
    """
    Parses NPI Platform Status (414008847) to extract Projects and Status.
    Heuristic: Look for Status Macros (Red/Yellow/Green) and find associated Project Name in the same row/block.
    """
    from bs4 import BeautifulSoup
    projects = []
    
    print(f"Fetching NPI Status Page {page_id}...")
    page = c.get_page_by_id(page_id, expand="body.view")
    if not page: return []
    
    soup = BeautifulSoup(page['body']['view']['value'], 'html.parser')
    
    # Strategy: Find all elements with class capable of holding a status
    # Standard Confluence Status macro in view is usually a span with inner text
    # But often it's easiest to look for the 'tr' if it's a table, or block if not.
    # Probe said "No tables found" but that might be due to nested divs.
    # Let's try to find text-based status pattern or the status macro span.
    
    # Heuristic 1: Look for table rows explicitly again (just in case probe missed them due to loading)
    # If no tables, we fall back to finding 'span' with style color/bg.
    
    rows = soup.find_all('tr')
    if rows:
        print(f"  Found {len(rows)} rows (Table layout detected).")
        for row in rows:
            text = row.get_text(" ", strip=True)
            # Simple extractor: Project Name is usually column 1 or 2.
            cells = row.find_all(['td', 'th'])
            if len(cells) < 2: continue
            
            # Extract Project Name (Col 0 usually)
            proj_name = cells[0].get_text(strip=True)
            if not proj_name or len(proj_name) > 50: continue # Noise filter
            
            # Detect Status in the row
            status = "GREEN" # Default
            row_html = str(row).lower()
            if "status-macro" in row_html:
                if "red" in row_html: status = "RED"
                elif "yellow" in row_html: status = "YELLOW"
            elif "color: red" in row_html or "color:red" in row_html:
                status = "RED"
            elif "{red}" in text: # Text marker fallback
                status = "RED"
                
            projects.append({"name": proj_name, "status": status})
    else:
        print("  No table rows found. Trying to parse blocks.")
        # Fallback: scan for specific keywords if unstructured
        # This is a placeholder since we believe there SHOULD be a structure.
        pass
        
    print(f"  Extracted {len(projects)} projects.")
    return projects

def find_odm_project_page_cql(c, project_name):
    """
    Deep Research: Find ODM Project Page using CQL.
    Target: Ancestor = 251433709 (External User Section) AND Text ~ ProjectName
    """
    cql = f'ancestor = 251433709 AND title ~ "{project_name}"'
    results = c.cql(cql, limit=1)
    if results.get('results'):
        # CQL return format: {'results': [{'content': {'id': '123', ...}, ...}]}
        item = results['results'][0]
        if 'content' in item:
            return item['content']
        return item # Sometimes it returns direct object depending on API version
    return None

def fetch_odm_jira_link(c, page_id):
    """
    Parses a specific ODM Project Page to find 'Jira_BIOS' link.
    """
    page = c.get_page_by_id(page_id, expand="body.view")
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(page['body']['view']['value'], 'html.parser')
    
    # 1. Search for link with text "Jira_BIOS"
    for a in soup.find_all('a'):
        if a.get_text() and "Jira_BIOS" in a.get_text():
            return a.get('href')
            
    # 2. Search for 'page-properties' table row key 'Jira_BIOS'
    # (Simplified View Parser)
    for tr in soup.find_all('tr'):
        if "Jira_BIOS" in tr.get_text():
            links = tr.find_all('a')
            if links: return links[0].get('href')
            
    return None

def cmd_scan_project_hub(c: Confluence, args):
    try:
        # 1. Get Projects
        projects = parse_npi_status_page(c, args.npi_id)
        
        results = []
        print("\n=== Project Intelligence Scan ===")
        
        for p in projects:
            name = p['name']
            status = p['status']
            
            # INTELLIGENT BRANCHING
            if status in ['RED', 'YELLOW']:
                print(f"[RED/YELLOW] [{status}] {name} -> Deep Research triggered.")
                
                # Deep Research: Find ODM Page
                odm_page = find_odm_project_page_cql(c, name)
                odm_info = "ODM Page Not Found"
                jira_link = None
                
                if odm_page:
                    odm_info = f"Found: {odm_page['title']}"
                    # Drill Down
                    jira_link = fetch_odm_jira_link(c, odm_page['id'])
                
                results.append({
                    "name": name,
                    "status": status,
                    "action": "DEEP_SCAN",
                    "odm_page": odm_info,
                    "jira_link": jira_link or "Not Found"
                })
                
            else:
                # Green
                # print(f"🟢 [{status}] {name} -> Monitoring.")
                results.append({
                    "name": name,
                    "status": status,
                    "action": "MONITOR",
                    "note": "Regular check"
                })

        # Output
        print("\n=== Scan Results ===")
        lines = []
        lines.append("| Project | Status | Action | ODM Info | Jira |")
        lines.append("|---|---|---|---|---|")
        for r in results:
            if r['status'] == 'GREEN': continue # Compress output for now
            lines.append(f"| {r['name']} | {r['status']} | {r['action']} | {r.get('odm_page','')} | {r.get('jira_link','')} |")
            
        for l in lines: print(l)
        
        # Save if requested
        output_file = getattr(args, 'output', None)
        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write("\n".join(lines))
            print(f"Saved to {output_file}")

    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"ERROR: {e}")

# -----------------------------------------------------------------------------

def cmd_scan_meeting_prep(c: Confluence, args):
    try:
        all_pims = []
        
        # 1. Scan SWDM
        if args.swdm_page_id:
            swdm_pims = parse_swdm_dashboard(c, args.swdm_page_id)
            all_pims.extend(swdm_pims)
            print(f"Found {len(swdm_pims)} PIMS from SWDM.")
            
        # 2. Scan PIMS List
        if args.pims_list_page_id:
            list_pims = parse_pims_list_page(c, args.pims_list_page_id)
            all_pims.extend(list_pims)
            print(f"Found {len(list_pims)} PIMS from List Page.")
            
        # 3. Generate Report
        output = getattr(args, 'output', None)
        generate_meeting_report(c, all_pims, output_file=output)
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"ERROR: Meeting Prep Scan failed: {e}", file=sys.stderr)
        sys.exit(1)


def analyze_issue_manager(c, page_title):
    """
    Analyzes Issue Manager page and returns a list of PIMS data objects.
    """
    from bs4 import BeautifulSoup
    
    # Resolve ID
    cql = f'title = "{page_title}"'
    search_res = c.cql(cql, limit=1)
    results = search_res.get('results', [])
    if not results:
        print(f"      [Error] Could not find page '{page_title}'.")
        return {"bios": [], "sw": []}

    page_id = safe_get(results[0], 'content.id') or results[0].get('id')
    if not page_id:
        print(f"      [Error] Could not resolve ID for '{page_title}'.")
        return {"bios": [], "sw": []}
    
    # Fetch content
    page = c.get_page_by_id(page_id, expand="body.view")
    if not page: return {"bios": [], "sw": []}
    content = safe_get(page, 'body.view.value', "")
    soup = BeautifulSoup(content, 'html.parser')
    
    pims_data = {"bios": [], "sw": []}
    expands = soup.find_all('div', class_='expand-container')
    
    pims_list_count = 0
    for block in expands:
        control = block.find(['span', 'div'], class_='expand-control-text')
        if not control: continue
        
        title = control.get_text(strip=True)
        if "PIMS List" not in title: continue
        
        pims_list_count += 1
        pims_type = None
        if "BIOS" in title: pims_type = "bios"
        elif "SW" in title: pims_type = "sw"
        
        if not pims_type:
            if pims_list_count == 1: pims_type = "bios"
            elif pims_list_count == 2: pims_type = "sw"
        
        if pims_type:
            content_div = block.select_one('.expand-content, .expand-content-active') or block
            found = re.findall(r'PIMS-\d+', content_div.get_text())
            for pid in sorted(list(set(found))):
                details = fetch_pims_details(pid)
                if details: pims_data[pims_type].append(details)
    
    return pims_data

def fetch_pims_details(pims_id):
    """Helper to fetch PIMS details from jira_tool."""
    jira_tool = Path(__file__).parent.parent.parent / "jira_integration" / "scripts" / "jira_tool.py"
    if not jira_tool.exists(): return None
    
    try:
        # Use analyze-pims instead of get to fetch stats
        cmd = [sys.executable, str(jira_tool), "analyze-pims", "--key", pims_id]
        res = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8')
        if res.returncode == 0:
            data = json.loads(res.stdout)
            # Check for error in response
            if "error" in data:
                 return {"key": pims_id, "status": "Error", "summary": f"Check Failed: {data['error']}", "assignee": "Unknown", "days_in_state": 0}
            
            raw_summary = data.get('summary')
            if raw_summary is None: raw_summary = "N/A"
            summary = str(raw_summary).replace('|', '-')
            if len(summary) > 60: summary = summary[:57] + "..."
            
            return {
                "key": pims_id,
                "status": data.get('status', 'Unknown'),
                "assignee": data.get('assignee', 'Unassigned'),
                "summary": summary,
                "days_in_state": data.get('days_in_state', 0)
            }
    except:
        pass
    return None

def cmd_inspect_macro(c: Confluence, args):
    try:
        page = c.get_page_by_id(args.id, expand='body.storage')
        if not page:
             print(f"ERROR: Page {args.id} not found.", file=sys.stderr)
             sys.exit(1)
             
        content = safe_get(page, 'body.storage.value', "")
        macro_name = args.name
        pattern = rf'(<ac:structured-macro[^>]+ac:name="{re.escape(macro_name)}"[^>]*>.*?</ac:structured-macro>)'
        matches = re.findall(pattern, content, re.DOTALL)
        
        if not matches:
            print(f"No instances of macro '{macro_name}' found.")
        else:
            print(f"Found {len(matches)} instance(s):")
            for i, match in enumerate(matches, 1):
                print(f"\n--- Instance {i} ---\n{match}\n" + "-"*40)
    except Exception as e:
        print(f"ERROR: Failed to inspect macro: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_grep_page(c: Confluence, args):
    try:
        page = c.get_page_by_id(args.id, expand='body.storage')
        if not page:
            print(f"ERROR: Page {args.id} not found.", file=sys.stderr)
            sys.exit(1)
            
        content = safe_get(page, 'body.storage.value', "")
        matches = []
        for match in re.finditer(args.pattern, content, re.IGNORECASE if args.ignore_case else 0):
            start = max(0, match.start() - 50)
            end = min(len(content), match.end() + 50)
            matches.append((match.start(), content[start:end]))
            
        print(f"Found {len(matches)} matches.")
        for pos, context in matches:
            print(f"Position {pos}: ...{context}...")
    except Exception as e:
        print(f"ERROR: Grep failed: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_analyze_health(c: Confluence, args):
    try:
        page = c.get_page_by_id(args.id, expand='body.storage')
        content = safe_get(page, 'body.storage.value', "")
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(content, 'html.parser')
        
        tables = soup.find_all('table')
        results = []
        for i, tbl in enumerate(tables):
            non_green = 0
            for row in tbl.find_all('tr'):
                for cell in row.find_all(['td', 'th']):
                    st = ConfluenceParser.get_cell_status(cell)
                    if not st['is_green']: non_green += 1
            results.append({"table": i+1, "non_green": non_green})
        
        print(json.dumps(results, indent=2))
    except Exception as e:
        print(f"ERROR: Health analysis failed: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_cql_search(c: Confluence, args):
    """
    Search using CQL (Confluence Query Language).
    """
    try:
        results = c.cql(args.query, limit=args.limit)
        # cql returns a dict with 'results' list, similar to search but structure might slightly differ
        # We print the raw results for the caller to parse, or standardize.
        # The existing tools expect JSON output.
        print(json.dumps(results, indent=2))
    except Exception as e:
        print(f"ERROR: CQL search failed: {e}", file=sys.stderr)
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="Confluence Tool")
    parser.add_argument("--config", default="config.toml", help="Path to config file")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Core commands
    p_search = subparsers.add_parser("search", help="Search pages in space")
    p_search.add_argument("--space", required=True, help="Space key")
    p_search.add_argument("--limit", type=int, default=10, help="Limit results")

    p_cql_search = subparsers.add_parser("cql-search", help="Search using CQL")
    p_cql_search.add_argument("--query", required=True, help="CQL Query")
    p_cql_search.add_argument("--limit", type=int, default=10, help="Limit results")

    p_get = subparsers.add_parser("get", help="Get page by ID or URL")
    p_get.add_argument("--id", required=True, help="Page ID or full Confluence URL")
    p_get.add_argument("--format", choices=['view', 'storage'], help="Format type (default: smart detection)")

    p_create = subparsers.add_parser("create", help="Create a new page")
    p_create.add_argument("--space", required=True, help="Space key")
    p_create.add_argument("--title", required=True, help="Page title")
    p_create.add_argument("--body", required=True, help="Page body (storage format)")
    p_create.add_argument("--parent-id", help="Parent page ID")

    p_update = subparsers.add_parser("update", help="Update an existing page")
    p_update.add_argument("--id", required=True, help="Page ID")
    p_update.add_argument("--body", required=True, help="New page body")
    p_update.add_argument("--title", help="New page title")
    p_update.add_argument("--parent-id", help="New parent ID")
    p_update.add_argument("--minor", action="store_true", help="Minor edit")

    p_clone = subparsers.add_parser("clone", help="Clone a page")
    p_clone.add_argument("--id", required=True, help="Source Page ID")
    p_clone.add_argument("--space", required=True, help="Target Space")
    p_clone.add_argument("--title", required=True, help="New Title")
    p_clone.add_argument("--parent-id", help="New Parent ID")

    p_comment = subparsers.add_parser("comment", help="Add comment to page")
    p_comment.add_argument("--id", required=True, help="Page ID")
    p_comment.add_argument("--body", required=True, help="Comment body")

    # Scan/Analysis commands
    p_scan_dash = subparsers.add_parser("scan-dashboard", help="Scan dashboard for status")
    p_scan_dash.add_argument("--dashboard-id", required=True, help="Dashboard Page ID")
    p_scan_dash.add_argument("--filter", help="Regex to filter Page Titles")

    p_scan_pipe = subparsers.add_parser("scan-pipeline", help="Scan SWDM pipeline page")
    p_scan_pipe.add_argument("--page-id", default="410290793", help="SWDM TODAY Page ID")

    p_health = subparsers.add_parser("analyze-health", help="Analyze health indices")
    p_health.add_argument("--id", required=True, help="Page ID")

    p_analyze_macros = subparsers.add_parser("analyze-macros", help="Analyze macros on a page")
    p_analyze_macros.add_argument("--id", required=True, help="Page ID")

    p_inspect_macro = subparsers.add_parser("inspect-macro", help="Inspect XML of a specific macro")
    p_inspect_macro.add_argument("--id", required=True, help="Page ID")
    p_inspect_macro.add_argument("--name", required=True, help="Macro Name")

    p_grep = subparsers.add_parser("grep-page", help="Grep page content")
    p_grep.add_argument("--id", required=True, help="Page ID")
    p_grep.add_argument("--pattern", required=True, help="Regex Pattern")
    p_grep.add_argument("--ignore-case", action="store_true", help="Case insensitive")

    p_fix_macros = subparsers.add_parser("fix-macros", help="Fix broken macros")
    p_fix_macros.add_argument("--id", required=True, help="Page ID")

    # Attachment commands
    p_upload = subparsers.add_parser("upload", help="Upload attachment")
    p_upload.add_argument("--id", required=True, help="Page ID")
    p_upload.add_argument("--file", required=True, help="Local file path")
    p_upload.add_argument("--name", help="Attachment name")
    p_upload.add_argument("--comment", help="Upload comment")

    p_download = subparsers.add_parser("download", help="Download attachment")
    p_download.add_argument("--id", required=True, help="Page ID")
    p_download.add_argument("--filename", required=True, help="Attachment filename")
    p_download.add_argument("--out", help="Output path")

    p_list_attach = subparsers.add_parser("list-attachments", help="List page attachments")
    p_list_attach.add_argument("--id", required=True, help="Page ID")

    p_verify_cycle = subparsers.add_parser("verify-attachment-cycle", help="Verify attachment cycle")
    p_verify_cycle.add_argument("--id", required=True, help="Page ID")

    # MEETING PREP
    p_meet_prep = subparsers.add_parser("scan-meeting-prep", help="Scan meeting preparation data")
    p_meet_prep.add_argument("--swdm-page-id", default="410290793", help="SWDM Dashboard Page ID")
    p_meet_prep.add_argument("--pims-list-page-id", default="1089398828", help="PIMS List Page ID")
    p_meet_prep.add_argument("--output", help="Output file path (e.g. report.md)")

    # PROJECT HUB
    p_proj_hub = subparsers.add_parser("scan-project-hub", help="Scan Project Intelligence Hub sources")
    p_proj_hub.add_argument("--npi-id", default="414008847", help="NPI Platform Status Page ID")
    p_proj_hub.add_argument("--output", help="Output file path")


    # Macro generation
    p_macro = subparsers.add_parser("macro", help="Generate macro XML")
    p_macro.add_argument("--name", required=True, help="Macro method name")
    p_macro.add_argument("--args", help="JSON string of arguments")

    p_gen_test = subparsers.add_parser("generate-test-page", help="Generate a macro demo page")
    p_gen_test.add_argument("--space", required=True, help="Space")
    p_gen_test.add_argument("--title", default="Macro Test Page", help="Title")

    args = parser.parse_args()
    config = load_config(Path(args.config))
    client = get_client(config)

    cmd_map = {
        "search": cmd_search,
        "cql-search": cmd_cql_search,
        "get": cmd_get,
        "create": cmd_create,
        "update": cmd_update,
        "clone": cmd_clone,
        "comment": cmd_comment,
        "scan-dashboard": cmd_scan_dashboard,
        "scan-pipeline": cmd_scan_pipeline,
        "analyze-health": cmd_analyze_health,
        "analyze-macros": cmd_analyze_macros,
        "inspect-macro": cmd_inspect_macro,
        "grep-page": cmd_grep_page,
        "fix-macros": cmd_fix_macros,
        "upload": cmd_upload_attachment,
        "download": cmd_download_attachment,
        "list-attachments": cmd_list_attachments,
        "verify-attachment-cycle": cmd_verify_attachment_cycle,
        "macro": cmd_macro,
        "macro": cmd_macro,
        "generate-test-page": cmd_generate_test_page,
        "scan-meeting-prep": cmd_scan_meeting_prep,
        "scan-project-hub": cmd_scan_project_hub
    }

    if args.command in cmd_map:
        cmd_map[args.command](client, args)

if __name__ == "__main__":
    main()
