
import uuid
import html
import re
import sys
import logging
from typing import Optional, List, Dict, Union

class ConfluenceMacros:
    def __init__(self):
        # Configure logging to stderr to avoid polluting stdout (which is used for JSON output)
        logging.basicConfig(level=logging.WARNING, stream=sys.stderr)

    def check_html_special_character(self, data: Optional[Union[str, int]], replace_newlines: bool = True) -> Optional[str]:
        if data is None:
            return None
        data_str = str(data)
        # Remove invalid XML 1.0 characters
        invalid_xml_chars_pattern = re.compile(u'[^\t\n\r -\ud7ff\u2000-\uFFFD\U00010000-\U0010FFFF]+')
        updated_data = invalid_xml_chars_pattern.sub('', data_str)
        # Escape HTML special characters
        updated_data = html.escape(updated_data)
        # Replace ']]>' with ']]&gt;'
        updated_data = updated_data.replace(']]>', ']]&gt;')
        # Handle newlines if enabled
        if replace_newlines:
            updated_data = updated_data.replace("\r\n", "<br />\n")
            updated_data = updated_data.replace("\r", "<br />\n")
            updated_data = updated_data.replace("\n", "<br />\n")
        return updated_data

    def add_handy_tip(self, tip_id: str, message: str) -> str:
        macro_id = str(uuid.uuid4())
        tip_id = self.check_html_special_character(tip_id, replace_newlines=False)
        message = self.check_html_special_character(message, replace_newlines=True)
        return (
            f'<p><a href="#handytip-{tip_id}">Handy tip {tip_id}</a></p>'
            f'<ac:structured-macro ac:name="handy-tip" ac:schema-version="1" ac:macro-id="{macro_id}">'
            f'<ac:parameter ac:name="id">{tip_id}</ac:parameter>'
            f'<ac:parameter ac:name="atlassian-macro-output-type">INLINE</ac:parameter>'
            f'<ac:rich-text-body><p>{message}</p></ac:rich-text-body>'
            f'</ac:structured-macro><p><br /></p>'
        )

    def add_status(self, title: str, colour: Optional[str] = None) -> str:
        macro_id = str(uuid.uuid4())
        title = self.check_html_special_character(title, replace_newlines=False)
        colour_param = f'<ac:parameter ac:name="colour">{self.check_html_special_character(colour, replace_newlines=False)}</ac:parameter>' if colour else ''
        return (
            f'<p><ac:structured-macro ac:name="status" ac:schema-version="1" ac:macro-id="{macro_id}">'
            f'{colour_param}'
            f'<ac:parameter ac:name="title">{title}</ac:parameter>'
            f'</ac:structured-macro></p>'
        )

    def add_inline_status(self, title: str, colour: Optional[str] = None) -> str:
        macro_id = str(uuid.uuid4())
        title = self.check_html_special_character(title, replace_newlines=False)
        colour_param = f'<ac:parameter ac:name="colour">{self.check_html_special_character(colour, replace_newlines=False)}</ac:parameter>' if colour else ''
        return (
            f'<ac:structured-macro ac:name="status" ac:schema-version="1" ac:macro-id="{macro_id}">'
            f'{colour_param}'
            f'<ac:parameter ac:name="title">{title}</ac:parameter>'
            f'</ac:structured-macro>'
        )

    def add_time(self, datetime: str) -> str:
        datetime = self.check_html_special_character(datetime, replace_newlines=False)
        return f'<p><time datetime="{datetime}" /></p>'

    def add_link(self, text: str, suffix: Optional[str] = None) -> str:
        text = self.check_html_special_character(text, replace_newlines=False)
        suffix = self.check_html_special_character(suffix, replace_newlines=False) if suffix else ''
        return f'<p><ac:link><ac:plain-text-link-body><![CDATA[{text}]]></ac:plain-text-link-body></ac:link>{suffix}</p>'

    def add_internal_page_link(self, page_title: str, link_text: str = '') -> str:
        page_title = self.check_html_special_character(page_title, replace_newlines=False)
        link_text = self.check_html_special_character(link_text or page_title, replace_newlines=False)
        return (
            f'<ac:link><ri:page ri:content-title="{page_title}" />'
            f'<ac:plain-text-link-body><![CDATA[{link_text}]]></ac:plain-text-link-body></ac:link>'
        )

    def add_external_link(self, url: str, text: str) -> str:
        url = self.check_html_special_character(url, replace_newlines=False)
        text = self.check_html_special_character(text, replace_newlines=False)
        return f'<a href="{url}">{text}</a>'

    def add_task_list(self, tasks: List[Dict[str, str]]) -> str:
        task_items = '<ac:task-list>'
        for task in tasks:
            task_id = self.check_html_special_character(task.get('id', ''), replace_newlines=False)
            status = self.check_html_special_character(task.get('status', ''), replace_newlines=False)
            body = self.check_html_special_character(task.get('body', ''), replace_newlines=False)
            task_items += (
                f'<ac:task>'
                f'<ac:task-id>{task_id}</ac:task-id>'
                f'<ac:task-status>{status}</ac:task-status>'
                f'<ac:task-body><span class="placeholder-inline-tasks">{body}</span></ac:task-body>'
                f'</ac:task>'
            )
        task_items += '</ac:task-list>'
        return f'{task_items}<p><br /></p>'

    def add_tabs_container(self, tabs_pages_html: str, direction: str = 'horizontal') -> str:
        macro_id = str(uuid.uuid4())
        direction = self.check_html_special_character(direction, replace_newlines=False)
        return (
            f'<ac:structured-macro ac:name="auitabs" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'<ac:parameter ac:name="direction">{direction}</ac:parameter>'
            f'<ac:rich-text-body>{tabs_pages_html}<p><br /></p></ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_tab_page(self, title: str, content: str) -> str:
        macro_id = str(uuid.uuid4())
        title = self.check_html_special_character(title, replace_newlines=False)
        return (
            f'<ac:structured-macro ac:name="auitabspage" ac:schema-version="1" ac:macro-id="{macro_id}">'
            f'<ac:parameter ac:name="title">{title}</ac:parameter>'
            f'<ac:rich-text-body>{content}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_table(self, headers: List[Union[str, Dict]], rows: List[List[Union[str, Dict]]], colgroup: Optional[List[str]] = None) -> str:
        colgroup_html = '<colgroup>' + ''.join(f'<col {width}/>' for width in colgroup) + '</colgroup>' if colgroup else ''
        table_html_inner = f'{colgroup_html}<tbody><tr>'
        for header in headers:
            if isinstance(header, dict):
                text = self.check_html_special_character(header.get('text', ''), replace_newlines=False)
                highlight = header.get('highlight_colour')
                title = header.get('title', '')
                header_content = text if text else '<br />'
                if highlight:
                    table_html_inner += f'<th class="highlight-{highlight}" data-highlight-colour="{highlight}" scope="col" title="{title}">{header_content}</th>'
                else:
                    table_html_inner += f'<th scope="col">{header_content}</th>'
            else:
                header = self.check_html_special_character(header, replace_newlines=False)
                table_html_inner += f'<th scope="col">{header if header else "<br />"}</th>'
        table_html_inner += '</tr>'
        for row in rows:
            table_html_inner += '<tr>'
            for cell in row:
                if isinstance(cell, dict):
                    text = self.check_html_special_character(cell.get('text', ''), replace_newlines=False)
                    highlight = cell.get('highlight_colour')
                    format_tags = cell.get('format', [])
                    title = cell.get('title', '')
                    cell_content = text if text else '<br />'
                    for tag in format_tags:
                        cell_content = f'<{tag}>{cell_content}</{tag}>'
                    if highlight:
                        table_html_inner += f'<td class="highlight-{highlight}" data-highlight-colour="{highlight}" title="{title}">{cell_content}</td>'
                    else:
                        table_html_inner += f'<td>{cell_content}</td>'
                else:
                    cell = self.check_html_special_character(cell, replace_newlines=False)
                    table_html_inner += f'<td>{cell if cell else "<br />"}</td>'
            table_html_inner += '</tr>'
        table_html_inner += '</tbody>'

        macro_id = str(uuid.uuid4())
        return (
            f'<ac:structured-macro ac:name="table" ac:schema-version="1" ac:macro-id="{macro_id}">'
            f'<ac:rich-text-body><table>{table_html_inner}</table></ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_unordered_list(self, items: List[str]) -> str:
        list_html = '<ul>'
        for item in items:
            item = self.check_html_special_character(item, replace_newlines=False)
            list_html += f'<li>{item}</li>'
        list_html += '</ul>'
        return f'{list_html}<p><br /></p>'

    def add_ordered_list(self, items: List[str]) -> str:
        list_html = '<ol>'
        for item in items:
            item = self.check_html_special_character(item, replace_newlines=False)
            list_html += f'<li>{item}</li>'
        list_html += '</ol>'
        return f'{list_html}<p><br /></p>'

    def add_emoticon(self, name: str, emoji_id: str, suffix: Optional[str] = None) -> str:
        name = self.check_html_special_character(name, replace_newlines=False)
        emoji_id = self.check_html_special_character(emoji_id, replace_newlines=False)
        suffix = self.check_html_special_character(suffix, replace_newlines=False) if suffix else ''
        return f'<p><ac:emoticon ac:name="{name}" ac:emoji-id="{emoji_id}" /> {suffix}</p>'

    def add_layout_section(self, content: str, section_type: str = 'single') -> str:
        section_type = self.check_html_special_character(section_type, replace_newlines=False)
        return f'<ac:layout-section ac:type="{section_type}">{content}</ac:layout-section>'

    def add_layout_cell(self, content: str) -> str:
        return f'<ac:layout-cell>{content}</ac:layout-cell>'

    def add_panel_macro(self, content: str, panel_type: str = 'info', title: str = '', raw_content: bool = False) -> str:
        macro_id = str(uuid.uuid4())
        title = self.check_html_special_character(title, replace_newlines=False)
        if raw_content:
            body_content = content
        else:
            sanitized_content = self.check_html_special_character(content, replace_newlines=True)
            body_content = f"<p>{sanitized_content}</p>"
        title_param = f'<ac:parameter ac:name="title">{title}</ac:parameter>' if title else ''
        return (
            f'<ac:structured-macro ac:name="{panel_type}" ac:schema-version="1" ac:macro-id="{macro_id}">'
            f'{title_param}'
            f'<ac:rich-text-body>{body_content}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_jira_macro(self, jql: str, server: str = 'Dell CPG JIRA', count: str = 'true', server_id: str = '5f961f0c-c1b1-3fb6-b1d9-1bec3b410d6d') -> str:
        macro_id = str(uuid.uuid4())
        jql = self.check_html_special_character(jql, replace_newlines=False)
        server = self.check_html_special_character(server, replace_newlines=False)
        server_id = self.check_html_special_character(server_id, replace_newlines=False)
        count = self.check_html_special_character(count, replace_newlines=False)
        return (
            f'<ac:structured-macro ac:name="jira" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'<ac:parameter ac:name="server">{server}</ac:parameter>'
            f'<ac:parameter ac:name="serverId">{server_id}</ac:parameter>'
            f'<ac:parameter ac:name="jqlQuery">{jql}</ac:parameter>'
            f'<ac:parameter ac:name="count">{count}</ac:parameter>'
            f'</ac:structured-macro>'
        )

    def add_content_by_label_macro(self, labels: str, operator: str = 'AND', delimiter: str = "‚") -> str:
        macro_id = str(uuid.uuid4())
        labels = self.check_html_special_character(labels, replace_newlines=False)
        operator = self.check_html_special_character(operator, replace_newlines=False)
        return (
            f'<ac:structured-macro ac:name="content-by-label" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'<ac:parameter ac:name="labels">{labels}</ac:parameter>'
            f'<ac:parameter ac:name="operator">{operator}</ac:parameter>'
            f'</ac:structured-macro>'
        )

    def add_pivot_table_macro(self, data_source_macro: str, row_fields: str, column_fields: str, aggregation_type: str, title: str = '', hide_total: bool = False, hide_pane: bool = False, delimiter: str = "‚") -> str:
        macro_id = str(uuid.uuid4())
        title = self.check_html_special_character(title, replace_newlines=False)
        row_fields = self.check_html_special_character(row_fields, replace_newlines=False)
        column_fields = self.check_html_special_character(column_fields, replace_newlines=False)
        aggregation_type = self.check_html_special_character(aggregation_type, replace_newlines=False)
        hide_total_param = 'true' if hide_total else 'false'
        hide_pane_param = 'true' if hide_pane else 'false'
        title_param = f'<ac:parameter ac:name="title">{title}</ac:parameter>' if title else ''
        return (
            f'<ac:structured-macro ac:name="pivot-table" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'{title_param}'
            f'<ac:parameter ac:name="row">{row_fields}</ac:parameter>'
            f'<ac:parameter ac:name="column">{column_fields}</ac:parameter>'
            f'<ac:parameter ac:name="type">{aggregation_type}</ac:parameter>'
            f'<ac:parameter ac:name="hideTotal">{hide_total_param}</ac:parameter>'
            f'<ac:parameter ac:name="hidePane">{hide_pane_param}</ac:parameter>'
            f'<ac:rich-text-body>{data_source_macro}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_details_macro(self, content: str) -> str:
        macro_id = str(uuid.uuid4())
        return (
            f'<ac:structured-macro ac:name="details" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'<ac:rich-text-body><p>{content}</p></ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_table_filter_macro(self, content: str, **kwargs) -> str:
        macro_id = str(uuid.uuid4())
        params = ''.join(
            f'<ac:parameter ac:name="{self.check_html_special_character(k, replace_newlines=False)}">'
            f'{self.check_html_special_character(v, replace_newlines=False)}</ac:parameter>'
            for k, v in kwargs.items()
        )
        return (
            f'<ac:structured-macro ac:name="table-filter" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'{params}'
            f'<ac:rich-text-body>{content}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_table_excerpt_macro(self, name: str, content: str) -> str:
        macro_id = str(uuid.uuid4())
        name = self.check_html_special_character(name, replace_newlines=False)
        return (
            f'<ac:structured-macro ac:name="table-excerpt" ac:schema-version="1" ac:macro-id="{macro_id}">'
            f'<ac:parameter ac:name="name">{name}</ac:parameter>'
            f'<ac:rich-text-body>{content}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_table_excerpt_include_macro(self, name: str, page_title: str = '', is_first_time_enter: bool = True, v: int = 2, transpose: str = 'never', type: str = 'page') -> str:
        macro_id = str(uuid.uuid4())
        name = self.check_html_special_character(name, replace_newlines=False)
        page_param = f'<ac:parameter ac:name="page"><ac:link><ri:page ri:content-title="{page_title}" /></ac:link></ac:parameter>' if page_title else '<ac:parameter ac:name="page"><ac:link /></ac:parameter>'
        return (
            f'<p><ac:structured-macro ac:name="table-excerpt-include" ac:schema-version="1" ac:macro-id="{macro_id}">'
            f'<ac:parameter ac:name="isFirstTimeEnter">{"true" if is_first_time_enter else "false"}</ac:parameter>'
            f'<ac:parameter ac:name="v">{v}</ac:parameter>'
            f'<ac:parameter ac:name="name">{name}</ac:parameter>'
            f'{page_param}'
            f'<ac:parameter ac:name="transpose">{transpose}</ac:parameter>'
            f'<ac:parameter ac:name="type">{type}</ac:parameter>'
            f'</ac:structured-macro></p>'
        )

    def add_table_joiner_macro(self, content: str, source: str, target: str, source_field: str, target_field: str) -> str:
        macro_id = str(uuid.uuid4())
        source = self.check_html_special_character(source, replace_newlines=False)
        target = self.check_html_special_character(target, replace_newlines=False)
        source_field = self.check_html_special_character(source_field, replace_newlines=False)
        target_field = self.check_html_special_character(target_field, replace_newlines=False)
        return (
            f'<ac:structured-macro ac:name="table-joiner" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'<ac:parameter ac:name="source">{source}</ac:parameter>'
            f'<ac:parameter ac:name="target">{target}</ac:parameter>'
            f'<ac:parameter ac:name="sourceField">{source_field}</ac:parameter>'
            f'<ac:parameter ac:name="targetField">{target_field}</ac:parameter>'
            f'<ac:rich-text-body>{content}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_table_transformer_macro(self, sql: str, content: str) -> str:
        macro_id = str(uuid.uuid4())
        sql = self.check_html_special_character(sql, replace_newlines=False)
        return (
            f'<ac:structured-macro ac:name="table-joiner" ac:schema-version="1" ac:macro-id="{macro_id}">'
            f'<ac:parameter ac:name="sql">{sql}</ac:parameter>'
            f'<ac:rich-text-body>{content}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_html_bobswift_macro(self, content: str) -> str:
        macro_id = str(uuid.uuid4())
        return (
            f'<ac:structured-macro ac:name="html-bobswift" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'<ac:rich-text-body>{content}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_html_macro(self, content: str) -> str:
        macro_id = str(uuid.uuid4())
        return (
            f'<ac:structured-macro ac:name="html" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'<ac:rich-text-body>{content}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_expand_macro(self, title: str, content: str) -> str:
        macro_id = str(uuid.uuid4())
        title = self.check_html_special_character(title, replace_newlines=False)
        return (
            f'<ac:structured-macro ac:name="expand" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'<ac:parameter ac:name="title">{title}</ac:parameter>'
            f'<ac:rich-text-body>{content}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_attachments_macro(self, upload: bool = True, sort_by: str = "date", sort_order: str = "descending") -> str:
        """
        Adds the Attachments macro to list files on the page.
        """
        macro_id = str(uuid.uuid4())
        return (
            f'<ac:structured-macro ac:name="attachments" ac:schema-version="1" ac:macro-id="{macro_id}">'
            f'<ac:parameter ac:name="upload">{"true" if upload else "false"}</ac:parameter>'
            f'<ac:parameter ac:name="sortBy">{sort_by}</ac:parameter>'
            f'<ac:parameter ac:name="sortOrder">{sort_order}</ac:parameter>'
            f'</ac:structured-macro>'
        )

    def add_view_file_macro(self, filename: str) -> str:
        """
        Adds the View File macro to preview an attachment on the page.
        """
        macro_id = str(uuid.uuid4())
        filename = self.check_html_special_character(filename, replace_newlines=False)
        return (
            f'<ac:structured-macro ac:name="view-file" ac:schema-version="1" ac:macro-id="{macro_id}">'
            f'<ac:parameter ac:name="name">'
            f'<ri:attachment ri:filename="{filename}" />'
            f'</ac:parameter>'
            f'</ac:structured-macro>'
        )


    def add_label_macro(self, labels: str) -> str:
        macro_id = str(uuid.uuid4())
        labels = self.check_html_special_character(labels, replace_newlines=False)
        return (
            f'<ac:structured-macro ac:name="add-label" ac:schema-version="1" ac:macro-id="{macro_id}">'
            f'<ac:parameter ac:name="labels">{labels}</ac:parameter>'
            f'</ac:structured-macro>'
        )

    def add_bar_chart_macro(self, data: List[List], title: str, data_orientation: str = 'Vertical', column: str = '', colors: str = "#f691b2,#69a6f9,#8cc3e9,#6ada6a,#8eb021,#d04437,#3572b0,#f6c342,#654982,#2484c1,#65a620,#7b6888,#d8d23a,#e98125,#0c6197,#e4a14b,#a3acb2,#cc1010,#31383b,#000000,#ffffff", color_columns: str = "", legend_position: str = "right", hide_controls: str = "false", separator: str = "Point (.)", version: str = "3", hide: str = "false", interpolation: str = "Linear", xlog: str = "false", grid: str = "true", date_pattern: str = "dd M yy", pie_keys: str = "", worklog: str = "", chart_type: str = "Bar", bar_coloring_type: str = "mono", is_3d: str = "false", align: str = "center", outer_labels: str = "Label", inner_labels: str = "Value", has_table: str = "true", trendline: str = "false", custom_no_table_msg: str = "false", log_scale: str = "false", is_first_time_enter: str = "true", delimiter: str = "‚", tfc_height: str = "300", tfc_width: str = "400") -> str:
        if not data or len(data) < 2:
            return ""
        if color_columns:
            color_cols = color_columns.split(delimiter)
            data_cols = data[0][1:] if data and data[0] else []
            if len(color_cols) != len(data_cols):
                raise ValueError(f"colorColumns ({len(color_cols)}) must match the number of data columns ({len(data_cols)}).")
        
        table_html = '<table class="wrapped"><tbody><tr>'
        for header in data[0]:
            header = self.check_html_special_character(header, replace_newlines=False)
            table_html += f"<th>{header if header else '<br />'}</th>"
        table_html += "</tr>"
        for row in data[1:]:
            table_html += "<tr>"
            for cell in row:
                cell = self.check_html_special_character(str(cell), replace_newlines=False)
                table_html += f"<td>{cell if cell else '<br />'}</td>"
            table_html += "</tr>"
        table_html += "</tbody></table>"
        
        aggregation_type = "Count"
        if "Commit Count" in title:
            aggregation_type = "Commit Count"
        elif "Risk Breakdown" in title:
            aggregation_type = "Risk Count"
            
        column = self.check_html_special_character(column or (data[0][0] if data and data[0] else ''), replace_newlines=False)
        macro_id = str(uuid.uuid4())
        color_columns_param = f'<ac:parameter ac:name="colorColumns">{color_columns}</ac:parameter>' if color_columns else ''
        pie_keys_param = f'<ac:parameter ac:name="pieKeys">{pie_keys}</ac:parameter>' if pie_keys else ''
        worklog_param = f'<ac:parameter ac:name="worklog">{worklog}</ac:parameter>' if worklog else ''
        tfc_height_param = f'<ac:parameter ac:name="tfc-height">{tfc_height}</ac:parameter>' if tfc_height else ''
        tfc_width_param = f'<ac:parameter ac:name="tfc-width">{tfc_width}</ac:parameter>' if tfc_width else ''
        
        return (
            f'<ac:structured-macro ac:name="table-chart" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'<ac:parameter ac:name="barColoringType">{bar_coloring_type}</ac:parameter>'
            f'<ac:parameter ac:name="log">{log_scale}</ac:parameter>'
            f'<ac:parameter ac:name="dataorientation">{data_orientation}</ac:parameter>'
            f'<ac:parameter ac:name="legend">{legend_position}</ac:parameter>'
            f'<ac:parameter ac:name="aggregation">{aggregation_type}</ac:parameter>'
            f'<ac:parameter ac:name="is3d">{is_3d}</ac:parameter>'
            f'<ac:parameter ac:name="align">{align}</ac:parameter>'
            f'<ac:parameter ac:name="title">{self.check_html_special_character(title, replace_newlines=False)}</ac:parameter>'
            f'<ac:parameter ac:name="type">{chart_type}</ac:parameter>'
            f'<ac:parameter ac:name="colors">{colors}</ac:parameter>'
            f'<ac:parameter ac:name="isFirstTimeEnter">{is_first_time_enter}</ac:parameter>'
            f'<ac:parameter ac:name="outerLabels">{outer_labels}</ac:parameter>'
            f'<ac:parameter ac:name="hasTable">{has_table}</ac:parameter>'
            f'<ac:parameter ac:name="trendline">{trendline}</ac:parameter>'
            f'<ac:parameter ac:name="customNoTableMsg">{custom_no_table_msg}</ac:parameter>'
            f'<ac:parameter ac:name="formatVersion">{version}</ac:parameter>'
            f'<ac:parameter ac:name="column">{column}</ac:parameter>'
            f'<ac:parameter ac:name="innerlabels">{inner_labels}</ac:parameter>'
            f'<ac:parameter ac:name="hidecontrols">{hide_controls}</ac:parameter>'
            f'<ac:parameter ac:name="separator">{separator}</ac:parameter>'
            f'<ac:parameter ac:name="version">{version}</ac:parameter>'
            f'<ac:parameter ac:name="hide">{hide}</ac:parameter>'
            f'<ac:parameter ac:name="interpolation">{interpolation}</ac:parameter>'
            f'<ac:parameter ac:name="xlog">{xlog}</ac:parameter>'
            f'<ac:parameter ac:name="grid">{grid}</ac:parameter>'
            f'<ac:parameter ac:name="datepattern">{date_pattern}</ac:parameter>'
            f'{color_columns_param}{pie_keys_param}{worklog_param}{tfc_height_param}{tfc_width_param}'
            f'<ac:rich-text-body>{table_html}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_line_chart_macro(self, data: List[List], title: str = "", data_orientation: str = "Vertical", column: str = "", colors: str = "#f691b2,#69a6f9,#8cc3e9,#6ada6a,#8eb021,#d04437,#3572b0,#f6c342,#654982,#2484c1,#65a620,#7b6888,#d8d23a,#e98125,#0c6197,#e4a14b,#a3acb2,#cc1010,#31383b,#000000,#ffffff", color_columns: str = "", legend_position: str = "right", hide_controls: str = "false", separator: str = "Point (.)", version: str = "3", hide: str = "false", interpolation: str = "Linear", xlog: str = "false", grid: str = "true", date_pattern: str = "M dd, yy", pie_keys: str = "", worklog: str = "", chart_type: str = "Line", bar_coloring_type: str = "multi", is_3d: str = "false", align: str = "Left", outer_labels: str = "Label", inner_labels: str = "Percentage (Value)", has_table: str = "true", trendline: str = "false", custom_no_table_msg: str = "false", log_scale: str = "false", is_first_time_enter: str = "false", delimiter: str = "‚", x_scale_step: str = "1", scalestep: str = "5", maxvalue: str = "", minvalue: str = "", tfc_height: str = "300", tfc_width: str = "500", line_settings: str = "solid-1.5,solid-1.5", xtitle: str = "Week", ytitle: str = "") -> str:
        if not data or len(data) < 2:
            return ""
        if color_columns:
            color_cols = color_columns.split(delimiter)
            data_cols = data[0][1:] if data and data[0] else []
            if len(color_cols) != len(data_cols):
                raise ValueError(f"colorColumns ({len(color_cols)}) must match the number of data columns ({len(data_cols)}).")
        if pie_keys:
            pie_keys_list = pie_keys.split(delimiter)
            if len(pie_keys_list) != len(data[1:]):
                raise ValueError(f"pieKeys ({len(pie_keys_list)}) must match the number of data rows ({len(data[1:])}).")
        
        table_html = '<table class="wrapped"><tbody><tr>'
        for header in data[0]:
            header = self.check_html_special_character(header, replace_newlines=False)
            table_html += f'<th><p title="">{header if header else "<br />"}</p></th>'
        table_html += "</tr>"
        for row in data[1:]:
            table_html += "<tr>"
            for cell in row:
                cell = self.check_html_special_character(str(cell), replace_newlines=False)
                table_html += f"<td>{cell if cell else '<br />'}</td>"
            table_html += "</tr>"
        table_html += "</tbody></table>"
        
        data_cols = data[0][1:] if data and data[0] else []
        aggregation_type = delimiter.join(self.check_html_special_character(str(header), replace_newlines=False) for header in data_cols)
        column = self.check_html_special_character(column or (data[0][0] if data and data[0] else ''), replace_newlines=False)
        macro_id = str(uuid.uuid4())
        
        color_columns_param = f'<ac:parameter ac:name="colorColumns">{color_columns}</ac:parameter>' if color_columns else ''
        pie_keys_param = f'<ac:parameter ac:name="pieKeys">{pie_keys}</ac:parameter>' if pie_keys else ''
        worklog_param = f'<ac:parameter ac:name="worklog">{worklog}</ac:parameter>' if worklog else ''
        maxvalue_param = f'<ac:parameter ac:name="maxvalue">{maxvalue}</ac:parameter>' if maxvalue else ''
        minvalue_param = f'<ac:parameter ac:name="minvalue">{minvalue}</ac:parameter>' if minvalue else ''
        tfc_height_param = f'<ac:parameter ac:name="tfc-height">{tfc_height}</ac:parameter>' if tfc_height else ''
        tfc_width_param = f'<ac:parameter ac:name="tfc-width">{tfc_width}</ac:parameter>' if tfc_width else ''
        line_settings_param = f'<ac:parameter ac:name="line-settings">{line_settings}</ac:parameter>' if line_settings else ''
        xtitle_param = f'<ac:parameter ac:name="xtitle">{xtitle}</ac:parameter>' if xtitle else ''
        ytitle_param = f'<ac:parameter ac:name="ytitle">{ytitle}</ac:parameter>' if ytitle else ''
        x_scale_step_param = f'<ac:parameter ac:name="xscalestep">{x_scale_step}</ac:parameter>' if x_scale_step else ''
        scalestep_param = f'<ac:parameter ac:name="scalestep">{scalestep}</ac:parameter>' if scalestep else ''
        title_param = f'<ac:parameter ac:name="title">{self.check_html_special_character(title, replace_newlines=False)}</ac:parameter>' if title else ''
        
        return (
            f'<ac:structured-macro ac:name="table-chart" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'<ac:parameter ac:name="barColoringType">{bar_coloring_type}</ac:parameter>'
            f'<ac:parameter ac:name="log">{log_scale}</ac:parameter>'
            f'<ac:parameter ac:name="dataorientation">{data_orientation}</ac:parameter>'
            f'<ac:parameter ac:name="legend">{legend_position}</ac:parameter>'
            f'<ac:parameter ac:name="aggregation">{aggregation_type}</ac:parameter>'
            f'<ac:parameter ac:name="is3d">{is_3d}</ac:parameter>'
            f'<ac:parameter ac:name="align">{align}</ac:parameter>'
            f'{title_param}'
            f'<ac:parameter ac:name="type">{chart_type}</ac:parameter>'
            f'<ac:parameter ac:name="colors">{colors}</ac:parameter>'
            f'<ac:parameter ac:name="isFirstTimeEnter">{is_first_time_enter}</ac:parameter>'
            f'<ac:parameter ac:name="outerLabels">{outer_labels}</ac:parameter>'
            f'<ac:parameter ac:name="hasTable">{has_table}</ac:parameter>'
            f'<ac:parameter ac:name="trendline">{trendline}</ac:parameter>'
            f'<ac:parameter ac:name="customNoTableMsg">{custom_no_table_msg}</ac:parameter>'
            f'<ac:parameter ac:name="formatVersion">{version}</ac:parameter>'
            f'<ac:parameter ac:name="column">{column}</ac:parameter>'
            f'<ac:parameter ac:name="innerlabels">{inner_labels}</ac:parameter>'
            f'<ac:parameter ac:name="hidecontrols">{hide_controls}</ac:parameter>'
            f'<ac:parameter ac:name="separator">{separator}</ac:parameter>'
            f'<ac:parameter ac:name="version">{version}</ac:parameter>'
            f'<ac:parameter ac:name="hide">{hide}</ac:parameter>'
            f'<ac:parameter ac:name="interpolation">{interpolation}</ac:parameter>'
            f'<ac:parameter ac:name="xlog">{xlog}</ac:parameter>'
            f'<ac:parameter ac:name="grid">{grid}</ac:parameter>'
            f'<ac:parameter ac:name="datepattern">{date_pattern}</ac:parameter>'
            f'{color_columns_param}{pie_keys_param}{worklog_param}{maxvalue_param}{minvalue_param}{tfc_height_param}{tfc_width_param}{line_settings_param}{xtitle_param}{ytitle_param}{x_scale_step_param}{scalestep_param}'
            f'<ac:rich-text-body><p><br /></p>{table_html}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_stacked_column_chart_macro(self, data: List[List], title: str = "", aggregation_type: str = "", data_orientation: str = "Vertical", column: str = "", colors: str = "#f691b2,#69a6f9,#8cc3e9,#6ada6a,#8eb021,#d04437,#3572b0,#f6c342,#654982,#2484c1,#65a620,#7b6888,#d8d23a,#e98125,#0c6197,#e4a14b,#a3acb2,#cc1010,#31383b,#000000,#ffffff", color_columns: str = "", legend_position: str = "right", hide_controls: str = "false", separator: str = "Point (.)", version: str = "3", hide: str = "false", interpolation: str = "Linear", xlog: str = "false", grid: str = "true", date_pattern: str = "dd M yy", pie_keys: str = "", worklog: str = "", chart_type: str = "Stacked Column", bar_coloring_type: str = "mono", is_3d: str = "false", align: str = "center", outer_labels: str = "Label", inner_labels: str = "Value", has_table: str = "true", trendline: str = "false", custom_no_table_msg: str = "false", log_scale: str = "false", is_first_time_enter: str = "true", delimiter: str = "‚") -> str:
        if not data or len(data) < 2:
            return ""
        
        data_cols = data[0][1:] if data and data[0] else []
        if color_columns:
            color_cols = color_columns.split(delimiter)
            if len(color_cols) != len(data_cols):
                raise ValueError(f"colorColumns ({len(color_cols)}) must match the number of data columns ({len(data_cols)}).")
        if aggregation_type:
            agg_cols = aggregation_type.split(delimiter)
            if len(agg_cols) != len(data_cols):
                raise ValueError(f"aggregation_type ({len(agg_cols)}) must match the number of data columns ({len(data_cols)}).")
        if pie_keys:
            pie_keys_list = pie_keys.split(delimiter)
            if len(pie_keys_list) != len(data[1:]):
                raise ValueError(f"pieKeys ({len(pie_keys_list)}) must match the number of data rows ({len(data[1:])}).")
                
        aggregation_type = aggregation_type or delimiter.join(self.check_html_special_character(str(header), replace_newlines=False) for header in data_cols)
        
        table_html = '<table class="wrapped"><tbody><tr>'
        for header in data[0]:
            header = self.check_html_special_character(header, replace_newlines=False)
            table_html += f"<th>{header if header else '<br />'}</th>"
        table_html += "</tr>"
        for row in data[1:]:
            table_html += "<tr>"
            for cell in row:
                cell = self.check_html_special_character(str(cell), replace_newlines=False)
                table_html += f"<td>{cell if cell else '<br />'}</td>"
            table_html += "</tr>"
        table_html += "</tbody></table>"
        
        column = self.check_html_special_character(column or (data[0][0] if data and data[0] else ''), replace_newlines=False)
        macro_id = str(uuid.uuid4())
        
        color_columns_param = f'<ac:parameter ac:name="colorColumns">{color_columns}</ac:parameter>' if color_columns else ''
        pie_keys_param = f'<ac:parameter ac:name="pieKeys">{pie_keys}</ac:parameter>' if pie_keys else ''
        worklog_param = f'<ac:parameter ac:name="worklog">{worklog}</ac:parameter>' if worklog else ''
        title_param = f'<ac:parameter ac:name="title">{self.check_html_special_character(title, replace_newlines=False)}</ac:parameter>' if title else ''
        
        return (
            f'<ac:structured-macro ac:name="table-chart" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'<ac:parameter ac:name="barColoringType">{bar_coloring_type}</ac:parameter>'
            f'<ac:parameter ac:name="log">{log_scale}</ac:parameter>'
            f'<ac:parameter ac:name="dataorientation">{data_orientation}</ac:parameter>'
            f'<ac:parameter ac:name="legend">{legend_position}</ac:parameter>'
            f'<ac:parameter ac:name="aggregation">{aggregation_type}</ac:parameter>'
            f'<ac:parameter ac:name="is3d">{is_3d}</ac:parameter>'
            f'<ac:parameter ac:name="align">{align}</ac:parameter>'
            f'{title_param}'
            f'<ac:parameter ac:name="type">{chart_type}</ac:parameter>'
            f'<ac:parameter ac:name="colors">{colors}</ac:parameter>'
            f'<ac:parameter ac:name="isFirstTimeEnter">{is_first_time_enter}</ac:parameter>'
            f'<ac:parameter ac:name="outerLabels">{outer_labels}</ac:parameter>'
            f'<ac:parameter ac:name="hasTable">{has_table}</ac:parameter>'
            f'<ac:parameter ac:name="trendline">{trendline}</ac:parameter>'
            f'<ac:parameter ac:name="customNoTableMsg">{custom_no_table_msg}</ac:parameter>'
            f'<ac:parameter ac:name="formatVersion">{version}</ac:parameter>'
            f'<ac:parameter ac:name="column">{column}</ac:parameter>'
            f'<ac:parameter ac:name="innerlabels">{inner_labels}</ac:parameter>'
            f'<ac:parameter ac:name="hidecontrols">{hide_controls}</ac:parameter>'
            f'<ac:parameter ac:name="separator">{separator}</ac:parameter>'
            f'<ac:parameter ac:name="version">{version}</ac:parameter>'
            f'<ac:parameter ac:name="hide">{hide}</ac:parameter>'
            f'<ac:parameter ac:name="interpolation">{interpolation}</ac:parameter>'
            f'<ac:parameter ac:name="xlog">{xlog}</ac:parameter>'
            f'<ac:parameter ac:name="grid">{grid}</ac:parameter>'
            f'<ac:parameter ac:name="datepattern">{date_pattern}</ac:parameter>'
            f'{color_columns_param}{pie_keys_param}{worklog_param}'
            f'<ac:rich-text-body>{table_html}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )

    def add_pie_chart_macro(self, data: List[List], title: str, column: str = '', colors: str = "#f691b2,#69a6f9,#8cc3e9,#6ada6a,#8eb021,#d04437,#3572b0,#f6c342,#654982,#2484c1,#65a620,#7b6888,#d8d23a,#e98125,#0c6197,#e4a14b,#a3acb2,#cc1010,#31383b,#000000,#ffffff", color_columns: str = "", legend_position: str = "right", hide_controls: str = "false", separator: str = "Point (.)", version: str = "3", hide: str = "false", interpolation: str = "Linear", xlog: str = "false", grid: str = "true", date_pattern: str = "dd M yy", pie_keys: str = "", worklog: str = "", chart_type: str = "Pie", bar_coloring_type: str = "mono", is_3d: str = "false", align: str = "center", outer_labels: str = "Label", inner_labels: str = "Value", has_table: str = "true", trendline: str = "false", custom_no_table_msg: str = "false", log_scale: str = "false", is_first_time_enter: str = "true", delimiter: str = "‚", tfc_height: str = "300", tfc_width: str = "400") -> str:
        if not data or len(data) < 2:
            return ""
        
        if color_columns:
            color_cols = color_columns.split(delimiter)
            data_cols = data[0][1:] if data and data[0] else []
            if len(color_cols) != len(data_cols):
                raise ValueError(f"colorColumns ({len(color_cols)}) must match the number of data columns ({len(data_cols)}).")
        if pie_keys:
            pie_keys_list = pie_keys.split(delimiter)
            if len(pie_keys_list) != len(data[1:]):
                raise ValueError(f"pieKeys ({len(pie_keys_list)}) must match the number of data rows ({len(data[1:])}).")
        
        table_html = '<table class="wrapped"><tbody><tr>'
        for header in data[0]:
            header = self.check_html_special_character(header, replace_newlines=False)
            table_html += f"<th>{header if header else '<br />'}</th>"
        table_html += "</tr>"
        for row in data[1:]:
            table_html += "<tr>"
            for cell in row:
                cell = self.check_html_special_character(str(cell), replace_newlines=False)
                table_html += f"<td>{cell if cell else '<br />'}</td>"
            table_html += "</tr>"
        table_html += "</tbody></table>"
        
        column = self.check_html_special_character(column or (data[0][0] if data and data[0] else ''), replace_newlines=False)
        macro_id = str(uuid.uuid4())
        
        color_columns_param = f'<ac:parameter ac:name="colorColumns">{color_columns}</ac:parameter>' if color_columns else ''
        pie_keys_param = f'<ac:parameter ac:name="pieKeys">{pie_keys}</ac:parameter>' if pie_keys else ''
        worklog_param = f'<ac:parameter ac:name="worklog">{worklog}</ac:parameter>' if worklog else ''
        tfc_height_param = f'<ac:parameter ac:name="tfc-height">{tfc_height}</ac:parameter>' if tfc_height else ''
        tfc_width_param = f'<ac:parameter ac:name="tfc-width">{tfc_width}</ac:parameter>' if tfc_width else ''
        
        return (
            f'<ac:structured-macro ac:name="table-chart" ac:schema-version="1" ac:macro-id="{macro_id}" atlassian-macro-output-type="INLINE">'
            f'<ac:parameter ac:name="barColoringType">{bar_coloring_type}</ac:parameter>'
            f'<ac:parameter ac:name="log">{log_scale}</ac:parameter>'
            f'<ac:parameter ac:name="dataorientation">Vertical</ac:parameter>'
            f'<ac:parameter ac:name="legend">{legend_position}</ac:parameter>'
            f'<ac:parameter ac:name="aggregation">Count</ac:parameter>'
            f'<ac:parameter ac:name="is3d">{is_3d}</ac:parameter>'
            f'<ac:parameter ac:name="align">{align}</ac:parameter>'
            f'<ac:parameter ac:name="title">{self.check_html_special_character(title, replace_newlines=False)}</ac:parameter>'
            f'<ac:parameter ac:name="type">{chart_type}</ac:parameter>'
            f'<ac:parameter ac:name="colors">{colors}</ac:parameter>'
            f'<ac:parameter ac:name="isFirstTimeEnter">{is_first_time_enter}</ac:parameter>'
            f'<ac:parameter ac:name="outerLabels">{outer_labels}</ac:parameter>'
            f'<ac:parameter ac:name="hasTable">{has_table}</ac:parameter>'
            f'<ac:parameter ac:name="trendline">{trendline}</ac:parameter>'
            f'<ac:parameter ac:name="customNoTableMsg">{custom_no_table_msg}</ac:parameter>'
            f'<ac:parameter ac:name="formatVersion">{version}</ac:parameter>'
            f'<ac:parameter ac:name="column">{column}</ac:parameter>'
            f'<ac:parameter ac:name="innerlabels">{inner_labels}</ac:parameter>'
            f'<ac:parameter ac:name="hidecontrols">{hide_controls}</ac:parameter>'
            f'<ac:parameter ac:name="separator">{separator}</ac:parameter>'
            f'<ac:parameter ac:name="version">{version}</ac:parameter>'
            f'<ac:parameter ac:name="hide">{hide}</ac:parameter>'
            f'<ac:parameter ac:name="interpolation">{interpolation}</ac:parameter>'
            f'<ac:parameter ac:name="xlog">{xlog}</ac:parameter>'
            f'<ac:parameter ac:name="grid">{grid}</ac:parameter>'
            f'<ac:parameter ac:name="datepattern">{date_pattern}</ac:parameter>'
            f'{color_columns_param}{pie_keys_param}{worklog_param}{tfc_height_param}{tfc_width_param}'
            f'<ac:rich-text-body>{table_html}</ac:rich-text-body>'
            f'</ac:structured-macro>'
        )
