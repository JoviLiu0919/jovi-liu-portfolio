
import json
import sys
import re
import urllib.parse
from pathlib import Path
from datetime import datetime
from bs4 import BeautifulSoup

# Reuse connection logic
sys.path.append(str(Path(__file__).parent))
try:
    from confluence_tool import load_config, get_client, safe_get
except ImportError:
    print("Error: Could not import confluence_tool. Make sure it's in the same directory.")
    sys.exit(1)

def load_crawl_config(path: Path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

class ConfigCrawler:
    def __init__(self, config_file: Path, secrets_file: Path):
        self.crawl_config = load_crawl_config(config_file)
        self.conf_config = load_config(secrets_file)
        self.client = get_client(self.conf_config)
        self.results = []

    def run(self):
        print("Starting Config Driven Crawl...")
        sources = self.crawl_config.get('data_sources', [])
        for source in sources:
            self.process_source(source)
        
        self.save_results()

    def process_source(self, source):
        print(f"\nProcessing Source: {source['name']} ({source['page_id']})")
        page = self.client.get_page_by_id(source['page_id'], expand="body.view")
        soup = BeautifulSoup(page['body']['view']['value'], 'html.parser')
        
        # Assume Table Iterator
        tables = soup.find_all('table')
        if not tables:
            print("  No tables found.")
            return

        # Find Primary Key Column Index
        headers = []
        rows = tables[0].find_all('tr')
        if rows:
            headers = [th.get_text(strip=True) for th in rows[0].find_all(['th', 'td'])]
        
        pk_col_name = source['primary_key']
        pk_idx = -1
        for i, h in enumerate(headers):
            if pk_col_name.lower() in h.lower():
                pk_idx = i
                break
        
        if pk_idx == -1:
            print(f"  Primary Key '{pk_col_name}' column not found in headers: {headers}")
            return

        print(f"  Found '{pk_col_name}' at column {pk_idx}")

        # Iterate Rows
        for i, row in enumerate(rows[1:]):
            context = {}
            cells = row.find_all(['td', 'th'])
            if len(cells) <= pk_idx: continue
            
            # Extract Fields first (needed for filtering sometimes, or Context)
            for field_key, field_def in source['fields'].items():
                col_name = field_def['col']
                attr = field_def['attr']
                
                # Find col idx for this field
                c_idx = -1
                for idx, h in enumerate(headers):
                    if col_name.lower() in h.lower():
                        c_idx = idx
                        break
                
                if c_idx != -1 and c_idx < len(cells):
                    cell = cells[c_idx]
                    if attr == 'text':
                        val = cell.get_text(strip=True)
                    elif attr == 'href':
                        links = cell.find_all('a')
                        val = links[0].get('href') if links else None
                    else:
                        val = None
                    context[field_key] = val

            # Apply Filters
            if not self.check_filters(row, source.get('filter_rules', [])):
                continue

            print(f"  >> Match: {context.get('platform_name', 'Unknown')}")
            
            # Execute Analysis Steps
            row_result = {"context": context, "analysis": {}}
            for step in source['analysis_steps']:
                self.execute_step(step, context, row_result)
            
            self.results.append(row_result)

    def check_filters(self, row, rules):
        for rule in rules:
            if rule['check'] == 'status_macro':
                # Check for Red/Yellow macro or style
                row_html = str(row).lower()
                target_values = [v.lower() for v in rule['value']]
                
                found = False
                for v in target_values:
                    # Check Macro Name or Color Style
                    if f"status-macro" in row_html and v in row_html: found = True
                    if f"color: {v}" in row_html or f"color:{v}" in row_html: found = True
                    if f"backgroud-color: {v}" in row_html: found = True
                    # Check text content fallback (e.g. {Red})
                    if f"{{{v}}}" in row.get_text(): found = True
                
                if not found: return False
        return True

    def execute_step(self, step, context, row_result):
        step_name = step['step']
        method = step['method']
        target_key = step['target']
        
        # Resolve Target (is it a literal ID or a variable from context?)
        target = target_key
        if target_key in context:
            target = context[target_key]
        elif target_key == "search_cql":
            target = None

        print(f"     [Step] {step_name} ({method})...")
        
        try:
            val = None
            if method == 'find_child_page':
                val = self.method_find_child_page(target, step['args'], context)
            elif method == 'find_link_and_analyze':
                val = self.method_find_link_and_analyze(target, step['args'], context)
            elif method == 'lookup_table_row':
                val = self.method_lookup_table_row(target, step['args'], context)
            elif method == 'deep_research_odm':
                val = self.method_deep_research_odm(step['args'], context)
            
            # Handle Next Action (Nested)
            if val and 'next_action' in step:
                # e.g. We found a page (val), now parse it
                next_act = step['next_action']
                if next_act['method'] == 'find_link_match':
                     val = self.method_find_link_match(val, next_act['args'])

            row_result['analysis'][step_name] = val
            print(f"       -> {str(val)[:50]}...")
            
        except Exception as e:
            row_result['analysis'][step_name] = f"Error: {e}"

    # --- Methods ---

    def resolve_url_to_id(self, url):
    # Extract ID or Page Title from URL to get ID
    # Supports multiple URL formats:
    # - /pages/1135567034/title
    # - ?pageId=1135567034
    # - /display/SPACE/Title
    if not url: return None
    
    # Format 1: /pages/1135567034/title
    if "/pages/" in url:
        parts = url.split("/pages/")
        if len(parts) > 1:
            page_part = parts[1].split("/")[0]
            if page_part.isdigit():
                return page_part
    
    # Format 2: ?pageId=1135567034
    if "pageId=" in url:
        return url.split("pageId=")[1].split("&")[0]
    
    # Format 3: /wiki/pages/viewpage.action?pageId=1135567034
    if "/viewpage.action" in url and "pageId=" in url:
        return url.split("pageId=")[1].split("&")[0]
    
    # Format 4: /display/SPACE/Title -> use c.get_page_by_title
    if "/display/" in url:
        parts = url.split("/display/")[1].split("/")
        space = parts[0]
        title = urllib.parse.unquote_plus(parts[1].split("?")[0])
        p = self.client.get_page_by_title(space, title)
        if p: return p['id']
    return None

    def method_find_child_page(self, parent_url, args, context):
        parent_id = self.resolve_url_to_id(parent_url)
        if not parent_id: return None
        
            # Rest of the code remains the same
        children = self.client.get_page_by_id(parent_id, expand="children.page")
        results = children.get('children', {}).get('page', {}).get('results', [])
        
        for ch in results:
            if keyword.lower() in ch['title'].lower():
                # Found it
                return ch['title'] # Return title or object? For now title/id
        return None

    def method_find_link_and_analyze(self, parent_url, args, context):
        parent_id = self.resolve_url_to_id(parent_url)
        if not parent_id: return None
        
        link_text = args['link_text']
        page = self.client.get_page_by_id(parent_id, expand="body.view")
        soup = BeautifulSoup(page['body']['view']['value'], 'html.parser')
        
        target_href = None
        for a in soup.find_all('a'):
            if link_text.lower() in a.get_text(strip=True).lower():
                target_href = a.get('href')
                break
        
        if target_href:
            # Analyze it (Stub for GYR parsing mentioned in screenshot)
            # We would fetch target_href and search for Red Status Reason
            return f"Found Link: {target_href}"
        return None

    def method_lookup_table_row(self, page_id, args, context):
        # Unpack args
        key_col = args['key_col']
        key_val_tmpl = args['key_value']
        target_col = args['target_col']
        
        # Render template
        key_val = key_val_tmpl.format(**context)
        
        page = self.client.get_page_by_id(page_id, expand="body.view")
        soup = BeautifulSoup(page['body']['view']['value'], 'html.parser')
        
        # Find table with key_col
        for tbl in soup.find_all('table'):
            rows = tbl.find_all('tr')
            if not rows: continue
            
            headers = [th.get_text(strip=True) for th in rows[0].find_all(['th', 'td'])]
            
            # Resolve indices
            try:
                k_idx = -1
                t_idx = -1
                for i, h in enumerate(headers):
                    if key_col.lower() in h.lower(): k_idx = i
                    if target_col.lower() in h.lower(): t_idx = i
                
                if k_idx == -1 or t_idx == -1: continue
                
                # Scan rows
                for row in rows[1:]:
                    cells = row.find_all(['td', 'th'])
                    if len(cells) <= max(k_idx, t_idx): continue
                    
                    if key_val.lower() in cells[k_idx].get_text(strip=True).lower():
                        return cells[t_idx].get_text(strip=True)[:100] # Return summary
                        
            except:
                continue
        return None

    def method_deep_research_odm(self, args, context):
        root_id = args['root_id']
        proj_name = args['project_name'].format(**context)
        
        # CQL Search
        cql = f'ancestor = {root_id} AND title ~ "{proj_name}"'
        res = self.client.cql(cql, limit=1)
        if res.get('results'):
             item = res['results'][0]
             return f"Found ODM Page: {item['content']['title']}"
        return None

    def method_find_link_match(self, page_info, args):
        # Stub: if page_info is a Title, we need to resolve ID then parse.
        # This part requires state management (passing Page Objects instead of strings).
        # For prototype simplification, I'll assume page_info is just string for now.
        return f"Scanned {page_info} for {args['regex']}"

    def save_results(self):
        print("\n=== Final Results ===")
        print(json.dumps(self.results, indent=2))
        
        # Save report following skill_guides Report Generation Standards
        self.save_report()

    def save_report(self):
        """Save report following skill_guides Report Generation Standards"""
        try:
            # Get Reports directory path - .windsurf/Reports/
            reports_dir = Path(__file__).parent.parent.parent.parent / "Reports"
            reports_dir.mkdir(exist_ok=True)
            
            timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
            filename = f"confluence_crawl_report_{timestamp}.md"
            filepath = reports_dir / filename
            
            # Add metadata header per standards
            report_header = f"""---
# Confluence Crawl Report
**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Description:** Project Intelligence Crawl Report from Confluence
**Skill:** confluence-integration
---

"""
            
            # Generate report content
            content = "# Project Intelligence Crawl Report\n\n"
            for r in self.results:
                proj = r['context'].get('platform_name', 'Unknown')
                content += f"## {proj}\n"
                for k, v in r['analysis'].items():
                    content += f"- **{k}**: {v}\n"
                content += "\n"
            
            # Add bilingual summary
            content += f"""## 📋 雙語摘要 / Bilingual Summary

🇹🇼 **繁體中文**:
- 從 Confluence 爬取了 {len(self.results)} 個項目的智慧資訊
- 報告生成時間: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- 使用 confluence-integration skill 自動生成

🇺🇸 **English Summary**:
- Crawled intelligence data from {len(self.results)} projects in Confluence
- Report generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- Automatically generated by confluence-integration skill

---
*Report generated following skill_guides standards*
"""
            
            # Write file
            full_content = report_header + content
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(full_content)
            
            print(f"✅ Report saved to: {filepath}")
            
        except Exception as e:
            print(f"Error saving report: {e}")

if __name__ == "__main__":
    crawler = ConfigCrawler(Path("crawl_config.json"), Path("config.toml"))
    crawler.run()
