
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from confluence_tool import load_config, get_client
from bs4 import BeautifulSoup
import re

def get_page_content(c, page_id):
    return c.get_page_by_id(page_id, expand="body.view,children.page")

def find_link_by_text(soup, pattern):
    """Deep Research Logic: 'Judge' if a link is relevant based on text pattern."""
    for a in soup.find_all('a'):
        if a.get_text() and re.search(pattern, a.get_text(), re.IGNORECASE):
            return a.get('href'), a.get_text()
    return None, None

def deep_dive_odm(c, root_id, target_odm="Compal", target_year="CY26"):
    print(f"\n[Level 1] Starting Deep Research at Root: {root_id}")
    root = get_page_content(c, root_id)
    
    # Decision 1: Which ODM?
    next_page_id = None
    children = root.get('children', {}).get('page', {}).get('results', [])
    
    print(f"  > Found {len(children)} ODM sections. Looking for '{target_odm}'...")
    for child in children:
        if target_odm.lower() in child['title'].lower():
            print(f"  > Match found: {child['title']} (ID: {child['id']})")
            next_page_id = child['id']
            break
            
    if not next_page_id:
        print("  > No matching ODM section found.")
        return

    # Level 2: Compal Section -> Look for Year/Platform Section
    print(f"\n[Level 2] Analyzing {target_odm} Section ({next_page_id})")
    level2_page = get_page_content(c, next_page_id)
    children_l2 = level2_page.get('children', {}).get('page', {}).get('results', [])
    
    next_page_id_l3 = None
    print(f"  > Found {len(children_l2)} subsections. Looking for '{target_year}'...")
    for child in children_l2:
        if target_year.lower() in child['title'].lower():
            print(f"  > Match found: {child['title']} (ID: {child['id']})")
            next_page_id_l3 = child['id']
            break
            
    if not next_page_id_l3:
        print("  > No matching Year section found.")
        return

    # Level 3: Year Section -> List Projects (Leaf Nodes)
    print(f"\n[Level 3] Analyzing Year Section ({next_page_id_l3})")
    level3_page = get_page_content(c, next_page_id_l3)
    children_l3 = level3_page.get('children', {}).get('page', {}).get('results', [])
    
    if not children_l3:
        print("  > No projects found in this section.")
        return
        
    print(f"  > Found {len(children_l3)} Projects. Picking the first one to drill down...")
    target_project = children_l3[0]
    print(f"  > Drilling into Project: {target_project['title']} (ID: {target_project['id']})")
    
    # Level 4: Project Page -> Find "Jira_BIOS" link (Hyperlink Recursion)
    print(f"\n[Level 4] Deep Scanning Project Page: {target_project['title']}")
    proj_page = get_page_content(c, target_project['id'])
    html = proj_page['body']['view']['value']
    soup = BeautifulSoup(html, 'html.parser')
    
    # Search for "Jira_BIOS" directly or contextually
    # Strategy: Look for text "Jira_BIOS" and see if it's a link or next to a link
    
    # 1. Check for specific Link text
    href, text = find_link_by_text(soup, r"Jira_BIOS|Weekly Report")
    if href:
        print(f"  > [SUCCESS] Found Link based on text judgment: '{text}' -> {href}")
    else:
        print("  > 'Jira_BIOS' link not found by text text. Checking Tables/Lists...")
        # 2. Check table columns
        found_jira = False
        for tr in soup.find_all('tr'):
            cells = tr.find_all(['td', 'th'])
            for cell in cells:
                if "jira" in cell.get_text().lower() or "bios" in cell.get_text().lower():
                    # Check if this cell contains a link OR the next cell contains a link
                    links = cell.find_all('a')
                    if links:
                        print(f"  > [SUCCESS] Found link in Jira/BIOS related cell: {links[0].get('href')}")
                        found_jira = True
        if not found_jira:
            print("  > Deep scan found no explicit Jira links.")

def main():
    config = load_config(Path("config.toml"))
    c = get_client(config)
    deep_dive_odm(c, "251433709", target_odm="Compal", target_year="CY26")

if __name__ == "__main__":
    main()
