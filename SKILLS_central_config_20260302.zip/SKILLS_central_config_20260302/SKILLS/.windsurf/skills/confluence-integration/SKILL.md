---
name: confluence-integration
description: Manage Confluence Pages and Comments (Search, Read, Create, Update). Use when accessing Confluence documentation, creating pages, or managing content in Confluence spaces.
---

# Confluence Integration Skill

Start here to manage Confluence pages, comments, and content. This skill provides comprehensive tools for Confluence operations including page management, content analysis, and documentation handling.

## Compliance with skill_guides

This skill follows all guidelines specified in `.windsurf/skills/skill-guides/SKILL.md`:
- **Core Integration Architecture**: Uses centralized Confluence configuration
- **Zero-Temp-File Policy**: All processing done in memory
- **Report Generation Standards**: Saves bilingual reports to `.windsurf/Reports/`
- **Cross-Session Consistency**: Ensures consistent behavior across sessions

## Interaction Rules (Agent Instructions)

*   **Validation**: Ensure you have the `space` and `title` for creation, or `id` for updates. Ask the user if details are missing.
*   **Confirmation**: Before **Creating** or **Updating** a page, outline the content changes and Metadata (Space, Title) to the user. Wait for approval.
*   **Smart Format Selection**: The skill automatically chooses between Storage and View formats based on operation type:
    - **View Format** (`expand="body.view"`): Default for content analysis, table parsing, text extraction
    - **Storage Format** (`expand="body.storage"`): Used for macro operations, page updates, content modification

## Setup

1.  **Install Dependencies** (One-time):
    ```powershell
    cd .windsurf/confluence_integration
    .\scripts\setup_env.ps1
    ```
2.  **Configuration**:
    Update `config.toml` with your `url` and `token`.

## Commands

Use `scripts/confluence_tool.py` for all operations.

### Search Content
Search using Confluence Query Language (CQL).
```powershell
# Search by title
python scripts/confluence_tool.py search --query "title ~ 'Meeting Notes'"

# Search in specific space
python scripts/confluence_tool.py search --query "space = 'CPSE' AND text ~ 'Architecture'"
```

### Read Page (Smart Format)
Get page content and metadata by ID or URL. Automatically extracts page ID from URLs.
```powershell
# Using Page ID
python scripts/confluence_tool.py get --id 1135567034

# Using Full URL (automatically extracts page ID)
python scripts/confluence_tool.py get --id "https://confluence.cpg.dell.com/spaces/CBDSE/pages/1135567034/SKILLS+for+Windsurf+editor"

# Smart detection with format override
python scripts/confluence_tool.py get --id "https://confluence.cpg.dell.com/pages/1135567034/SKILLS+for+Windsurf+editor" --format view

# Force Storage format for macro analysis
python scripts/confluence_tool.py get --id 1135567034 --format storage
```

**Supported URL Formats:**
- `https://confluence.cpg.dell.com/pages/1135567034/SKILLS+for+Windsurf+editor`
- `https://confluence.cpg.dell.com/display/CBDSE/SKILLS+for+Windsurf+editor?pageId=1135567034`
- `https://confluence.cpg.dell.com/wiki/pages/viewpage.action?pageId=1135567034`

**Smart Detection Logic:**
- **URL Parsing**: Automatically extracts page ID from any supported URL format
- **Starts with View format** for performance and to avoid truncation
- **Detects macros** automatically in content
- **Switches to Storage format** if macros are found and needed
- **Large page optimization**: Uses view format for pages >1MB to prevent truncation

### Create Page
Create a new page in a specific space.
```powershell
python scripts/confluence_tool.py create --space "CPSE" --title "My New Page" --body "<h1>Hello World</h1>"
```

### Clone Page
Clone an existing page's content to a new location.
```powershell
python scripts/confluence_tool.py clone --id 12345678 --space "~my_space" --title "Cloned Page" --parent 98765432
```

### Update Page
Update an existing page.
```powershell
python scripts/confluence_tool.py update --id 12345678 --title "Updated Title" --body "<h1>New Content</h1>" --minor
```

### Add Comment
Comment on a page.
```powershell
python scripts/confluence_tool.py comment --id 12345678 --body "Great page!"
```

### Analyze Macros
Scan a page to list all used macros.
```powershell
python scripts/confluence_tool.py analyze-macros --id 12345678
```

### Upload Attachment
Upload a file to a page.
```powershell
python scripts/confluence_tool.py upload-attachment --id 12345678 --file "./doc.pdf" --comment "Uploaded by AI"
```

### Verify Attachment Cycle
Test upload/download integrity (generates random file, uploads, downloads, compares hash).
```powershell
python scripts/confluence_tool.py verify-attachment-cycle --id 12345678
```

### Inspect Macro
Extract XML of a specific macro from a page (useful for debugging storage format).
```powershell
python scripts/confluence_tool.py inspect-macro --id 12345678 --name "view-file"
```

### Grep Page Content
Search for a regex pattern in the raw storage format of a page.
```powershell
python scripts/confluence_tool.py grep-page --id 12345678 --pattern "ac:name=\"view-file\""
```

### Analyze Health (Green/Red/Yellow)
Scans tables (including table-filter macros) for Non-Green items.
Useful for identifying "At Risk" items on dashboard pages.
```powershell
python scripts/confluence_tool.py analyze-health --id 12345678
```

### Scan Dashboard (Project List)
Crawls a dashboard page containing links to individual project pages.
```powershell
python scripts/confluence_tool.py scan-dashboard --dashboard-id 436491408 --filter ".*Project.*"
```

### Scan Pipeline (SWDM Today)
Specialized scan for SWDM pipeline reports, deep-crawling Issue Managers.
```powershell
python scripts/confluence_tool.py scan-pipeline --page-id 410290793
```

### Scan Meeting Prep
Aggregates PIMS data from SWDM Dashboard and BSE Watchlist, categorizing tickets for meeting review.
```powershell
python scripts/confluence_tool.py scan-meeting-prep --swdm-page-id 410290793 --pims-list-page-id 1089398828
```

### Scan Project Hub (Red/Yellow/Green Deep Research)
Intelligent scan of NPI projects. Triggers deep research for Red/Yellow items (finding ODM reports via CQL), and light monitoring for Green items.
```powershell
python scripts/confluence_tool.py scan-project-hub --npi-id 414008847 --output hub_report.md
```

### Generate Test Page (Macro Demo)
Generate a test page demonstrating all supported macros (Charts, Lists, Panels, etc.).
If the page exists, it will be UPDATED (preserving page history).
```powershell
python scripts/confluence_tool.py generate-test-page --space "~user" --title "Macro_Demo" --parent 12345678
```

## Troubleshooting

*   **XML Parsing Errors**: "Unexpected character ' ' (missing name?)" usually means invalid XML in the Storage Format.
    *   **Common Cause**: Unescaped special characters (e.g., `&` must be `&amp;`) in titles or content passed to macros.
    *   **Solution**: Ensure all user-visible strings injected into macros are escaped using `html.escape()`.
*   **HTML Structure Changes**: If `scan-pipeline` or table parsing fails due to Confluence cloud updates:
    *   **Debug**: Use `inspect-macro` or `grep-page` to see the *actual* storage format.
    *   **Action**: Update the regex or BeautifulSoup logic in `confluence_tool.py` based on the new structure.
*   **Content Truncation**: For large pages (like pageid 1135567034):
    *   **Use View Format**: Default for analysis to avoid truncation
    *   **Storage Format Only**: When macro operations are needed
    *   **Fallback Strategy**: Start with view format, switch to storage only if macros detected

## Smart Format Detection Logic

The skill automatically detects when to use Storage vs View format:

### Triggers for Storage Format:
- Macro operations (`analyze-macros`, `fix-macros`, `inspect-macro`)
- Page updates/creation
- Content modification operations
- Explicit `--format storage` parameter

### Triggers for View Format:
- Content analysis and parsing
- Table extraction
- Text search and analysis
- Large page processing (to avoid truncation)
- Default read operations

### Detection Pattern:
```python
# Pseudo-code for format selection
def should_use_storage_format(operation_type, page_size=None):
    storage_operations = ['macro', 'update', 'create', 'fix', 'inspect']
    if any(op in operation_type.lower() for op in storage_operations):
        return True
    if page_size and page_size > 1000000:  # 1MB threshold
        return False  # Use view for large pages
    return False  # Default to view

# Smart detection with fallback
def get_page_with_smart_format(c, page_id, operation_type='get'):
    # Try view format first
    page = c.get_page_by_id(page_id, expand="body.view")
    if detect_macros_in_content(page['body']['view']['value']):
        # Switch to storage if macros detected
        page = c.get_page_by_id(page_id, expand="body.storage")
    return page
```

## Implementation Summary

**Key Features Added:**
1. **Smart Format Detection**: Automatically chooses optimal format based on operation type
2. **Macro Detection**: Identifies when storage format is needed for macro operations  
3. **Fallback Strategy**: View format fails gracefully to storage format
4. **Large Page Optimization**: Prioritizes view format for large pages to prevent truncation
5. **Explicit Override**: Users can force specific format with `--format` parameter

**Benefits for pageid 1135567034:**
- **Reduced Truncation**: Uses view format by default for analysis
- **Automatic Macro Handling**: Switches to storage only when macros are detected
- **Better Performance**: Faster content retrieval for large pages
- **Flexible Control**: Can override automatic detection when needed
