"""
Centralized Configuration Loader for BIOS SE Tools
Provides shared configuration loading functionality for all skills
"""

import os
import sys
from pathlib import Path
from typing import Dict, Any, Optional

try:
    import tomllib
except ImportError:
    import tomli as tomllib


def get_central_config_path() -> Path:
    """Get the path to the central configuration file"""
    # Get the SKILLS directory (this file is in SKILLS/)
    skills_dir = Path(__file__).parent
    return skills_dir / "central_config.toml"


def load_central_config() -> Dict[str, Any]:
    """Load the central configuration file"""
    central_config_path = get_central_config_path()
    
    if not central_config_path.exists():
        return {}
    
    try:
        with open(central_config_path, "rb") as f:
            return tomllib.load(f)
    except Exception as e:
        print(f"Warning: Could not load central config: {e}", file=sys.stderr)
        return {}


def get_token(service_name: str) -> Optional[str]:
    """
    Get API token for a specific service from central config
    
    Args:
        service_name: Name of the service (jira, confluence, github, microsoft)
    
    Returns:
        API token string or None if not found
    """
    central_config = load_central_config()
    api_tokens = central_config.get("api_tokens", {})
    
    token_key = f"{service_name}_token"
    if service_name == "microsoft":
        # Microsoft uses client_id and client_secret instead of token
        return None
    
    token = api_tokens.get(token_key)
    
    # Return None if token is still a placeholder
    if token and token.startswith("YOUR_"):
        return None
    
    return token


def get_microsoft_credentials() -> Dict[str, str]:
    """Get Microsoft API credentials from central config"""
    central_config = load_central_config()
    api_tokens = central_config.get("api_tokens", {})
    
    credentials = {
        "client_id": api_tokens.get("microsoft_client_id", ""),
        "client_secret": api_tokens.get("microsoft_client_secret", ""),
        "tenant_id": api_tokens.get("microsoft_tenant_id", "consumers")
    }
    
    # Check if credentials are still placeholders or not configured
    # Check if client_id and client_secret are configured (tenant_id can be default)
    if not credentials["client_id"] or not credentials["client_secret"]:
        return {}
    if any(cred.startswith("YOUR_") for cred in [credentials["client_id"], credentials["client_secret"]] if cred):
        return {}
    
    return credentials


def get_service_url(service_name: str) -> Optional[str]:
    """
    Get service URL from central config
    
    Args:
        service_name: Name of the service (jira, confluence, github)
    
    Returns:
        Service URL string or None if not found
    """
    central_config = load_central_config()
    service_urls = central_config.get("service_urls", {})
    
    url_key = f"{service_name}_url"
    return service_urls.get(url_key)


def get_default_value(key: str) -> Any:
    """
    Get default value from central config
    
    Args:
        key: Key name (e.g., 'github_owner', 'jira_project_key')
    
    Returns:
        Default value or None if not found
    """
    central_config = load_central_config()
    defaults = central_config.get("defaults", {})
    return defaults.get(key)


def load_skill_config_with_central_fallback(skill_config_path: Path) -> Dict[str, Any]:
    """
    Load skill configuration with central config as fallback
    
    Args:
        skill_config_path: Path to the skill's local config.toml file
    
    Returns:
        Merged configuration dictionary
    """
    # Load local skill config
    skill_config = {}
    if skill_config_path.exists():
        try:
            with open(skill_config_path, "rb") as f:
                skill_config = tomllib.load(f)
        except Exception as e:
            print(f"Warning: Could not load skill config {skill_config_path}: {e}", file=sys.stderr)
    
    # Load central config for fallback values
    central_config = load_central_config()
    
    # Merge configurations with priority to local config
    merged_config = {}
    
    # Helper function to merge nested dicts
    def merge_dicts(target: Dict, source: Dict):
        for key, value in source.items():
            if key not in target:
                target[key] = value
            elif isinstance(value, dict) and isinstance(target[key], dict):
                merge_dicts(target[key], value)
    
    # Start with central config defaults
    if "defaults" in central_config:
        merged_config.update(central_config["defaults"])
    
    # Add service-specific central config
    for service_name in ["jira", "confluence", "github", "microsoft"]:
        service_config = {}
        
        # Add service URL
        url = get_service_url(service_name)
        if url:
            service_config["url"] = url
        
        # Add service token
        if service_name == "microsoft":
            credentials = get_microsoft_credentials()
            if credentials:
                service_config.update(credentials)
        else:
            token = get_token(service_name)
            if token:
                service_config["token"] = token
        
        if service_config:
            merged_config[service_name] = service_config
    
    # Override with local skill config
    merge_dicts(merged_config, skill_config)
    
    return merged_config


def validate_central_config() -> Dict[str, bool]:
    """
    Validate central configuration and return validation results
    
    Returns:
        Dictionary with validation status for each service
    """
    central_config = load_central_config()
    results = {}
    
    # Check API tokens
    api_tokens = central_config.get("api_tokens", {})
    
    # Jira validation
    jira_token = api_tokens.get("jira_token", "")
    results["jira"] = bool(jira_token and not jira_token.startswith("YOUR_"))
    
    # Confluence validation
    confluence_token = api_tokens.get("confluence_token", "")
    results["confluence"] = bool(confluence_token and not confluence_token.startswith("YOUR_"))
    
    # GitHub validation
    github_token = api_tokens.get("github_token", "")
    results["github"] = bool(github_token and not github_token.startswith("YOUR_"))
    
    # Microsoft validation (optional - only needed for Graph API/Teams)
    ms_creds = get_microsoft_credentials()
    results["microsoft"] = bool(ms_creds)  # True if credentials are properly configured
    
    # Check service URLs
    service_urls = central_config.get("service_urls", {})
    results["urls_configured"] = bool(service_urls)
    
    return results


def print_config_status():
    """Print the current configuration status for user information"""
    print("=== Central Configuration Status ===")
    
    if not get_central_config_path().exists():
        print("X Central config file not found")
        return
    
    validation = validate_central_config()
    
    for service, status in validation.items():
        if service == "urls_configured":
            if status:
                print("OK Service URLs configured")
            else:
                print("X Service URLs not configured")
        else:
            if status:
                print(f"OK {service.title()} token configured")
            else:
                print(f"X {service.title()} token not configured")
    
    print(f"\nConfig file location: {get_central_config_path()}")


if __name__ == "__main__":
    # Test the configuration loader
    print_config_status()
