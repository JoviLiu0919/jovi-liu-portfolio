# CPSE Debug Analysis Skill

Advanced deep analysis capability for CPSE (Common Platform Systems Engineering) JIRA issues with automated log processing, problem localization, and solution recommendation.

## 🎯 Purpose

This skill provides comprehensive technical analysis for CPSE tickets, specifically designed to:
- **Deep analyze** CPSE JIRA issues with technical context
- **Process debug logs** and identify failure patterns  
- **Correlate issues** with UEFI/BIOS codebase components
- **Provide actionable solutions** with specific code examples
- **Specialize in PQC integration** and BIOS update failures

## 🚀 Quick Start

### Basic Usage
```bash
# Analyze a CPSE issue
python .windsurf/cpse_debug_analysis/scripts/cpse_analyzer.py --ticket CPSE-46745

# Save analysis to file
python .windsurf/cpse_debug_analysis/scripts/cpse_analyzer.py --ticket CPSE-46745 --output analysis_report.json
```

### Advanced Usage
```bash
# Specify custom codebase location
python .windsurf/cpse_debug_analysis/scripts/cpse_analyzer.py --ticket CPSE-46745 --codebase /path/to/bios/codebase

# Use custom jira tool location
python .windsurf/cpse_debug_analysis/scripts/cpse_analyzer.py --ticket CPSE-46745 --jira-tool /custom/path/jira_tool.py
```

## 🔍 Capabilities

### **Technical Analysis**
- **PQC Integration Issues**: LMS signing, key management, protocol failures
- **BIOS Update Failures**: Flash update mechanisms, signature verification
- **Protocol Installation**: UEFI driver initialization and dependencies
- **Platform Configurations**: CongoLnlOne, VisionWCL, and other Dell platforms

### **Log Processing**
- **Automatic Download**: Retrieve debug logs from JIRA attachments
- **Pattern Extraction**: Identify critical error patterns and GUID references
- **Timeline Reconstruction**: Build chronological failure sequences
- **Root Cause Isolation**: Pinpoint exact technical failure points

### **Codebase Correlation**
- **Pattern Matching**: Map log errors to specific source files
- **Configuration Analysis**: Examine platform-specific PCD settings
- **Dependency Mapping**: Identify missing protocols and key containers
- **Architecture Review**: Analyze UEFI driver initialization sequences

### **Solution Architecture**
- **Fix Identification**: Pinpoint exact code changes needed
- **Implementation Guidance**: Provide specific code examples
- **Validation Strategy**: Define testing approaches
- **Risk Assessment**: Evaluate impact and deployment considerations

## 📊 Analysis Output

The tool generates comprehensive analysis reports including:

### **Ticket Overview**
- Basic ticket information (status, assignee, priority)
- Comment history and discussion progression
- Linked issues and dependencies

### **Technical Analysis**
- Debug log findings with line numbers and context
- Protocol installation status and GUID references
- PQC verification results and failure patterns
- Error event timeline and sequence

### **Codebase Correlation**
- Relevant source files and configurations
- Missing implementations and key categories
- Platform-specific settings and dependencies
- Architecture recommendations

### **Solution Recommendations**
- **High Priority**: Critical fixes for blocking issues
- **Medium Priority**: Improvements and optimizations
- **Implementation Steps**: Specific code changes and file locations
- **Verification Strategy**: Testing and validation approaches

## 🛠️ Technical Details

### **Critical GUID Patterns**
The tool monitors these key GUIDs for CPSE analysis:

```python
critical_guids = {
    'pqc_dxe_protocol': 'C41932C0-6DAD-4E62-BE6A-8100138699C2',
    'flash_update_protocol': '941255B3-677B-494E-8317-1A35E52F4C92', 
    'pqc_ppi': '7B99C7AE-2138-4399-A006-D30E39536C7C',
    'missing_pqc_category': '540B32B0-808D-47E1-A188-76AA7CF1BB93'
}
```

### **Error Pattern Detection**
Automatically identifies these critical patterns:

- **PQC Key Missing**: `PQC Public key category not found <GUID>`
- **Protocol Installation**: `InstallProtocolInterface: <GUID> <HANDLE>`
- **BIOS Update Failure**: `BIOS Update failed. Rebooting your system`
- **Verification Failure**: `VerifyPayloadWithPqcSignature() returning FALSE`
- **Protocol Not Found**: `Located gDellPqcCryptoProtocolDxeGuid with Status: Not Found`

### **Solution Templates**
The tool generates ready-to-use code solutions:

```c
// Example: Missing PQC key category
#define MISSING_PQC_KEY_CATEGORY_GUID { 0x540B32B0, 0x808D, 0x47E1, { 0xA1, 0x88, 0x76, 0xAA, 0x7C, 0xF1, 0xBB, 0x93 } }

static DELL_PUBLIC_KEY mMissingKeyEntry = {
    mMissingKeyData,
    sizeof(mMissingKeyData),
    (ATTR_LMS_N32_H20_W4 | ATTR_HASH_SHA384 | ATTR_SIGN_LMS),
    MISSING_PQC_KEY_CATEGORY_GUID
};
```

## 📋 Use Cases

### **Case 1: PQC Integration Failure**
```bash
# Analyze PQC-related BIOS update failure
python .windsurf/cpse_debug_analysis/scripts/cpse_analyzer.py --ticket CPSE-46745

# Expected: Identify missing PQC key categories and provide fix
```

### **Case 2: Protocol Installation Issues**
```bash
# Debug UEFI driver initialization problems
python .windsurf/cpse_debug_analysis/scripts/cpse_analyzer.py --ticket CPSE-46800

# Expected: Find protocol dependency issues and installation order problems
```

### **Case 3: Platform-Specific Issues**
```bash
# Analyze CongoLnlOne platform configuration
python .windsurf/cpse_debug_analysis/scripts/cpse_analyzer.py --ticket CPSE-46900

# Expected: Identify platform-specific PCD settings and key table issues
```

## 🔧 Integration

### **Dependencies**
- **jira_integration**: Core JIRA data access
- **Python 3.7+**: Script execution environment
- **Git/Find Tools**: Codebase search capabilities

### **Data Flow**
1. **Input**: CPSE ticket ID
2. **Collection**: JIRA data via jira_integration
3. **Processing**: Specialized CPSE analysis patterns
4. **Correlation**: Codebase mapping and dependency analysis
5. **Output**: Comprehensive technical report with solutions

## 📈 Quality Assurance

### **Validation Criteria**
- **Completeness**: All attachments processed and analyzed
- **Technical Accuracy**: Code references verified against actual codebase
- **Solution Feasibility**: Proposed fixes validated for implementation
- **Risk Assessment**: Balanced view of complexity and impact

### **Continuous Improvement**
- **Pattern Library**: Maintained database of common failure patterns
- **Solution Templates**: Reusable fix patterns for common issues
- **Knowledge Base**: Updated with new platform configurations
- **Feedback Integration**: User validation incorporated into recommendations

## 🚨 Error Handling

### **Insufficient Data**
- Requests additional debug information when needed
- Identifies missing technical files or vague descriptions
- Provides guidance on what information to collect

### **Complex Scenarios**
- Handles multi-platform issues and cross-dependencies
- Identifies competing requirements and legacy compatibility
- Flags security implications and platform-wide impacts

## 📚 Examples

### **Sample Analysis Output**
```json
{
  "ticket": {
    "key": "CPSE-46745",
    "summary": "[CongoLnlOne] BIOS exe cannot be flash after enable PQC",
    "status": "Backlog",
    "assignee": "Tang, Tim"
  },
  "attachments": {
    "debug_logs": [
      {
        "findings": [
          {
            "type": "pqc_key_not_found",
            "match": "PQC Public key category not found 540B32B0-808D-47E1-A188-76AA7CF1BB93"
          }
        ]
      }
    ]
  },
  "solutions": [
    {
      "type": "add_missing_pqc_key",
      "priority": "HIGH",
      "description": "Add missing PQC key category to platform key table",
      "implementation": "// Code solution provided",
      "files_to_modify": ["DellPqcPublicKeyTable.h"]
    }
  ]
}
```

## 🤝 Contributing

### **Adding New Patterns**
1. Update `error_patterns` in `cpse_analyzer.py`
2. Add corresponding analysis logic
3. Create solution templates
4. Update documentation

### **Extending Platform Support**
1. Add platform-specific GUID patterns
2. Include platform configuration files
3. Create platform-specific solution templates
4. Update knowledge base

## 📞 Support

For issues or questions:
1. Check the analysis output for specific error messages
2. Verify jira_integration tool is properly configured
3. Ensure codebase path is correct and accessible
4. Review debug logs for additional context

---

**Note**: This skill is designed specifically for Dell CPSE issues and requires proper access to Dell internal JIRA system and BIOS codebase.
