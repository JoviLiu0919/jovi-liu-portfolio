#!/usr/bin/env python3
"""
Enhanced Report Generator for CPSE Debug Analysis

Provides detailed analysis reports including:
- Log analysis details
- Code correlation findings
- Execution sequence analysis
- Root cause correlation
"""

from typing import Dict, List, Any
import re
from datetime import datetime

class EnhancedReportGenerator:
    """Enhanced report generator with detailed technical analysis"""
    
    def __init__(self):
        self.execution_patterns = {
            'bios_initialization': r'BIOS\s+Initialization|POST\s+Complete|DXE\s+Phase',
            'payload_verification': r'VerifyPayload|Signature\s+Verification|PQC\s+LMS',
            'ec_initialization': r'EC\s+Initialize|Embedded\s+Controller|MCHP\s+550',
            'flash_update': r'Flash\s+Update|BIOS\s+Update|Firmware\s+Update',
            'security_check': r'Secure\s+Boot|TPM\s+Check|Platform\s+Key'
        }
        
        self.code_correlation_patterns = {
            'dell_pqc_signer': r'DellBiosPqcSigner|VerifyLmsSignature',
            'ec_payload_handler': r'EcPayload|EmbeddedController|BoardPayload',
            'platform_config': r'CongoLnlOne|DellPlatformPkg|FlashPayload',
            'key_management': r'PqcPublicKeyTable|KeyCategory|SYSTEM_PQC_LMS'
        }
    
    def generate_enhanced_technical_analysis(self, analysis_data: Dict[str, Any]) -> str:
        """Generate enhanced technical analysis section"""
        report = """
## Enhanced Technical Analysis

### Log Analysis Details
"""
        
        # Add detailed log analysis
        if 'log_analysis' in analysis_data:
            log_analysis = analysis_data['log_analysis']
            report += self._generate_log_analysis_section(log_analysis)
        
        # Add execution sequence analysis
        if 'execution_sequence' in analysis_data:
            exec_sequence = analysis_data['execution_sequence']
            report += self._generate_execution_sequence_section(exec_sequence)
        
        # Add code correlation analysis
        if 'code_correlation' in analysis_data:
            code_corr = analysis_data['code_correlation']
            report += self._generate_code_correlation_section(code_corr)
        
        # Add root cause correlation
        if 'root_cause_analysis' in analysis_data:
            root_cause = analysis_data['root_cause_analysis']
            report += self._generate_root_cause_section(root_cause)
        
        return report
    
    def _generate_log_analysis_section(self, log_analysis: Dict[str, Any]) -> str:
        """Generate detailed log analysis section"""
        section = f"""
#### Analyzed Logs
- **Total Logs Processed**: {log_analysis.get('total_logs', 0)}
- **Log Files**: {', '.join(log_analysis.get('log_files', []))}
- **Analysis Timestamp**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

#### Critical Error Patterns Found
"""
        
        error_patterns = log_analysis.get('error_patterns', [])
        for i, pattern in enumerate(error_patterns, 1):
            section += f"""
**Pattern {i}: {pattern.get('type', 'Unknown')}**
- **Description**: {pattern.get('description', 'No description')}
- **Frequency**: {pattern.get('count', 0)} occurrences
- **First Occurrence**: Line {pattern.get('first_line', 'N/A')}
- **Last Occurrence**: Line {pattern.get('last_line', 'N/A')}
- **Log Excerpt**:
```
{pattern.get('excerpt', 'No excerpt available')}
```
- **Context**: {pattern.get('context', 'No context available')}
"""
        
        return section
    
    def _generate_execution_sequence_section(self, exec_sequence: Dict[str, Any]) -> str:
        """Generate execution sequence analysis section"""
        section = """
### Execution Sequence Analysis

#### System Boot/Update Flow
"""
        
        phases = exec_sequence.get('phases', [])
        for i, phase in enumerate(phases, 1):
            section += f"""
**Phase {i}: {phase.get('name', 'Unknown')}**
- **Timeline**: {phase.get('start_time', 'N/A')} → {phase.get('end_time', 'N/A')}
- **Duration**: {phase.get('duration', 'Unknown')}
- **Status**: {phase.get('status', 'Unknown')}
- **Key Events**:
"""
            for event in phase.get('events', []):
                section += f"  - {event.get('timestamp', 'N/A')}: {event.get('description', 'No description')}\n"
        
        # Add failure point analysis
        failure_point = exec_sequence.get('failure_point', {})
        if failure_point:
            section += f"""
#### Critical Failure Point
- **Phase**: {failure_point.get('phase', 'Unknown')}
- **Timestamp**: {failure_point.get('timestamp', 'N/A')}
- **Error**: {failure_point.get('error', 'Unknown error')}
- **Impact**: {failure_point.get('impact', 'Unknown impact')}
- **Root Cause Indicator**: {failure_point.get('root_cause_indicator', 'No indicator')}
"""
        
        return section
    
    def _generate_code_correlation_section(self, code_corr: Dict[str, Any]) -> str:
        """Generate code correlation analysis section"""
        section = """
### Code Correlation Analysis

#### Source Code Components Identified
"""
        
        components = code_corr.get('components', [])
        for component in components:
            section += f"""
**Component: {component.get('name', 'Unknown')}**
- **File Path**: `{component.get('file_path', 'Unknown')}`
- **Function**: {component.get('function', 'Unknown')}
- **Line Numbers**: {component.get('line_range', 'Unknown')}
- **Relevance**: {component.get('relevance', 'Unknown')}
- **Code Context**:
```c
{component.get('code_snippet', 'No code snippet available')}
```
- **Issue Correlation**: {component.get('issue_correlation', 'No correlation identified')}
"""
        
        # Add configuration correlation
        configs = code_corr.get('configurations', [])
        if configs:
            section += """
#### Platform Configurations
"""
            for config in configs:
                section += f"""
- **Config File**: `{config.get('file', 'Unknown')}`
- **Setting**: {config.get('setting', 'Unknown')}
- **Current Value**: {config.get('current_value', 'Unknown')}
- **Expected Value**: {config.get('expected_value', 'Unknown')}
- **Impact**: {config.get('impact', 'Unknown')}
"""
        
        return section
    
    def _generate_root_cause_section(self, root_cause: Dict[str, Any]) -> str:
        """Generate root cause correlation section"""
        section = """
### Root Cause Correlation Analysis

#### Causal Chain Analysis
"""
        
        causal_chain = root_cause.get('causal_chain', [])
        for i, link in enumerate(causal_chain, 1):
            section += f"""
**Link {i}: {link.get('event', 'Unknown')}**
- **Timeline**: {link.get('timestamp', 'N/A')}
- **Trigger**: {link.get('trigger', 'Unknown trigger')}
- **Effect**: {link.get('effect', 'Unknown effect')}
- **Evidence**: {link.get('evidence', 'No evidence')}
- **Confidence**: {link.get('confidence', 'Unknown')}%
"""
        
        # Add contributing factors
        factors = root_cause.get('contributing_factors', [])
        if factors:
            section += """
#### Contributing Factors
"""
            for factor in factors:
                section += f"""
- **Factor**: {factor.get('name', 'Unknown')}
- **Category**: {factor.get('category', 'Unknown')}
- **Impact Level**: {factor.get('impact_level', 'Unknown')}
- **Evidence**: {factor.get('evidence', 'No evidence')}
- **Mitigation**: {factor.get('mitigation', 'No mitigation')}
"""
        
        # Add execution flow correlation
        flow_correlation = root_cause.get('execution_flow_correlation', {})
        if flow_correlation:
            section += f"""
#### Execution Flow Correlation
- **Normal Flow**: {flow_correlation.get('normal_flow', 'Unknown')}
- **Actual Flow**: {flow_correlation.get('actual_flow', 'Unknown')}
- **Deviation Point**: {flow_correlation.get('deviation_point', 'Unknown')}
- **Deviation Impact**: {flow_correlation.get('deviation_impact', 'Unknown')}
- **Root Cause Location**: {flow_correlation.get('root_cause_location', 'Unknown')}
"""
        
        return section
    
    def analyze_log_execution_sequence(self, log_content: str) -> Dict[str, Any]:
        """Analyze execution sequence from log content"""
        lines = log_content.split('\n')
        phases = []
        current_phase = None
        failure_point = None
        
        for i, line in enumerate(lines):
            # Detect phase transitions
            for phase_name, pattern in self.execution_patterns.items():
                if re.search(pattern, line, re.IGNORECASE):
                    if current_phase and current_phase['name'] != phase_name:
                        phases.append(current_phase)
                    
                    current_phase = {
                        'name': phase_name,
                        'start_line': i + 1,
                        'start_time': self._extract_timestamp(line),
                        'events': [],
                        'status': 'in_progress'
                    }
                    break
            
            # Detect failure patterns
            if re.search(r'error|failed|exception|critical', line, re.IGNORECASE):
                if current_phase:
                    current_phase['events'].append({
                        'timestamp': self._extract_timestamp(line),
                        'description': line.strip(),
                        'type': 'error'
                    })
                
                if not failure_point:
                    failure_point = {
                        'phase': current_phase['name'] if current_phase else 'Unknown',
                        'timestamp': self._extract_timestamp(line),
                        'error': line.strip(),
                        'line_number': i + 1,
                        'root_cause_indicator': self._identify_root_cause_indicator(line)
                    }
        
        # Add final phase
        if current_phase:
            phases.append(current_phase)
        
        return {
            'phases': phases,
            'failure_point': failure_point,
            'total_phases': len(phases)
        }
    
    def analyze_code_correlation(self, log_content: str, codebase_root: str) -> Dict[str, Any]:
        """Analyze code correlation based on log patterns"""
        components = []
        configurations = []
        
        # Analyze log for code references
        for pattern_name, pattern in self.code_correlation_patterns.items():
            matches = re.finditer(pattern, log_content, re.IGNORECASE)
            for match in matches:
                component = {
                    'name': pattern_name,
                    'pattern_matched': match.group(),
                    'line_number': log_content[:match.start()].count('\n') + 1,
                    'context': self._get_code_context(match.group(), codebase_root)
                }
                components.append(component)
        
        return {
            'components': components,
            'configurations': configurations,
            'total_components': len(components)
        }
    
    def _extract_timestamp(self, line: str) -> str:
        """Extract timestamp from log line"""
        # Common timestamp patterns
        patterns = [
            r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})',
            r'(\d{2}:\d{2}:\d{2})',
            r'\[(\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})\]'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, line)
            if match:
                return match.group(1)
        
        return 'Unknown'
    
    def _identify_root_cause_indicator(self, error_line: str) -> str:
        """Identify potential root cause from error line"""
        indicators = {
            'PQC signing': r'PQC|LMS|verification.*failed',
            'EC payload': r'EC|Embedded|Controller|5A0D5E58',
            'Key category': r'key.*category|GUID|540B32B0',
            'Platform config': r'CongoLnlOne|platform|configuration'
        }
        
        for indicator, pattern in indicators.items():
            if re.search(pattern, error_line, re.IGNORECASE):
                return indicator
        
        return 'Unknown'
    
    def _get_code_context(self, pattern: str, codebase_root: str) -> Dict[str, Any]:
        """Get code context for a pattern"""
        # This would search the codebase for the pattern
        # For now, return placeholder
        return {
            'file_path': 'Unknown',
            'function': 'Unknown',
            'line_range': 'Unknown',
            'code_snippet': f'// Pattern found: {pattern}',
            'relevance': 'High'
        }
