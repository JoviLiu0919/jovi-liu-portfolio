# Dell Skill Creation Template

## 📋 Dell Skill Template

This template demonstrates how to create Dell-specific skills that properly integrate dell-domain-knowledge.

## 🎯 Skill Structure Template

```markdown
---
name: dell-{skill-purpose}
description: {Dell-specific skill description}. Use when analyzing Dell platforms, validating Dell BIOS code, or working with Dell-specific configurations. Automatically integrates Dell platform identification and silicon vendor knowledge.
---

# Dell {Skill Name} Skill

{Skill description focusing on Dell-specific use cases}

## 📚 Dell Domain Knowledge Integration

This skill follows dell-domain-knowledge/SKILL.md for:
- **Platform Identification**: Automatic detection of Dell platform types (NB, DT, Workstation)
- **Silicon Vendor Mapping**: Intel, AMD, Qualcomm, NVIDIA identification
- **Dell-Specific Patterns**: FSP vs AGESA, signing processes, platform configurations

## 🛠️ Dell Platform Analysis

### Platform Detection
- **Package Structure**: `DellPkgs/DellPlatformPkgs/{TYPE}/{PROJECT}Pkg/DellPlatformPkg.dsc`
- **SILICON_PRODUCT_PATH**: Key identifier for silicon vendor detection
- **Platform Types**: NB (Notebook), DT (Desktop), PW (Workstation)

### Silicon Vendor Integration
- **Intel Platforms**: OneSiliconPkg/Product/{PLATFORM_NAME} + FSP support
- **AMD Platforms**: Amd/AGESA_* paths + AGESA support
- **ARM Platforms**: Qualcomm/NVIDIA paths + ARM64 architecture

## 🔧 Integration with Dell Skills

### Required Imports
```python
# Dell domain knowledge integration
from dell_domain_knowledge.scripts.platform_identifier import DellPlatformIdentifier
from dell_ags_standards.scripts.dell_standards_checker import DellStandardsChecker
```

### Platform Identification Usage
```python
# Initialize Dell platform identifier
dell_identifier = DellPlatformIdentifier()

# Analyze platform from DSC file
platform_info = dell_identifier.identify_platform_from_dsc(dsc_path)

# Use platform context for analysis
silicon_vendor = platform_info.get('silicon_vendor')
platform_type = platform_info.get('platform_type')
```

### Dell Standards Integration
```python
# Apply Dell coding standards
dell_checker = DellStandardsChecker()
compliance_results = dell_checker.check_file_compliance(file_path)
```

## 📊 Dell-Specific Reporting

### Report Structure
```markdown
# Dell {Analysis Type} Report

## 📋 Platform Overview
- **Platform Type**: {NB/DT/Workstation}
- **Silicon Vendor**: {Intel/AMD/Qualcomm/NVIDIA}
- **Platform Name**: {PantherLake/LunarLake/etc.}

## 🔍 Dell-Specific Analysis
{Dell-specific findings}

## 📋 雙語摘要 / Bilingual Summary
{Chinese + English summary}
```

## 🎯 Usage Examples

### Dell Platform Analysis
```powershell
# Analyze Dell platform with automatic detection
python scripts/dell_analyzer.py --platform-path "DellPkgs/DellPlatformPkgs/NB/BladePtlOnePkg"

# Validate Dell coding standards
python scripts/dell_validator.py --check-standards --platform-type nb
```

### Integration Examples
- **BBU Platform Checker**: Uses platform identification for BBU validation
- **CPSE Debug Analysis**: Platform-specific context for troubleshooting
- **Code Review**: Dell coding standards validation
```

## ✅ Dell Skill Requirements Checklist

When creating Dell skills, ensure:

- [ ] **Read dell-domain-knowledge/SKILL.md** for platform knowledge
- [ ] **Integrated platform identification** using DellPlatformIdentifier
- [ ] **Applied silicon vendor mapping** (Intel/AMD/Qualcomm/NVIDIA)
- [ ] **Used Dell coding standards** via dell-ags-standards
- [ ] **Included Dell-specific terminology** and acronyms
- [ ] **Followed Dell naming conventions** and structures
- [ ] **Added bilingual reporting** (English + Traditional Chinese)
- [ ] **Implemented Dell error handling** patterns

## 🔄 Integration Patterns

### Dell Platform Context
```python
def analyze_dell_platform(platform_path):
    # Identify platform using Dell domain knowledge
    platform_info = dell_identifier.identify_platform_from_dsc(
        f"{platform_path}/DellPlatformPkg.dsc"
    )
    
    # Apply Dell-specific logic based on platform
    if platform_info.get('silicon_vendor') == 'Intel':
        return analyze_intel_platform(platform_info)
    elif platform_info.get('silicon_vendor') == 'AMD':
        return analyze_amd_platform(platform_info)
```

### Dell Standards Validation
```python
def validate_dell_compliance(code_path, platform_info):
    # Apply Dell AGS standards
    dell_results = dell_checker.check_file_compliance(code_path)
    
    # Add platform-specific validation
    if platform_info.get('fsp_support') == 'Yes':
        return validate_intel_fsp_compliance(code_path, dell_results)
    else:
        return validate_amd_agesa_compliance(code_path, dell_results)
```

This template ensures all Dell skills consistently integrate Dell domain knowledge and follow established patterns.
