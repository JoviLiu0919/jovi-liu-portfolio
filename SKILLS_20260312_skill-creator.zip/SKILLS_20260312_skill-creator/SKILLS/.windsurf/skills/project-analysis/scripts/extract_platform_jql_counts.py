#!/usr/bin/env python3
"""
Platform Issue Status Extractor - Redesigned Version
基於表格結構的 JQL 查詢處理器
"""

import json
import re
import argparse
import subprocess
import sys
import os
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from bs4 import BeautifulSoup


@dataclass
class TableCell:
    """表格單元格定義"""
    row: str  # Sev-1, Sev-2, Sev-3, Total
    column: str  # Submitted, Analyze UI-1, etc.
    value: int = 0
    jql: str = ""
    found: bool = False


@dataclass
class JQLPattern:
    """JQL 查詢模式定義"""
    column: str
    severity: Optional[str]  # None for Total row
    pattern: str
    priority: int = 1


class TableBasedExtractor:
    """基於表格結構的數據提取器"""
    
    # 表格結構定義
    ROWS = ['Sev-1', 'Sev-2', 'Sev-3', 'Total']
    COLUMNS = [
        'Submitted', 'Analyze UI-1', 'Analyze UI-2', 'Analyze UI-3',
        'Wait', 'Review', 'Verify', 'Total Open', 'Closed',
        'Post-RTS', 'ATS-P1', 'ATS-P2', 'ATS-P3', 'ATS-P4', 'ATS-P5',
        'EB/WAD', 'Total'
    ]
    
    def __init__(self):
        """初始化提取器"""
        # 設置路徑
        current_dir = os.getcwd()
        skills_dir = os.path.dirname(current_dir)
        self.jira_tool_path = os.path.join(skills_dir, 'jira-integration', 'scripts')
        self.confluence_tool_path = os.path.join(skills_dir, 'confluence-integration', 'scripts')
        
        self.table_data = {}
        self.raw_results = {}
        self._initialize_table()
    
    def jira_search(self, jql: str) -> int:
        """執行 JQL 查詢並返回計數"""
        try:
            # 構建命令
            cmd = [
                'python', 'jira_tool.py', 'search',
                '--jql', jql,
                '--limit', '1'  # 只需要計數，不需要詳細內容
            ]
            
            # 執行命令
            result = subprocess.run(
                cmd,
                cwd=self.jira_tool_path,
                capture_output=True,
                text=True,
                timeout=60
            )
            
            if result.returncode == 0:
                # 解析 JSON 輸出獲取計數
                output = result.stdout.strip()
                
                # 嘗試解析 JSON
                try:
                    data = json.loads(output)
                    if 'total' in data:
                        return int(data['total'])
                    elif 'issues' in data and len(data['issues']) > 0:
                        # 如果沒有 total 字段，返回 issues 數組長度
                        return len(data['issues'])
                except json.JSONDecodeError:
                    # 如果 JSON 解析失敗，嘗試從文本中提取數字
                    match = re.search(r'"total":\s*(\d+)', output)
                    if match:
                        return int(match.group(1))
                
                print(f"Unable to parse count from output: {output[:200]}...")
                return 0
            else:
                print(f"JQL search failed: {result.stderr}")
                return 0
                
        except Exception as e:
            print(f"Error executing JQL search: {e}")
            return 0
    
    def _initialize_table(self):
        """初始化表格數據結構"""
        for row in self.ROWS:
            self.table_data[row] = {}
            for column in self.COLUMNS:
                self.table_data[row][column] = TableCell(row=row, column=column)
    
    def extract_from_page(self, page_id: str) -> Dict[str, Any]:
        """從 Confluence 頁面提取數據"""
        print(f"Extracting data from page {page_id}...")
        
        try:
            # 獲取頁面內容並提取 JQL 查詢
            jql_queries = self.extract_jql_from_confluence(page_id)
            
            if not jql_queries:
                print("No JQL queries found in the page")
                return {'error': 'No JQL queries found'}
            
            print(f"Found {len(jql_queries)} JQL queries")
            
            # 尋找第一個目標 JQL（Sev-1 - Submitted）
            first_target_jql = None
            first_target_index = None
            
            for i, jql_info in enumerate(jql_queries):
                jql = jql_info['jql']
                
                # 檢查是否是 Sev-1 Submitted 的 JQL（考慮 HTML 編碼）
                if (('status in (Submitted)' in jql or 'status in (&quot;Submitted&quot;)' in jql) and 
                    ('"Issue Severity" = "1-High"' in jql or '&quot;Issue Severity&quot; = &quot;1-High&quot;' in jql)):
                    first_target_jql = jql
                    first_target_index = i
                    print(f"\nFound first target JQL (Sev-1 - Submitted) at position {i+1}!")
                    print(f"JQL: {jql[:100]}...")
                    break
            
            if first_target_jql is None:
                print("Warning: First target JQL (Sev-1 - Submitted) not found")
                # 使用默認從第 0 個開始
                first_target_index = 0
            else:
                print(f"Starting sequential mapping from position {first_target_index + 1}")
            
            # 從第一個目標 JQL 開始，處理 68 個 JQL 查詢
            start_index = first_target_index
            end_index = min(start_index + 68, len(jql_queries))
            actual_jql_queries = jql_queries[start_index:end_index]
            
            print(f"Processing JQL queries from position {start_index + 1} to {end_index}")
            
            results = {}  # 初始化 results 字典
            
            for i, jql_info in enumerate(actual_jql_queries):
                jql = jql_info['jql']
                # 使用順序映射：第 0 個對應 Sev-1-Submitted，第 16 個對應 Sev-1-Total
                severity, column = self._get_sequential_mapping(i)
                
                # 更新映射信息
                mapping = {
                    'severity': severity,
                    'column': column,
                    'confidence': 0.9,
                    'reasoning': [f'Sequential mapping: {severity} - {column} (position {i+1})']
                }
                
                confidence = 0.9
                
                print(f"\nQuery {i+1}/68 (confidence: {confidence:.2f}):")
                print(f"  Target: {severity} - {column}")
                print(f"  Reasoning: {'; '.join(mapping['reasoning'])}")
                print(f"  JQL: {jql[:80]}...")
                
                try:
                    count = self.jira_search(jql)
                    results[f"query_{i}"] = {
                        'count': count,
                        'jql': jql,
                        'raw': jql_info.get('raw', ''),
                        'cell_mapping': mapping,
                        'confidence': confidence,
                        'success': True
                    }
                    print(f"   [OK] Success: {count} issues")
                except Exception as e:
                    results[f"query_{i}"] = {
                        'count': 0,
                        'jql': jql,
                        'raw': jql_info.get('raw', ''),
                        'cell_mapping': mapping,
                        'confidence': confidence,
                        'success': False,
                        'error': str(e)
                    }
                    print(f"   [FAIL] Failed: {str(e)}")
            
            print(f"\nProcessed {len(actual_jql_queries)} JQL queries (from position {start_index + 1} to {end_index})")
            self.raw_results = results
            self._map_results_to_table_simple()
            
            return self._generate_report()
            
        except Exception as e:
            print(f"Error extracting from page: {e}")
            return {'error': str(e)}
    
    def _get_sequential_mapping(self, index: int) -> tuple:
        """根據索引獲取順序映射的嚴重性和列"""
        # 定義表格順序：4 行 × 17 列 = 68 個單元格
        rows = ['Sev-1', 'Sev-2', 'Sev-3', 'Total']
        columns = [
            'Submitted', 'Analyze UI-1', 'Analyze UI-2', 'Analyze UI-3',
            'Wait', 'Review', 'Verify', 'Total Open', 'Closed',
            'Post-RTS', 'ATS-P1', 'ATS-P2', 'ATS-P3', 'ATS-P4', 'ATS-P5',
            'EB/WAD', 'Total'
        ]
        
        # 計算位置
        row_index = index // 17  # 每行 17 列
        col_index = index % 17
        
        if row_index < len(rows) and col_index < len(columns):
            return rows[row_index], columns[col_index]
        else:
            return 'Total', 'Total'  # 默認值
    
    def _map_results_to_table_simple(self):
        """簡化的結果映射，直接使用提取的 JQL 信息"""
        # 清空現有表格
        self._initialize_table()
        
        print("\n=== Mapping JQL Results to Table Cells ===")
        
        # 直接映射結果到表格
        for key, result in self.raw_results.items():
            if result['success']:
                mapping = result['cell_mapping']
                severity = mapping.get('severity')
                column = mapping.get('column')
                count = result['count']
                
                if severity and column and severity in self.table_data and column in self.table_data[severity]:
                    self.table_data[severity][column].value = count
                    self.table_data[severity][column].found = True
                    self.table_data[severity][column].jql = result['jql']
                    
                    print(f"Mapped: {severity} - {column} = {count}")
        
        # 計算總計
        self._calculate_totals()
    
    def extract_jql_from_confluence(self, page_id: str) -> List[Dict]:
        """從 Confluence 頁面提取 JQL 查詢"""
        try:
            # 獲取頁面內容
            cmd = [
                'python', 'confluence_tool.py', 'get',
                '--id', page_id,
                '--format', 'storage'
            ]
            
            result = subprocess.run(
                cmd,
                cwd=self.confluence_tool_path,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                # 解析 JSON 以獲得實際的 HTML 內容
                try:
                    import json
                    data = json.loads(result.stdout)
                    html_content = data['body']['storage']['value']
                    print("Successfully retrieved HTML content from JSON structure")
                except (json.JSONDecodeError, KeyError):
                    html_content = result.stdout
                    print("Using raw HTML content")
                
                if html_content:
                    return self.extract_jql_from_html(html_content)
                else:
                    print("No content found in page")
                    return []
            else:
                print(f"Failed to get page content: {result.stderr}")
                return []
            
        except Exception as e:
            print(f"Error extracting JQL from Confluence: {str(e)}")
            return []
    
    def extract_jql_from_html(self, html_content: str) -> List[Dict]:
        """從 Confluence 頁面提取 JQL 查詢 - 按照 ac:name='jqlQuery' 順序"""
        jql_queries = []
        
        try:
            print("Searching for JQL queries in order of ac:name='jqlQuery' tags...")
            
            # 使用與測試腳本相同的正則表達式
            # 查找完整的 <ac:parameter ac:name="jqlQuery">...</ac:parameter> 標籤
            jql_pattern = r'<ac:parameter[^>]*ac:name=[\'"]jqlQuery[\'"][^>]*>(.*?)</ac:parameter>'
            jql_matches = re.findall(jql_pattern, html_content, re.DOTALL | re.IGNORECASE)
            
            print(f"Found {len(jql_matches)} JQL queries with comprehensive regex")
            
            # 顯示前幾個 JQL 的內容以便調試
            for i in range(min(5, len(jql_matches))):
                jql_content = jql_matches[i].strip()
                print(f"  Debug JQL {i+1}: {jql_content[:100]}...")
            
            for i, jql_content in enumerate(jql_matches):
                if jql_content and len(jql_content.strip()) > 50:
                    # 清理 JQL 內容
                    cleaned_jql = self.html_decode(jql_content.strip())
                    jql_info = self.parse_jql_text(cleaned_jql)
                    if jql_info:
                        jql_queries.append(jql_info)
                        print(f"  JQL {i+1}: Extracted ({len(cleaned_jql)} chars) - {cleaned_jql[:80]}...")
                    else:
                        print(f"  JQL {i+1}: Skipped (parse failed)")
                else:
                    print(f"  JQL {i+1}: Skipped (too short or empty)")
            
            # 備用方法：使用 BeautifulSoup 來確保正確順序
            if not jql_queries:
                print("Regex extraction failed, trying BeautifulSoup method...")
                
                soup = BeautifulSoup(html_content, 'html.parser')
                
                # 查找所有 ac:name="jqlQuery" 的參數
                jql_params = []
                
                # 遍歷所有 ac:parameter 標籤
                for param in soup.find_all('ac:parameter'):
                    if param.get('ac:name') == 'jqlQuery':
                        jql_params.append(param)
                
                print(f"Found {len(jql_params)} JQL parameters with BeautifulSoup")
                
                for i, param in enumerate(jql_params):
                    try:
                        jql_content = param.get_text(strip=True)
                        if jql_content and len(jql_content) > 50:
                            cleaned_jql = self.html_decode(jql_content.strip())
                            jql_info = self.parse_jql_text(cleaned_jql)
                            if jql_info:
                                jql_queries.append(jql_info)
                                print(f"  JQL {i+1}: Extracted ({len(cleaned_jql)} chars) - {cleaned_jql[:80]}...")
                            else:
                                print(f"  JQL {i+1}: Skipped (parse failed)")
                        else:
                            print(f"  JQL {i+1}: Skipped (too short or empty)")
                    except Exception as e:
                        print(f"  JQL {i+1}: Error processing parameter - {str(e)}")
                        continue
            
            # 最後備用：使用之前的文本搜索方法
            if not jql_queries:
                print("Both structured methods failed, using fallback text search...")
                
                # 查找所有包含 project = "PIMS" 的文本節點
                soup = BeautifulSoup(html_content, 'html.parser')
                text_nodes = soup.find_all(string=re.compile(r'project\s*=\s*"PIMS"', re.IGNORECASE))
                
                print(f"Found {len(text_nodes)} text nodes with PIMS project")
                
                for node in text_nodes:
                    jql_text = node.strip()
                    if jql_text and len(jql_text) > 50:  # 過濾掉太短的文本
                        jql_info = self.parse_jql_text(jql_text)
                        if jql_info:
                            jql_queries.append(jql_info)
                            print(f"  JQL: Extracted ({len(jql_text)} chars) - {jql_text[:80]}...")
            
            print(f"Total JQL queries extracted: {len(jql_queries)}")
            return jql_queries
            
        except Exception as e:
            print(f"Error extracting JQL from HTML: {str(e)}")
            return []
    
    def parse_jql_text(self, jql_text: str) -> Optional[Dict]:
        """解析 JQL 文本並確定其對應的欄位"""
        if not jql_text or len(jql_text) < 50:
            return None
        
        # 清理 JQL 文本，移除所有不必要的跳脫字符
        jql_text = self.clean_jql_match(jql_text)
        
        # 確定嚴重性級別
        severity = None
        if '"Issue Severity" = "1-High"' in jql_text:
            severity = 'Sev-1'
        elif '"Issue Severity" = "2-Medium"' in jql_text:
            severity = 'Sev-2'
        elif '"Issue Severity" = "3-Low"' in jql_text:
            severity = 'Sev-3'
        else:
            severity = 'Total'  # 假設沒有嚴重性的是 Total
        
        # 確定欄位
        column = self.determine_column_from_jql(jql_text)
        
        if column:
            return {
                'index': 0,  # 後續會更新
                'jql': jql_text,
                'raw': jql_text,
                'cell_mapping': {
                    'severity': severity,
                    'column': column,
                    'confidence': 0.9,
                    'reasoning': [f'JQL content analysis: {severity} - {column}']
                }
            }
        
        return None
    
    def determine_column_from_jql(self, jql: str) -> Optional[str]:
        """從 JQL 內容確定對應的欄位"""
        # 按優先級檢查各種條件
        conditions = [
            ('Submitted', r'status\s*in\s*\(\s*Submitted\s*\)'),
            ('Analyze UI-1', r'status\s*in\s*\(\s*Analyze\s*\).*UI-1.*No Root Cause.*No Resolution Plan'),
            ('Analyze UI-2', r'Executive Status.*=.*UI-2.*Root Causing.*No Resolution Plan'),
            ('Analyze UI-3', r'Executive Status.*IN.*UI-3.*Resolution Plan'),
            ('Wait', r'status\s*in\s*\(\s*Wait\s*\)'),
            ('Review', r'status\s*in\s*\(\s*Review\s*\)'),
            ('Verify', r'status\s*in\s*\(\s*Verify\s*\)'),
            ('Total Open', r'status\s*in\s*\(\s*Review\s*,\s*Analyze\s*,\s*Verify\s*,\s*Wait\s*\)'),
            ('Total Open', r'status\s*in\s*\(\s*Review\s*,\s*Submitted\s*,\s*Analyze\s*,\s*Verify\s*,\s*Wait\s*\)'),
            ('Total', r'status\s*in\s*\(\s*Review\s*,\s*Analyze\s*,\s*Verify\s*,\s*Wait\s*,\s*Closed\s*\)'),
            ('Closed', r'status\s*in\s*\(\s*Closed\s*\)'),
            ('Post-RTS', r'"Discretionary Field 2".*"Post-RTS"'),
            ('ATS-P1', r'"Discretionary Field 2".*"ATS P1"'),
            ('ATS-P2', r'"Discretionary Field 2".*"ATS P2"'),
            ('ATS-P3', r'"Discretionary Field 2".*"ATS P3"'),
            ('ATS-P4', r'"Discretionary Field 2".*"ATS P4"'),
            ('ATS-P5', r'"Discretionary Field 2".*"ATS P5"'),
            ('EB/WAD', r'"Discretionary Field 2".*"EB/WAD"'),
        ]
        
        for column, pattern in conditions:
            if re.search(pattern, jql, re.IGNORECASE):
                return column
        
        # 如果沒有匹配到，使用更寬鬆的匹配
        if 'status in (Submitted)' in jql:
            return 'Submitted'
        elif 'status in (Analyze)' in jql and 'UI-1' in jql:
            return 'Analyze UI-1'
        elif 'status in (Analyze)' in jql and 'UI-2' in jql:
            return 'Analyze UI-2'
        elif 'status in (Analyze)' in jql and 'UI-3' in jql:
            return 'Analyze UI-3'
        elif 'status in (Wait)' in jql:
            return 'Wait'
        elif 'status in (Review)' in jql:
            return 'Review'
        elif 'status in (Verify)' in jql:
            return 'Verify'
        elif 'status in (Closed)' in jql:
            return 'Closed'
        elif 'ATS P1' in jql:
            return 'ATS-P1'
        elif 'ATS P2' in jql:
            return 'ATS-P2'
        elif 'ATS P3' in jql:
            return 'ATS-P3'
        elif 'ATS P4' in jql:
            return 'ATS-P4'
        elif 'ATS P5' in jql:
            return 'ATS-P5'
        elif 'Post-RTS' in jql:
            return 'Post-RTS'
        elif 'EB/WAD' in jql:
            return 'EB/WAD'
        
        return None
    
    def extract_jql_from_html_string(self, html_content: str) -> List[Dict]:
        """直接從 HTML 字符串中提取 JQL"""
        jql_queries = []
        
        # 查找所有包含 project = "PIMS" 的段落
        jql_pattern = r'project\s*=\s*"PIMS"[^;}]*(?:\s+(?:AND|OR)\s+[^;}]*)*'
        matches = re.findall(jql_pattern, html_content, re.IGNORECASE | re.DOTALL)
        
        print(f"Found {len(matches)} JQL patterns in HTML string")
        
        for match in matches:
            # 清理和驗證 JQL
            cleaned_jql = self.clean_jql_match(match)
            if cleaned_jql:
                jql_info = self.parse_jql_text(cleaned_jql)
                if jql_info:
                    jql_queries.append(jql_info)
        
        return jql_queries
    
    def clean_jql_match(self, match: str) -> str:
        """清理 JQL 匹配結果，修復 Confluence HTML 編碼問題"""
        # 移除 HTML 標籤
        clean = re.sub(r'<[^>]+>', '', match)
        
        # 解碼 HTML 實體
        clean = self.html_decode(clean)
        
        # 清理空白字符
        clean = ' '.join(clean.split())
        
        # 修復 Confluence 特有的編碼問題
        # 1. 將 \\" 替換為 " (HTML 編碼的引號)
        clean = clean.replace('\\"', '"')
        
        # 2. 將 \\" 替換為 " (雙反斜杠加引號)
        clean = clean.replace('\\"', '"')
        
        # 3. 修復雙反斜杠問題，但保留引號前的跳脫
        # 將 \\"text\\" 模式修復為 "text"
        clean = re.sub(r'\\"([^"]*)\\"', r'"\1"', clean)
        
        # 4. 修復多餘的反斜杠，但保留必要的跳脫
        # 將 \\ 替換為 \，但保留 \" 
        clean = re.sub(r'\\(?!")', r'', clean)  # 移除不是引號前的反斜杠
        
        # 5. 處理其他常見的編碼問題
        clean = clean.replace("\\'", "'")       # 移除單引號前的反斜杠
        clean = clean.replace('\\ ', ' ')        # 移除空格前的反斜杠
        clean = clean.replace('\\(', '(')       # 移除括號前的反斜杠
        clean = clean.replace('\\)', ')')       # 移除括號後的反斜杠
        
        # 6. 最終清理：確保沒有連續的雙引號（除了正常的 "" 空字符串）
        clean = re.sub(r'""([^"]+)""', r'"\1"', clean)  # 修復 ""text"" 為 "text"
        
        # 確保 JQL 完整性
        # 移除截斷邏輯，因為它會錯誤地截斷有效的 JQL
        # 只移除明顯的 HTML 標籤和編碼問題
        
        return clean
    
    def extract_jql_from_macro(self, macro) -> Optional[str]:
        """從單個 macro 中提取 JQL 內容"""
        try:
            # 查找 jql 參數
            jql_param = macro.find('ac:parameter', {'ac:name': 'jql'})
            if jql_param:
                return jql_param.get_text().strip()
            
            # 備用方法：查找任何包含 JQL 的文本
            for element in macro.find_all(['ac:parameter', 'ac:plain-text-link']):
                text = element.get_text().strip()
                if text.startswith('project =') or 'project =' in text:
                    return text
            
            return None
        except Exception as e:
            print(f"Error extracting JQL from macro: {str(e)}")
            return None
    
    def validate_jql_for_column(self, jql: str, column: str, severity: str) -> bool:
        """驗證 JQL 是否適合指定的欄位和嚴重性"""
        if not jql.strip():
            return False
        
        # 基本驗證：必須包含 project = "PIMS"
        if 'project =' not in jql and 'project=' not in jql:
            return False
        
        # 驗證嚴重性（除了 Total 欄位）
        if severity != 'Total':
            severity_mapping = {
                'Sev-1': '"Issue Severity" = "1-High"',
                'Sev-2': '"Issue Severity" = "2-Medium"',
                'Sev-3': '"Issue Severity" = "3-Low"'
            }
            if severity_mapping[severity] not in jql:
                return False
        
        # 特定欄位驗證
        column_patterns = {
            'Submitted': r'status\s*in\s*\(\s*Submitted\s*\)',
            'Analyze UI-1': r'status\s*in\s*\(\s*Analyze\s*\).*UI-1.*No Root Cause.*No Resolution Plan',
            'Analyze UI-2': r'Executive Status.*=.*UI-2.*Root Causing.*No Resolution Plan',
            'Analyze UI-3': r'Executive Status.*IN.*UI-3.*Resolution Plan',
            'Wait': r'status\s*in\s*\(\s*Wait\s*\)',
            'Review': r'status\s*in\s*\(\s*Review\s*\)',
            'Verify': r'status\s*in\s*\(\s*Verify\s*\)',
            'Total Open': r'status\s*in\s*\(\s*Review\s*,\s*Analyze\s*,\s*Verify\s*,\s*Wait\s*\)',
            'Closed': r'status\s*in\s*\(\s*Closed\s*\)',
            'Post-RTS': r'"Discretionary Field 2".*"Post-RTS"',
            'ATS-P1': r'"Discretionary Field 2".*"ATS P1"',
            'ATS-P2': r'"Discretionary Field 2".*"ATS P2"',
            'ATS-P3': r'"Discretionary Field 2".*"ATS P3"',
            'ATS-P4': r'"Discretionary Field 2".*"ATS P4"',
            'ATS-P5': r'"Discretionary Field 2".*"ATS P5"',
            'EB/WAD': r'"Discretionary Field 2".*"EB/WAD"',
        }
        
        if column in column_patterns:
            pattern = column_patterns[column]
            if not re.search(pattern, jql, re.IGNORECASE):
                # 對於複雜模式，使用更寬鬆的驗證
                if column.startswith('ATS-'):
                    return f'"ATS {column.split("-")[1]}"' in jql
                elif column.startswith('Analyze UI-'):
                    return 'status in (Analyze)' in jql and column.split()[-1] in jql
                elif column in ['Total Open', 'Closed']:
                    return True  # 這些欄位的驗證較複雜，暫時跳過
                else:
                    return column in jql
        
        return True
    
    def extract_jql_fallback(self, html_content: str) -> List[Dict]:
        """備用的正則表達式提取方法"""
        print("Using fallback regex method...")
        jql_queries = []
        
        # 改進的正則表達式，更好地處理 Confluence macro
        macro_pattern = r'<ac:structured-macro[^>]*name="jqlquery"[^>]*>.*?<ac:parameter[^>]*name="jql"[^>]*>(.*?)</ac:parameter>.*?</ac:structured-macro>'
        all_macros = re.findall(macro_pattern, html_content, re.DOTALL | re.IGNORECASE)
        
        print(f"Found {len(all_macros)} JQL macros with fallback method")
        
        # 簡化的順序分配邏輯
        severity_sections = ['Sev-1', 'Sev-2', 'Sev-3', 'Total']
        expected_columns = ['Submitted', 'Analyze UI-1', 'Analyze UI-2', 'Analyze UI-3', 'Wait', 'Review', 'Verify', 'Total Open', 'Closed', 'Post-RTS', 'ATS-P1', 'ATS-P2', 'ATS-P3', 'ATS-P4', 'ATS-P5', 'EB/WAD', 'Total']
        
        # 按嚴重性分組
        severity_jqls = {'Sev-1': [], 'Sev-2': [], 'Sev-3': [], 'Total': []}
        
        for jql in all_macros:
            decoded_jql = self.html_decode(jql.strip())
            
            if '"Issue Severity" = "1-High"' in decoded_jql:
                severity_jqls['Sev-1'].append(decoded_jql)
            elif '"Issue Severity" = "2-Medium"' in decoded_jql:
                severity_jqls['Sev-2'].append(decoded_jql)
            elif '"Issue Severity" = "3-Low"' in decoded_jql:
                severity_jqls['Sev-3'].append(decoded_jql)
            else:
                severity_jqls['Total'].append(decoded_jql)
        
        # 分配到欄位
        for severity in severity_sections:
            jqls_for_severity = severity_jqls[severity]
            for i, column in enumerate(expected_columns):
                if i < len(jqls_for_severity):
                    jql = jqls_for_severity[i]
                    jql_info = {
                        'index': len(jql_queries),
                        'jql': jql,
                        'raw': jql,
                        'cell_mapping': {
                            'severity': severity,
                            'column': column,
                            'confidence': 0.8,  # 較低的信心度
                            'reasoning': [f'Fallback grouping: {severity} - {column}']
                        }
                    }
                    jql_queries.append(jql_info)
        
        return jql_queries
    
    def analyze_jql_cell_mapping(self, jql: str) -> Dict:
        """分析 JQL 查詢以確定它可能對應的表格單元格"""
        mapping = {
            'severity': None,
            'column': None,
            'confidence': 0.0,
            'reasoning': []
        }
        
        # 確定嚴重性級別
        if '"Issue Severity" = "1-High"' in jql:
            mapping['severity'] = 'Sev-1'
            mapping['confidence'] += 0.3
            mapping['reasoning'].append('Issue Severity = 1-High')
        elif '"Issue Severity" = "2-Medium"' in jql:
            mapping['severity'] = 'Sev-2'
            mapping['confidence'] += 0.3
            mapping['reasoning'].append('Issue Severity = 2-Medium')
        elif '"Issue Severity" = "3-Low"' in jql:
            mapping['severity'] = 'Sev-3'
            mapping['confidence'] += 0.3
            mapping['reasoning'].append('Issue Severity = 3-Low')
        
        # 確定狀態欄位 - 需要考慮嚴重性級別的存在
        has_severity = any(severity in jql for severity in ['"Issue Severity" = "1-High"', '"Issue Severity" = "2-Medium"', '"Issue Severity" = "3-Low"'])
        
        # 如果沒有嚴重性級別，這是 Total 行的查詢
        if not has_severity:
            mapping['severity'] = 'Total'
            mapping['confidence'] += 0.3
            mapping['reasoning'].append('No severity filter -> Total row')
        
        if 'status in (Submitted)' in jql:
            mapping['column'] = 'Submitted'
            mapping['confidence'] += 0.4
            mapping['reasoning'].append('status = Submitted')
        elif 'status in (Closed)' in jql:
            mapping['column'] = 'Closed'
            mapping['confidence'] += 0.4
            mapping['reasoning'].append('status = Closed')
        elif 'status in (Wait)' in jql:
            mapping['column'] = 'Wait'
            mapping['confidence'] += 0.4
            mapping['reasoning'].append('status = Wait')
        elif 'status in (Review)' in jql:
            mapping['column'] = 'Review'
            mapping['confidence'] += 0.4
            mapping['reasoning'].append('status = Review')
        elif 'status in (Verify)' in jql:
            mapping['column'] = 'Verify'
            mapping['confidence'] += 0.4
            mapping['reasoning'].append('status = Verify')
        elif 'status in (Review, Analyze, Verify, Wait)' in jql or 'status in (Analyze, Review, Verify, Wait)' in jql:
            mapping['column'] = 'Total Open'
            mapping['confidence'] += 0.4
            mapping['reasoning'].append('status = Total Open')
        elif 'status in (Analyze)' in jql:
            # 分析 UI 狀態需要進一步檢查
            if '"Executive Status"  = "UI-1' in jql or ('"Executive Status"  = ' in jql and 'UI-1' in jql):
                mapping['column'] = 'Analyze UI-1'
                mapping['confidence'] += 0.5
                mapping['reasoning'].append('Analyze UI-1 status')
            elif '"Executive Status"  = "UI-2' in jql or ('"Executive Status"  = ' in jql and 'UI-2' in jql):
                mapping['column'] = 'Analyze UI-2'
                mapping['confidence'] += 0.5
                mapping['reasoning'].append('Analyze UI-2 status')
            elif '"Executive Status"' in jql and ('UI-3' in jql):
                mapping['column'] = 'Analyze UI-3'
                mapping['confidence'] += 0.5
                mapping['reasoning'].append('Analyze UI-3 status')
            else:
                mapping['column'] = 'Analyze UI-1'  # 默認
                mapping['confidence'] += 0.2
                mapping['reasoning'].append('Analyze status (default UI-1)')
        
        # ATS 相關欄位
        if '"Discretionary Field 2" = Post-RTS' in jql:
            mapping['column'] = 'Post-RTS'
            mapping['confidence'] += 0.6
            mapping['reasoning'].append('Post-RTS field')
        elif '"Discretionary Field 2" = "ATS P1"' in jql:
            mapping['column'] = 'ATS-P1'
            mapping['confidence'] += 0.6
            mapping['reasoning'].append('ATS-P1 field')
        elif '"Discretionary Field 2" = "ATS P2"' in jql:
            mapping['column'] = 'ATS-P2'
            mapping['confidence'] += 0.6
            mapping['reasoning'].append('ATS-P2 field')
        elif '"Discretionary Field 2" = "ATS P3"' in jql:
            mapping['column'] = 'ATS-P3'
            mapping['confidence'] += 0.6
            mapping['reasoning'].append('ATS-P3 field')
        elif '"Discretionary Field 2" = "ATS P4"' in jql:
            mapping['column'] = 'ATS-P4'
            mapping['confidence'] += 0.6
            mapping['reasoning'].append('ATS-P4 field')
        elif '"Discretionary Field 2" = "ATS P5"' in jql:
            mapping['column'] = 'ATS-P5'
            mapping['confidence'] += 0.6
            mapping['reasoning'].append('ATS-P5 field')
        elif '"Discretionary Field 2" = "EB/WAD"' in jql:
            mapping['column'] = 'EB/WAD'
            mapping['confidence'] += 0.6
            mapping['reasoning'].append('EB/WAD field')
        
        # Total 欄位 - 包含所有狀態
        if 'status in (Review, Analyze, Verify, Wait, Closed)' in jql or 'status in (Review, Analyze, Verify, Wait, Submitted, Closed)' in jql:
            mapping['column'] = 'Total'
            mapping['confidence'] += 0.4
            mapping['reasoning'].append('Total status (all states)')
        
        # 特殊檢查：如果 JQL 包含 Platform Found 但不包含 Part No with PAW，可能是錯誤的
        if '"Platform Found (PF)"' in jql and '"Part No with PAW"' not in jql:
            mapping['confidence'] -= 0.3
            mapping['reasoning'].append('WARNING: Contains Platform Found but missing Part No with PAW')
        
        # 如果只包含 Part No with PAW，大幅提高置信度（這是正確的 CS 格式）
        if '"Part No with PAW"' in jql and '"Platform Found (PF)"' not in jql:
            mapping['confidence'] += 0.5
            mapping['reasoning'].append('Contains only Part No with PAW (correct CS format)')
        
        # 如果同時包含 Platform Found 和 Part No with PAW，降低置信度（這可能是錯誤的）
        if '"Platform Found (PF)"' in jql and '"Part No with PAW"' in jql:
            mapping['confidence'] -= 0.2
            mapping['reasoning'].append('WARNING: Contains both Platform Found and Part No with PAW (may be incorrect)')
        
        return mapping
    
    def html_decode(self, html_content: str) -> str:
        """增強的 HTML 實體解碼"""
        import html
        
        try:
            # 首先使用 Python 內建的 html.unescape
            decoded = html.unescape(html_content)
            
            # 處理一些常見的編碼問題
            decoded = decoded.replace('&amp;', '&')
            decoded = decoded.replace('&lt;', '<')
            decoded = decoded.replace('&gt;', '>')
            decoded = decoded.replace('&quot;', '"')
            decoded = decoded.replace('&#39;', "'")
            decoded = decoded.replace('&apos;', "'")
            
            # 處理 Confluence 特定的編碼
            decoded = decoded.replace('\\n', '\n')
            decoded = decoded.replace('\\t', '\t')
            decoded = decoded.replace('\\"', '"')
            decoded = decoded.replace('\\\'', "'")
            
            # 修復 JQL 中的雙反斜杠問題 - 移除不必要的跳脫
            decoded = decoded.replace('\\\\', '\\')  # 將雙反斜杠替換為單反斜杠
            decoded = decoded.replace('\\"', '"')   # 移除引號前的跳脫
            decoded = decoded.replace("\\'", "'")   # 移除單引號前的跳脫
            
            return decoded.strip()
        except Exception as e:
            print(f"Warning: HTML decoding failed: {str(e)}")
            # 備用：使用基本的字符串替換
            return html_content.replace('&amp;', '&').replace('&quot;', '"').replace('&lt;', '<').replace('&gt;', '>')
    
    def _map_results_to_table(self):
        """將 JQL 查詢結果映射到表格單元格 - 使用基於置信度的智能匹配"""
        # 清空現有表格
        self._initialize_table()
        
        print("\n=== Mapping JQL Results to Table Cells ===")
        
        # 為每個表格單元格找到最佳匹配的 JQL
        for severity in ['Sev-1', 'Sev-2', 'Sev-3']:
            for column in self.table_data[severity].keys():
                best_match = self._find_best_jql_match(severity, column)
                
                if best_match:
                    jql_info = best_match
                    count = jql_info['count']
                    jql = jql_info['jql']
                    confidence = jql_info['confidence']
                    reasoning = jql_info['cell_mapping']['reasoning']
                    
                    # 填充表格單元格
                    cell = self.table_data[severity][column]
                    cell.value = count
                    cell.found = True
                    cell.jql = jql
                    
                    print(f"{severity} - {column}: {count} (confidence: {confidence:.2f})")
                    print(f"  Reasoning: {'; '.join(reasoning)}")
                    print(f"  JQL: {jql[:100]}...")
                    print()
                else:
                    print(f"{severity} - {column}: No matching JQL found")
        
        # 計算總計行
        self._calculate_totals()
    
    def _find_best_jql_match(self, target_severity: str, target_column: str) -> Optional[Dict]:
        """為指定的表格單元格找到最佳匹配的 JQL 查詢 - 使用結構化順序"""
        # 由於我們使用結構化順序，直接查找對應的 JQL
        for jql_info in self.raw_results.values():
            if not jql_info.get('success', False):
                continue
                
            mapping = jql_info.get('cell_mapping', {})
            severity = mapping.get('severity')
            column = mapping.get('column')
            
            # 直接匹配結構化分配
            if severity == target_severity and column == target_column:
                return jql_info
        
        return None
    
    def _calculate_totals(self):
        """計算總計行和列"""
        # 計算每個嚴重性級別的總計
        for severity in ['Sev-1', 'Sev-2', 'Sev-3']:
            total = 0
            for column, cell in self.table_data[severity].items():
                if column != 'Total' and cell.found:
                    total += cell.value
            
            self.table_data[severity]['Total'].value = total
            self.table_data[severity]['Total'].found = True
        
        # 計算 Total 行
        for column in self.table_data['Total'].keys():
            if column == 'Total':
                continue
                
            total = 0
            for severity in ['Sev-1', 'Sev-2', 'Sev-3']:
                cell = self.table_data[severity][column]
                if cell.found:
                    total += cell.value
            
            self.table_data['Total'][column].value = total
            self.table_data['Total'][column].found = True
        
        # 計算 Grand Total
        grand_total = 0
        for severity in ['Sev-1', 'Sev-2', 'Sev-3']:
            if self.table_data[severity]['Total'].found:
                grand_total += self.table_data[severity]['Total'].value
        
        self.table_data['Total']['Total'].value = grand_total
        self.table_data['Total']['Total'].found = True
    
    def _match_jql_to_cells(self, jql: str) -> List[TableCell]:
        """使用基於順序的匹配將JQL結果映射到表格單元格"""
        matched_cells = []
        
        # 從 raw_results 中找到當前 JQL 的索引
        query_index = None
        for i, (key, result) in enumerate(self.raw_results.items()):
            if result.get('jql') == jql:
                query_index = i
                break
        
        if query_index is None:
            return matched_cells
        
        # 定義JQL查詢順序到表格單元格的映射
        # 基於標準的 Platform Issue Status 表格結構
        # 所有專案都遵循相同的表格順序：每個嚴重性級別有固定的查詢順序
        query_mapping = {
            # Sev-1 查詢 (0-16) - 標準順序
            0: ('Sev-1', 'Submitted'),
            1: ('Sev-1', 'Analyze UI-1'),
            2: ('Sev-1', 'Analyze UI-2'),
            3: ('Sev-1', 'Analyze UI-3'),
            4: ('Sev-1', 'Wait'),
            5: ('Sev-1', 'Review'),
            6: ('Sev-1', 'Verify'),
            7: ('Sev-1', 'Total Open'),
            8: ('Sev-1', 'Closed'),
            9: ('Sev-1', 'Post-RTS'),
            10: ('Sev-1', 'ATS-P1'),
            11: ('Sev-1', 'ATS-P2'),
            12: ('Sev-1', 'ATS-P3'),
            13: ('Sev-1', 'ATS-P4'),
            14: ('Sev-1', 'ATS-P5'),
            15: ('Sev-1', 'EB/WAD'),
            16: ('Sev-1', 'Total'),
            
            # Sev-2 查詢 (17-33) - 標準順序
            17: ('Sev-2', 'Submitted'),
            18: ('Sev-2', 'Analyze UI-1'),
            19: ('Sev-2', 'Analyze UI-2'),
            20: ('Sev-2', 'Analyze UI-3'),
            21: ('Sev-2', 'Wait'),
            22: ('Sev-2', 'Review'),
            23: ('Sev-2', 'Verify'),
            24: ('Sev-2', 'Total Open'),
            25: ('Sev-2', 'Closed'),
            26: ('Sev-2', 'Post-RTS'),
            27: ('Sev-2', 'ATS-P1'),
            28: ('Sev-2', 'ATS-P2'),
            29: ('Sev-2', 'ATS-P3'),
            30: ('Sev-2', 'ATS-P4'),
            31: ('Sev-2', 'ATS-P5'),
            32: ('Sev-2', 'EB/WAD'),
            33: ('Sev-2', 'Total'),
            
            # Sev-3 查詢 (34-50) - 標準順序
            34: ('Sev-3', 'Submitted'),
            35: ('Sev-3', 'Analyze UI-1'),
            36: ('Sev-3', 'Analyze UI-2'),
            37: ('Sev-3', 'Analyze UI-3'),
            38: ('Sev-3', 'Wait'),
            39: ('Sev-3', 'Review'),
            40: ('Sev-3', 'Verify'),
            41: ('Sev-3', 'Total Open'),
            42: ('Sev-3', 'Closed'),
            43: ('Sev-3', 'Post-RTS'),
            44: ('Sev-3', 'ATS-P1'),
            45: ('Sev-3', 'ATS-P2'),
            46: ('Sev-3', 'ATS-P3'),
            47: ('Sev-3', 'ATS-P4'),
            48: ('Sev-3', 'ATS-P5'),
            49: ('Sev-3', 'EB/WAD'),
            50: ('Sev-3', 'Total'),
            
            # Total 查詢 (51-67) - 標準順序
            51: ('Total', 'Submitted'),
            52: ('Total', 'Analyze UI-1'),
            53: ('Total', 'Analyze UI-2'),
            54: ('Total', 'Analyze UI-3'),
            55: ('Total', 'Wait'),
            56: ('Total', 'Review'),
            57: ('Total', 'Verify'),
            58: ('Total', 'Total Open'),
            59: ('Total', 'Closed'),
            60: ('Total', 'Post-RTS'),
            61: ('Total', 'ATS-P1'),
            62: ('Total', 'ATS-P2'),
            63: ('Total', 'ATS-P3'),
            64: ('Total', 'ATS-P4'),
            65: ('Total', 'ATS-P5'),
            66: ('Total', 'EB/WAD'),
            67: ('Total', 'Total'),
        }
        
        # 使用順序映射
        if query_index in query_mapping:
            severity, column = query_mapping[query_index]
            if severity in self.table_data and column in self.table_data[severity]:
                cell = self.table_data[severity][column]
                matched_cells.append(cell)
        
        return matched_cells
    
    def _matches_pattern(self, jql: str, pattern: JQLPattern) -> bool:
        """檢查 JQL 是否匹配模式"""
        # 直接使用正則表達式匹配
        try:
            return re.search(pattern.pattern, jql, re.IGNORECASE) is not None
        except:
            # 如果正則表達式失敗，回退到簡單字符串匹配
            return pattern.pattern in jql
    
    def _calculate_derived_values(self):
        """計算衍生值"""
        # 計算 Total Open (Submitted + Analyze UI-1/2/3 + Wait + Review + Verify)
        for row in ['Sev-1', 'Sev-2', 'Sev-3']:
            total_open = (
                self.table_data[row]['Submitted'].value +
                self.table_data[row]['Analyze UI-1'].value +
                self.table_data[row]['Analyze UI-2'].value +
                self.table_data[row]['Analyze UI-3'].value +
                self.table_data[row]['Wait'].value +
                self.table_data[row]['Review'].value +
                self.table_data[row]['Verify'].value
            )
            self.table_data[row]['Total Open'].value = total_open
            self.table_data[row]['Total Open'].found = True
        
        # 計算 Total (所有狀態的總和)
        for row in ['Sev-1', 'Sev-2', 'Sev-3']:
            total = 0
            for column in self.COLUMNS:
                if column not in ['Total', 'Total Open']:  # 排除計算欄位
                    total += self.table_data[row][column].value
            self.table_data[row]['Total'].value = total
            self.table_data[row]['Total'].found = True
        
        # 計算 Total 列
        for column in self.COLUMNS:
            total = 0
            for row in ['Sev-1', 'Sev-2', 'Sev-3']:
                total += self.table_data[row][column].value
            self.table_data['Total'][column].value = total
            self.table_data['Total'][column].found = True
    
    def _generate_report(self) -> Dict[str, Any]:
        """生成最終報告"""
        self._calculate_derived_values()
        
        # 生成表格數據
        table = {}
        for row in self.ROWS:
            table[row] = {}
            for column in self.COLUMNS:
                cell = self.table_data[row][column]
                table[row][column] = {
                    'value': cell.value,
                    'found': cell.found,
                    'jql': cell.jql
                }
        
        # 生成統計摘要
        summary = self._generate_summary()
        
        return {
            'table': table,
            'summary': summary,
            'raw_results': self.raw_results,
            'structure': {
                'rows': self.ROWS,
                'columns': self.COLUMNS
            }
        }
    
    def _generate_summary(self) -> Dict[str, Any]:
        """生成統計摘要"""
        total_open = self.table_data['Total']['Total Open'].value
        total_closed = self.table_data['Total']['Closed'].value
        grand_total = self.table_data['Total']['Total'].value
        
        return {
            'total_open': total_open,
            'total_closed': total_closed,
            'grand_total': grand_total,
            'closure_rate': (total_closed / grand_total * 100) if grand_total > 0 else 0
        }
    
    def _print_table(self):
        """打印格式化表格"""
        print("\n=== Platform Issue Status Table ===")
        
        # 表頭
        header = "               |"
        separator = "---------------|"
        for col in self.COLUMNS:
            header += f" {col:>11} |"
            separator += "------------|"
        
        print(header)
        print(separator)
        
        # 數據行
        for row in self.ROWS:
            if row == 'Total':
                print(separator)
            
            row_data = f" {row:<14} |"
            for col in self.COLUMNS:
                cell = self.table_data[row][col]
                if cell.found:
                    row_data += f" {cell.value:>11} |"
                else:
                    # 對於沒有匹配查詢的欄位，顯示 0 而不是 ?
                    row_data += f" {0:>11} |"
            print(row_data)
        
        print()
    
    def save_results(self, filename: str):
        """保存結果到文件"""
        report = self._generate_report()
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        print(f"Results saved to: {filename}")


def main():
    """主函數"""
    parser = argparse.ArgumentParser(description='Extract Platform Issue Status from Confluence')
    parser.add_argument('--page-id', required=True, help='Confluence page ID')
    parser.add_argument('--output', default='platform_status.json', help='Output file name')
    parser.add_argument('--print-table', action='store_true', help='Print table to console')
    
    args = parser.parse_args()
    
    # 創建提取器
    extractor = TableBasedExtractor()
    
    # 提取數據
    report = extractor.extract_from_page(args.page_id)
    
    if 'error' in report:
        print(f"Error: {report['error']}")
        return
    
    # 打印表格
    if args.print_table:
        extractor._print_table()
    
    # 保存結果
    extractor.save_results(args.output)
    
    # 打印摘要
    summary = report.get('summary', {})
    print(f"\n=== Summary ===")
    print(f"Total Open Issues: {summary.get('total_open', 0)}")
    print(f"Total Closed Issues: {summary.get('total_closed', 0)}")
    print(f"Grand Total: {summary.get('grand_total', 0)}")
    print(f"Closure Rate: {summary.get('closure_rate', 0):.1f}%")


if __name__ == '__main__':
    main()
