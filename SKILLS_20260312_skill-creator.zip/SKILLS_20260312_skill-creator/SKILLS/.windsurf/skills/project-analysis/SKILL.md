---
name: project-analysis
description: Comprehensive project analysis skill for analyzing project structure, dependencies, metrics, and generating detailed reports. Use when analyzing project health, code quality, or generating project documentation.
---

# Project Analysis Skill

Start here to perform comprehensive project analysis. This skill integrates with Confluence and JIRA to fetch project information and analyze project data.

### Project Discovery
```powershell
# Method 1: NPI Platform Information Lookup (Primary Method for New Projects)
# Search NPI Platform Information page for project references
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py grep-page --id 311322473 --pattern "PROJECT_NAME"

# If found in NPI page, get the main project page
python scripts/confluence_tool.py cql-search --query "title='PROJECT_NAME' AND space=CSEI" --limit 5

# Method 2: Sustaining Platform Information Lookup (For Sustaining Projects)
# Search Sustaining Platform Information page for sustaining project references
python scripts/confluence_tool.py grep-page --id 313693926 --pattern "PROJECT_NAME"

# If found in Sustaining page, get the main project page
python scripts/confluence_tool.py cql-search --query "title='PROJECT_NAME' AND space=CSEI" --limit 5

# Method 3: Direct CQL Search (Alternative Method)
# Search for project pages across all spaces
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME'" --limit 20

# Method 4: Issue Manager Search (Find main Issue Manager page only)
# Find main Issue Manager pages (exclude BIOS/EC and SW/Driver/App sub-pages)
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME' AND title~'Issue Manager' AND title!~'BIOS/EC' AND title!~'SW/Driver/App'" --limit 10

# Verify page content before analysis
python scripts/confluence_tool.py get --id [PAGE_ID] | Select-String "Platform Issue Status"
```

## Key Features

### Platform Issue Status Analysis
- **Precise JQL Extraction**: Extracts JQL from Platform Issue Status tables
- **Order-Based Matching**: Uses sequential query mapping for accurate data assignment
- **Automatic Column Mapping**: Handles Sev-1/2/3 × Total/Closed/Submitted/Analyze/Wait/Review/Verify
- **Issue Count Calculation**: Uses JIRA skill for accurate counting
- **UI Classification Support**: Processes Analyze UI-1/UI-2/UI-3 breakdowns
- **ATS Status Handling**: Correctly identifies exclusion logic for Post-RTS/ATS-P1-5/EB/WAD
- **FV Entry Compliance Assessment**: Zero open issues requirement evaluation
- **NUDD Integration**: Validates architecture document completion against project milestones

### Intelligent Page Discovery
- **NPI Platform Information Lookup**: Primary method for new projects using centralized platform database (ID: 311322473)
- **Sustaining Platform Information Lookup**: Dedicated method for sustaining projects using sustaining database (ID: 313693926)
- **Cross-Space Search**: Uses CQL search across all Confluence spaces as backup method
- **Automatic Page Identification**: Finds main project and Issue Manager pages with smart filtering
- **Smart Prioritization**: Prioritizes main Issue Manager pages over sub-pages (BIOS/EC, SW/Driver/App)
- **Content Filtering**: Excludes SW List, Preferences, and other sub-pages
- **Naming Convention Support**: Handles various project naming formats
- **Platform ID Mapping**: Links NPI and Sustaining platform entries to Confluence project pages
- **Project Type Detection**: Automatically distinguishes between NPI and Sustaining projects

### Comprehensive Reporting
- **Real-time Progress**: Shows extraction and execution progress
- **Statistical Reports**: Detailed breakdowns by severity and status
- **JSON Output**: Complete results with metadata
- **Compliance Evaluation**: Risk assessment and recommendations

### NUDD Compliance Analysis
- **NUDD Progress Tracking**: Monitors New Unit Development Document completion status
- **PBA Ticket Validation**: Verifies Platform Business Architecture tickets against milestones
- **Milestone Compliance Check**: Ensures PBA target end dates precede Feature Complete (CP#3)
- **Architecture Document Assessment**: Tracks completion of critical architecture deliverables
- **Risk Evaluation**: Identifies schedule, scope, and quality risks in NUDD implementation
- **Action Item Tracking**: Monitors "Action Needed" and "Wait Issue" counts for project health

### Project Discovery Examples
```powershell
# Example 1: Finding Citadel NVL using NPI Platform Information (New Projects)
cd .windsurf/skills/confluence-integration
# Step 1: Search NPI Platform Information page for Citadel NVL
python scripts/confluence_tool.py grep-page --id 311322473 --pattern "Citadel NVL"

# Step 2: Get the main project page using exact title match
python scripts/confluence_tool.py cql-search --query "title='CITADEL NVL' AND space=CSEI" --limit 5

# Step 3: Find the main Issue Manager page (without BIOS/EC or SW/Driver/App suffixes)
python scripts/confluence_tool.py cql-search --query "title~'Citadel NVL Issue Manager' AND title!~'BIOS/EC' AND title!~'SW/Driver/App'" --limit 5

# Step 4: Run project analysis using the found Issue Manager page ID
cd .windsurf/skills/project-analysis
python scripts/extract_platform_jql_counts.py --page-id 1130469636

# Step 5: Perform NUDD compliance check
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py cql-search --query "title~'Citadel NVL NUDD Summary'" --limit 5

# Step 6: Check NUDD Progress and extract PBA tickets
python scripts/confluence_tool.py grep-page --id [NUDD_SUMMARY_ID] --pattern "NUDD Progress|100.0%"
python scripts/confluence_tool.py cql-search --query "title~'Citadel NVL NUDD Status'" --limit 5

# Step 7: Verify PBA compliance with Feature Complete milestone
python scripts/confluence_tool.py grep-page --id [NUDD_STATUS_ID] --pattern "PBA-[0-9]+|202[0-9]/[0-9]{2}/[0-9]{2}"

# Example 2: Finding Citadel GNR using Sustaining Platform Information (Sustaining Projects)
cd .windsurf/skills/confluence-integration
# Step 1: Search Sustaining Platform Information page for Citadel GNR
python scripts/confluence_tool.py grep-page --id 313693926 --pattern "Citadel GNR"

# Step 2: Get the main project page using exact title match
python scripts/confluence_tool.py cql-search --query "title='CITADEL GNR' AND space=CSEI" --limit 5

# Step 3: Find the main Issue Manager page (without BIOS/EC or SW/Driver/App suffixes)
python scripts/confluence_tool.py cql-search --query "title~'Citadel GNR Issue Manager' AND title!~'BIOS/EC' AND title!~'SW/Driver/App'" --limit 5

# Step 4: Run project analysis using the found Issue Manager page ID
cd .windsurf/skills/project-analysis
python scripts/extract_platform_jql_counts.py --page-id [FOUND_ISSUE_MANAGER_ID]

# Step 5: Perform NUDD compliance check
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME NUDD Summary'" --limit 5

# Step 6: Check NUDD Progress and extract PBA tickets
python scripts/confluence_tool.py grep-page --id [NUDD_SUMMARY_ID] --pattern "NUDD Progress|100.0%"
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME NUDD Status'" --limit 5

# Step 7: Verify PBA compliance with Feature Complete milestone
python scripts/confluence_tool.py grep-page --id [NUDD_STATUS_ID] --pattern "PBA-[0-9]+|202[0-9]/[0-9]{2}/[0-9]{2}"
```

### Advanced Options
```powershell
# Debug mode for troubleshooting
python scripts/extract_platform_jql_counts.py --project "CONGO" --debug

# Verbose output with detailed logging
python scripts/extract_platform_jql_counts.py --project "CONGO" --verbose --output "detailed_results.json"

# Print formatted table with all columns
python scripts/extract_platform_jql_counts.py --project "BLADE PTL 14" --print-table --output "blade_results.json"
```

## Platform Issue Status Table Structure

### Table Logic and Calculations

The Platform Issue Status table follows a specific mathematical structure for issue tracking and reporting:

#### **Row-wise Calculations (Open Issues)**
For each severity level (Sev-1, Sev-2, Sev-3, and Total row):
```
Total Open = Submitted + Analyze UI-1 + Analyze UI-2 + Analyze UI-3 + Wait + Review + Verify
```

#### **Row-wise Calculations (Grand Totals)**
For each severity level (Sev-1, Sev-2, Sev-3, and Total row):
```
Total = Total Open + Closed + Post-RTS + ATS-P1 + ATS-P2 + ATS-P3 + ATS-P4 + ATS-P5 + EB/WAD
```

#### **Column-wise Calculations (Vertical Totals)**
For each column (Submitted, Analyze UI-1, Analyze UI-2, Analyze UI-3, Wait, Review, Verify, Total Open, Closed, Post-RTS, ATS-P1, ATS-P2, ATS-P3, ATS-P4, ATS-P5, EB/WAD, Total):
```
Total Row = Sev-1 + Sev-2 + Sev-3
```

#### **Table Structure**
The Platform Issue Status table has the following structure:

**Rows (4 total):**
- Sev-1 (High Severity)
- Sev-2 (Medium Severity) 
- Sev-3 (Low Severity)
- Total (Vertical sum of all severity levels)

**Columns (17 total):**
- **Status Columns**: Submitted, Analyze UI-1, Analyze UI-2, Analyze UI-3, Wait, Review, Verify, Total Open
- **Resolution Columns**: Closed
- **Special Categories**: Post-RTS, ATS-P1, ATS-P2, ATS-P3, ATS-P4, ATS-P5, EB/WAD
- **Grand Total**: Total

#### **Special Category Definitions**
- **Post-RTS**: Issues marked as Post-Release to Service (excluded from regular open/closed counts)
- **ATS-P1 to ATS-P5**: ATS (Acceptance Test System) priority levels 1-5 (excluded from regular counts)
- **EB/WAD**: Early Build/WAIVED issues (excluded from regular counts)

#### **Exclusion Logic**
The special categories (Post-RTS, ATS-P1-5, EB/WAD) use exclusion logic in JQL:
- These issues are **subtracted** from the main issue counts
- They appear as separate columns for tracking but don't affect Total Open calculations
- This prevents double-counting and maintains data integrity

#### **Example Calculation**
```
Sev-1 Row Example:
Submitted: 0
Analyze UI-1: 2
Analyze UI-2: 0
Analyze UI-3: 0
Wait: 0
Review: 0
Verify: 0
---
Total Open: 0 + 2 + 0 + 0 + 0 + 0 + 0 = 2

Closed: 291
Post-RTS: 0
ATS-P1: 0
ATS-P2: 0
ATS-P3: 0
ATS-P4: 0
ATS-P5: 0
EB/WAD: 0
---
Total: 2 + 291 + 0 + 0 + 0 + 0 + 0 + 0 + 0 = 293

Sev-2 Row Example:
Submitted: 0
Analyze UI-1: 0
Analyze UI-2: 0
Analyze UI-3: 0
Wait: 0
Review: 0
Verify: 2
---
Total Open: 0 + 0 + 0 + 0 + 0 + 0 + 2 = 2

Closed: 854
Post-RTS: 17
ATS-P1: 0
ATS-P2: 0
ATS-P3: 0
ATS-P4: 0
ATS-P5: 0
EB/WAD: 1
---
Total: 2 + 854 + 17 + 0 + 0 + 0 + 0 + 0 + 1 = 874

Vertical Total Row Example:
Total Open: 2 (Sev-1) + 2 (Sev-2) + [Sev-3 count] = [Vertical Total]
Closed: 291 (Sev-1) + 854 (Sev-2) + [Sev-3 count] = [Vertical Total]
```

## Open Issues Aging Analysis

### Aging Days Analysis Features

The project-analysis skill provides comprehensive aging analysis for all open issues to help teams track issue freshness and identify stale tickets requiring attention.

#### **Aging Categories**
- **0-7 days (Recent)**: Actively maintained issues ✅
- **8-14 days (Moderate)**: Issues needing attention ⚠️
- **15-30 days (Stale)**: Issues requiring immediate review 🔴
- **31-60 days (Very Stale)**: Critical issues needing escalation 🔴
- **61-90 days (Critical)**: High-priority stale issues 🔴
- **91+ days (Severe)**: Extreme aging requiring management intervention 🔴

#### **Analysis Capabilities**
- **Comprehensive Aging Distribution**: Categorize all open issues by aging brackets
- **Status Distribution**: Break down issues by current status (Analyze, Verify, Review, etc.)
- **Assignee Workload Analysis**: Identify team members with high ticket loads
- **Bottleneck Detection**: Find phases where issues accumulate
- **Performance Benchmarks**: Compare against industry standards
- **Risk Assessment**: Evaluate aging-related project risks

#### **JQL Queries for Aging Analysis**

```powershell
# Platform Total Open Issues Only (Based on Platform Issue Status Table)
cd .windsurf/skills/jira-integration

# Sev-1 Total Open Issues
python scripts/jira_tool.py batch-search --jql "project = \"PIMS\" AND issuetype = \"Defect\" AND ((status in (Review, Analyze, Verify, Wait) AND (filter = 107934 Or filter = 107932 Or filter = 107933)) OR (status = Submitted AND (filter = 137023 Or filter = 137021 Or filter = 137022))) AND (((\"Platform Found (PF)\" in (\"PROJECT_NAME\") OR \"Platform Affected with PAW\" in (\"PROJECT_NAME:VERIFIED_PRESENT\", \"PROJECT_NAME:VERIFIED_FIXED\")) )) AND \"Issue Severity\" = \"1-High\" AND (\"Discretionary Field 2\" is EMPTY OR \"Discretionary Field 2\" not in (\"ATS P1\",\"ATS P2\",\"ATS P3\",\"ATS P4\",\"ATS P5\",\"Post-RTS\",\"EB/WAD\"))" --save-report

# Sev-2 Total Open Issues
python scripts/jira_tool.py batch-search --jql "project = \"PIMS\" AND issuetype = \"Defect\" AND ((status in (Review, Analyze, Verify, Wait) AND (filter = 107934 Or filter = 107932 Or filter = 107933)) OR (status = Submitted AND (filter = 137023 Or filter = 137021 Or filter = 137022))) AND (((\"Platform Found (PF)\" in (\"PROJECT_NAME\") OR \"Platform Affected with PAW\" in (\"PROJECT_NAME:VERIFIED_PRESENT\", \"PROJECT_NAME:VERIFIED_FIXED\")) )) AND \"Issue Severity\" = \"2-Medium\" AND (\"Discretionary Field 2\" is EMPTY OR \"Discretionary Field 2\" not in (\"ATS P1\",\"ATS P2\",\"ATS P3\",\"ATS P4\",\"ATS P5\",\"Post-RTS\",\"EB/WAD\"))" --save-report

# Sev-3 Total Open Issues
python scripts/jira_tool.py batch-search --jql "project = \"PIMS\" AND issuetype = \"Defect\" AND ((status in (Review, Analyze, Verify, Wait) AND (filter = 107934 Or filter = 107932 Or filter = 107933)) OR (status = Submitted AND (filter = 137023 Or filter = 137021 Or filter = 137022))) AND (((\"Platform Found (PF)\" in (\"PROJECT_NAME\") OR \"Platform Affected with PAW\" in (\"PROJECT_NAME:VERIFIED_PRESENT\", \"PROJECT_NAME:VERIFIED_FIXED\")) )) AND \"Issue Severity\" = \"3-Low\" AND (\"Discretionary Field 2\" is EMPTY OR \"Discretionary Field 2\" not in (\"ATS P1\",\"ATS P2\",\"ATS P3\",\"ATS P4\",\"ATS P5\",\"Post-RTS\",\"EB/WAD\"))" --save-report

# Combined Platform Total Open (All Severities)
python scripts/jira_tool.py batch-search --jql "project = \"PIMS\" AND issuetype = \"Defect\" AND ((status in (Review, Analyze, Verify, Wait) AND (filter = 107934 Or filter = 107932 Or filter = 107933)) OR (status = Submitted AND (filter = 137023 Or filter = 137021 Or filter = 137022))) AND (((\"Platform Found (PF)\" in (\"PROJECT_NAME\") OR \"Platform Affected with PAW\" in (\"PROJECT_NAME:VERIFIED_PRESENT\", \"PROJECT_NAME:VERIFIED_FIXED\")) )) AND (\"Discretionary Field 2\" is EMPTY OR \"Discretionary Field 2\" not in (\"ATS P1\",\"ATS P2\",\"ATS P3\",\"ATS P4\",\"ATS P5\",\"Post-RTS\",\"EB/WAD\"))" --save-report
```

#### **Aging Analysis Workflow**

```powershell
# Step 1: Extract Platform Total Open Issues by Severity
cd .windsurf/skills/jira-integration

# Extract Sev-1, Sev-2, Sev-3 Total Open issues separately
python scripts/jira_tool.py batch-search --jql "project = \"PIMS\" AND issuetype = \"Defect\" AND ((status in (Review, Analyze, Verify, Wait) AND (filter = 107934 Or filter = 107932 Or filter = 107933)) OR (status = Submitted AND (filter = 137023 Or filter = 137021 Or filter = 137022))) AND (((\"Platform Found (PF)\" in (\"PROJECT_NAME\") OR \"Platform Affected with PAW\" in (\"PROJECT_NAME:VERIFIED_PRESENT\", \"PROJECT_NAME:VERIFIED_FIXED\")) )) AND \"Issue Severity\" = \"1-High\" AND (\"Discretionary Field 2\" is EMPTY OR \"Discretionary Field 2\" not in (\"ATS P1\",\"ATS P2\",\"ATS P3\",\"ATS P4\",\"ATS P5\",\"Post-RTS\",\"EB/WAD\"))" --save-report

# Step 2: Analyze aging for Platform Total Open tickets only
# Use PowerShell script to process Platform-defined Total Open tickets
# (See brickyard_aging_analysis.ps1 for example implementation, but filter for Platform Total Open only)

# Step 3: Generate Platform-focused aging report
# Report should align with Platform Issue Status table definitions
```

#### **Key Metrics and KPIs**

**Performance Indicators:**
- **Recent Activity Rate**: Percentage of tickets updated ≤7 days (Target: >70%)
- **Stale Issue Rate**: Percentage of tickets >15 days old (Target: <20%)
- **Average Aging**: Mean days since last update (Target: <21 days)
- **Median Aging**: Middle value of aging distribution
- **Workload Balance**: Standard deviation of tickets per assignee

**Risk Assessment:**
- **Aging Risk Level**: Based on stale issue percentage and aging distribution
- **Capacity Risk**: Based on assignee workload distribution
- **Process Risk**: Based on status bottlenecks and flow issues

#### **Industry Benchmarks**

| Metric | Excellent | Good | Acceptable | Concerning |
|--------|-----------|------|------------|------------|
| **Recent Activity** | >90% | 70-90% | 50-70% | <50% |
| **Stale Issues** | <5% | 5-15% | 15-25% | >25% |
| **Average Aging** | <7 days | 7-14 days | 14-21 days | >21 days |
| **Unassigned Rate** | <5% | 5-10% | 10-15% | >15% |

#### **Report Components**

**Executive Summary:**
- Overall aging performance assessment
- Key findings and risk level
- Comparison with industry benchmarks
- Top recommendations

**Detailed Analysis:**
- Aging distribution by category
- Status breakdown with percentages
- Assignee workload analysis
- Oldest and most recent tickets
- Process flow analysis

**Actionable Insights:**
- Immediate actions for stale issues
- Process improvement recommendations
- Workload balancing suggestions
- Long-term monitoring strategies

#### **Common Aging Patterns**

**Healthy Project Indicators:**
- 70%+ tickets in 0-7 days category
- <20% tickets older than 15 days
- Balanced distribution across statuses
- Even workload across team members

**Warning Signs:**
- High concentration in 15-30+ days categories
- Bottlenecks in specific statuses (usually Analyze)
- Uneven assignee workload
- High percentage of unassigned tickets

#### **Integration with Platform Issue Status**

**Primary Data Source: Platform Issue Status Table**
- **Structured Data**: All analysis uses Platform Issue Status table as primary data source
- **Total Open Definition**: Strictly follows Platform table definition (excludes Post-RTS, ATS-P1-5, EB/WAD)
- **Severity-Based Analysis**: Maintains Sev-1/2/3 separation as defined in Platform table
- **Consistent Metrics**: All aging metrics align with Platform Issue Status reporting standards

**Platform-Defined Total Open Issues:**
```
Total Open = Submitted + Analyze UI-1 + Analyze UI-2 + Analyze UI-3 + Wait + Review + Verify
Exclusions: Post-RTS, ATS-P1, ATS-P2, ATS-P3, ATS-P4, ATS-P5, EB/WAD
```

**Analysis Scope:**
- **Sev-1 Total Open**: High severity issues requiring immediate attention
- **Sev-2 Total Open**: Medium severity issues with standard priority
- **Sev-3 Total Open**: Low severity issues with routine handling
- **Combined Total**: All severities for comprehensive project view

**BRICKYARD Example (Platform-Based):**
- **Sev-1 Total Open**: 2 tickets
- **Sev-2 Total Open**: 2 tickets  
- **Sev-3 Total Open**: 0 tickets
- **Platform Total Open**: 4 tickets (vs 45 comprehensive open issues)

**Analysis Methodology:**
1. **Extract Platform Data**: Use Platform-defined JQL queries for each severity
2. **Calculate Aging**: Analyze days since last update for Platform Total Open tickets only
3. **Generate Reports**: Create aging analysis that aligns with Platform Issue Status metrics
4. **Maintain Consistency**: Ensure all aging analysis matches Platform table definitions

**Benefits of Platform-Based Analysis:**
- **Data Consistency**: Aligns with official Platform Issue Status reporting
- **Management Visibility**: Results match what management sees in Platform tables
- **Standardized Metrics**: Uses same definitions and exclusions as Platform reporting
- **Trend Analysis**: Enables consistent historical tracking using Platform definitions

## Output

### Console Output
- Real-time execution progress
- Individual query results
- Statistical summaries
- FV Entry compliance assessment

### JSON Output
```json
{
  "jql_queries": [...],           # All extracted JQL queries
  "results": {...},               # Query execution results
  "statistics": {...},            # Statistical summaries
  "compliance": {...},            # FV Entry assessment
  "metadata": {...}               # Page and execution info
}
```

### Statistical Report
```
=== Project Issue Status Analysis ===

Overall Statistics:
   Total Open Issues: 68
   Total Closed Issues: 146
   Grand Total: 214
   Closure Rate: 68.2%

Statistics by Severity:
   Sev-1:
     Total: 8 issues
     Closed: 9 issues
     Submitted: 2 issues
     Analyze: 3 issues
   Sev-2:
     Total: 57 issues
     Closed: 126 issues
     Submitted: 7 issues
     Analyze: 55 issues
   Sev-3:
     Total: 8 issues
     Closed: 11 issues
     Analyze: 2 issues

FV Entry Compliance Assessment:
   FV Entry Requirement: Zero open issues
   Current Open Issues: 68
   [FAIL] Non-compliant
   Risk Level: High
```

## Troubleshooting

### Platform Issues
```powershell
# Method 1: Use NPI Platform Information Lookup (For New Projects)
cd .windsurf/skills/confluence-integration
# Search NPI page for project references
python scripts/confluence_tool.py grep-page --id 311322473 --pattern "PROJECT_NAME"

# If found, get exact project page
python scripts/confluence_tool.py cql-search --query "title='PROJECT_NAME' AND space=CSEI" --limit 5

# Method 2: Use Sustaining Platform Information Lookup (For Sustaining Projects)
cd .windsurf/skills/confluence-integration
# Search Sustaining page for project references
python scripts/confluence_tool.py grep-page --id 313693926 --pattern "PROJECT_NAME"

# If found, get exact project page
python scripts/confluence_tool.py cql-search --query "title='PROJECT_NAME' AND space=CSEI" --limit 5

# Method 3: Project not found automatically - use direct page ID
python scripts/extract_platform_jql_counts.py --page-id [PAGE_ID]

# Method 4: Search manually for project pages across all spaces
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME'" --limit 20

# JQL execution failures
python scripts/extract_platform_jql_counts.py --project "PROJECT_NAME" --debug

# Verify page content manually
python scripts/confluence_tool.py get --id [PAGE_ID] | Select-String "Platform Issue Status"

# Common Platform Information Issues:
# - Project name might have different formatting in NPI/Sustaining pages
# - Try variations: "CITADEL NVL", "Citadel NVL", "CITADEL NVL Issue Manager"
# - Check if project is listed in NPI page (for new projects) or Sustaining page (for sustaining projects)
# - Sustaining projects often have different naming conventions (e.g., "CITADEL GNR" vs "CITADEL NVL")
```

### Integration with Other Skills
```powershell
# Combine with confluence-integration
cd .windsurf/skills/confluence-integration
python scripts/confluence_nudd.py extract --page-id 1086093660
```

## Development Phase Gates

Extract development milestone information from project pages:
```powershell
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py grep-page --id 1008911302 --pattern "Phase Exit|Entry|CP#[0-9]"

# Key development milestones:
# - Define Phase Exit
# - Plan Phase Exit  
# - ULV/MLV Entry (CP#1)
# - IEV/SLV Entry (CP#2)
# - Feature Complete (CP#3)
# - Bug Cutoff (CP#4)
# - FV Entry (CP#5)
# - FV Exit (CP#6)
# - RTS
```
```

**Development Phase Gates**:
- **Define Phase Exit**: Requirements definition completion
- **Plan Phase Exit**: Planning phase completion
- **ULV/MLV Entry (CP#1)**: Ultra-Low/Mid-Volume entry point
- **IEV/SLV Entry (CP#2)**: Initial/Small-Volume entry point
- **Feature Complete (CP#3)**: Feature development completion
- **Bug Cutoff (CP#4)**: Bug fixing cutoff date
- **FV Entry (CP#5)**: Final Validation entry
- **FV Exit (CP#6)**: Final Validation exit
- **RTS**: Release to Ship

**Development Focus**: These gates are critical for development teams to track progress and ensure timely delivery of milestones.

### Issue Risk Analysis

**FV Entry (CP#5) Milestone Compliance Check**:
```powershell
# Extract FV Entry date from project milestones
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py grep-page --id 1008911302 --pattern "FV Entry.*CP#5|CP#5.*FV Entry"

# Found: FV Entry (CP#5): 2026/01/14

# Check Total Open Issues count from Issue Management Page
python scripts/confluence_tool.py grep-page --id 1008911303 --pattern "count.*true"

# Extract JQL queries for total open issues count
python scripts/confluence_tool.py grep-page --id 1008911303 --pattern "jqlQuery.*BLACKHAWK.*count.*true"
```

**Critical Risk Assessment**:
- **FV Entry (CP#5) Date**: 2026/01/14
- **Requirement**: Total Open Issues must be ZERO after FV Entry
- **Risk Status**: ❌ **HIGH RISK** if any open issues remain after 2026/01/14

**Risk Mitigation Timeline**:
- **Before 2026/01/14**: All PRTS issues must be resolved
- **After FV Entry**: Zero tolerance for open issues
- **Compliance Check**: Daily monitoring required as milestone approaches