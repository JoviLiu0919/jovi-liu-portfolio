# Microsoft Integration Skill

## Quick Start

### 1. Setup Azure App Registration
1. Go to [Azure Portal](https://portal.azure.com)
2. Navigate to Azure Active Directory → App registrations → New registration
3. Create app with "Accounts in this organizational directory only"
4. Add API permissions: Mail.Read, Chat.Read, User.Read.All, Calendars.Read
5. Create client secret and copy values

### 2. Configure Skill
Edit `config.toml`:
```toml
[microsoft]
tenant_id = "your-tenant-id"
client_id = "your-client-id" 
client_secret = "your-client-secret"
```

### 3. Basic Usage
```bash
# Get recent emails
python scripts/microsoft_tool.py get-emails --limit 10

# Get Teams chats
python scripts/microsoft_tool.py get-teams-chats --limit 20

# Search Teams messages
python scripts/microsoft_tool.py search-teams --query "BIOS" --save-report
```

## Features
- 📧 **Outlook Email Access**: Retrieve emails with filtering
- 💬 **Teams Integration**: Access chats and search messages
- 📅 **Calendar Events**: Get calendar events with date filtering
- 📊 **Report Generation**: Automatic bilingual reports
- 🔐 **Secure Authentication**: OAuth2 with Microsoft Graph

## Documentation
See [SKILL.md](SKILL.md) for complete documentation and usage examples.

## Requirements
- Python 3.7+
- Microsoft 365 organization account
- Azure AD admin access for setup

## Dependencies
```bash
pip install requests toml
```
