"""
Microsoft Integration Skill
Provides access to Microsoft Graph API for Outlook, Teams, and Calendar operations.
"""

__version__ = "1.0.0"
__author__ = "Cascade AI Assistant"
