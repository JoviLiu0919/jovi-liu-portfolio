#!/usr/bin/env python3
"""
GitHub Integration Tool - Comprehensive GitHub repository and PR management
"""

import argparse
import json
import sys
import os
import base64
import re
from datetime import datetime, timedelta
from pathlib import Path
import toml

try:
    import tomllib
except ImportError:
    import tomli as tomllib

import requests
import urllib3

# Disable SSL verification warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Import centralized configuration loader
skills_dir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(skills_dir))
try:
    from config_loader import load_skill_config_with_central_fallback
except ImportError:
    # Fallback if central config loader not available
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib
    
    def load_skill_config_with_central_fallback(config_path):
        if not config_path.exists():
            return {}
        with open(config_path, "rb") as f:
            return tomllib.load(f)


class GitHubTool:
    def __init__(self):
        # Load configuration with central config fallback
        config_path = Path(__file__).parent.parent / "config.toml"
        try:
            self.config = load_skill_config_with_central_fallback(config_path)
        except Exception as e:
            print(f"Error loading configuration: {str(e)}")
            sys.exit(1)
        
        # Extract GitHub configuration
        github_config = self.config.get('github', {})
        self.base_url = github_config.get('base_url', 'https://api.github.com')
        self.owner = github_config.get('owner', '')
        self.token = github_config.get('token', '')
        
        # Extract API configuration
        api_config = self.config.get('api', {})
        self.timeout = api_config.get('timeout', 30)
        self.max_retries = api_config.get('max_retries', 3)
        self.per_page = api_config.get('per_page', 100)
        
        self.headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github.v3+json"
        }
        
        if self.token == "YOUR_GITHUB_TOKEN":
            print("Error: Please replace 'YOUR_GITHUB_TOKEN' with your actual GitHub token in config.toml")
            sys.exit(1)

    def _make_request(self, method, endpoint, params=None, data=None):
        """Make HTTP request to GitHub API"""
        url = f"{self.base_url}/{endpoint}"
        response = requests.request(method, url, headers=self.headers, params=params, json=data, verify=False)
        
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 204:
            return True
        else:
            return f"Error: {response.status_code} - {response.text}"

    # Repository Management
    def list_repos(self):
        """List all repositories for the owner (handles pagination)"""
        all_repos = []
        page = 1
        per_page = 100
        
        while True:
            params = {"per_page": per_page, "page": page}
            response = self._make_request("GET", f"orgs/{self.owner}/repos", params=params)
            
            if isinstance(response, str) and response.startswith("Error:"):
                return response
            
            if not response:  # Empty response
                break
                
            all_repos.extend(response)
            
            # If we got less than per_page items, we're on the last page
            if len(response) < per_page:
                break
                
            page += 1
        
        return all_repos

    def list_favorites(self):
        """List favorite repositories from TOML config"""
        favorites_config = self.config.get('favorites', {})
        return favorites_config.get('repos', [])

    def list_repo_names(self):
        """List all repository names in a simple, concise format"""
        repos = self.list_repos()
        
        if isinstance(repos, str) and repos.startswith("Error:"):
            return repos
        
        # Extract and sort repository names
        repo_names = []
        for repo in repos:
            name = repo.get('name', '')
            if name:
                repo_names.append(name)
        
        return sorted(repo_names)

    def list_repos_detailed(self, show_summary=True, include_bios_submodules=False):
        """
        Get detailed repository information with in-memory processing
        Returns formatted summary without creating temp files
        
        Args:
            show_summary: Whether to show summary statistics
            include_bios_submodules: Whether to include BIOS TOT submodules analysis
        """
        repos = self.list_repos()
        
        if not isinstance(repos, list):
            return {"error": "Failed to fetch repositories", "data": repos}
        
        # Process data in memory
        summary = {
            "total_count": len(repos),
            "private_count": 0,
            "public_count": 0,
            "languages": {},
            "recent_updates": [],
            "favorites": [],
            "repos_by_category": {
                "private": [],
                "public": [],
                "bios_tot": [],
                "others": []
            }
        }
        
        # Get favorites list
        favorites = set(self.list_favorites())
        
        # Identify BIOS TOT repositories
        bios_tot_pattern = re.compile(r'^CDC_AgS_\d{4}$')
        
        # Process each repository
        for repo in repos:
            name = repo.get('name', 'Unknown')
            description = repo.get('description', '')
            private = repo.get('private', False)
            language = repo.get('language', 'Unknown')
            updated = repo.get('updated_at', '')
            size = repo.get('size', 0)
            
            # Categorize
            category = "private" if private else "public"
            summary["repos_by_category"][category].append({
                "name": name,
                "description": description,
                "language": language,
                "updated": updated[:10] if updated else 'Unknown',
                "size": size
            })
            
            # Check if BIOS TOT repository
            if bios_tot_pattern.match(name):
                summary["repos_by_category"]["bios_tot"].append({
                    "name": name,
                    "description": description,
                    "language": language,
                    "updated": updated[:10] if updated else 'Unknown',
                    "size": size
                })
            else:
                summary["repos_by_category"]["others"].append({
                    "name": name,
                    "description": description,
                    "language": language,
                    "updated": updated[:10] if updated else 'Unknown',
                    "size": size
                })
            
            # Count statistics
            if private:
                summary["private_count"] += 1
            else:
                summary["public_count"] += 1
            
            # Language statistics
            if language and language != 'Unknown':
                summary["languages"][language] = summary["languages"].get(language, 0) + 1
            
            # Check if favorite
            if name in favorites:
                summary["favorites"].append(name)
        
        # Sort languages by count
        summary["languages"] = dict(sorted(summary["languages"].items(), key=lambda x: x[1], reverse=True))
        
        # Sort repos by update time (most recent first)
        for category in summary["repos_by_category"]:
            summary["repos_by_category"][category].sort(
                key=lambda x: x["updated"], reverse=True
            )
        
        # Add BIOS submodules analysis if requested
        if include_bios_submodules and summary["repos_by_category"]["bios_tot"]:
            bios_years = [repo["name"].split("_")[-1] for repo in summary["repos_by_category"]["bios_tot"]]
            bios_submodules_analysis = self.analyze_bios_tot_submodules(bios_years)
            summary["bios_submodules_analysis"] = bios_submodules_analysis
        
        return summary
    
    def format_repos_summary(self, summary_data):
        """
        Format repository summary for display with bilingual output
        All processing done in memory, no temp files
        """
        if "error" in summary_data:
            return f"❌ {summary_data['error']}"
        
        summary = summary_data
        
        output = []
        output.append(f"# GitHub Repository Analysis Report")
        output.append(f"")
        output.append(f"**Analysis Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        output.append(f"")
        output.append(f"## � Statistics Overview")
        output.append(f"")
        output.append(f"- **Total Repositories:** {summary['total_count']}")
        output.append(f"- **Private Repositories:** {summary['private_count']}")
        output.append(f"- **Internal Repositories:** {summary['public_count']}")
        output.append(f"")
        
        # BIOS TOT Repositories
        bios_tot_repos = summary["repos_by_category"].get("bios_tot", [])
        if bios_tot_repos:
            output.append(f"## 🔥 BIOS TOT Repositories ({len(bios_tot_repos)} repos)")
            output.append(f"")
            output.append(f"| No. | Repository | Language | Last Updated | Description |")
            output.append(f"|-----|------------|----------|--------------|-------------|")
            
            for i, repo in enumerate(bios_tot_repos, 1):
                desc = repo["description"] if repo["description"] and repo["description"].strip() else "N/A"
                if len(desc) > 50:
                    desc = desc[:50] + '...'
                output.append(f"| {i:2d} | `{repo['name']}` | {repo['language']} | {repo['updated']} | {desc} |")
            
            output.append(f"")
        
        # Other Repositories (non-BIOS TOT)
        other_repos = summary["repos_by_category"].get("others", [])
        if other_repos:
            output.append(f"## 📦 Other Repositories ({len(other_repos)} repos)")
            output.append(f"")
            output.append(f"| No. | Repository | Language | Last Updated | Description |")
            output.append(f"|-----|------------|----------|--------------|-------------|")
            
            for i, repo in enumerate(other_repos, 1):  # Show ALL other repositories
                desc = repo["description"] if repo["description"] and repo["description"].strip() else "N/A"
                if len(desc) > 50:
                    desc = desc[:50] + '...'
                output.append(f"| {i:2d} | `{repo['name']}` | {repo['language']} | {repo['updated']} | {desc} |")
            
            output.append(f"")
        
        # BIOS Submodules Analysis (if available)
        if "bios_submodules_analysis" in summary:
            output.append(f"## 🔧 BIOS TOT Submodules Analysis")
            output.append(f"")
            output.append(summary["bios_submodules_analysis"])
            output.append(f"")
        
        # Favorites
        if summary["favorites"]:
            output.append(f"## ⭐ Favorite Repositories")
            output.append(f"")
            output.append(f"| No. | Repository |")
            output.append(f"|-----|------------|")
            for i, fav in enumerate(summary["favorites"], 1):
                output.append(f"| {i:2d} | `{fav}` |")
            output.append(f"")
        
        # Language Statistics
        if summary["languages"]:
            output.append(f"## 🔧 Programming Languages")
            output.append(f"")
            output.append(f"| Language | Repository Count | Percentage |")
            output.append(f"|----------|------------------|------------|")
            
            total_repos = sum(summary["languages"].values())
            for lang, count in list(summary["languages"].items())[:10]:
                percentage = (count / total_repos) * 100
                output.append(f"| {lang} | {count} | {percentage:.1f}% |")
            output.append(f"")
        
        # Bilingual Summary Section
        output.append(f"---")
        output.append(f"")
        output.append(f"## 📋 BilingualSummary / Bilingual Summary")
        output.append(f"")
        output.append(f"### 🇹🇼 Traditional Chinese")
        output.append(f"")
        output.append(f"- **Total repositories:** {summary['total_count']}")
        output.append(f"- **BIOS TOT repositories:** {len(bios_tot_repos)}")
        output.append(f"- **Other repositories:** {len(other_repos)}")
        output.append(f"- **Private repositories:** {summary['private_count']}")
        output.append(f"- **Internal repositories:** {summary['public_count']}")
        
        if summary["languages"]:
            output.append(f"- **Top programming languages:**")
            for lang, count in list(summary["languages"].items())[:5]:
                output.append(f"- {lang}: {count} repositories")
        
        output.append(f"")
        output.append(f"### 🇺🇸 English Summary")
        output.append(f"")
        output.append(f"- **Total Repositories:** {summary['total_count']}")
        output.append(f"- **BIOS TOT Repositories:** {len(bios_tot_repos)}")
        output.append(f"- **Other Repositories:** {len(other_repos)}")
        output.append(f"- **Private Repositories:** {summary['private_count']}")
        output.append(f"- **Internal Repositories:** {summary['public_count']}")
        
        if summary["languages"]:
            output.append(f"- **Top Programming Languages:**")
            for lang, count in list(summary["languages"].items())[:5]:
                output.append(f"  - {lang}: {count} repositories")
        
        return "\n".join(output)

    def save_report(self, content, report_name, description=""):
        """
        Save markdown report to centralized Reports directory following skill_guides standards
        
        Args:
            content: Report content in markdown format
            report_name: Base name for the report file
            description: Optional description for the report
        """
        try:
            # Get Reports directory path - CORRECTED: .windsurf/Reports/
            reports_dir = Path(__file__).parent.parent.parent.parent / "Reports"
            reports_dir.mkdir(exist_ok=True)
            
            # Generate timestamped filename
            timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
            filename = f"{report_name}_{timestamp}.md"
            filepath = reports_dir / filename
            
            # Add report metadata header
            report_header = f"""---
# {report_name} Report
**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Description:** {description}
**Skill:** github-integration
---

"""
            
            # Combine header and content
            full_content = report_header + content
            
            # Save to file
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(full_content)
            
            return f"✅ Report saved to: {filepath}"
            
        except Exception as e:
            return f"❌ Failed to save report: {str(e)}"

    def decode_gitmodules_content(self, content_b64):
        """Decode base64 .gitmodules content"""
        try:
            decoded = base64.b64decode(content_b64).decode('utf-8')
            return decoded
        except Exception as e:
            return None

    def parse_gitmodules(self, content):
        """Parse .gitmodules documentation content"""
        submodules = []
        
        # Use regular expressions to parse submodule information
        submodule_pattern = r'\[submodule\s+"([^"]+)"\](.*?)(?=\[submodule|\Z)'
        
        for match in re.finditer(submodule_pattern, content, re.DOTALL):
            name = match.group(1)
            module_content = match.group(2)
            
            # Extract path and url
            path_match = re.search(r'path\s*=\s*(.+)', module_content)
            url_match = re.search(r'url\s*=\s*(.+)', module_content)
            branch_match = re.search(r'branch\s*=\s*(.+)', module_content)
            
            submodule = {
                'name': name.strip(),
                'path': path_match.group(1).strip() if path_match else '',
                'url': url_match.group(1).strip() if url_match else '',
                'branch': branch_match.group(1).strip() if branch_match else 'master'
            }
            
            # Extract repository name from URL
            if submodule['url'].startswith('../'):
                repo_name = submodule['url'][3:].replace('.git', '')
                submodule['repo_name'] = repo_name
            else:
                submodule['repo_name'] = submodule['url']
            
            submodules.append(submodule)
        
        return submodules

    def analyze_bios_tot_submodules(self, years=None):
        """
        Analyze BIOS TOT repository submodules
        years: Specify list of years to analyze, default analyze all years
        """
        if years is None:
            years = ['2025', '2024', '2023', '2022', '2021']
        
        bios_repos = [f'CDC_AgS_{year}' for year in years]
        analysis_results = []
        
        for repo in bios_repos:
            # Get .gitmodules documentation
            gitmodules_result = self.get_contents(repo, '.gitmodules')
            
            if isinstance(gitmodules_result, str) and gitmodules_result.startswith('Error'):
                analysis_results.append({
                    'repo': repo, 
                    'submodules': [], 
                    'error': gitmodules_result
                })
                continue
            
            if not isinstance(gitmodules_result, dict) or 'content' not in gitmodules_result:
                analysis_results.append({
                    'repo': repo, 
                    'submodules': [], 
                    'error': 'No .gitmodules file found'
                })
                continue
            
            # Decode and parse
            content = self.decode_gitmodules_content(gitmodules_result['content'])
            if not content:
                analysis_results.append({
                    'repo': repo, 
                    'submodules': [], 
                    'error': 'Failed to decode .gitmodules'
                })
                continue
            
            submodules = self.parse_gitmodules(content)
            analysis_results.append({
                'repo': repo,
                'submodules': submodules,
                'error': None
            })
        
        return self.format_bios_submodules_table(analysis_results)

    def format_bios_submodules_table(self, analysis_results):
        """Format BIOS submodules analysis results as bilingual tables"""
        # Collect all unique submodule repositories
        all_submodule_repos = set()
        repo_submodules = {}
        
        for result in analysis_results:
            if result['error']:
                continue
                
            repo_name = result['repo']
            repo_submodules[repo_name] = set()
            
            for submodule in result['submodules']:
                if submodule['repo_name']:
                    all_submodule_repos.add(submodule['repo_name'])
                    repo_submodules[repo_name].add(submodule['repo_name'])
        
        # Sort
        all_submodule_repos = sorted(all_submodule_repos)
        bios_repos = sorted([result['repo'] for result in analysis_results if not result['error']])
        
        # Generate output
        output_lines = []
        output_lines.append('# BIOS TOT Repository Submodules Analysis')
        output_lines.append('')
        output_lines.append(f'**Analysis Time:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        output_lines.append('')
        
        # Statistics
        output_lines.append('## 📊 Statistics Overview')
        output_lines.append('')
        output_lines.append(f'- **BIOS TOT Repositories:** {len(bios_repos)}')
        output_lines.append(f'- **Submodule Repositories:** {len(all_submodule_repos)}')
        output_lines.append('')
        
        # Main table - simplified version
        output_lines.append('## 📋 Submodules Mapping Table')
        output_lines.append('')
        output_lines.append('### Core Submodules (100% Usage Rate)')
        output_lines.append('')
        output_lines.append('| BIOS Repository | DellFeaturesPkg | DellBiosConnectPkg | DellManageabilityPkg |')
        output_lines.append('|' + '-' * 65 + '|')
        output_lines.append('| :-: | :-: | :-: | :-: |')
        
        for bios_repo in bios_repos:
            row = [f'| {bios_repo}']
            
            core_submodules = ['CBF_DellFeaturesPkg', 'CBF_DellBiosConnectPkg', 'CBF_DellManageabilityPkg']
            for submodule_repo in core_submodules:
                if submodule_repo in all_submodule_repos:
                    if bios_repo in repo_submodules and submodule_repo in repo_submodules[bios_repo]:
                        row.append(' ✅ ')
                    else:
                        row.append(' ❌ ')
                else:
                    row.append(' ❌ ')
            
            row.append('|')
            output_lines.append(''.join(row))
        
        output_lines.append('')
        
        # Platform Submodules
        output_lines.append('### Platform Submodules')
        output_lines.append('')
        output_lines.append('| BIOS Repository | AMD | EDK2 | EDK2Platforms | Intel |')
        output_lines.append('|' + '-' * 55 + '|')
        output_lines.append('| :-: | :-: | :-: | :-: | :-: |')
        
        for bios_repo in bios_repos:
            row = [f'| {bios_repo}']
            
            platform_submodules = ['CDC_Amd', 'CDC_Edk2', 'CDC_Edk2Platforms', 'CDC_Intel']
            for platform in platform_submodules:
                # Find corresponding year repository
                year = bios_repo.split('_')[-1]
                platform_repo = f'{platform}_{year}'
                
                if platform_repo in all_submodule_repos:
                    if bios_repo in repo_submodules and platform_repo in repo_submodules[bios_repo]:
                        row.append(f' ✅ {platform_repo}')
                    else:
                        row.append(f' ❌ {platform_repo}')
                else:
                    row.append(f' ❌ {platform_repo}')
            
            row.append('|')
            output_lines.append(''.join(row))
        
        output_lines.append('')
        
        # Usage frequency statistics
        output_lines.append('## 🔄 Submodule Repository Usage Frequency')
        output_lines.append('')
        
        submodule_usage = {}
        for submodule_repo in all_submodule_repos:
            usage_count = sum(1 for repo_subs in repo_submodules.values() if submodule_repo in repo_subs)
            submodule_usage[submodule_repo] = usage_count
        
        output_lines.append('| Submodule Repository | Usage Count | Usage Rate |')
        output_lines.append('|' + '-' * 40 + '|')
        
        for submodule_repo, count in sorted(submodule_usage.items(), key=lambda x: x[1], reverse=True):
            usage_rate = (count / len(bios_repos)) * 100
            output_lines.append(f'| `{submodule_repo}` | {count} | {usage_rate:.1f}% |')
        
        output_lines.append('')
        
        # Detailed information
        output_lines.append('## 📝 Detailed Information')
        output_lines.append('')
        
        for result in analysis_results:
            repo_name = result['repo']
            output_lines.append(f'### {repo_name}')
            
            if result['error']:
                output_lines.append(f'❌ Error: {result["error"]}')
            else:
                output_lines.append(f'**Submodules ({len(result["submodules"])}):**')
                for submodule in result['submodules']:
                    output_lines.append(f'- **{submodule["name"]}** → `{submodule["repo_name"]}` (branch: {submodule["branch"]})')
            
            output_lines.append('')
        
        # Bilingual Summary
        output_lines.append('---')
        output_lines.append('')
        output_lines.append('## 📋 BilingualSummary / Bilingual Summary')
        output_lines.append('')
        output_lines.append('### 🇹🇼 **Traditional Chinese**')
        output_lines.append('')
        output_lines.append(f'- **BIOS TOT repositories:** {len(bios_repos)}')
        output_lines.append(f'- **Submodule repositories:** {len(all_submodule_repos)}')
        output_lines.append('')
        output_lines.append('### 🇺🇸 English Summary')
        output_lines.append('')
        output_lines.append(f'- **BIOS TOT Repositories:** {len(bios_repos)}')
        output_lines.append(f'- **Submodule Repositories:** {len(all_submodule_repos)}')
        
        return '\n'.join(output_lines)

    def get_repo(self, repo):
        """Get repository details"""
        return self._make_request("GET", f"repos/{self.owner}/{repo}")

    def get_contents(self, repo, path="/"):
        """Get repository contents"""
        return self._make_request("GET", f"repos/{self.owner}/{repo}/contents/{path}")

    def get_branches(self, repo):
        """Get repository branches"""
        return self._make_request("GET", f"repos/{self.owner}/{repo}/branches")

    # Pull Request Management
    def get_pr(self, repo, number):
        """Get pull request details"""
        return self._make_request("GET", f"repos/{self.owner}/{repo}/pulls/{number}")

    def get_pr_diff(self, repo, number):
        """Get pull request diff"""
        url = f"{self.base_url}/repos/{self.owner}/{repo}/pulls/{number}"
        headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github.v3.diff"
        }
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            return response.text
        else:
            return f"Error fetching PR diff: {response.status_code} {response.text}"

    def get_pr_files(self, repo, number):
        """Get pull request files"""
        return self._make_request("GET", f"repos/{self.owner}/{repo}/pulls/{number}/files")

    def create_pr(self, repo, title, body, head, base):
        """Create pull request"""
        data = {
            "title": title,
            "body": body,
            "head": head,
            "base": base
        }
        return self._make_request("POST", f"repos/{self.owner}/{repo}/pulls", data=data)

    def update_pr(self, repo, number, title=None, body=None):
        """Update pull request"""
        data = {}
        if title:
            data["title"] = title
        if body:
            data["body"] = body
        return self._make_request("PATCH", f"repos/{self.owner}/{repo}/pulls/{number}", data=data)

    def add_reviewers(self, repo, number, reviewers):
        """Add reviewers to pull request"""
        reviewers_list = reviewers.split(",") if isinstance(reviewers, str) else reviewers
        data = {"reviewers": reviewers_list}
        return self._make_request("POST", f"repos/{self.owner}/{repo}/pulls/{number}/requested_reviewers", data=data)

    def assign_pr(self, repo, number, assignees):
        """Assign pull request"""
        assignees_list = assignees.split(",") if isinstance(assignees, str) else assignees
        data = {"assignees": assignees_list}
        return self._make_request("PATCH", f"repos/{self.owner}/{repo}/pulls/{number}", data=data)

    def merge_pr(self, repo, number, merge_method="merge"):
        """Merge pull request"""
        data = {"merge_method": merge_method}
        return self._make_request("PUT", f"repos/{self.owner}/{repo}/pulls/{number}/merge", data=data)

    def close_pr(self, repo, number):
        """Close pull request"""
        data = {"state": "closed"}
        return self._make_request("PATCH", f"repos/{self.owner}/{repo}/pulls/{number}", data=data)

    def reopen_pr(self, repo, number):
        """Reopen pull request"""
        data = {"state": "open"}
        return self._make_request("PATCH", f"repos/{self.owner}/{repo}/pulls/{number}", data=data)

    # Commit Management
    def get_commit(self, repo, sha):
        """Get commit details"""
        return self._make_request("GET", f"repos/{self.owner}/{repo}/commits/{sha}")

    def get_commit_diff(self, repo, sha):
        """Get commit diff"""
        url = f"{self.base_url}/repos/{self.owner}/{repo}/commits/{sha}"
        headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github.v3.diff"
        }
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            return response.text
        else:
            return f"Error fetching commit diff: {response.status_code} {response.text}"

    def get_commit_files(self, repo, sha):
        """Get commit files"""
        return self._make_request("GET", f"repos/{self.owner}/{repo}/commits/{sha}/files")

    def list_commits(self, repo, branch="main", per_page=30):
        """List commits for a branch"""
        params = {"per_page": per_page, "sha": branch}
        return self._make_request("GET", f"repos/{self.owner}/{repo}/commits", params=params)

    def list_pr_commits(self, repo, number):
        """List commits for a pull request"""
        return self._make_request("GET", f"repos/{self.owner}/{repo}/pulls/{number}/commits")

    # Issue Management
    def get_issue(self, repo, number):
        """Get issue details"""
        return self._make_request("GET", f"repos/{self.owner}/{repo}/issues/{number}")

    def list_issues(self, repo, state="open"):
        """List issues"""
        params = {"state": state}
        return self._make_request("GET", f"repos/{self.owner}/{repo}/issues", params=params)

    def search_issues(self, repo, query):
        """Search issues"""
        params = {"q": f"repo:{self.owner}/{repo} {query}"}
        return self._make_request("GET", "search/issues", params=params)

    def create_issue(self, repo, title, body):
        """Create issue"""
        data = {"title": title, "body": body}
        return self._make_request("POST", f"repos/{self.owner}/{repo}/issues", data=data)

    def update_issue(self, repo, number, title=None, body=None):
        """Update issue"""
        data = {}
        if title:
            data["title"] = title
        if body:
            data["body"] = body
        return self._make_request("PATCH", f"repos/{self.owner}/{repo}/issues/{number}", data=data)

    def add_labels(self, repo, number, labels):
        """Add labels to issue"""
        labels_list = labels.split(",") if isinstance(labels, str) else labels
        data = {"labels": labels_list}
        return self._make_request("POST", f"repos/{self.owner}/{repo}/issues/{number}/labels", data=data)

    def assign_issue(self, repo, number, assignees):
        """Assign issue"""
        assignees_list = assignees.split(",") if isinstance(assignees, str) else assignees
        data = {"assignees": assignees_list}
        return self._make_request("PATCH", f"repos/{self.owner}/{repo}/issues/{number}", data=data)

    # Comment Management
    def add_comment(self, repo, number, comment_type, body):
        """Add comment to issue or PR"""
        if comment_type == "issue":
            endpoint = f"repos/{self.owner}/{repo}/issues/{number}/comments"
        elif comment_type == "pr":
            endpoint = f"repos/{self.owner}/{repo}/pulls/{number}/comments"
        else:
            return "Error: comment_type must be 'issue' or 'pr'"
        
        data = {"body": body}
        return self._make_request("POST", endpoint, data=data)

    def get_comments(self, repo, number, comment_type):
        """Get comments for issue or PR"""
        if comment_type == "issue":
            endpoint = f"repos/{self.owner}/{repo}/issues/{number}/comments"
        elif comment_type == "pr":
            endpoint = f"repos/{self.owner}/{repo}/pulls/{number}/comments"
        else:
            return "Error: comment_type must be 'issue' or 'pr'"
        
        return self._make_request("GET", endpoint)

    # Search and Filtering
    def search_repos(self, query):
        """Search repositories"""
        params = {"q": f"org:{self.owner} {query}"}
        return self._make_request("GET", "search/repositories", params=params)

    def search_code(self, repo, query):
        """Search code in repository"""
        params = {"q": f"repo:{self.owner}/{repo} {query}"}
        return self._make_request("GET", "search/code", params=params)

    def search_prs(self, repo, query):
        """Search pull requests"""
        params = {"q": f"repo:{self.owner}/{repo} {query}"}
        return self._make_request("GET", "search/issues", params=params)

    # Enhanced Search Methods for Deep Research
    def search_all_repositories(self, query, repo_types=None, limit=10):
        """
        Search across all repositories with optional filtering
        
        Args:
            query: Search query
            repo_types: List of repository types to filter (e.g., ['bios', 'ec', 'firmware'])
            limit: Maximum number of results
        
        Returns:
            List of matching repositories
        """
        # First get all repositories
        repos = self.list_repos()
        if not isinstance(repos, list):
            return []
        
        # Filter repositories based on types if specified
        filtered_repos = []
        for repo in repos:
            repo_name = repo.get('name', '') or ''
            description = repo.get('description', '') or ''
            
            repo_name = repo_name.lower()
            description = description.lower()
            
            if repo_types:
                # Check if repository matches any of the specified types
                if any(repo_type in repo_name or repo_type in description for repo_type in repo_types):
                    filtered_repos.append(repo)
            else:
                # No filtering, include all repositories
                filtered_repos.append(repo)
        
        # Search in filtered repositories
        findings = []
        for repo in filtered_repos[:limit]:
            repo_name = repo.get('name', '')
            
            # Check if query matches repository name or description
            if (query.lower() in repo_name.lower() or 
                query.lower() in repo.get('description', '').lower()):
                
                findings.append({
                    "name": repo.get('full_name', ''),
                    "description": repo.get('description', ''),
                    "language": repo.get('language', ''),
                    "stars": repo.get('stargazers_count', 0),
                    "url": repo.get('html_url', ''),
                    "match_type": "repository"
                })
        
        return findings

    def search_bios_ec_code(self, query, years=None, limit_per_repo=3):
        """
        Search specifically in BIOS/EC repositories
        
        Args:
            query: Search query
            years: List of years to filter (e.g., ['2025', '2024'])
            limit_per_repo: Maximum results per repository
        
        Returns:
            List of code search results
        """
        # Define BIOS/EC repositories to search
        bios_ec_repos = []
        
        if years:
            # Search specific year repositories
            for year in years:
                bios_ec_repos.extend([f"CDC_AgS_{year}", f"CDC_AgS_{int(year)-1}"])
        else:
            # Search all available BIOS repositories
            bios_ec_repos = [
                "CDC_AgS_2025", "CDC_AgS_2024", "CDC_AgS_2023", 
                "CDC_AgS_2022", "CDC_AgS_2021"
            ]
        
        findings = []
        
        for repo_name in bios_ec_repos:
            # Search code in each repository
            search_result = self.search_code(repo_name, query)
            
            if isinstance(search_result, dict) and search_result.get('items'):
                items = search_result['items']
                
                for item in items[:limit_per_repo]:
                    findings.append({
                        "repository": repo_name,
                        "file": item.get('path', ''),
                        "url": item.get('html_url', ''),
                        "matches": item.get('text_matches', []),
                        "score": item.get('score', 0)
                    })
        
        return findings

    def comprehensive_search(self, query, include_repos=True, include_code=True, 
                           repo_types=None, years=None):
        """
        Perform comprehensive search across repositories and code
        
        Args:
            query: Search query
            include_repos: Whether to search repositories
            include_code: Whether to search code
            repo_types: Repository types to filter
            years: BIOS years to search
        
        Returns:
            Dictionary with search results
        """
        results = {
            "repositories": [],
            "code": [],
            "summary": {
                "total_repo_results": 0,
                "total_code_results": 0,
                "search_timestamp": datetime.now().isoformat()
            }
        }
        
        if include_repos:
            repo_results = self.search_all_repositories(query, repo_types)
            results["repositories"] = repo_results
            results["summary"]["total_repo_results"] = len(repo_results)
        
        if include_code:
            code_results = self.search_bios_ec_code(query, years)
            results["code"] = code_results
            results["summary"]["total_code_results"] = len(code_results)
        
        return results

    # Branch Management
    def create_branch(self, repo, branch, from_branch="main"):
        """Create branch"""
        # First get the reference for the base branch
        ref_data = self._make_request("GET", f"repos/{self.owner}/{repo}/git/refs/heads/{from_branch}")
        if isinstance(ref_data, str) and ref_data.startswith("Error"):
            return ref_data
        
        sha = ref_data["object"]["sha"]
        data = {
            "ref": f"refs/heads/{branch}",
            "sha": sha
        }
        return self._make_request("POST", f"repos/{self.owner}/{repo}/git/refs", data=data)

    def delete_branch(self, repo, branch):
        """Delete branch"""
        return self._make_request("DELETE", f"repos/{self.owner}/{repo}/git/refs/heads/{branch}")

    def get_branch(self, repo, branch):
        """Get branch information"""
        return self._make_request("GET", f"repos/{self.owner}/{repo}/branches/{branch}")

    # Repository Analytics
    def get_stats(self, repo):
        """Get repository statistics"""
        return self._make_request("GET", f"repos/{self.owner}/{repo}/stats/contributors")

    def get_contributors(self, repo):
        """Get contributor information"""
        return self._make_request("GET", f"repos/{self.owner}/{repo}/contributors")

    def get_activity(self, repo, days=30):
        """Get commit activity for specified days"""
        since = (datetime.now() - timedelta(days=days)).isoformat()
        params = {"since": since}
        return self._make_request("GET", f"repos/{self.owner}/{repo}/commits", params=params)

    # Favorite Repositories Management
    def add_favorite(self, repo):
        """Add repository to favorites in central TOML config"""
        favorites_config = self.config.get('favorites', {})
        favorites = favorites_config.get('repos', [])
        
        if repo not in favorites:
            favorites.append(repo)
            self.config['favorites']['repos'] = favorites
            
            # Save updated config to central TOML file
            central_config_path = Path(__file__).parent.parent.parent.parent / "central_config.toml"
            try:
                # Load current central config
                with open(central_config_path, 'rb') as f:
                    central_config = tomllib.load(f)
                
                # Update favorites
                if 'github_favorites' not in central_config:
                    central_config['github_favorites'] = {}
                central_config['github_favorites']['repos'] = favorites
                
                # Save back to central config
                with open(central_config_path, 'w') as f:
                    toml.dump(central_config, f)
                
                return f"Added {repo} to favorites (saved to central config)"
            except Exception as e:
                return f"Error saving to central config: {str(e)}"
        else:
            return f"{repo} is already in favorites"

    def remove_favorite(self, repo):
        """Remove repository from favorites in central TOML config"""
        favorites_config = self.config.get('favorites', {})
        favorites = favorites_config.get('repos', [])
        
        if repo in favorites:
            favorites.remove(repo)
            self.config['favorites']['repos'] = favorites
            
            # Save updated config to central TOML file
            central_config_path = Path(__file__).parent.parent.parent.parent / "central_config.toml"
            try:
                # Load current central config
                with open(central_config_path, 'rb') as f:
                    central_config = tomllib.load(f)
                
                # Update favorites
                if 'github_favorites' not in central_config:
                    central_config['github_favorites'] = {}
                central_config['github_favorites']['repos'] = favorites
                
                # Save back to central config
                with open(central_config_path, 'w') as f:
                    toml.dump(central_config, f)
                
                return f"Removed {repo} from favorites (saved to central config)"
            except Exception as e:
                return f"Error saving to central config: {str(e)}"
        else:
            return f"{repo} not found in favorites"

    def show_favorites(self):
        """Show favorite repositories from TOML config"""
        favorites_config = self.config.get('favorites', {})
        return favorites_config.get('repos', [])


def main():
    parser = argparse.ArgumentParser(description="GitHub Integration Tool")
    tool = GitHubTool()
    
    # Create subparsers for different commands
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Repository Management
    list_repos_parser = subparsers.add_parser("list-repos", help="List all repositories")
    list_repos_parser.add_argument("--format", choices=["json", "summary"], default="json", help="Output format")
    list_repos_parser.add_argument("--include-bios-submodules", action="store_true", help="Include BIOS TOT submodules analysis")
    list_repos_parser.add_argument("--save-report", action="store_true", help="Save report to .windsurf/Reports directory")
    
    list_repos_detail_parser = subparsers.add_parser("list-repos-detailed", help="List repositories with detailed summary")
    list_repos_detail_parser.add_argument("--max-private", type=int, default=20, help="Max private repos to show")
    list_repos_detail_parser.add_argument("--max-public", type=int, default=10, help="Max public repos to show")
    list_repos_detail_parser.add_argument("--include-bios-submodules", action="store_true", help="Include BIOS TOT submodules analysis")
    
    list_repo_names_parser = subparsers.add_parser("list-repo-names", help="List repository names in simple format")
    
    bios_submodules_parser = subparsers.add_parser("analyze-bios-submodules", help="Analyze BIOS TOT repository submodules")
    bios_submodules_parser.add_argument("--years", help="Years to analyze (comma-separated, e.g., 2025,2024)")
    bios_submodules_parser.add_argument("--save-report", action="store_true", help="Save report to .windsurf/Reports directory")
    
    subparsers.add_parser("list-favorites", help="List favorite repositories")
    
    repo_parser = subparsers.add_parser("get-repo", help="Get repository details")
    repo_parser.add_argument("--repo", required=True, help="Repository name")
    
    contents_parser = subparsers.add_parser("get-contents", help="Get repository contents")
    contents_parser.add_argument("--repo", required=True, help="Repository name")
    contents_parser.add_argument("--path", default="/", help="Path to contents")
    
    branches_parser = subparsers.add_parser("get-branches", help="Get repository branches")
    branches_parser.add_argument("--repo", required=True, help="Repository name")
    
    # Pull Request Management
    pr_parser = subparsers.add_parser("get-pr", help="Get pull request details")
    pr_parser.add_argument("--repo", required=True, help="Repository name")
    pr_parser.add_argument("--number", required=True, type=int, help="Pull request number")
    
    pr_diff_parser = subparsers.add_parser("get-pr-diff", help="Get pull request diff")
    pr_diff_parser.add_argument("--repo", required=True, help="Repository name")
    pr_diff_parser.add_argument("--number", required=True, type=int, help="Pull request number")
    
    pr_files_parser = subparsers.add_parser("get-pr-files", help="Get pull request files")
    pr_files_parser.add_argument("--repo", required=True, help="Repository name")
    pr_files_parser.add_argument("--number", required=True, type=int, help="Pull request number")
    
    create_pr_parser = subparsers.add_parser("create-pr", help="Create pull request")
    create_pr_parser.add_argument("--repo", required=True, help="Repository name")
    create_pr_parser.add_argument("--title", required=True, help="Pull request title")
    create_pr_parser.add_argument("--body", required=True, help="Pull request body")
    create_pr_parser.add_argument("--head", required=True, help="Head branch")
    create_pr_parser.add_argument("--base", required=True, help="Base branch")
    
    update_pr_parser = subparsers.add_parser("update-pr", help="Update pull request")
    update_pr_parser.add_argument("--repo", required=True, help="Repository name")
    update_pr_parser.add_argument("--number", required=True, type=int, help="Pull request number")
    update_pr_parser.add_argument("--title", help="New title")
    update_pr_parser.add_argument("--body", help="New body")
    
    # Commit Management
    commit_parser = subparsers.add_parser("get-commit", help="Get commit details")
    commit_parser.add_argument("--repo", required=True, help="Repository name")
    commit_parser.add_argument("--sha", required=True, help="Commit SHA")
    
    commit_diff_parser = subparsers.add_parser("get-commit-diff", help="Get commit diff")
    commit_diff_parser.add_argument("--repo", required=True, help="Repository name")
    commit_diff_parser.add_argument("--sha", required=True, help="Commit SHA")
    
    # Issue Management
    issue_parser = subparsers.add_parser("get-issue", help="Get issue details")
    issue_parser.add_argument("--repo", required=True, help="Repository name")
    issue_parser.add_argument("--number", required=True, type=int, help="Issue number")
    
    list_issues_parser = subparsers.add_parser("list-issues", help="List issues")
    list_issues_parser.add_argument("--repo", required=True, help="Repository name")
    list_issues_parser.add_argument("--state", default="open", choices=["open", "closed", "all"], help="Issue state")
    
    # Search and Filtering
    search_repos_parser = subparsers.add_parser("search-repos", help="Search repositories")
    search_repos_parser.add_argument("--query", required=True, help="Search query")
    
    search_code_parser = subparsers.add_parser("search-code", help="Search code in repository")
    search_code_parser.add_argument("--repo", required=True, help="Repository name")
    search_code_parser.add_argument("--query", required=True, help="Search query")
    
    search_prs_parser = subparsers.add_parser("search-prs", help="Search pull requests")
    search_prs_parser.add_argument("--repo", required=True, help="Repository name")
    search_prs_parser.add_argument("--query", required=True, help="Search query")
    
    # Enhanced Search Commands for Deep Research
    search_all_parser = subparsers.add_parser("search-all", help="Search across all repositories with filtering")
    search_all_parser.add_argument("--query", required=True, help="Search query")
    search_all_parser.add_argument("--repo-types", help="Repository types to filter (comma-separated)")
    search_all_parser.add_argument("--limit", type=int, default=10, help="Maximum number of results")
    
    search_bios_parser = subparsers.add_parser("search-bios", help="Search specifically in BIOS/EC repositories")
    search_bios_parser.add_argument("--query", required=True, help="Search query")
    search_bios_parser.add_argument("--years", help="BIOS years to search (comma-separated)")
    search_bios_parser.add_argument("--limit-per-repo", type=int, default=3, help="Maximum results per repository")
    
    comprehensive_parser = subparsers.add_parser("comprehensive-search", help="Perform comprehensive search across repositories and code")
    comprehensive_parser.add_argument("--query", required=True, help="Search query")
    comprehensive_parser.add_argument("--include-repos", action="store_true", default=True, help="Include repository search")
    comprehensive_parser.add_argument("--include-code", action="store_true", default=True, help="Include code search")
    comprehensive_parser.add_argument("--repo-types", help="Repository types to filter (comma-separated)")
    comprehensive_parser.add_argument("--years", help="BIOS years to search (comma-separated)")
    
    # Favorite Management
    add_fav_parser = subparsers.add_parser("add-favorite", help="Add repository to favorites")
    add_fav_parser.add_argument("--repo", required=True, help="Repository name")
    
    remove_fav_parser = subparsers.add_parser("remove-favorite", help="Remove repository from favorites")
    remove_fav_parser.add_argument("--repo", required=True, help="Repository name")
    
    subparsers.add_parser("show-favorites", help="Show favorite repositories")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # Execute command
    try:
        if args.command == "list-repos":
            result = tool.list_repos()
            if hasattr(args, 'format') and args.format == "summary":
                include_bios = hasattr(args, 'include_bios_submodules') and args.include_bios_submodules
                summary = tool.list_repos_detailed(include_bios_submodules=include_bios)
                result = tool.format_repos_summary(summary)
                
                # Save report if requested
                if hasattr(args, 'save_report') and args.save_report:
                    save_result = tool.save_report(result, "github_repository_analysis", "Comprehensive GitHub repository analysis with BIOS TOT submodules")
                    print(save_result)
        elif args.command == "list-repos-detailed":
            include_bios = hasattr(args, 'include_bios_submodules') and args.include_bios_submodules
            summary = tool.list_repos_detailed(include_bios_submodules=include_bios)
            result = tool.format_repos_summary(summary)
        elif args.command == "list-repo-names":
            result = tool.list_repo_names()
            if isinstance(result, list):
                print(f"Total repositories: {len(result)}")
                for i, name in enumerate(result, 1):
                    print(f"{i:3d}. {name}")
            else:
                print(result)
        elif args.command == "analyze-bios-submodules":
            years = None
            if hasattr(args, 'years') and args.years:
                years = [year.strip() for year in args.years.split(',')]
            result = tool.analyze_bios_tot_submodules(years)
            
            # Save report if requested
            if hasattr(args, 'save_report') and args.save_report:
                save_result = tool.save_report(result, "bios_submodules_analysis", "BIOS TOT repository submodules analysis")
                print(save_result)
        elif args.command == "list-favorites":
            result = tool.list_favorites()
        elif args.command == "get-repo":
            result = tool.get_repo(args.repo)
        elif args.command == "get-contents":
            result = tool.get_contents(args.repo, args.path)
        elif args.command == "get-branches":
            result = tool.get_branches(args.repo)
        elif args.command == "get-pr":
            result = tool.get_pr(args.repo, args.number)
        elif args.command == "get-pr-diff":
            result = tool.get_pr_diff(args.repo, args.number)
        elif args.command == "get-pr-files":
            result = tool.get_pr_files(args.repo, args.number)
        elif args.command == "create-pr":
            result = tool.create_pr(args.repo, args.title, args.body, args.head, args.base)
        elif args.command == "update-pr":
            result = tool.update_pr(args.repo, args.number, args.title, args.body)
        elif args.command == "get-commit":
            result = tool.get_commit(args.repo, args.sha)
        elif args.command == "get-commit-diff":
            result = tool.get_commit_diff(args.repo, args.sha)
        elif args.command == "get-issue":
            result = tool.get_issue(args.repo, args.number)
        elif args.command == "list-issues":
            result = tool.list_issues(args.repo, args.state)
        elif args.command == "search-repos":
            result = tool.search_repos(args.query)
        elif args.command == "search-code":
            result = tool.search_code(args.repo, args.query)
        elif args.command == "search-prs":
            result = tool.search_prs(args.repo, args.query)
        elif args.command == "search-all":
            repo_types = None
            if args.repo_types:
                repo_types = [t.strip() for t in args.repo_types.split(',')]
            result = tool.search_all_repositories(args.query, repo_types, args.limit)
        elif args.command == "search-bios":
            years = None
            if args.years:
                years = [y.strip() for y in args.years.split(',')]
            result = tool.search_bios_ec_code(args.query, years, args.limit_per_repo)
        elif args.command == "comprehensive-search":
            repo_types = None
            if args.repo_types:
                repo_types = [t.strip() for t in args.repo_types.split(',')]
            years = None
            if args.years:
                years = [y.strip() for y in args.years.split(',')]
            result = tool.comprehensive_search(args.query, args.include_repos, args.include_code, repo_types, years)
        elif args.command == "add-favorite":
            result = tool.add_favorite(args.repo)
        elif args.command == "remove-favorite":
            result = tool.remove_favorite(args.repo)
        elif args.command == "show-favorites":
            result = tool.show_favorites()
        else:
            result = f"Unknown command: {args.command}"
        
        # Print result
        if args.command == "list-repo-names":
            # Already handled above, don't print again
            pass
        elif isinstance(result, str):
            print(result)
        else:
            print(json.dumps(result, indent=2))
    
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
