from __future__ import annotations

import argparse
import html
import re
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Post-process Mermaid SVGs to restore indentation and code alignment."
    )
    parser.add_argument(
        "svg_path",
        help="Path to the SVG file to update",
    )
    return parser.parse_args()


def load_svg(svg_path: Path) -> str:
    if not svg_path.exists():
        raise FileNotFoundError(f"SVG file not found: {svg_path}")
    return svg_path.read_text(encoding="utf-8")


def save_svg(svg_path: Path, content: str) -> None:
    svg_path.write_text(content, encoding="utf-8")


def main() -> None:
    args = parse_args()
    svg_path = Path(args.svg_path)
    text = load_svg(svg_path)

    PLACEHOLDER_SYMBOL = "¤"
    NBSP = "\u00A0"
    INDENT_HTML = NBSP * 2  # two non-breaking spaces per indent level

    # Normalize any existing &nbsp; entities to Unicode NBSP so SVG remains valid XML
    if "&nbsp;" in text:
        text = text.replace("&nbsp;", NBSP)

    # Convert placeholder symbols into indentation sequences before styling tweaks
    if PLACEHOLDER_SYMBOL in text:
        text = text.replace(PLACEHOLDER_SYMBOL, INDENT_HTML)

    # Remove the global left-align style block we injected earlier (if present)
    text, removed_count = re.subn(
        r"</style><style>#container \\.label text[^<]+?#container foreignObject div[^<]+?</style>",
        "</style>",
        text,
        count=1,
        flags=re.S,
    )

    pattern = re.compile(
        r'(<foreignObject[^>]*>\s*<div[^>]*style=")([^"]*)("[^>]*>)(.*?)(</div>\s*</foreignObject>)',
        re.S,
    )

    code_char_pattern = re.compile(r"[();{}=]")

    def has_code(body: str) -> bool:
        plain = re.sub(r"<[^>]+>", "", body)
        plain = html.unescape(plain).strip()
        if not plain:
            return False
        # Only treat as code when the block label contains CODE BLOCK
        if "CODE BLOCK" not in plain:
            return False
        return bool(code_char_pattern.search(plain))

    def normalize_style(style: str) -> str:
        style = re.sub(r"text-align:\s*[^;]+;?", "", style, flags=re.I)
        style = re.sub(r"padding-left:\s*[^;]+;?", "", style, flags=re.I)
        parts = [segment.strip() for segment in style.split(";") if segment.strip()]
        normalized = "; ".join(parts)
        if normalized:
            normalized += "; "
        return normalized

    def repl(match: re.Match) -> str:
        prefix, style, suffix, body, closing = match.groups()
        base_style = normalize_style(style)
        if has_code(body):
            base_style += "text-align: left; padding-left:6px;"
        updated_style = base_style.strip()
        if updated_style and not updated_style.endswith(";"):
            updated_style += ";"
        return f"{prefix}{updated_style}{suffix}{body}{closing}"

    new_text = pattern.sub(repl, text)
    save_svg(svg_path, new_text)

    print({"extra_style_removed": bool(removed_count), "updated_length": len(new_text)})


if __name__ == "__main__":
    main()
