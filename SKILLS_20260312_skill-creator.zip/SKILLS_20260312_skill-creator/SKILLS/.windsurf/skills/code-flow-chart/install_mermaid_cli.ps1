# Install mermaid-cli globally if missing. Run in PowerShell.
$ErrorActionPreference = 'Stop'

# Check if mermaid-cli is available
$hasMermaid = $false
try {
    npx @mermaid-js/mermaid-cli -V *> $null
    $hasMermaid = $true
} catch {
    $hasMermaid = $false
}

if ($hasMermaid) {
    Write-Host "mermaid-cli already installed." -ForegroundColor Green
    exit 0
}

Write-Host "mermaid-cli not found. Installing globally..." -ForegroundColor Yellow
# Skip bundled Chromium download; use system Chrome/Edge
$env:PUPPETEER_SKIP_DOWNLOAD = "true"
npm install -g @mermaid-js/mermaid-cli

# Verify
npx @mermaid-js/mermaid-cli -V
Write-Host "mermaid-cli installation complete." -ForegroundColor Green
