#!/usr/bin/env python3
"""
Jira Ticket Creator

Creates Jira tickets from JSON input provided by the agent.
The agent is responsible for understanding the task content and
formatting it according to the ticket template.

Usage:
    # Preview ticket (dry-run)
    echo '{"summary": "...", "description": "..."}' | python create_ticket.py
    
    # Create ticket in Jira
    echo '{"summary": "...", "description": "..."}' | python create_ticket.py --push
    
    # From JSON file
    python create_ticket.py --input ticket.json --push
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Optional

try:
    import tomllib
except ImportError:
    import tomli as tomllib

from pydantic import BaseModel, Field


# =============================================================================
# Configuration
# =============================================================================

class JiraConfig(BaseModel):
    """Jira server configuration."""
    url: str
    token: str
    project_key: str = "SDA"
    issue_type: str = "Story"
    priority: str = "Medium"


class CustomFieldsConfig(BaseModel):
    """Custom field IDs for the Jira project."""
    epic_link: str = "customfield_12300"
    epic_key: str = ""
    acceptance_criteria: str = "customfield_12500"
    dor_field: str = "customfield_45400"
    dod_field: str = "customfield_45411"


class LabelsConfig(BaseModel):
    """Label configuration."""
    default: list[str] = Field(default_factory=lambda: ["code-insight"])
    phase_prefix: str = "phase"


class OptionsConfig(BaseModel):
    """Runtime options."""
    dry_run: bool = True


class Config(BaseModel):
    """Complete configuration."""
    jira: JiraConfig
    custom_fields: CustomFieldsConfig = Field(default_factory=CustomFieldsConfig)
    labels: LabelsConfig = Field(default_factory=LabelsConfig)
    options: OptionsConfig = Field(default_factory=OptionsConfig)

    @classmethod
    def load(cls, config_path: Path) -> "Config":
        """Load configuration from TOML file."""
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
        return cls(**data)


# =============================================================================
# Ticket Model
# =============================================================================

class TicketInput(BaseModel):
    """Input model for a Jira ticket from the agent."""
    # Required fields for create
    summary: str = Field(..., description="Ticket summary/title. Format: [Tag] Title (Phase X.X)")
    description: str = Field(..., description="Ticket description in Jira wiki markup")
    
    # Optional overrides (defaults come from config)
    project_key: Optional[str] = Field(None, description="Override project key")
    issue_type: Optional[str] = Field(None, description="Override issue type (Story, Task, Bug)")
    priority: Optional[str] = Field(None, description="Override priority (High, Medium, Low)")
    epic_key: Optional[str] = Field(None, description="Override epic link")
    labels: Optional[list[str]] = Field(None, description="Override labels (replaces defaults)")
    acceptance_criteria: Optional[str] = Field(None, description="Acceptance criteria text")
    status: Optional[str] = Field(None, description="Initial status (e.g., 'Inbox', 'Closed')")


class TicketsInput(BaseModel):
    """Input model for multiple tickets."""
    tickets: list[TicketInput]


class TicketUpdate(BaseModel):
    """Input model for updating an existing Jira ticket."""
    # Required: ticket key to update
    key: str = Field(..., description="Jira ticket key (e.g., SDA-123)")
    
    # All fields optional - only provided fields will be updated
    summary: Optional[str] = Field(None, description="New summary/title")
    description: Optional[str] = Field(None, description="New description")
    priority: Optional[str] = Field(None, description="New priority")
    labels: Optional[list[str]] = Field(None, description="New labels (replaces existing)")
    acceptance_criteria: Optional[str] = Field(None, description="New acceptance criteria")
    status: Optional[str] = Field(None, description="Transition to status: INBOX, DEVELOPING, DONE")


class TicketUpdatesInput(BaseModel):
    """Input model for multiple ticket updates."""
    updates: list[TicketUpdate]


class TicketQuery(BaseModel):
    """Input model for querying Jira tickets."""
    # JQL query (most flexible)
    jql: Optional[str] = Field(None, description="JQL query string")
    
    # Simple filters (will be combined into JQL)
    project: Optional[str] = Field(None, description="Project key (e.g., SDA)")
    labels: Optional[list[str]] = Field(None, description="Filter by additional labels")
    summary_contains: Optional[str] = Field(None, description="Summary contains text")
    status: Optional[str] = Field(None, description="Filter by status")
    phase: Optional[str] = Field(None, description="Filter by phase (e.g., 1.4) - uses phase_prefix from config")
    
    # Use default labels from config for filtering (identifies the component)
    include_default_labels: bool = Field(True, description="Include default labels from config in search")
    
    # Result options
    max_results: int = Field(50, description="Maximum results to return")
    fields: list[str] = Field(
        default_factory=lambda: ["key", "summary", "status", "labels"],
        description="Fields to return"
    )


# =============================================================================
# Jira Client
# =============================================================================

class JiraClient:
    """Wrapper around atlassian-python-api Jira client."""
    
    def __init__(self, config: Config):
        self.config = config
        self._client = None
    
    @property
    def client(self):
        """Lazy-load Jira client."""
        if self._client is None:
            from atlassian import Jira
            self._client = Jira(
                url=self.config.jira.url,
                token=self.config.jira.token,
            )
        return self._client
    
    def create_issue(self, ticket: TicketInput) -> dict:
        """Create an issue in Jira."""
        cfg = self.config
        cf = cfg.custom_fields
        
        # Build labels - start with provided or defaults
        labels = list(ticket.labels) if ticket.labels is not None else list(cfg.labels.default)
        
        # Auto-extract phase from summary and add phase label
        # Looks for patterns like "(Phase 1.0)" or "(Phase 1.4.1)"
        import re
        phase_match = re.search(r'\(Phase\s+(\d+\.\d+(?:\.\d+)?)\)', ticket.summary, re.IGNORECASE)
        if phase_match:
            phase_num = phase_match.group(1)
            phase_label = f"{cfg.labels.phase_prefix}-{phase_num}"
            if phase_label not in labels:
                labels.append(phase_label)
        
        # Build fields with defaults and overrides
        fields = {
            "project": {"key": ticket.project_key or cfg.jira.project_key},
            "summary": ticket.summary,
            "description": ticket.description,
            "issuetype": {"name": ticket.issue_type or cfg.jira.issue_type},
            "priority": {"name": ticket.priority or cfg.jira.priority},
            "labels": labels,
        }
        
        # Epic Link
        epic_key = ticket.epic_key or cf.epic_key
        if epic_key:
            fields[cf.epic_link] = epic_key
        
        # Acceptance Criteria
        if ticket.acceptance_criteria:
            fields[cf.acceptance_criteria] = ticket.acceptance_criteria
        
        # Create the issue
        result = self.client.create_issue(fields=fields)
        
        # Handle initial status if different from default
        # Note: We need the key from the result to transition
        if ticket.status and ticket.status.lower() != cfg.workflow.default_status.lower():
            issue_key = result.get("key")
            if issue_key:
                try:
                    self._transition_issue(issue_key, ticket.status)
                    result["status_updated"] = True
                except Exception as e:
                    print(f"Warning: Created ticket but failed to transition to '{ticket.status}': {e}", file=sys.stderr)
                    result["status_error"] = str(e)
        
        return result
    
    def update_issue(self, update: TicketUpdate) -> dict:
        """Update an existing issue in Jira."""
        cfg = self.config
        cf = cfg.custom_fields
        
        fields = {}
        
        # Only include fields that are provided
        if update.summary is not None:
            fields["summary"] = update.summary
        
        if update.description is not None:
            fields["description"] = update.description
        
        if update.priority is not None:
            fields["priority"] = {"name": update.priority}
        
        if update.labels is not None:
            fields["labels"] = update.labels
        
        if update.acceptance_criteria is not None:
            fields[cf.acceptance_criteria] = update.acceptance_criteria
        
        # Update fields
        if fields:
            self.client.update_issue_field(update.key, fields)
        
        # Handle status transition if requested
        if update.status:
            self._transition_issue(update.key, update.status)
        
        return {"key": update.key, "updated": True}
    
    def _transition_issue(self, key: str, target_status: str):
        """Transition an issue to a new status."""
        # Get available transitions
        transitions_response = self.client.get_issue_transitions(key)
        
        # Handle both list and dict responses
        if isinstance(transitions_response, list):
            transitions = transitions_response
        else:
            transitions = transitions_response.get("transitions", [])
        
        def get_trans_name(t):
            """Extract transition name from various formats."""
            if isinstance(t, dict):
                # Try 'name' first (transition name)
                if "name" in t:
                    return str(t["name"])
                # Try 'to' (might be string or dict)
                if "to" in t:
                    if isinstance(t["to"], dict):
                        return str(t["to"].get("name", ""))
                    return str(t["to"])
            return str(t)
        
        # Find matching transition - issue_transition takes status name, not ID
        for transition in transitions:
            trans_name = get_trans_name(transition)
            if trans_name.lower() == target_status.lower():
                self.client.issue_transition(key, trans_name)
                return
        
        # If exact match not found, try partial match
        for transition in transitions:
            trans_name = get_trans_name(transition)
            if target_status.lower() in trans_name.lower():
                self.client.issue_transition(key, trans_name)
                return
        
        # List available transitions in error
        available = [get_trans_name(t) for t in transitions]
        raise ValueError(f"No transition found for status '{target_status}'. Available: {available}")
    
    def search_issues(self, query: TicketQuery) -> list[dict]:
        """Search for issues using JQL or simple filters."""
        cfg = self.config
        
        # Build JQL from query
        if query.jql:
            jql = query.jql
        else:
            conditions = []
            
            # Project filter
            project = query.project or cfg.jira.project_key
            if project:
                conditions.append(f"project = {project}")
            
            # Default labels filter (identifies the component)
            if query.include_default_labels and cfg.labels.default:
                for label in cfg.labels.default:
                    conditions.append(f'labels = "{label}"')
            
            # Phase filter - converts phase number to label using prefix
            if query.phase:
                phase_label = f"{cfg.labels.phase_prefix}-{query.phase}"
                conditions.append(f'labels = "{phase_label}"')
            
            # Additional labels filter
            if query.labels:
                for label in query.labels:
                    conditions.append(f'labels = "{label}"')
            
            # Summary contains
            if query.summary_contains:
                conditions.append(f'summary ~ "{query.summary_contains}"')
            
            # Status filter
            if query.status:
                conditions.append(f'status = "{query.status}"')
            
            jql = " AND ".join(conditions) if conditions else f"project = {cfg.jira.project_key}"
        
        # Execute search
        results = self.client.jql(
            jql,
            limit=query.max_results,
            fields=",".join(query.fields)
        )
        
        # Format results
        issues = []
        for issue in results.get("issues", []):
            issue_data = {
                "key": issue["key"],
                "summary": issue["fields"].get("summary", ""),
            }
            
            # Add status if available
            status = issue["fields"].get("status")
            if status:
                issue_data["status"] = status.get("name", "")
            
            # Add labels if available
            labels = issue["fields"].get("labels")
            if labels:
                issue_data["labels"] = labels
            
            issues.append(issue_data)
        
        return issues
    
    def test_connection(self) -> bool:
        """Test the Jira connection."""
        try:
            self.client.myself()
            return True
        except Exception as e:
            print(f"Connection failed: {e}", file=sys.stderr)
            return False


# =============================================================================
# CLI
# =============================================================================

def print_ticket_preview(ticket: TicketInput, index: int, config: Config):
    """Print a formatted preview of a ticket."""
    cfg = config
    cf = cfg.custom_fields
    
    print(f"\n{'='*60}")
    print(f"Ticket #{index + 1}")
    print(f"{'='*60}")
    print(f"Summary:    {ticket.summary}")
    print(f"Project:    {ticket.project_key or cfg.jira.project_key}")
    print(f"Type:       {ticket.issue_type or cfg.jira.issue_type}")
    print(f"Priority:   {ticket.priority or cfg.jira.priority}")
    print(f"Epic:       {ticket.epic_key or cf.epic_key}")
    
    # Build labels with auto-extracted phase (same logic as create_issue)
    labels = list(ticket.labels) if ticket.labels is not None else list(cfg.labels.default)
    import re
    phase_match = re.search(r'\(Phase\s+(\d+\.\d+(?:\.\d+)?)\)', ticket.summary, re.IGNORECASE)
    if phase_match:
        phase_num = phase_match.group(1)
        phase_label = f"{cfg.labels.phase_prefix}-{phase_num}"
        if phase_label not in labels:
            labels.append(phase_label)
    
    print(f"Labels:     {', '.join(labels)}")
    print(f"\nDescription:\n{'-'*40}")
    desc = ticket.description
    print(desc[:500] + "..." if len(desc) > 500 else desc)
    if ticket.acceptance_criteria:
        print(f"\nAcceptance Criteria:\n{'-'*40}")
        print(ticket.acceptance_criteria)
    if ticket.status and ticket.status.lower() != cfg.workflow.default_status.lower():
        print(f"\nInitial Status: -> {ticket.status}")


def print_update_preview(update: TicketUpdate, index: int):
    """Print a formatted preview of a ticket update."""
    print(f"\n{'='*60}")
    print(f"Update #{index + 1}: {update.key}")
    print(f"{'='*60}")
    if update.summary is not None:
        print(f"Summary:    {update.summary}")
    if update.description is not None:
        desc = update.description
        print(f"Description: {desc[:100]}..." if len(desc) > 100 else f"Description: {desc}")
    if update.priority is not None:
        print(f"Priority:   {update.priority}")
    if update.labels is not None:
        print(f"Labels:     {', '.join(update.labels)}")
    if update.acceptance_criteria is not None:
        print(f"Acceptance: {update.acceptance_criteria[:100]}...")
    if update.status is not None:
        print(f"Status:     → {update.status}")


def main():
    parser = argparse.ArgumentParser(
        description="Create or update Jira tickets from JSON input."
    )
    parser.add_argument(
        "-i", "--input",
        help="Path to JSON file with ticket data. If not provided, reads from stdin."
    )
    parser.add_argument(
        "-c", "--config",
        default="config.toml",
        help="Path to config file (default: config.toml)"
    )
    parser.add_argument(
        "--push",
        action="store_true",
        help="Actually create/update tickets in Jira (disables dry-run)"
    )
    parser.add_argument(
        "--update",
        action="store_true",
        help="Update existing tickets instead of creating new ones"
    )
    parser.add_argument(
        "--query",
        action="store_true",
        help="Query/search for existing tickets"
    )
    parser.add_argument(
        "--template",
        action="store_true",
        help="Print the expected JSON template and exit"
    )
    
    args = parser.parse_args()
    
    # Print template if requested
    if args.template:
        if args.query:
            template = {
                "# Search uses default labels from config to identify component": "",
                "phase": "1.4",
                "# OR use other filters": "",
                "status": "INBOX",
                "summary_contains": "Dashboard",
                "# Set to false to search across all labels": "",
                "include_default_labels": True,
                "max_results": 50
            }
        elif args.update:
            template = {
                "updates": [
                    {
                        "key": "SDA-123",
                        "summary": "[Tag] Updated Title (Phase X.X)",
                        "description": "h3. Background\n...",
                        "status": "DEVELOPING"
                    }
                ]
            }
        else:
            template = {
                "tickets": [
                    {
                        "summary": "[Tag] Title (Phase X.X)",
                        "description": "h3. Background\n...\n\nh3. Scope\n* Item 1\n* Item 2\n\nh3. Impact\n...",
                        "acceptance_criteria": "- Criterion 1\n- Criterion 2"
                    }
                ]
            }
        print(json.dumps(template, indent=2))
        return
    
    # Resolve paths relative to skill directory
    skill_dir = Path(__file__).parent.parent
    config_path = skill_dir / args.config
    
    # Load configuration
    if not config_path.exists():
        print(f"ERROR: Config file not found: {config_path}", file=sys.stderr)
        print("Copy config.toml.example to config.toml and fill in your values.", file=sys.stderr)
        sys.exit(1)
    
    try:
        config = Config.load(config_path)
    except Exception as e:
        print(f"ERROR: Failed to load config: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Override dry_run if --push specified
    if args.push:
        config.options.dry_run = False
    
    # Read input
    if args.input:
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"ERROR: Input file not found: {input_path}", file=sys.stderr)
            sys.exit(1)
        json_data = input_path.read_text(encoding="utf-8")
    else:
        # Read from stdin
        if sys.stdin.isatty():
            print("Reading ticket data from stdin (paste JSON and press Ctrl+D):", file=sys.stderr)
        json_data = sys.stdin.read()
    
    if not json_data.strip():
        print("ERROR: No input provided", file=sys.stderr)
        sys.exit(1)
    
    # Parse input
    try:
        data = json.loads(json_data)
    except json.JSONDecodeError as e:
        print(f"ERROR: Invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)
    # Handle query mode
    if args.query:
        client = JiraClient(config)
        
        if not client.test_connection():
            print("ERROR: Could not connect to Jira. Check your config.", file=sys.stderr)
            sys.exit(1)
        
        # Parse query
        query = TicketQuery(**data)
        
        print(f"Searching Jira...")
        issues = client.search_issues(query)
        
        if not issues:
            print("No tickets found matching query.")
        else:
            print(f"\nFound {len(issues)} ticket(s):\n")
            print(f"{'Key':<12} {'Status':<15} {'Summary'}")
            print("-" * 70)
            for issue in issues:
                key = issue.get("key", "")
                status = issue.get("status", "")
                summary = issue.get("summary", "")[:45]
                print(f"{key:<12} {status:<15} {summary}")
            
            # Output as JSON for programmatic use
            print(f"\n{json.dumps({'issues': issues}, indent=2)}")
        return
    
    # Handle update mode
    if args.update:
        if "updates" in data:
            updates_input = TicketUpdatesInput(**data)
            updates = updates_input.updates
        elif "key" in data:
            updates = [TicketUpdate(**data)]
        else:
            print("ERROR: JSON must contain 'updates' array or a single update with 'key'", file=sys.stderr)
            sys.exit(1)
        
        if not updates:
            print("No updates to process.")
            return
        
        print(f"Processing {len(updates)} update(s)")
        
        if config.options.dry_run:
            print("\n" + "="*60)
            print("DRY RUN MODE - No tickets will be updated")
            print("="*60)
            
            for i, update in enumerate(updates):
                print_update_preview(update, i)
            
            print("\n" + "="*60)
            print(f"Total: {len(updates)} ticket(s) would be updated")
            print("Run with --push to update tickets in Jira")
            print("="*60)
        else:
            print("\nUpdating tickets in Jira...")
            client = JiraClient(config)
            
            if not client.test_connection():
                print("ERROR: Could not connect to Jira. Check your config.", file=sys.stderr)
                sys.exit(1)
            
            updated = []
            failed = []
            
            for i, update in enumerate(updates):
                try:
                    client.update_issue(update)
                    updated.append(update.key)
                    print(f"  OK Updated: {update.key}")
                except Exception as e:
                    failed.append((update.key, str(e)))
                    print(f"  X Failed: {update.key} - {e}")
            
            print("\n" + "="*60)
            print(f"Updated: {len(updated)} ticket(s)")
            if updated:
                print(f"  Keys: {', '.join(updated)}")
            if failed:
                print(f"Failed: {len(failed)} ticket(s)")
                for key, error in failed:
                    print(f"  - {key}: {error}")
            print("="*60)
            
            if updated:
                print(f"\n{json.dumps({'updated': updated})}")
        return
    
    # Handle create mode
    if "tickets" in data:
        tickets_input = TicketsInput(**data)
        tickets = tickets_input.tickets
    elif "summary" in data:
        tickets = [TicketInput(**data)]
    else:
        print("ERROR: JSON must contain 'tickets' array or a single ticket with 'summary'", file=sys.stderr)
        sys.exit(1)
    
    if not tickets:
        print("No tickets to process.")
        return
    
    print(f"Processing {len(tickets)} ticket(s)")
    
    # Preview or push
    if config.options.dry_run:
        print("\n" + "="*60)
        print("DRY RUN MODE - No tickets will be created")
        print("="*60)
        
        for i, ticket in enumerate(tickets):
            print_ticket_preview(ticket, i, config)
        
        print("\n" + "="*60)
        print(f"Total: {len(tickets)} ticket(s) would be created")
        print("Run with --push to create tickets in Jira")
        print("="*60)
    else:
        print("\nCreating tickets in Jira...")
        client = JiraClient(config)
        
        # Test connection first
        if not client.test_connection():
            print("ERROR: Could not connect to Jira. Check your config.", file=sys.stderr)
            sys.exit(1)
        
        created = []
        failed = []
        
        for i, ticket in enumerate(tickets):
            try:
                result = client.create_issue(ticket)
                key = result.get("key", "???")
                created.append(key)
                print(f"  OK Created: {key} - {ticket.summary[:50]}...")
            except Exception as e:
                failed.append((ticket.summary, str(e)))
                print(f"  X Failed: {ticket.summary[:50]}... - {e}")
        
        print("\n" + "="*60)
        print(f"Created: {len(created)} ticket(s)")
        if created:
            print(f"  Keys: {', '.join(created)}")
        if failed:
            print(f"Failed: {len(failed)} ticket(s)")
            for summary, error in failed:
                print(f"  - {summary[:40]}...: {error}")
        print("="*60)
        
        # Output created keys as JSON for programmatic use
        if created:
            print(f"\n{json.dumps({'created': created})}")


if __name__ == "__main__":
    main()
