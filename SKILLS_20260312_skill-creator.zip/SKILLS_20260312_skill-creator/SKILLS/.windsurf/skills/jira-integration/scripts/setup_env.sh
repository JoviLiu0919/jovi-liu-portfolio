#!/bin/bash
# Setup script for Jira Integration Skill
# Creates an isolated virtual environment with required dependencies

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
VENV_DIR="$SKILL_DIR/.venv"

echo "=== Jira Integration Skill Setup ==="
echo "Skill directory: $SKILL_DIR"
echo ""

# Check Python version
PYTHON_CMD=""
if command -v python3.11 &> /dev/null; then
    PYTHON_CMD="python3.11"
elif command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
else
    echo "ERROR: Python 3 not found. Please install Python 3.11+"
    exit 1
fi

PYTHON_VERSION=$($PYTHON_CMD --version 2>&1)
echo "Using: $PYTHON_VERSION"

# Create virtual environment
if [ -d "$VENV_DIR" ]; then
    echo "Virtual environment already exists at $VENV_DIR"
    read -p "Recreate? (y/N) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -rf "$VENV_DIR"
        echo "Removed existing environment"
    else
        echo "Keeping existing environment"
    fi
fi

if [ ! -d "$VENV_DIR" ]; then
    echo "Creating virtual environment..."
    $PYTHON_CMD -m venv "$VENV_DIR"
    echo "Created: $VENV_DIR"
fi

# Activate and install dependencies
echo ""
echo "Installing dependencies..."
source "$VENV_DIR/bin/activate"
pip install --upgrade pip -q
pip install -r "$SKILL_DIR/requirements.txt"

echo ""
echo "=== Setup Complete ==="
echo ""
echo "To use the skill:"
echo "  1. Copy config.toml.example to config.toml and fill in your values"
echo "  2. Run: $VENV_DIR/bin/python $SKILL_DIR/scripts/generate_tickets.py --help"
echo ""
echo "Or activate the environment manually:"
echo "  source $VENV_DIR/bin/activate"
