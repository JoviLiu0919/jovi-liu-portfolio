#!/usr/bin/env python3
"""
Dell Platform Identifier Tool

Identifies Dell platform silicon vendor and platform type from DellPlatformPkg.dsc files.
Based on Dell domain knowledge for platform identification.
"""

import os
import re
from pathlib import Path
from typing import Dict, Optional, Tuple

class DellPlatformIdentifier:
    """Identifies Dell platform silicon vendor and characteristics"""
    
    def __init__(self):
        self.silicon_vendors = {
            'OneSiliconPkg': 'Intel',
            'Amd': 'AMD', 
            'Qualcomm': 'Qualcomm',
            'Nvidia': 'NVIDIA'
        }
        
        self.platform_types = {
            'NB': 'Notebook',
            'DT': 'Desktop',
            'Workstation': 'Workstation'
        }
    
    def identify_platform_from_dsc(self, dsc_path: str) -> Dict[str, str]:
        """Identify platform from DellPlatformPkg.dsc file"""
        dsc_path = Path(dsc_path)
        
        if not dsc_path.exists():
            return {'error': f'DSC file not found: {dsc_path}'}
        
        # Extract platform info from path
        path_parts = dsc_path.parts
        platform_info = self._extract_from_path(path_parts)
        
        # Parse DSC content for SILICON_PRODUCT_PATH
        try:
            with open(dsc_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            silicon_product_path = self._extract_silicon_product_path(content)
            if silicon_product_path:
                silicon_info = self._parse_silicon_product_path(silicon_product_path)
                platform_info.update(silicon_info)
            
        except Exception as e:
            platform_info['error'] = f'Error reading DSC file: {e}'
        
        return platform_info
    
    def _extract_from_path(self, path_parts: Tuple[str, ...]) -> Dict[str, str]:
        """Extract platform info from directory path"""
        info = {}
        
        # Find DellPlatformPkgs in path
        if 'DellPlatformPkgs' in path_parts:
            dell_pkgs_index = path_parts.index('DellPlatformPkgs')
            
            # Extract platform type (NB, DT, Workstation)
            if dell_pkgs_index + 1 < len(path_parts):
                platform_type_code = path_parts[dell_pkgs_index + 1]
                info['platform_type_code'] = platform_type_code
                info['platform_type'] = self.platform_types.get(platform_type_code, 'Unknown')
            
            # Extract project name (e.g., BladePtlOnePkg)
            if dell_pkgs_index + 2 < len(path_parts):
                project_pkg = path_parts[dell_pkgs_index + 2]
                info['project_package'] = project_pkg
                info['project_name'] = project_pkg.replace('Pkg', '')
        
        return info
    
    def _extract_silicon_product_path(self, content: str) -> Optional[str]:
        """Extract SILICON_PRODUCT_PATH from DSC content"""
        # Look for DEFINE SILICON_PRODUCT_PATH
        pattern = r'DEFINE\s+SILICON_PRODUCT_PATH\s*=\s*([^\r\n]+)'
        match = re.search(pattern, content, re.IGNORECASE)
        
        if match:
            return match.group(1).strip()
        
        return None
    
    def _parse_silicon_product_path(self, silicon_path: str) -> Dict[str, str]:
        """Parse silicon product path to identify vendor and platform"""
        info = {}
        
        # Remove quotes and whitespace
        silicon_path = silicon_path.strip(' \t"\'')
        info['silicon_product_path'] = silicon_path
        
        # Identify silicon vendor from path prefix
        for vendor_prefix, vendor_name in self.silicon_vendors.items():
            if silicon_path.startswith(vendor_prefix):
                info['silicon_vendor'] = vendor_name
                info['silicon_vendor_prefix'] = vendor_prefix
                break
        
        # Extract platform name from path
        # Pattern: Vendor/Product/PlatformName or Vendor/PlatformName
        path_parts = silicon_path.split('/')
        
        if len(path_parts) >= 3 and path_parts[1] == 'Product':
            # Vendor/Product/PlatformName format
            platform_name = path_parts[2]
        elif len(path_parts) >= 2:
            # Vendor/PlatformName format
            platform_name = path_parts[1]
        else:
            platform_name = 'Unknown'
        
        info['platform_name'] = platform_name
        
        # Add vendor-specific characteristics
        if info.get('silicon_vendor') == 'Intel':
            info['architecture'] = 'x86_64'
            info['fsp_support'] = 'Yes'  # Intel platforms use FSP
            info['agesa_support'] = 'No'
        elif info.get('silicon_vendor') == 'AMD':
            info['architecture'] = 'x86_64'
            info['fsp_support'] = 'No'   # AMD platforms use AGESA
            info['agesa_support'] = 'Yes'
        elif info.get('silicon_vendor') in ['Qualcomm', 'NVIDIA']:
            info['architecture'] = 'ARM64'
            info['fsp_support'] = 'No'
            info['agesa_support'] = 'No'
        
        return info
    
    def scan_dell_platforms(self, base_path: str) -> Dict[str, Dict]:
        """Scan all Dell platforms in base directory"""
        base_path = Path(base_path)
        platforms = {}
        
        # Look for DellPlatformPkgs structure
        dell_platforms_path = base_path / 'DellPkgs' / 'DellPlatformPkgs'
        
        if not dell_platforms_path.exists():
            return {'error': f'Dell platform packages not found at: {dell_platforms_path}'}
        
        # Scan each platform type (NB, DT, Workstation)
        for platform_type_dir in dell_platforms_path.iterdir():
            if not platform_type_dir.is_dir():
                continue
            
            platform_type = platform_type_dir.name
            
            # Scan each project package
            for project_dir in platform_type_dir.iterdir():
                if not project_dir.is_dir():
                    continue
                
                # Look for DellPlatformPkg.dsc
                dsc_file = project_dir / 'DellPlatformPkg.dsc'
                if dsc_file.exists():
                    project_name = project_dir.name
                    platform_key = f"{platform_type}/{project_name}"
                    
                    platforms[platform_key] = self.identify_platform_from_dsc(dsc_file)
        
        return platforms


def main():
    """Main entry point for platform identification"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Dell Platform Identifier')
    parser.add_argument('--dsc-file', help='Path to DellPlatformPkg.dsc file')
    parser.add_argument('--scan-dir', help='Base directory to scan for Dell platforms')
    parser.add_argument('--base-path', default='.', help='Base path for scanning (default: current directory)')
    
    args = parser.parse_args()
    
    identifier = DellPlatformIdentifier()
    
    if args.dsc_file:
        # Analyze single DSC file
        result = identifier.identify_platform_from_dsc(args.dsc_file)
        print(f"Platform Analysis for: {args.dsc_file}")
        print("=" * 50)
        for key, value in result.items():
            print(f"{key}: {value}")
    
    elif args.scan_dir or args.base_path:
        # Scan directory for platforms
        scan_path = args.scan_dir or args.base_path
        platforms = identifier.scan_dell_platforms(scan_path)
        
        if 'error' in platforms:
            print(f"Error: {platforms['error']}")
            return
        
        print(f"Dell Platform Scan Results for: {scan_path}")
        print("=" * 60)
        
        for platform_key, info in platforms.items():
            print(f"\n📁 Platform: {platform_key}")
            print("-" * 40)
            for key, value in info.items():
                if key != 'error':
                    print(f"  {key}: {value}")
            if 'error' in info:
                print(f"  ❌ Error: {info['error']}")
    
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
