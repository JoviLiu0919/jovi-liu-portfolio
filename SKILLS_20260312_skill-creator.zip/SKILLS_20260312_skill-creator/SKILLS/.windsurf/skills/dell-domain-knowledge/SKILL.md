---
name: dell-domain-knowledge
description: Dell proprietary domain knowledge for CPSE analysis, including signing processes, platform configurations, and internal systems. Use when analyzing Dell-specific issues, understanding internal workflows, or accessing Dell proprietary knowledge.
---

# DELL Domain Knowledge Skill

This skill contains Dell-specific proprietary knowledge required for deep CPSE issue analysis, including signing processes, platform configurations, and internal system workflows.

## Core Knowledge Areas

### **Dell Signing Infrastructure**
#### **PQC (Post-Quantum Cryptography) Signing Process**
- **Dell Sign Server**: Central signing authority for PQC-signed binaries
- **Key Management**: Single PQC public key design in BIOS code
- **Key Category Mapping**: Critical for payload verification
- **Signing Workflow**: External signing process, internal verification

#### **Key Category System**
- **Primary PQC Key**: `89084706-e614-44db-8ad1-bc1dca73b299` (SYSTEM_PQC_LMS_PRIMARY_KEY_GUID)
- **Missing Key Category**: `540B32B0-808D-47E1-A188-76AA7CF1BB93` (EC-specific category)
- **Key Category Mismatch**: Common failure pattern in PQC deployment

### **Platform Payload Classification**
#### **EC (Embedded Controller) Payloads**
- **EC Types**: 550X series (MCHP 5507 iFuse)
- **Payload GUIDs**: 
  - `5A0D5E58-1001-5507-AD34-29E13F481D4C` - NON_FUSED_EC_PRIMARY
  - `5A0D5E58-1002-5507-AD34-29E13F481D4C` - NON_FUSED_EC_FAILSAFE
  - `5A0D5E58-1011-5507-AD34-29E13F481D4C` - FUSED_EC_PRIMARY
  - `5A0D5E58-1012-5507-AD34-29E13F481D4C` - FUSED_EC_FAILSAFE
- **Binary Files**:
  - Unsigned: `Congo_LNL_00.00.05_mec_signed.bin`
  - Signed: `Congo_LNL_00.00.05_AF_mec_signed.bin` (AF = AutoFuse)
- **Signing Types**: RSA vs PQC classification issues

#### **BIOS Payloads**
- **PFAT_BIOS**: `F6BAA1AC-39BC-4066-92F3-2471D1E7C5C6` - Successfully PQC signed
- **Legacy Payloads**: Various GUIDs with RSA signatures

### **Platform Configurations**
#### **Platform Architecture Distinction**
- **Critical Rule**: AMD platforms do NOT use Intel FSP (Firmware Support Package)
- **FSP Exclusivity**: FSP functionality is exclusive to Intel platforms only
- **AMD Alternative**: AMD platforms use AGESA (AMD Generic Encapsulated Software Architecture)
- **Implication**: Any FSP-related error automatically indicates Intel platform context

#### **Intel FSP Platforms**
- **FSP Components**: FSP-T (Temp RAM Init), FSP-M (Memory Init), FSP-S (Silicon Init)
- **FSP Integration**: Requires symbol resolution during PEI phase
- **Common Issues**: Symbol resolution errors, version mismatches, linker configuration
- **Platform Examples**: TwinLake, PantherLake, LunarLake, NovaLakeH/S

#### **AMD AGESA Platforms**  
- **AGESA Components**: AMD platform initialization equivalent to FSP
- **Architecture**: Different initialization flow and symbol management
- **Platform Examples**: ComboAM5, GorgonFP8, MedusaFP10, ShimadaPeak

#### **CongoLnlOne Platform**
- **Platform Type**: Notebook (NB)
- **Silicon**: LunarLake (LNL) - **Intel Platform**
- **FSP Support**: Uses Intel FSP (not AGESA)
- **PQC Support**: Enabled via `SECURITY_PFS_PQC_SUPPORT = TRUE`
- **EC Configuration**: MCHP 5507 iFuse, non-fused and fused variants
- **Build Configuration**: `builda.bat` with EC binary paths

#### **Platform-Specific Files**
- **Payload Definition**: `FlashPayload/BoardPayload.dsc`
- **PQC Key Table**: `Include/DellPqcPublicKeyTable.h`
- **Build Script**: `builda.bat` with EC binary mappings
- **Platform Package**: `DellPkgs/DellPlatformPkgs/NB/CongoLnlOnePkg`

### **Internal Systems & Processes**
#### **DACI Token System & BIOS Attributes**
- **DACI (Direct Access Controller Interface)**: Dell's proprietary interface for BIOS configuration management
- **DACI Token Authentication**: Traditional method using BIOS passwords for command authentication
- **Security Vulnerabilities**: DACI commands with BIOS passwords are vulnerable to brute-force and dictionary attacks
- **DCSBC (Dell Command Secure BIOS Configuration)**: Modern approach replacing DACI password authentication
- **PKI Infrastructure**: Certificate-based authentication mechanism for BIOS configuration
- **Encrypted Channels**: Secure communication between platform and client
- **Integrity & Confidentiality**: Protection of customer data and configuration commands

#### **BIOS Attributes Management**
- **Attribute System**: Structured BIOS configuration parameters managed through DACI interface
- **Attribute Types**: CIM_BIOSEnumeration, string, integer, checkbox types
- **Attribute Properties**: 
  - **AttributeName**: Internal identifier (e.g., "WindowsCPC")
  - **AttributeDisplayName**: User-friendly name (e.g., "Windows Cloud PC Config")
  - **ValueName**: Possible values (e.g., "Enabled;Disabled")
  - **ValueDisplayName**: Display names for values
  - **IsReadOnly**: Read-only vs writable attribute control
- **Manufacturing Mode (MFG Mode)**: Special state where attributes can be modified
- **Service Menu Integration**: Service staff access to BIOS attributes for maintenance
- **Factory Tools Integration**: platcfg2 tool usage for factory configuration

#### **Platform Identification System**
- **Platform Package Structure**: `DellPkgs/DellPlatformPkgs/{TYPE}/{PROJECT}Pkg/DellPlatformPkg.dsc`
- **Platform Types**: 
  - **NB**: Notebook platforms
  - **DT**: Desktop platforms  
  - **Workstation**: High-performance workstations (PW)
- **Project Examples**: BladePtlOnePkg, CongoLnlOnePkg, etc.
- **SILICON_PRODUCT_PATH Mapping**: Key identifier in DellPlatformPkg.dsc for silicon vendor

#### **Silicon Vendor Identification**
- **Intel Platforms**: `OneSiliconPkg/Product/{PLATFORM_NAME}`
  - **PantherLake**: `OneSiliconPkg/Product/PantherLake`
  - **LunarLake**: `OneSiliconPkg/Product/LunarLake` 
  - **NovaLakeH/S**: `OneSiliconPkg/Product/NovaLakeH` or `OneSiliconPkg/Product/NovaLakeS`
  - **TwinLake**: `OneSiliconPkg/Product/TwinLake`
  - **PantherLakeFspPkg**: Indicates Intel FSP usage

- **AMD Platforms**: `Amd/AGESA_ComboAM5/AGESA` or similar AMD paths
  - **ComboAM5**: `Amd/AGESA_ComboAM5/AGESA`
  - **GorgonFP8**: `Amd/AGESA_GorgonFP8/AGESA`
  - **MedusaFP10**: `Amd/AGESA_MedusaFP10/AGESA`
  - **ShimadaPeak**: `Amd/AGESA_ShimadaPeak/AGESA`

- **Qualcomm Platforms**: `Qualcomm/{PLATFORM_NAME}` paths
  - **Snapdragon**: Typically ARM-based platforms
  - **SCM**: Snapdragon Compute platforms

- **NVIDIA Platforms**: `Nvidia/{PLATFORM_NAME}` paths
  - **Tegra**: ARM-based platforms
  - **GPU Integration**: Graphics-focused platforms

#### **Platform Detection Algorithm**
1. **Read DellPlatformPkg.dsc** from project package
2. **Extract SILICON_PRODUCT_PATH** definition
3. **Map path prefix to silicon vendor**:
   - `OneSiliconPkg/` → Intel
   - `Amd/` → AMD  
   - `Qualcomm/` → Qualcomm
   - `Nvidia/` → NVIDIA
4. **Extract platform name** from path (e.g., PantherLake, LunarLake)
5. **Determine platform type** from directory structure (NB/DT/Workstation)

#### **Platform-Specific Examples**
- **BladePtlOnePkg**: 
  - **SILICON_PRODUCT_PATH**: `OneSiliconPkg/Product/PantherLake`
  - **Silicon Vendor**: Intel PantherLake
  - **Platform Type**: NB (Notebook)
  - **FSP Usage**: Intel FSP enabled

- **CongoLnlOnePkg**:
  - **SILICON_PRODUCT_PATH**: `OneSiliconPkg/Product/LunarLake`  
  - **Silicon Vendor**: Intel LunarLake
  - **Platform Type**: NB (Notebook)
  - **FSP Usage**: Intel FSP enabled

#### **Platform Configuration Workflow**
- **Factory Configuration**: Use platcfg2 tool to enable/disable features during manufacturing
- **Service Menu Access**: Field service personnel can modify attributes via service menu
- **PID (Platform Identifier) System**: 
  - **PID_WCPC_CONFIG_FACTORY_FLAG**: Windows Cloud PC configuration flag
  - **Default Setting**: "Disabled" state for security
  - **Factory Enable**: platcfg2 tool enables configuration by order
- **Attribute Persistence**: Configuration persistence across reboots and BIOS defaults
- **Validation Requirements**: Ensure settings survive load BIOS default and RTC reset operations

#### **Windows Cloud PC Configuration Example**
- **Attribute Name**: "WindowsCPC"
- **Attribute Display Name**: "Windows Cloud PC Config"
- **Value Options**: "Enabled;Disabled"
- **Security Requirements**: 
  - Secure Boot enabled and cannot be disabled
  - PXE boot restricted and removed from boot options
  - Attribute writable in MFG mode, read-only outside MFG mode
- **Implementation**: New PCD for feature control, service menu integration

#### **DACI vs DCSBC Migration**
- **Legacy DACI**: Password-based authentication, vulnerable to attacks
- **Modern DCSBC**: PKI-based authentication with encrypted channels
- **Migration Benefits**: Enhanced security, integrity protection, confidentiality
- **Technology Integration**: Supports password management, platform configuration mirroring, factory tools
- **Backward Compatibility**: DCSBC maintains compatibility while improving security

#### **ATS Approval Process**
- **ATS = Agree To Ship**: Mechanism allowing certain issues to be resolved after MP (Mass Production)
- **Core Principle**: SEV1 must be resolved before MP, SEV2/SEV3 can become ATS candidates
- **Decision Authority**: Dell VM (Validation Management) defines levels, ODM test team alignment
- **BIOS SE Role**: Review levels and discuss adjustments with VM, typically require ODM to resolve directly

#### **ATS Priority Levels Mapping**
**SEV2 → ATS P1/P2**:
- **P1**: Web post at RTS and FI cut-in (RTS < 90 days)
  - Driver/BIOS install issues (resolvable via web-post update)
  - High/medium product impact + low likelihood (<1%)
- **P2**: 1st block: RTS < 90 days
  - Issues without expected high volume, causal but currently unresolvable

**SEV3 → ATS P3/P4/P5**:
- **P3**: Fix in sustaining (RTS+90~120 days, 3-6 months after shipment)
  - Must be resolved within product lifecycle
  - Dell sw driver team has clear timeline
  - Low user impact, resolvable in 1st Block
- **P4**: Approved to ship, resolve in next project
  - Low failure rate BSOD (<500DPPM)
  - Marginal violation of VTS specs
  - Engineering tool issues
- **P5**: Close/Obsolete, no resolution needed
  - Minor spec impact, no user impact
  - Issues only detectable in specific test cases

#### **Severity Calculator**
**Product Impact**:
- **High**: Data loss/damage, catastrophic failure, security, function loss, permanent damage
- **Medium**: Recoverable errors or application crashes, function/performance impaired, no permanent damage
- **Low**: Minor inconvenience or annoyance, system continues function

**Customer Impact**:
- **High**: Many calls expected, dispatch or refund possible, competitive disadvantage
- **Medium**: Some calls expected, dispatch or refund unlikely
- **Low**: Few calls expected, customers may experience similar issues with other systems

**Likelihood**:
- **Frequent**: Issue occurs >10% of time
- **Reasonably Possible**: Issue occurs <10% of time
- **Occasional**: Issue occurs <1% of time
- **Remote**: Issue occurs <0.1% of time
- **Extremely Unlikely**: Issue occurs <0.01% of time

#### **ATS Process Workflow**
1. **Meeting**: Convene meeting to discuss issue severity
2. **Classification**: Assign P1-P5 levels
3. **Timeline**: Resolution can occur on or after RTS date
4. **Tracking**: Manage, track, and report ATS P1/P2/P3 closures

#### **ATS Purpose & Actions**
- **Review**: ATS candidates severity rating
- **Assess**: Evaluate customer impact, decide Approve/Reject
- **Recommend**: Review and Approve/recommend ATS priority level
- **Manage**: Manage, Track & Report ATS P1/P2/P3 closures

#### **Signing Workflow**
1. **Binary Generation**: Platform build process creates unsigned binaries
2. **External Signing**: Dell Sign Server applies PQC signatures
3. **Key Category Assignment**: Critical mapping step
4. **Internal Verification**: BIOS code verifies signatures using public keys

#### **Common Failure Patterns**
- **Key Category Mismatch**: External signing uses different key category than internal verification
- **PQC Deployment Issues**: Transition from RSA to PQC signing
- **EC Signing Conflicts**: EC payloads incorrectly classified for signing type
- **Platform Configuration**: Missing or incorrect PQC support settings
- **FSP Symbol Resolution**: Intel platform-specific linker errors during PEI phase
- **Platform Misidentification**: Incorrectly applying FSP solutions to AMD platforms
- **ATS Eligibility Issues**: Incorrect severity classification affecting ATS decisions
- **Priority Mismatch**: SEV2/SEV3 issues not properly mapped to ATS P1-P5 levels
- **RTS Timeline Conflicts**: ATS resolution timeline not aligned with production schedule

### **BIOS Project Health Workflow (BIOS SE Daily Operations)**

#### **1. Code Name Interpretation & Naming Rules**
- Prefix letters map silicon vendors: `i` = Intel, `a` = AMD, `q` = Qualcomm, `N` = NVIDIA.
- Examples:
  - `Arwing 16 iARL-HX` → Intel Arrow Lake-HX 16'' NB.
  - `Jarvis N 14 aKrackan CY25` → AMD Kraken Point, CY25 program.
  - `Sanctuary A 16/18 iARL-HX (IEP)` → Intel Arrow Lake-HX, Innovation Excellence Program.
  - `26Q1_Huracan14_Performante16_iPTL` → multiple code names merged, Intel Panther Lake, NUDD 26Q1.
- Non-standard names (ex: `Sirius+SFF+RMB`) require CPSE page tree query to determine platform/NUDD/ODM.

#### **2. Confluence Page Tree Navigation (CPSE Space)**
- **Primary Path**: `CPG Platform Software Engineering` → ODM section (e.g., Compal, AMD Delta).
- Use CY+Quarter nodes to quickly locate NUDD packages and ODM dashboards (e.g., `26Q2_Slate14_iPtl`).
- **Page Content**:
  - `Jira_BIOS` field: System ticket and 4 Epic types (Task, Issue, PCR, EC Status).
  - `BIOS Generation`: NUDD version (e.g., 26Q2 NUDD).
  - `Model Name / ODM / LOB / SSID / CHID / ERST GUID / Chipset / TPM / EC / TBT / Type-C / PD / Graphic / Audio / Camera / LAN / WWAN / Dell Dock / NUDD links / PCR list / BIOS Status / SW Status / BIOS Codebase / Ingredients / Code Branch` etc. 1~29 fields.
- **Document Area**: ARD, PRD, Platform Feature Matrix, RFQ, Schedule, Platform BIOS POV, User Behavioral Spec, Platform Schematic, GPIO table.
- **Draft_Schedule**: Contains CP0/CP1/CP2 etc. milestones, can cross-reference Jira Task completion.

#### **3. Jira / PIMS Integration Pattern**
- System ticket (CPSE-xxxx) as entry point, linking to four Epics: Task, Issue, PCR, EC Status.
- Task Epic manages CPx milestone work; Issue Epic tracks Debug; PCR Epic controls design changes; EC Status Epic indexes ODM EC weekly updates.
- `Status-Flag` custom fields provide ODM confidence (Green/Yellow/Red), if inconsistent with Description, use content as basis and remind to update.
- If Confluence table lacks Jira info, use JQL: `project = CPSE AND issuetype = System AND summary ~ "<CodeName>"` to find corresponding ticket.
- Issue Manager → PIMS list: categorize by `Analyze` / `Investigating` etc. status, need to track linked CPSE tickets, FV Entry Date -5w risk, long-term unclosed cases.

#### **4. BFM / PR Code / SMT / BIOS Task / SWDM Today Cross-Check**
- **BFM (Platform Feature Matrix)**: `Public Platform Section -> CYxx Platform BIOS Feature Matrix`, confirm feature coverage and gaps.
- **PR Code Healthiness**: Check each PR code readiness, red/yellow light status, pending actions.
- **SMT Build Tracker**: EVT/DVT1/DVT2 task completion, identify undelivered items.
- **BIOS Task boards**: CY26 Intel Task list, check SlatePTL task progress vs Draft_Schedule.
- **SWDM Today**: First confirm if listed in Yellow/Red, if not, go to Issue Manager for deep review.

#### **5. Page Table Field Reference (Common 29 Fields)**
1. **Jira_BIOS**: System/Epic tickets.
2. **BIOS Generation**: NUDD version (ex: 26Q2).
3. **Model Name**: Customer-facing model (SMBIOS / dell.com).
4. **ODM**: Partner vendor (Compal, Wistron...).
5. **LOB**: Line of Business.
6. **SSID / CHID / ERST GUID**: Driver/Windows Update/ESRT identification.
7. **Chipset / TPM / EC / TBT / Type-C / PD / Graphics / Audio / Camera / LAN / WWAN / Dock**: Hardware ingredients.
8. **NUDD links / PCR list / BIOS Status / SW Status / BIOS Codebase / Ingredients / Code Branch**: Architecture baseline and status.
9. **Draft_Schedule / Document tables**: Milestones and attachment index.

#### **6. Reporting Cadence**
1. Confirm project code → check naming rules → lock ODM/CY/NUDD.
2. Extract main Page + include (ISH tables 1~29).
3. Parse Jira System/Epic status; compare Draft Schedule vs Task completion.
4. Sequentially collect BFM, PR Code, SMT, BIOS Task, SWDM, Issue Manager, PIMS.
5. Generate Executive Summary (Sectioned) + Bilingual Summary.

> **Purpose**: Enable any Skill (cpse_debug_analysis, bios-project-reporter, etc.) to call unified knowledge base when performing BIOS project health checks, maintaining naming rules, Page tree processes, and report field standardization.

### **Dell Internal References**
#### **JIRA Integration**
- **CPSE Tickets**: Common Platform Systems Engineering issues
- **PIMS References**: Product Issue Management System links
- **CBDCIT References**: Cross-Build Dependency and Component Integration Tracking

#### **Build Systems**
- **AGS 2025**: Dell BIOS generation system
- **Platform Packages**: Hierarchical structure (DT/NB/PW)
- **Binary Management**: Version-controlled binary repositories

## Knowledge Expansion Framework

### **Extensible Structure**
This skill is designed for continuous expansion with new Dell domain knowledge:

#### **New Knowledge Categories**
```markdown
### **[New Category Name]**
#### **[Subcategory]**
- **Key Concept**: Description
- **Implementation Details**: Technical specifics
- **Common Issues**: Known failure patterns
```

#### **Platform Expansion**
- Add new platform configurations as needed
- Include platform-specific GUID mappings
- Document platform-unique failure patterns

#### **Process Updates**
- Update signing workflow changes
- Add new internal system references
- Document evolving failure patterns

### **Maintenance Guidelines**
1. **Version Control**: Track knowledge updates with timestamps
2. **Cross-Reference**: Link related knowledge areas
3. **Validation**: Ensure technical accuracy with Dell subject matter experts
4. **Classification**: Organize by platform, process, and issue type

## Usage

### Platform Identification
Use the platform identifier tool to analyze Dell platforms:

```powershell
# Analyze single platform DSC file
python scripts/platform_identifier.py --dsc-file "DellPkgs/DellPlatformPkgs/NB/BladePtlOnePkg/DellPlatformPkg.dsc"

# Scan all Dell platforms in workspace
python scripts/platform_identifier.py --scan-dir "."
```

### Platform Analysis Output
The tool provides comprehensive platform information:
- **Platform Type**: NB (Notebook), DT (Desktop), PW (Workstation)
- **Silicon Vendor**: Intel, AMD, Qualcomm, NVIDIA
- **Platform Name**: PantherLake, LunarLake, NovaLake, etc.
- **Architecture**: x86_64, ARM64
- **FSP/AGESA Support**: Intel FSP vs AMD AGESA

### Domain Knowledge Areas
Use this skill when analyzing:
- Dell platform configurations and silicon vendor identification
- FSP vs AGESA platform distinctions
- Platform-specific payload classifications
- Dell signing processes and key management
- Internal system workflows and DACI configurations

### Integration with Other Skills
- **BBU Platform Checker**: Use platform identification for BBU validation
- **Code Review**: Apply Dell-specific coding standards
- **CPSE Debug Analysis**: Understand platform-specific issues

## Usage Integration

### **For CPSE Analysis**
This skill should be referenced by:
- **CPSE_Debug_Analysis**: For domain-specific context
- **Issue Classification**: Understanding Dell-specific failure patterns
- **Solution Generation**: Providing Dell-appropriate fixes
- **ATS Decision Support**: For ATS eligibility and priority recommendations

### **Knowledge Retrieval**
When analyzing CPSE issues:
1. **Identify Platform**: Determine affected Dell platform (Intel vs AMD)
2. **Classify Issue Type**: Match against known failure patterns
3. **Apply Domain Knowledge**: Use Dell-specific insights
4. **Generate Solutions**: Provide Dell-appropriate recommendations
5. **Platform Context**: FSP errors = Intel only; AGESA errors = AMD only
6. **ATS Assessment**: Evaluate ATS eligibility and recommend priority levels
7. **Severity Calculation**: Apply Dell severity calculator for product/customer impact

## Dell Proprietary Notice

This skill contains Dell-proprietary information including:
- Internal system configurations
- Signing process details
- Platform-specific knowledge
- Internal workflow information

**Usage Restrictions**: For Dell internal use only
**Classification**: Dell Confidential
**Distribution**: Restricted to Dell authorized personnel

---

*Last Updated: 2026-02-24*
*Version: 1.3*
*Maintainer: Dell CPSE Team*

### **Update History**
- **2026-02-24 v1.3**: Added DACI Token System & BIOS Attributes knowledge
  - Complete DACI (Direct Access Controller Interface) system documentation
  - BIOS Attributes management and properties system
  - Platform configuration workflow with platcfg2 tool
  - Windows Cloud PC configuration example
  - DACI vs DCSBC migration benefits and security improvements
  - Manufacturing mode (MFG mode) attribute control
  - Factory tools and service menu integration
  - Attribute persistence and validation requirements
- **2026-02-09 v1.2**: Added ATS Approval Process knowledge
  - Complete ATS priority levels mapping (SEV2 → P1/P2, SEV3 → P3/P4/P5)
  - Severity calculator with product/customer impact and likelihood criteria
  - ATS process workflow and decision authority guidelines
  - Common ATS-related failure patterns and timeline conflicts
  - Integration guidelines for ATS decision support in CPSE analysis
- **2026-02-05 v1.1**: Added Intel vs AMD platform architecture distinction
  - Critical rule: AMD platforms do NOT use Intel FSP
  - FSP exclusivity to Intel platforms
  - AGESA as AMD alternative
  - Platform identification guidelines for troubleshooting
