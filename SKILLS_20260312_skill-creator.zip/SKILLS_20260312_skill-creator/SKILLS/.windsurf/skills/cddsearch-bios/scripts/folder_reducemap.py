#!/usr/bin/env python3
import os
import argparse
import json
import sys
from pathlib import Path

# ==========================================
# Config Loading (Hard Fail if missing)
# ==========================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH_1 = os.path.join(SCRIPT_DIR, "layer_config.json")
CONFIG_PATH_2 = os.path.join(os.getcwd(), "layer_config.json")

target_config = None
if os.path.exists(CONFIG_PATH_1):
    target_config = CONFIG_PATH_1
elif os.path.exists(CONFIG_PATH_2):
    target_config = CONFIG_PATH_2

if not target_config:
    print(f"FATAL ERROR: Could not find 'layer_config.json'. Checked paths:\n1. {CONFIG_PATH_1}\n2. {CONFIG_PATH_2}", file=sys.stderr)
    sys.exit(1)

try:
    with open(target_config, 'r', encoding='utf-8') as f:
        LAYER_CONFIG = json.load(f)
except Exception as e:
    print(f"FATAL ERROR: Failed to parse '{target_config}'. Invalid JSON format. Error: {e}", file=sys.stderr)
    sys.exit(1)

GLOBAL_EXCLUDES = [ex.lower().strip() for ex in LAYER_CONFIG.get("GlobalExcludes", [])]
LAYER_GROUPS = LAYER_CONFIG.get("LayerGroups", [])

# ==========================================
# Exact Node Matching Engine
# ==========================================
def path_contains_node(full_path, node_path):
    full_parts = [p for p in full_path.split('/') if p]
    node_parts = [p for p in node_path.split('/') if p]
    if not node_parts: return False
    n = len(node_parts)
    for i in range(len(full_parts) - n + 1):
        if full_parts[i:i+n] == node_parts:
            return True
    return False

def is_ignored(folder_name):
    return folder_name.lower().strip() in GLOBAL_EXCLUDES

def get_common_root(abs_roots):
    if not abs_roots: return ""
    return os.path.commonpath(abs_roots)

def count_total_subdirs(folder_path):
    count = 0
    try:
        for root, dirs, files in os.walk(folder_path):
            dirs[:] = [d for d in dirs if not is_ignored(d)]
            count += len(dirs)
    except Exception:
        pass
    return count

def get_immediate_subdirs(folder_path):
    subdirs = []
    try:
        with os.scandir(folder_path) as it:
            for entry in it:
                if entry.is_dir() and not entry.name.startswith('.') and not is_ignored(entry.name):
                    subdirs.append(entry.path)
    except Exception:
        pass
    return subdirs

def classify_layer(folder_path):
    folder_lower_normalized = folder_path.lower().replace('\\', '/')
    for group in LAYER_GROUPS:
        excludes = [ex.lower().replace('\\', '/').strip() for ex in group.get("Excludes", [])]
        if any(path_contains_node(folder_lower_normalized, ex) for ex in excludes):
            continue 
        includes = [inc.lower().replace('\\', '/').strip() for inc in group.get("Includes", [])]
        if any(path_contains_node(folder_lower_normalized, inc) for inc in includes):
            return group["Name"]
    return "Unknown"

def generate_reduced_map(roots, default_depth):
    
    # ==========================================
    # Step 1. 先從 command 進來...去重 (並且統一大小寫防禦 Windows 雷區)
    # ==========================================
    unique_roots = []
    seen_roots = set()
    for r in roots:
        norm_r = os.path.normpath(r).lower()
        if norm_r not in seen_roots:
            seen_roots.add(norm_r)
            unique_roots.append(r)
            
    abs_roots = [os.path.abspath(r) for r in unique_roots]
    common_root = get_common_root(abs_roots)
    target_roots = abs_roots[1:] if len(abs_roots) > 1 else []
    
    items = []

    # 建立初始 BFS 地圖
    for root_dir in abs_roots:
        if not os.path.isdir(root_dir) or is_ignored(os.path.basename(root_dir)): continue
        try:
            with os.scandir(root_dir) as it:
                for entry in it:
                    if entry.is_file() and not entry.name.startswith('.'):
                        items.append({"folder": entry.path, "type": "file", "depth": 0})
        except Exception: pass

        queue = [(root_dir, 0)]
        while queue:
            current_path, current_depth = queue.pop(0)
            folder_type = "recursive" if current_depth == default_depth else "shallow"
            items.append({"folder": current_path, "type": folder_type, "depth": current_depth})

            if current_depth < default_depth:
                for d in get_immediate_subdirs(current_path):
                    queue.append((d, current_depth + 1))

    items = [i for i in items if not (i["folder"] == common_root and i["type"] != "file")]

    # ==========================================
    # Step 2. 將 folder 層數找出來...全部 recursive 目錄要小於 50
    # ==========================================
    while True:
        dir_items = [i for i in items if i["type"] != "file"]
        if len(dir_items) <= 50:
            break
        max_depth = max((i["depth"] for i in dir_items), default=0)
        if max_depth <= 1:
            break
        items = [i for i in items if i.get("depth", 0) != max_depth or i["type"] == "file"]
        for item in items:
            if item["type"] != "file" and item["depth"] == max_depth - 1:
                item["type"] = "recursive"

    # 防呆機制：將所有沒被設為 file 的目錄，強制統一為 recursive，方便後續穩定判定
    for item in items:
        if item["type"] != "file":
            item["type"] = "recursive"

    # ==========================================
    # Step 3. 一個一個檢驗... recursive 超過 100 個 folder 的就在展開一層
    # ==========================================
    new_items_pass1 = []
    for item in items:
        if item["type"] == "recursive" and count_total_subdirs(item["folder"]) > 100:
            subdirs = get_immediate_subdirs(item["folder"])
            if subdirs:
                new_items_pass1.append({"folder": item["folder"], "type": "file", "depth": item.get("depth", 0)})
                for sub in subdirs:
                    new_items_pass1.append({"folder": sub, "type": "recursive", "depth": item.get("depth", 0) + 1})
            else:
                new_items_pass1.append(item)
        else:
            new_items_pass1.append(item)
    items = new_items_pass1

    # ==========================================
    # Step 4. 展開完後...看最底層的 node，如果是 DellPlatformPkgs / DellRcEdk2ModsPkg 就再展開一層
    # ==========================================
    TARGET_EXTEND = {"dellplatformpkgs", "dellplatformpkg", "dellrcedk2modspkg", "dellrcedk2modspkgs"}
    new_items_pass2 = []
    
    for item in items:
        if item["type"] == "recursive":
            norm_folder = item["folder"].lower().replace('\\', '/')
            path_nodes = [p for p in norm_folder.split('/') if p]
            base_node = path_nodes[-1].strip() if path_nodes else ""
            
            if base_node in TARGET_EXTEND:
                subdirs = get_immediate_subdirs(item["folder"])
                if subdirs:
                    new_items_pass2.append({"folder": item["folder"], "type": "file", "depth": item.get("depth", 0)})
                    for sub in subdirs:
                        new_items_pass2.append({"folder": sub, "type": "recursive", "depth": item.get("depth", 0) + 1})
                else:
                    new_items_pass2.append(item)
            else:
                new_items_pass2.append(item)
        else:
            new_items_pass2.append(item)
    items = new_items_pass2

    # 執行最後的穩定去重 (確保展開的結果不會被前面的舊路徑覆蓋)
    unique_dict = {}
    for item in items:
        n_path = os.path.normpath(item["folder"]).lower()
        if n_path not in unique_dict:
            unique_dict[n_path] = item
        else:
            if unique_dict[n_path]["type"] == "recursive" and item["type"] == "file":
                unique_dict[n_path]["type"] = "file"
    items = list(unique_dict.values())

    # ==========================================
    # Step 5 & 6. Group 完排列 (有 Dell 在前，無 Dell 在後，由深至淺，file 排在 recursive 後面)
    # ==========================================
    grouped_items = {group["Name"]: [] for group in LAYER_GROUPS}
    grouped_items["Unknown"] = []

    def sort_key(item):
        folder_lower = item["folder"].lower().replace('\\', '/')
        path_nodes = [p for p in folder_lower.split('/') if p]
        
        in_target = False
        if target_roots:
            for tr in target_roots:
                if item["folder"].startswith(tr):
                    in_target = True
                    break
        else:
            in_target = True

        has_dell = any('dell' in p for p in path_nodes)
        depth = item.get("depth", 0)
        
        # Step 6 實踐：recursive(1) 大於 file(0)，配合 reverse=True 讓 recursive 排在前面！
        is_recursive = 1 if item["type"] == "recursive" else 0

        # Tuple 比較 (True > False, 數字大 > 數字小)
        return (in_target, has_dell, depth, is_recursive, folder_lower)

    for item in items:
        layer_name = classify_layer(item["folder"])
        grouped_items[layer_name].append({"folder": item["folder"], "type": item["type"]})

    for layer in grouped_items:
        grouped_items[layer].sort(key=sort_key, reverse=True)

    clean_output = {k: v for k, v in grouped_items.items() if v}
    return clean_output

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate a dynamically reduced and layer-grouped folder map.")
    parser.add_argument("--roots", nargs='+', required=True, help="First is codebase root, rest are targets.")
    parser.add_argument("--depth", type=int, default=3, help="Default search depth before pruning.")
    parser.add_argument("--session-id", type=str, help="Session ID (optional)")
    parser.add_argument("--output-dir", type=str, help="Output directory (optional)")
    
    args = parser.parse_args()

    result_map = generate_reduced_map(args.roots, args.depth)

    filename = f"reduce_map_{args.session_id}.json" if args.session_id else "reduce_map.json"

    if args.output_dir:
        target_dir = os.path.abspath(args.output_dir)
        if target_dir.endswith("tmp"):
            save_path = os.path.join(target_dir, filename)
        else:
            save_dir = os.path.join(target_dir, "tmp")
            os.makedirs(save_dir, exist_ok=True)
            save_path = os.path.join(save_dir, filename)
            
        with open(save_path, 'w', encoding='utf-8') as f:
            json.dump(result_map, f, indent=4)
        print(f"Fast layer-grouped map generated at: {save_path}")
    else:
        print(json.dumps(result_map, indent=4))