# 🏗️ CDDSearch State Database - [Target_Name] Analysis

**Session ID:** {SESSION_ID}
**Target:** [Target_Name]
**Status:** Phase 1 - Active Search

---
## 1. CURRENT EXECUTION STATE (OVERWRITE ONLY)
*(CRITICAL: Read-and-burn section. Overwrite this after every search batch. DO NOT KEEP HISTORY!)*
- **Last Searched Keywords:** `[Keywords]`
- **Last Scanned Folders:** `[Folders from reduce_map]`
- **Found New Items:** [Yes/No]

---
## 2. SYMBOLS DISCOVERED (APPEND-ONLY DATABASE)
*(CRITICAL: This is the ONLY source for the final Report. EVERY item MUST have an exact `[Layer]` and `[File_Path]`. If you cannot find the path, DO NOT write it here!)*

### A. Functions & Implementations
- `[FunctionName]()`
  - **Prototype**: `[Full C prototype]`
  - **Implemented In**: `[Layer]` `[File_Path]`
  - **Callers**: 
    - `[CallerFunction]()` in `[Layer]` `[File_Path]`

### B. Macros & PCDs (Hawk-Eye Extractions)
- `[Macro_Name]`
  - **Defined Value**: `[Exact Value]` in `[Layer]` `[File_Path]`
  - **Used By**: `[Function/Struct]` in `[Layer]` `[File_Path]`

### C. Structures
- `[Struct_Name]`
  - **Definition**: `[Layer]` `[File_Path]`
  - **Instances**: `[Instance_Name]` in `[Layer]` `[File_Path]` (Contains Macros: `[Macro1, Macro2]`)

### D. Protocols / PPIs / GUIDs
- `[Guid_Name]`
  - **Installed By**: `[Layer]` `[File_Path]`
  - **Located/Consumed By**: `[ConsumerFunction]()` in `[Layer]` `[File_Path]`

---
## 3. PENDING TASKS (QUEUE)
*(CRITICAL: Double-Entry Bookkeeping. Any new Callers, Macros, or Structs found above MUST be copied here as a pending search task! Must reach 0 before yielding!)*
- [ ] `[Initial_Target]`

---
## 4. ARCHITECTURE ANALYSIS & DEAD-ENDS
*(If PENDING TASKS is 0, but a layer implementation is missing, document it here and explain why)*
- **Missing Implementations**: `[Description of missing layer/variant and your hypothesis why]`
- **Exhausted Dead-Ends**: `[List of keywords that yielded 0 results across the ENTIRE reduce_map]`

---
## 5. COMPLETED TASKS (ANTI-LOOP TRACKER)
*(CRITICAL: To prevent infinite loops, EVERY keyword that has been searched MUST be moved from PENDING TASKS to here. Do NOT search these keywords again!)*
- `[Completed_Keyword_1]`

---
## 6. LOW CONFIDENCE / UNVERIFIED SYMBOLS
*(CRITICAL: If a keyword is found used/called, but its strict definition/typedef CANNOT be located in the current 3-layer scan, put it here. DO NOT guess its origin! You MUST still add it to PENDING_TASKS to retry later.)*
- `[Symbol_Name]`
  - **Used In**: `[Layer]` `[File_Path]` (e.g., Called by `[CallerFunction]`)
  - **Missing**: `[Definition / Typedef / Original Macro]`