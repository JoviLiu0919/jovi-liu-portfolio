# 🗺️ FUNCTION: Generate Folder Map

**Input**: `roots`, `depth` (default 3, optional), `session_id`, `output_dir` (Base root directory ONLY. Do NOT append `/tmp`)

**Action Constraint**: 
Execute `.windsurf/skills/cddsearch-bios/scripts/folder_reducemap.py` exactly with these parameters:
`--roots <Absolute_Workspace_Root> <TargetRoot1> <TargetRoot2>...`
`--depth <number>` (Optional, use if a specific depth is requested)
`--session-id <session_id>`
`--output-dir <output_dir>`

🛑 **ROOTS PARAMETER CRITICAL RULE**:
The first argument to `--roots` MUST be the absolute path to the entire codebase workspace (e.g., `/workspace` or the highest level folder containing all EDK2 packages). It CANNOT be just a target folder. The target folders (e.g., specific Dell features) must be passed as the 2nd, 3rd parameters, etc.

**CRITICAL WARNING ON PATHS**: 
The python script automatically appends `/tmp` internally to the `output_dir`. If you manually pass a path ending in `/tmp` to the command, it will create a broken `/tmp/tmp` structure. Pass the base root strictly! Verify `reduce_map_{SESSION_ID}.json` is created inside the proper `{first_root_abs}/tmp/` directory.