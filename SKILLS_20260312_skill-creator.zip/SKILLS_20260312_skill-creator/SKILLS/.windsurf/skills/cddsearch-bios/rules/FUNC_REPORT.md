# 📊 FUNCTION: Generate Architecture Report

**Input**: `session_ids`, `output_dir`

**Action Steps**: 
1. **[MANDATORY DB READ]**: Execute `read_file` to load `tmp/architecture_ledger_{SESSION_ID}.md`.
2. 🛑 **[TRACEABILITY MANDATE (NO HALLUCINATION)]**: 
   - The Report you generate is merely a "Read-Only View" of the Ledger.
   - EVERY Function, Macro, Struct, and Protocol in the Report MUST have its `[Layer]` and `[File_Path]` **100% copy-pasted from the `SYMBOLS DISCOVERED` section of the Ledger**.
   - **Zero Fabrication:** If a component lacks a File Path in the Ledger, DO NOT guess or hallucinate. You MUST explicitly output `[Path_Unknown]` and list it under the `TECHNICAL DEBT & DEAD-ENDS` section.
3. **[RENDER VIEW]**: Map the data accurately from the Ledger into the format defined in `rules/REPORT_TEMPLATE.md`.
4. **[OUTPUT]**: Use `edit_file` to generate `{output_dir}/tmp/architecture_final_report_{SESSION_ID}.md`.