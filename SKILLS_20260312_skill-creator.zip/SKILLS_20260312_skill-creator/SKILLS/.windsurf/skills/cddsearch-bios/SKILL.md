---
name: cddsearch-bios
description: BIOS architectural search Workflow Orchestrator. Enforces strict unified tmp paths, anti-root cheating, cross-layer extraction, and locked reporting.

trigger_keywords:
  - "/cddsearch-bios"
  - "cddsearch-bios"
  - "/cddsearch"
  - "cddsearch"
  - "/CDDSearch"
  - "CDDSearch"
auto_launch: true
---

# 🎯 CDDSearch State Machine (Orchestrator)

## Phase 0: INIT & PATH ALIGNMENT
1. **SESSION_ID**: Generate `YYYYMMDD_HHMMSS`. Use for all filenames.
2. **DEFINE WORKSPACE_TMP**: Let `<Codebase_Root>` be the absolute path of the target BIOS codebase. 
   - `WORKSPACE_TMP` MUST be exactly `<Codebase_Root>/tmp/`.
   - **ALL** generated files MUST be saved inside `WORKSPACE_TMP`.
3. **Execute Map Gen**: Run `scripts/folder_reducemap.py` EXACTLY with arguments:
   - `--roots <Codebase_Root> <TargetRoot1>...`
   - 🛑 **TARGET LOCK MANDATE**: You MUST ONLY pass the actual BIOS codebase directory. You are **STRICTLY FORBIDDEN** from passing the `Windsurf` or rule directory into the `--roots` argument.
   - `--session-id {SESSION_ID}`
   - `--output-dir <Codebase_Root>` (The script handles `/tmp` internally).
4. **Load Kernel**: `read_file: rules/CORE_DIRECTIVES.md`, `read_file: rules/LEDGER_TEMPLATE.md`. 

## Phase 1 & 2: CORE LOOP
1. **Engage Kernel**: Execute the declarative instructions exactly as defined in `CORE_DIRECTIVES.md`.
2. **🛑 THE HARD STOP BARRIER (STATE MACHINE LOCK)**:
   - When `PENDING_TASKS` reaches 0, you MUST physically HALT all tool executions.
   - You are **STRICTLY FORBIDDEN** from moving to Phase 3 or reading `FUNC_REPORT.md`.
   - Announce: "Tasks exhausted. Awaiting command: Provide new keywords, type `proceed report`, or `terminate`."
   - **WAIT FOR USER INPUT.** Do not proceed unless the exact override keywords are provided.

## Phase 3: REPORT (LOCKED)
*(⚠️ DO NOT EXECUTE THIS PHASE UNTIL THE USER EXPLICITLY REPLIES "Proceed" or "Generate Report".)*
1. `read_file: rules/FUNC_REPORT.md`.
2. Generate `{WORKSPACE_TMP}/architecture_final_report_{SESSION_ID}.md` based STRICTLY on the `SYMBOLS DISCOVERED` database.