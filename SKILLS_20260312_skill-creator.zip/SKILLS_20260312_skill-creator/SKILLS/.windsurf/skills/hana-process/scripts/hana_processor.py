#!/usr/bin/env python3
"""
Hana Process Tool
Specialized tool for processing TBABP1 (Hana) tickets
"""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
import subprocess
import os
import io
from atlassian import Jira
try:
    import tomllib
except ImportError:
    import tomli as tomllib

# Add config loader path - search for config_loader.py in parent directories
def find_config_loader():
    """Search for config_loader.py in parent directories"""
    current_dir = Path(__file__).parent
    while current_dir != current_dir.parent:  # Stop at root
        config_loader_path = current_dir / "config_loader.py"
        if config_loader_path.exists():
            return current_dir, config_loader_path
        current_dir = current_dir.parent
    
    # If not found, try one more level up
    config_loader_path = current_dir / "config_loader.py"
    if config_loader_path.exists():
        return current_dir, config_loader_path
    
    return None, None

skills_root, config_loader_path = find_config_loader()
if skills_root and config_loader_path:
    sys.path.append(str(skills_root))
    try:
        from config_loader import load_skill_config_with_central_fallback
    except ImportError:
        print("Error: Cannot import config_loader, please check path setting")
        print(f"Skills root: {skills_root}")
        print(f"Config loader path: {config_loader_path}")
        print(f"Config loader exists: {config_loader_path.exists()}")
        sys.exit(1)
else:
    print("Error: Cannot find config_loader.py")
    print(f"Current script path: {__file__}")
    sys.exit(1)

# Force UTF-8 encoding for stdout/stderr
if sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except AttributeError:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

if sys.stderr.encoding.lower() != 'utf-8':
    try:
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

def load_config():
    """Load configuration file, using central config as fallback"""
    config_path = Path(__file__).parent.parent / "config.toml"
    try:
        config = load_skill_config_with_central_fallback(config_path)
        if not config:
            print(f"❌ Configuration file not found and unable to load central config: {config_path}")
            sys.exit(1)
        return config
    except Exception as e:
        print(f"❌ Failed to read configuration file: {e}")
        sys.exit(1)

# Load configuration
config = load_config()

class HanaJiraIntegration:
    """Fully standalone Jira integration class"""
    
    def __init__(self):
        self.jira_url = config["jira"]["url"]
        self.jira_token = config["jira"]["token"]
        self.default_assignee = config["jira"].get("default_assignee", "ProcessBiosNVMB")
        # Safely get options configuration, use default values if not exist
        options = config.get("options", {})
        self.debug = options.get("debug", False)
        self.comment_length_limit = options.get("comment_length_limit", 200)
        self.jira = None
        self._connect()
    
    def _connect(self):
        """Establish Jira connection"""
        try:
            if self.debug:
                print(f"DEBUG: Connecting to {self.jira_url}")
            self.jira = Jira(
                url=self.jira_url,
                token=self.jira_token
            )
            if self.debug:
                print("DEBUG: Jira connection successful")
        except Exception as e:
            print(f"❌ Jira connection failed: {e}")
            return False
        return True
    
    def get_ticket(self, ticket_key: str) -> Dict[str, Any]:
        """Get ticket information"""
        try:
            if not self.jira:
                return {"error": "Jira connection not established"}
            
            ticket = self.jira.issue(ticket_key)
            return {"success": True, "ticket": ticket}
        except Exception as e:
            return {"error": f"Failed to get ticket: {str(e)}"}
    
    def get_comments(self, ticket_key: str) -> Dict[str, Any]:
        """Get ticket comments"""
        try:
            if not self.jira:
                return {"error": "Jira connection not established"}
            
            # Use correct API method
            comments = self.jira.issue(ticket_key, fields='comment').get('fields', {}).get('comment', {}).get('comments', [])
            return {"success": True, "comments": {"comments": comments}}
        except Exception as e:
            return {"error": f"Failed to get comments: {str(e)}"}
    
    def add_comment(self, ticket_key: str, body: str) -> Dict[str, Any]:
        """Add comment"""
        try:
            if not self.jira:
                return {"error": "Jira connection not established"}
            
            self.jira.issue_add_comment(ticket_key, body)
            return {"success": True, "message": "Comment added successfully"}
        except Exception as e:
            return {"error": f"Failed to add comment: {str(e)}"}
    
    def assign_ticket(self, ticket_key: str, assignee: str) -> Dict[str, Any]:
        """Assign ticket"""
        try:
            if not self.jira:
                return {"error": "Jira connection not established"}
            
            # Send string directly, consistent with jira_tool.py
            self.jira.assign_issue(ticket_key, assignee)
            return {"success": True, "message": f"Ticket assigned to {assignee}"}
        except Exception as e:
            return {"error": f"Failed to assign ticket: {str(e)}"}
    
    def search_tickets(self, jql: str, limit: int = 50) -> Dict[str, Any]:
        """Search tickets"""
        try:
            if not self.jira:
                return {"error": "Jira connection not established"}
            
            # Use correct Jira API method
            issues = self.jira.jql(jql, limit=limit).get('issues', [])
            return {"success": True, "issues": issues}
        except Exception as e:
            return {"error": f"Failed to search tickets: {str(e)}"}

# Global Jira integration instance
jira_integration = HanaJiraIntegration()

def run_jira_command(args: List[str]) -> Dict[str, Any]:
    """Execute Jira command and return results (completely standalone implementation)"""
    try:
        if not args:
            return {"error": "No command parameters provided"}
        
        command = args[0]
        
        if command == "get":
            if len(args) < 3 or args[1] != "--key":
                return {"error": "get command requires --key parameter"}
            ticket_key = args[2]
            return jira_integration.get_ticket(ticket_key)
        
        elif command == "get-comments":
            if len(args) < 3 or args[1] != "--key":
                return {"error": "get-comments command requires --key parameter"}
            ticket_key = args[2]
            return jira_integration.get_comments(ticket_key)
        
        elif command == "comment":
            if len(args) < 5 or args[1] != "--key" or args[3] != "--body":
                return {"error": "comment command requires --key and --body parameters"}
            ticket_key = args[2]
            body = args[4]
            return jira_integration.add_comment(ticket_key, body)
        
        elif command == "assign":
            if len(args) < 5 or args[1] != "--key" or args[3] != "--user":
                return {"error": "assign command requires --key and --user parameters"}
            ticket_key = args[2]
            user = args[4]
            return jira_integration.assign_ticket(ticket_key, user)
        
        elif command == "search":
            if len(args) < 3 or args[1] != "--jql":
                return {"error": "search command requires --jql parameter"}
            jql = " ".join(args[2:])
            limit = 50
            if "--limit" in args:
                limit_idx = args.index("--limit")
                if limit_idx + 1 < len(args):
                    limit = int(args[limit_idx + 1])
            return jira_integration.search_tickets(jql, limit)
        
        else:
            return {"error": f"Unsupported command: {command}"}
            
    except Exception as e:
        return {"error": f"Command execution failed: {str(e)}"}

def get_last_comment_from_user(ticket_key: str, username: str) -> Dict[str, Any]:
    """Get the last comment from specified user"""
    try:
        # Get all comments
        comments_result = run_jira_command(["get-comments", "--key", ticket_key])
        
        if "error" in comments_result:
            return {"error": f"Failed to get comments: {comments_result['error']}"}
        
        # Parse JSON format comments
        comments = comments_result.get("comments", {}).get("comments", [])
        user_comments = []
        
        for comment in comments:
            author = comment.get("author", {}).get("displayName", "")
            created = comment.get("created", "")
            body = comment.get("body", "")
            
            # Check if it is the target user
            if username.lower() in author.lower():
                user_comments.append({
                    "author": author,
                    "created": created,
                    "body": body
                })
        
        if not user_comments:
            return {"found": False, "message": f"No comments found from {username}"}
        
        # Sort by time, take the latest
        user_comments.sort(key=lambda x: x.get("created", ""), reverse=True)
        last_comment = user_comments[0]
        
        return {
            "found": True,
            "author": last_comment["author"],
            "created": last_comment["created"],
            "body": last_comment["body"]
        }
        
    except Exception as e:
        return {"error": f"Error processing comments: {str(e)}"}

def check_tbabp1_ticket(ticket_key: str) -> Dict[str, Any]:
    """Check single TBABP1 ticket"""
    if not ticket_key.startswith("TBABP1-"):
        return {"error": f"Invalid ticket format: {ticket_key}. Must start with TBABP1-"}
    
    # Get ticket information
    ticket_result = run_jira_command(["get", "--key", ticket_key])
    
    if "error" in ticket_result:
        return {"error": f"Failed to get ticket: {ticket_result['error']}"}
    
    # Parse ticket information and check required fields
    ticket = ticket_result.get("ticket", {})
    fields = ticket.get("fields", {})
    
    # Generate check result output
    output = f"{ticket_key} CheckResult\n"
    output += "=" * 50 + "\n"
    output += f"Ticket Link: https://jira.cpg.dell.com/browse/{ticket_key}\n"
    output += f"Summary: {fields.get('summary', 'N/A')}\n"
    output += f"Status: {fields.get('status', {}).get('name', 'N/A')}\n"
    output += f"Assignee: {fields.get('assignee', {}).get('displayName', 'None')}\n"
    output += f"Priority: {fields.get('priority', {}).get('name', 'N/A')}\n"
    output += f"Reporter: {fields.get('reporter', {}).get('displayName', 'N/A')}\n"
    output += f"Created: {fields.get('created', 'N/A')[:10]}\n"
    output += f"Updated: {fields.get('updated', 'N/A')[:10]}\n"
    output += "\nRequired field check:\n\n"
    
    # Parse BIOS Information and SSID from description
    description = fields.get('description', '')
    bios_version = 'Not Found'
    bios_source = 'Not Found'
    ssid_from_desc = 'Not Found'
    
    if description:
        for line in description.split('\n'):
            if 'BIOS_Version=' in line:
                bios_version = line.split('BIOS_Version=')[1].strip()
            elif 'BIOS_Source=' in line:
                bios_source = line.split('BIOS_Source=')[1].strip()
            elif 'SSID=' in line:
                ssid_from_desc = line.split('SSID=')[1].strip()
    
    # Use description in SSID, if not then use customfield
    ssid = ssid_from_desc if ssid_from_desc != 'Not Found' else str(fields.get('customfield_27700', {}).get('value', 'Not Found'))
    
    # Epic Link Check
    epic_link_raw = fields.get('customfield_12300')
    if epic_link_raw:
        epic_link = str(epic_link_raw)
    else:
        epic_link = 'Not Found'
    
    all_passed = True
    
    if ssid != 'Not Found' and ssid.strip() != '':
        output += f"SSID: {ssid} ✅\n"
        # If is from description parse SSID, display source
        if ssid_from_desc != 'Not Found' and ssid_from_desc.strip() != '':
            output += f"  └─ Source: Description (SSID={ssid_from_desc})\n"
        else:
            # Display customfield complete content
            ssid_field = fields.get('customfield_27700', {})
            if isinstance(ssid_field, dict):
                output += f"  └─ Source: CustomField\n"
                output += f"  └─ ID: {ssid_field.get('id', 'N/A')}\n"
                output += f"  └─ Value: {ssid_field.get('value', 'N/A')}\n"
    else:
        output += f"SSID: Not Found ❌\n"
        all_passed = False
    
    if bios_version != 'Not Found' and bios_version.strip() != '':
        output += f"BIOS_Version: {bios_version} ✅\n"
    else:
        output += f"BIOS_Version: Not Found ❌\n"
        all_passed = False
    
    if bios_source != 'Not Found' and bios_source.strip() != '':
        output += f"BIOS_Source: {bios_source} ✅\n"
    else:
        output += f"BIOS_Source: Not Found ❌\n"
        all_passed = False
    
    if epic_link != 'Not Found':
        output += f"Epic Link: {epic_link} ✅\n"
    else:
        output += f"Epic Link: Not Found ❌\n"
        all_passed = False
    
    output += "\n"
    
    if all_passed:
        output += "✅ PASSED - All required fields are correctly filled\n\n"
        output += f"This TBABP1 ticket meets all specification requirements, can continue handling.\n"
    else:
        output += "❌ FAILED - Missing required fields, please supplement and check again\n"
    
    # Get ProcessBiosNVMB last comment
    comment_result = get_last_comment_from_user(ticket_key, "ProcessBiosNVMB")
    
    if comment_result.get("found"):
        output += f"\nProcessBiosNVMB last comment:\n"
        output += f"Author: {comment_result['author']}\n"
        output += f"Time: {comment_result['created'][:19].replace('T', ' ')}\n"
        body = comment_result['body']
        limit = jira_integration.comment_length_limit
        output += f"Content: {body[:limit]}{'...' if len(body) > limit else ''}\n"
    elif comment_result.get("error"):
        output += f"\n⚠️ Cannot get ProcessBiosNVMB comment: {comment_result['error']}\n"
    else:
        output += f"\nℹ️ ProcessBiosNVMB has not left a comment on this ticket yet\n"
    
    return {"success": True, "output": output}

def batch_check_tickets(tickets: str) -> Dict[str, Any]:
    """Batch check multiple tickets"""
    ticket_list = [t.strip() for t in tickets.split(",") if t.strip()]
    results = []
    
    for ticket in ticket_list:
        print(f"Check {ticket}...")
        result = check_tbabp1_ticket(ticket)
        results.append({
            "ticket": ticket,
            "result": result
        })
    
    # Generate report
    return generate_batch_report(results)

def search_tbabp1_tickets(assignee: Optional[str] = None, status: Optional[str] = None, 
                         created_after: Optional[str] = None, limit: int = 20) -> Dict[str, Any]:
    """Search TBABP1 tickets"""
    jql_parts = ["project = TBABP1"]
    
    if assignee:
        jql_parts.append(f"assignee = '{assignee}'")
    
    if status:
        jql_parts.append(f"status = '{status}'")
    
    if created_after:
        jql_parts.append(f"created >= '{created_after}'")
    
    jql = " AND ".join(jql_parts)
    
    result = jira_integration.search_tickets(jql, limit)
    return result

def generate_batch_report(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Generate batch check report"""
    report_content = f"""# Hana Batch Check Report

**Check time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Check ticket quantity:** {len(results)}

## Check result summary

"""
    
    passed_count = 0
    failed_count = 0
    
    for item in results:
        ticket = item["ticket"]
        result = item["result"]
        
        if "error" in result:
            status = "❌ FAILED"
            failed_count += 1
            details = f"Bug: {result['error']}"
        else:
            # Parse success result
            if "✅ PASSED" in result["output"]:
                status = "✅ PASSED"
                passed_count += 1
            else:
                status = "❌ FAILED"
                failed_count += 1
            details = result["output"][:200] + "..." if len(result["output"]) > 200 else result["output"]
        
        report_content += f"### {ticket} - {status}\n"
        report_content += f"{details}\n\n"
    
    report_content += f"""## summarize

- ✅ passed: {passed_count}
- ❌ Failed: {failed_count}
- 📊 Total: {len(results)}

---
*Report generated by Hana Process Skill automatically*
"""
    
    # Save report
    try:
        reports_dir = Path(__file__).parent.parent.parent.parent / "Reports"
        reports_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        filename = f"Hana_batch_check_{timestamp}.md"
        filepath = reports_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        return {
            "success": True,
            "summary": f"Batch check complete: {passed_count} passed, {failed_count} failed",
            "report_file": str(filepath),
            "details": report_content
        }
    except Exception as e:
        return {"error": f"Failed to save report: {str(e)}"}

    """Batch build multiple tickets"""
    ticket_list = [t.strip() for t in tickets.split(",") if t.strip()]
    results = []
    
    print(f"🔍 Start batch build process, total {len(ticket_list)} tickets...")
    print("=" * 60)
    
    for i, ticket in enumerate(ticket_list, 1):
        print(f"\n📋 Handle the {i}/{len(ticket_list)} ticket: {ticket}")
        print("-" * 40)
        
        # Execute single ticket build
        result = build_tbabp1_ticket(ticket)
        results.append({
            "ticket": ticket,
            "result": result
        })
        
        # Display result summary
        if "error" in result:
            print(f"❌ {ticket}: {result['error']}")
        else:
            print(f"✅ {ticket}: Build complete")
    
    # Generate batch report
    return generate_batch_build_report(results)

def generate_batch_build_report(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Generate batch build report"""
    report_content = f"""# Hana Batch Build Report

**Build time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Build ticket quantity:** {len(results)}

## Build result summary

"""
    
    success_count = 0
    failed_count = 0
    
    for item in results:
        ticket = item["ticket"]
        result = item["result"]
        
        if "error" in result:
            status = "❌ FAILED"
            failed_count += 1
            details = f"Bug: {result['error']}"
        else:
            status = "✅ SUCCESS"
            success_count += 1
            details = f"Build process complete"
        
        report_content += f"### {ticket} - {status}\n"
        report_content += f"{details}\n\n"
    
    report_content += f"""## summarize

- ✅ Successful builds: {success_count}
- ❌ Failed builds: {failed_count}
- 📊 Total tickets: {len(results)}

---
*Report generated by Hana Process Skill automatically*
"""
    
    # Save report
    try:
        reports_dir = Path(__file__).parent.parent.parent.parent / "Reports"
        reports_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        filename = f"Hana_batch_build_{timestamp}.md"
        filepath = reports_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        return {
            "success": True,
            "summary": f"Batch build complete: {success_count} Success, {failed_count} Failed",
            "report_file": str(filepath),
            "details": report_content
        }
    except Exception as e:
        return {"error": f"Failed to save report: {str(e)}"}

def build_tbabp1_ticket(ticket_key: str) -> Dict[str, Any]:
    """Build TBABP1 ticket: check status, approve, assign to ProcessBiosNVMB"""
    if not ticket_key.startswith("TBABP1-"):
        return {"error": f"Invalid ticket format: {ticket_key}. Must start with TBABP1-"}
    
    print(f"🔍 Start build process for {ticket_key}...")
    
    # 1. Check ticket status
    print("📋 Step 1: Check ticket status...")
    check_result = check_tbabp1_ticket(ticket_key)
    
    if "error" in check_result:
        return {"error": f"Ticket check failed: {check_result['error']}"}
    
    # Check if passed verify
    if "❌ FAILED" in check_result["output"] or "FAILED" in check_result["output"]:
        return {"error": f"Ticket did not pass required field check, cannot perform build operation\n{check_result['output']}"}
    
    print("✅ Ticket status check passed")
    
    # 2. Add Approved comment
    print("📝 Step 2: Add approved comment...")
    comment_result = jira_integration.add_comment(ticket_key, "Approved")
    
    if "error" in comment_result:
        return {"error": f"Add comment failed: {comment_result['error']}"}
    
    print("✅ Approved comment already added")
    
    # 3. Assign to ProcessBiosNVMB
    print("👤 Step 3: Assign to ProcessBiosNVMB...")
    assign_result = jira_integration.assign_ticket(ticket_key, "ProcessBiosNVMB")
    
    if "error" in assign_result:
        print(f"⚠️ Assignment failed: {assign_result['error']}")
        print("📝 Build process partial complete, but assignment failed")
        return {
            "success": True,
            "message": f"⚠️ Build process partial complete for {ticket_key} (Assignment failed)",
            "details": {
                "ticket": ticket_key,
                "status_check": "✅ passed",
                "comment": "✅ Approved already added",
                "assignment": f"❌ Assignment failed: {assign_result['error']}"
            }
        }
    
    print("✅ Already assigned to ProcessBiosNVMB")
    
    return {
        "success": True,
        "message": f"✅ Build process complete for {ticket_key}",
        "details": {
            "ticket": ticket_key,
            "status_check": "✅ passed",
            "comment": "✅ Approved already added",
            "assignment": "✅ Already assigned to ProcessBiosNVMB"
        }
    }

def main():
    parser = argparse.ArgumentParser(description="Hana Process Tool for TBABP1 tickets")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Check command
    check_parser = subparsers.add_parser("check", help="Check single TBABP1 ticket")
    check_parser.add_argument("--ticket", required=True, help="Ticket key (e.g., TBABP1-74418)")
    
    # Batch check command
    batch_parser = subparsers.add_parser("batch-check", help="Check multiple TBABP1 tickets")
    batch_parser.add_argument("--tickets", required=True, help="Comma-separated ticket keys")
    
    # Search command
    search_parser = subparsers.add_parser("search", help="Search TBABP1 tickets")
    search_parser.add_argument("--assignee", help="Filter by assignee")
    search_parser.add_argument("--status", help="Filter by status")
    search_parser.add_argument("--created-after", help="Filter by creation date (YYYY-MM-DD)")
    search_parser.add_argument("--limit", type=int, default=20, help="Limit results (default: 20)")
    
    # Build command
    build_parser = subparsers.add_parser("build", help="Build TBABP1 ticket: check, approve, and assign to ProcessBiosNVMB")
    build_parser.add_argument("--ticket", required=True, help="Ticket key (e.g., TBABP1-74418)")
    
    # Batch build command
    batch_build_parser = subparsers.add_parser("batch-build", help="Batch build multiple TBABP1 tickets")
    batch_build_parser.add_argument("--tickets", required=True, help="Comma-separated ticket keys")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    if args.command == "check":
        result = check_tbabp1_ticket(args.ticket)
        if "error" in result:
            print(f"❌ Bug: {result['error']}", file=sys.stderr)
            sys.exit(1)
        else:
            print(result["output"])
    
    elif args.command == "batch-check":
        result = batch_check_tickets(args.tickets)
        if "error" in result:
            print(f"❌ Bug: {result['error']}", file=sys.stderr)
            sys.exit(1)
        else:
            print(result["summary"])
            print(f"📄 Report saved: {result['report_file']}")
    
    elif args.command == "search":
        result = search_tbabp1_tickets(
            assignee=args.assignee,
            status=args.status, 
            created_after=args.created_after,
            limit=args.limit
        )
        if "error" in result:
            print(f"❌ Bug: {result['error']}", file=sys.stderr)
            sys.exit(1)
        else:
            issues = result.get("issues", [])
            print(f"🔍 Found {len(issues)} tickets:")
            print()
            for issue in issues:
                fields = issue.get("fields", {})
                key = issue.get("key", "N/A")
                summary = fields.get("summary", "N/A")
                status = fields.get("status", {}).get("name", "N/A")
                assignee = fields.get("assignee", {}).get("displayName", "Unassigned")
                print(f"📋 {key}: {summary}")
                print(f"   Status: {status} | Assigned to: {assignee}")
                print()
    
    elif args.command == "build":
        result = build_tbabp1_ticket(args.ticket)
        if "error" in result:
            print(f"❌ Bug: {result['error']}", file=sys.stderr)
            sys.exit(1)
        else:
            print(result["message"])
            if "details" in result:
                print("\n📋 Detailed Result:")
                for key, value in result["details"].items():
                    print(f"  {key}: {value}")
    
    elif args.command == "batch-build":
        result = batch_build_tickets(args.tickets)
        if "error" in result:
            print(f"❌ Bug: {result['error']}", file=sys.stderr)
            sys.exit(1)
        else:
            print(result["summary"])
            print(f"📄 Report saved: {result['report_file']}")

if __name__ == "__main__":
    main()
