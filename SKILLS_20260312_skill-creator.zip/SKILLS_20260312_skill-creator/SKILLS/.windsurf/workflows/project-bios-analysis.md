---
name: project-bios-analysis
description: Comprehensive BIOS project analysis skill for analyzing BIOS project structure, dependencies, metrics, and generating detailed reports. Use when analyzing BIOS project health, code quality, or generating BIOS project documentation.
---

# BIOS Project Analysis Skill

Start here to perform comprehensive project analysis. This skill integrates with Confluence and JIRA to fetch project information and analyze project data.

### Project Discovery
```powershell
# Method 1: NPI Platform Information Lookup (Primary Method for New Projects)
# Search NPI Platform Information page for project references
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py grep-page --id 311322473 --pattern "PROJECT_NAME"

# If found in NPI page, get the main project page
python scripts/confluence_tool.py cql-search --query "title='PROJECT_NAME' AND space=CSEI" --limit 5

# Method 2: Sustaining Platform Information Lookup (For Sustaining Projects)
# Search Sustaining Platform Information page for sustaining project references
python scripts/confluence_tool.py grep-page --id 313693926 --pattern "PROJECT_NAME"

# If found in Sustaining page, get the main project page
python scripts/confluence_tool.py cql-search --query "title='PROJECT_NAME' AND space=CSEI" --limit 5

# Method 3: Direct CQL Search (Alternative Method)
# Search for project pages across all spaces
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME'" --limit 20

# Method 4: Issue Manager Search (Find BIOS/EC Issue Manager page only)
# Find BIOS/EC Issue Manager pages specifically
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME' AND title~'Issue Manager - BIOS/EC'" --limit 10

# Verify page content before analysis
python scripts/confluence_tool.py get --id [PAGE_ID] | Select-String "Overall BIOS issue status"
```

## Key Features

### Overall BIOS issue status Analysis
- **Precise JQL Extraction**: Extracts JQL from Overall BIOS issue status tables
- **Order-Based Matching**: Uses sequential query mapping for accurate data assignment
- **Automatic Column Mapping**: Handles Sev-1/2/3 × Total/Closed/Submitted/Analyze/Wait/Review/Verify
- **Issue Count Calculation**: Uses JIRA skill for accurate counting
- **UI Classification Support**: Processes Analyze UI-1/UI-2/UI-3 breakdowns
- **ATS Status Handling**: Correctly identifies exclusion logic for Post-RTS/ATS-P1-5/EB/WAD
- **FV Entry Compliance Assessment**: Zero open issues requirement evaluation
- **Chopsticks Threshold Analysis**: Compares Submitted + Analyze against Red/Yellow thresholds
- **Health Status Assessment**: GREEN/YELLOW/RED status determination with action recommendations
- **NUDD Compliance Verification**: Validates PBA tickets against Feature Complete milestone
- **Architecture Document Tracking**: Monitors New Unit Development Document completion status
- **Comprehensive Reporting**: Generates timestamped analysis reports in .windsurf/Reports

### Intelligent Page Discovery
- **NPI Platform Information Lookup**: Primary method for new projects using centralized platform database (ID: 311322473)
- **Sustaining Platform Information Lookup**: Dedicated method for sustaining projects using sustaining database (ID: 313693926)
- **Cross-Space Search**: Uses CQL search across all Confluence spaces as backup method
- **Automatic Page Identification**: Finds main project and Issue Manager pages with smart filtering
- **Smart Prioritization**: Prioritizes BIOS/EC Issue Manager pages for BIOS-specific analysis
- **Content Filtering**: Excludes SW List, Preferences, and other sub-pages
- **Naming Convention Support**: Handles various project naming formats
- **Platform ID Mapping**: Links NPI and Sustaining platform entries to Confluence project pages
- **Project Type Detection**: Automatically distinguishes between NPI and Sustaining projects

### Comprehensive Reporting
- **Real-time Progress**: Shows extraction and execution progress
- **Statistical Reports**: Detailed breakdowns by severity and status
- **JSON Output**: Complete results with metadata
- **Compliance Evaluation**: Risk assessment and recommendations

### Project Discovery Examples
```powershell
# Step 0: Create Reports directory for analysis output
if (-not (Test-Path ".windsurf/Reports")) {
    New-Item -ItemType Directory -Path ".windsurf/Reports" -Force
    Write-Host "Created Reports directory: .windsurf/Reports" -ForegroundColor Green
}

# Example 1: Finding Citadel NVL using NPI Platform Information (New Projects)
cd .windsurf/skills/confluence-integration
# Step 1: Search NPI Platform Information page for Citadel NVL
python scripts/confluence_tool.py grep-page --id 311322473 --pattern "Citadel NVL"

# Step 2: Get the main project page using exact title match
python scripts/confluence_tool.py cql-search --query "title='CITADEL NVL' AND space=CSEI" --limit 5

# Step 3: Find the BIOS/EC Issue Manager page specifically
python scripts/confluence_tool.py cql-search --query "title~'Citadel NVL Issue Manager - BIOS/EC'" --limit 5

# Step 4: Run project analysis using the found Issue Manager page ID
cd .windsurf/skills/project-analysis
python scripts/extract_platform_jql_counts.py --page-id 1130469636

# Step 5: Perform Chopsticks threshold analysis
cd .windsurf/skills/confluence-integration
# IMPORTANT: Chopsticks thresholds are in MAIN Issue Manager page, NOT BIOS/EC sub-page
# Use the main Issue Manager page ID (e.g., 1043248863 for BLADE PTL 14)
python scripts/confluence_tool.py grep-page --id [MAIN_ISSUE_MANAGER_ID] --pattern "Chopsticks Target Checking Issue Count|BIOS_Chopsticks_Red|BIOS_Chopsticks_Yellow"

# Alternative: Search for main Issue Manager page if not known
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME Issue Manager' AND title!~'BIOS/EC' AND title!~'SW/Driver/App'" --limit 5

# Step 6: Calculate Submitted + Analyze total and compare with thresholds
# Use the results from Step 4 to calculate: Submitted + Analyze UI-1 + Analyze UI-2 + Analyze UI-3

# Step 7: Perform NUDD compliance check
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py cql-search --query "title~'Citadel NVL NUDD Summary'" --limit 5

# Step 8: Check NUDD Progress and extract PBA tickets
python scripts/confluence_tool.py grep-page --id [NUDD_SUMMARY_ID] --pattern "NUDD Progress|100.0%"
python scripts/confluence_tool.py cql-search --query "title~'Citadel NVL NUDD Status'" --limit 5

# Step 9: Verify PBA compliance with Feature Complete milestone
python scripts/confluence_tool.py grep-page --id [NUDD_STATUS_ID] --pattern "PBA-[0-9]+|202[0-9]/[0-9]{2}/[0-9]{2}"

# Step 10: Enhanced CPSE System Ticket Search
cd .windsurf/skills/jira-integration
# Strategy 1: Multiple naming patterns
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND (summary ~ 'PROJECT_NAME%BIOS' OR summary ~ 'PROJECT_NAME_BIOS' OR summary ~ 'PROJECT_NAME%BIOS' OR summary ~ 'PROJECT_NAME')"

# Strategy 2: Keyword combination search
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND (summary ~ 'KEYWORD1' AND summary ~ 'KEYWORD2' AND summary ~ 'KEYWORD3')"

# Strategy 3: Fuzzy matching with post-processing
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND summary ~ 'PROJECT_NAME'" | Select-String -Pattern "summary|description"

# Step 11: Extract BIOS status from CPSE ticket description
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND summary ~ 'PROJECT_NAME'" | Select-String -Pattern "description" -Context 0,50

# Example 2: Finding Citadel GNR using Sustaining Platform Information (Sustaining Projects)
cd .windsurf/skills/confluence-integration
# Step 1: Search Sustaining Platform Information page for Citadel GNR
python scripts/confluence_tool.py grep-page --id 313693926 --pattern "Citadel GNR"

# Step 2: Get the main project page using exact title match
python scripts/confluence_tool.py cql-search --query "title='CITADEL GNR' AND space=CSEI" --limit 5

# Step 3: Find the BIOS/EC Issue Manager page specifically
python scripts/confluence_tool.py cql-search --query "title~'Citadel GNR Issue Manager - BIOS/EC'" --limit 5

# Step 4: Run project analysis using the found Issue Manager page ID
cd .windsurf/skills/project-analysis
python scripts/extract_platform_jql_counts.py --page-id [FOUND_ISSUE_MANAGER_ID]

# Step 5: Perform Chopsticks threshold analysis
cd .windsurf/skills/confluence-integration
# IMPORTANT: Chopsticks thresholds are in MAIN Issue Manager page, NOT BIOS/EC sub-page
# Use the main Issue Manager page ID (e.g., 1043248863 for BLADE PTL 14)
python scripts/confluence_tool.py grep-page --id [MAIN_ISSUE_MANAGER_ID] --pattern "Chopsticks Target Checking Issue Count|BIOS_Chopsticks_Red|BIOS_Chopsticks_Yellow"

# Alternative: Search for main Issue Manager page if not known
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME Issue Manager' AND title!~'BIOS/EC' AND title!~'SW/Driver/App'" --limit 5

# Step 6: Calculate Submitted + Analyze total and compare with thresholds
# Use the results from Step 4 to calculate: Submitted + Analyze UI-1 + Analyze UI-2 + Analyze UI-3

# Step 7: Perform NUDD compliance check
python scripts/confluence_tool.py cql-search --query "title~'Citadel GNR NUDD Summary'" --limit 5

# Step 8: Check NUDD Progress and extract PBA tickets
python scripts/confluence_tool.py grep-page --id [NUDD_SUMMARY_ID] --pattern "NUDD Progress|100.0%"
python scripts/confluence_tool.py cql-search --query "title~'Citadel GNR NUDD Status'" --limit 5

# Step 9: Verify PBA compliance with Feature Complete milestone
python scripts/confluence_tool.py grep-page --id [NUDD_STATUS_ID] --pattern "PBA-[0-9]+|202[0-9]/[0-9]{2}/[0-9]{2}"

# Step 10: Enhanced CPSE System Ticket Search
cd .windsurf/skills/jira-integration
# Strategy 1: Multiple naming patterns
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND (summary ~ 'PROJECT_NAME%BIOS' OR summary ~ 'PROJECT_NAME_BIOS' OR summary ~ 'PROJECT_NAME%BIOS' OR summary ~ 'PROJECT_NAME')"

# Strategy 2: Keyword combination search
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND (summary ~ 'KEYWORD1' AND summary ~ 'KEYWORD2' AND summary ~ 'KEYWORD3')"

# Strategy 3: Fuzzy matching with post-processing
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND summary ~ 'PROJECT_NAME'" | Select-String -Pattern "summary|description"

# Step 11: Extract BIOS status from CPSE ticket description
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND summary ~ 'PROJECT_NAME'" | Select-String -Pattern "description" -Context 0,50

# Step 12: Generate Comprehensive Analysis Report
# Create timestamped report in .windsurf\Reports directory
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$reportPath = ".windsurf/Reports/PROJECT_NAME_BIOS_Analysis_$timestamp.md"

# Generate comprehensive report combining all analysis results
@"
# PROJECT_NAME BIOS Project Analysis Report

**Generated**: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
**Analysis Type**: Comprehensive BIOS Project Health Assessment

## Executive Summary
- [BIOS Issue Status Analysis Results]
- [Chopsticks Threshold Assessment]
- [NUDD Compliance Status]
- [CPSE System Ticket Analysis]

## Detailed Analysis Sections

### 1. BIOS Issue Status Analysis
[Insert BIOS issue counts and status from Confluence Issue Manager]

### 2. Chopsticks Threshold Analysis
[Insert threshold comparison and health status]

### 3. NUDD Compliance Check
[Insert PBA ticket validation results]

### 4. CPSE System Ticket Analysis
[Insert system-level BIOS status from JIRA]

### 5. Integrated Risk Assessment
[Combine all analysis results for overall project health]

### 6. Recommendations
[Action items based on analysis findings]

---
*Report generated by project-bios-analysis workflow*
"@ | Out-File -FilePath $reportPath -Encoding UTF8

Write-Host "Report saved to: $reportPath" -ForegroundColor Green
```

### Advanced Options
```powershell
# Debug mode for troubleshooting
python scripts/extract_platform_jql_counts.py --project "CONGO" --debug

# Verbose output with detailed logging
python scripts/extract_platform_jql_counts.py --project "CONGO" --verbose --output "detailed_results.json"

# Print formatted table with all columns
python scripts/extract_platform_jql_counts.py --project "BLADE PTL 14" --print-table --output "blade_results.json"

# Generate detailed HTML report
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$htmlReportPath = ".windsurf/Reports/PROJECT_NAME_BIOS_Analysis_$timestamp.html"

@"
<!DOCTYPE html>
<html>
<head>
    <title>PROJECT_NAME BIOS Analysis Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background-color: #f0f0f0; padding: 20px; border-radius: 5px; }
        .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .status-green { color: green; font-weight: bold; }
        .status-yellow { color: orange; font-weight: bold; }
        .status-red { color: red; font-weight: bold; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div class="header">
        <h1>PROJECT_NAME BIOS Project Analysis Report</h1>
        <p>Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")</p>
    </div>
    
    <div class="section">
        <h2>Executive Summary</h2>
        <p>Overall Status: <span class="status-green">GREEN</span></p>
        <p>Analysis includes BIOS Issue Status, Chopsticks Thresholds, NUDD Compliance, and CPSE System Ticket analysis.</p>
    </div>
    
    <div class="section">
        <h2>BIOS Issue Status Analysis</h2>
        <table>
            <tr><th>Severity</th><th>Total</th><th>Closed</th><th>Submitted</th><th>Analyze</th></tr>
            <tr><td>Sev-1</td><td>[COUNT]</td><td>[COUNT]</td><td>[COUNT]</td><td>[COUNT]</td></tr>
            <tr><td>Sev-2</td><td>[COUNT]</td><td>[COUNT]</td><td>[COUNT]</td><td>[COUNT]</td></tr>
            <tr><td>Sev-3</td><td>[COUNT]</td><td>[COUNT]</td><td>[COUNT]</td><td>[COUNT]</td></tr>
        </table>
    </div>
    
    <div class="section">
        <h2>Recommendations</h2>
        <ul>
            <li>[Action item 1]</li>
            <li>[Action item 2]</li>
            <li>[Action item 3]</li>
        </ul>
    </div>
</body>
</html>
"@ | Out-File -FilePath $htmlReportPath -Encoding UTF8

Write-Host "HTML report saved to: $htmlReportPath" -ForegroundColor Green

# Export analysis data to JSON for further processing
$exportData = @{
    project = "PROJECT_NAME"
    timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    biosStatus = @{
        overallStatus = "GREEN"
        totalIssues = 30
        openIssues = 15
        closedIssues = 15
    }
    chopsticksAnalysis = @{
        threshold = 18
        current = 15
        status = "GREEN"
    }
    nuddCompliance = @{
        progress = "100.0%"
        compliant = $true
        pbaTickets = 20
    }
    cpseTicket = @{
        key = "CPSE-XXXXX"
        summary = "PROJECT_NAME_BIOS"
        status = "Green"
    }
}

$exportData | ConvertTo-Json -Depth 3 | Out-File -FilePath ".windsurf/Reports/PROJECT_NAME_BIOS_Analysis_$timestamp.json" -Encoding UTF8
```

## Chopsticks Threshold Analysis

### Chopsticks Target Checking Issue Count Analysis

The Chopsticks Target Checking Issue Count table provides project health thresholds for BCO+1 ~ FV Entry period. This analysis compares current issue status against predefined thresholds.

#### **Threshold Definitions**
- **BIOS_Chopsticks_Red**: Critical threshold - project status turns RED when issues ≥ threshold
- **BIOS_Chopsticks_Yellow**: Warning threshold - project status turns YELLOW when issues ≥ threshold
- **Comparison Metric**: Submitted + Analyze issues total (all UI levels)

#### **Analysis Workflow**
```powershell
# Step 1: Extract current BIOS issue status
cd .windsurf/skills/project-analysis
python scripts/extract_platform_jql_counts.py --page-id [BIOS_EC_ISSUE_MANAGER_ID] --output "bios_status.json"

# Step 2: Get Chopsticks thresholds from main Issue Manager page
cd .windsurf/skills/confluence-integration
# IMPORTANT: Chopsticks thresholds are in MAIN Issue Manager page, NOT BIOS/EC sub-page
# Use the main Issue Manager page ID (e.g., 1043248863 for BLADE PTL 14)
python scripts/confluence_tool.py grep-page --id [MAIN_ISSUE_MANAGER_ID] --pattern "Chopsticks Target Checking Issue Count|BIOS_Chopsticks_Red|BIOS_Chopsticks_Yellow"

# Alternative: Search for main Issue Manager page if not known
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME Issue Manager' AND title!~'BIOS/EC' AND title!~'SW/Driver/App'" --limit 5

# Step 3: Calculate Submitted + Analyze total
# Formula: Submitted + Analyze UI-1 + Analyze UI-2 + Analyze UI-3 (all severities)

# Step 4: Compare with thresholds and determine project health status
```

#### **Health Status Assessment**
- **🟢 GREEN**: Submitted + Analyze < Yellow threshold
- **⚠️ YELLOW**: Yellow threshold ≤ Submitted + Analyze < Red threshold  
- **🔴 RED**: Submitted + Analyze ≥ Red threshold

#### **Example Analysis (BLADE PTL 14)**
```powershell
# Current Status (from BIOS/EC Issue Manager):
# Submitted + Analyze = 15 issues
#   - Sev-1: 2 (Analyze UI-1)
#   - Sev-2: 12 (Analyze UI-1: 8, Analyze UI-2: 2, Analyze UI-3: 2)
#   - Sev-3: 1 (Analyze UI-3)

# Chopsticks Thresholds (2026-03-11):
# BIOS_Chopsticks_Red: 19
# BIOS_Chopsticks_Yellow: 18

# Assessment: GREEN (15 < 18 < 19)
```

#### **Action Recommendations**
**GREEN Status**:
- Maintain current issue levels
- Focus on Analyze UI-1 backlog reduction
- Monitor for threshold breaches

**YELLOW Status**:
- Immediate action required
- Prioritize Submitted + Analyze issue reduction
- Daily threshold monitoring

**RED Status**:
- Critical intervention needed
- Escalate to management
- Implement daily reduction targets

#### **Integration with FV Entry Compliance**
Combine Chopsticks analysis with FV Entry requirements:
- **FV Entry Goal**: Zero Total Open issues
- **Chopsticks Goal**: Maintain Submitted + Analyze below thresholds
- **Combined Strategy**: Use Chopsticks for early warning, FV Entry for final compliance

## NUDD Compliance Check

### NUDD (New Unit Development Document) Analysis

The NUDD compliance check verifies that all PBA (Platform Business Architecture) tickets are completed before key development milestones, particularly Feature Complete (CP#3).

#### **NUDD Analysis Workflow**
```powershell
# Step 1: Find NUDD Summary page
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME NUDD Summary'" --limit 5

# Step 2: Check NUDD Progress percentage
python scripts/confluence_tool.py grep-page --id [NUDD_SUMMARY_ID] --pattern "NUDD Progress|100.0%"

# Step 3: Find NUDD Status page
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME NUDD Status'" --limit 5

# Step 4: Extract all PBA tickets and target end dates
python scripts/confluence_tool.py grep-page --id [NUDD_STATUS_ID] --pattern "PBA-[0-9]+|202[0-9]/[0-9]{2}/[0-9]{2}"

# Step 5: Get Feature Complete (CP#3) milestone date
python scripts/confluence_tool.py grep-page --id [MAIN_PROJECT_ID] --pattern "Feature Complete.*CP#3"

# Step 6: Compare PBA target end dates with CP#3 milestone
# All PBA target end dates must be before Feature Complete (CP#3)
```

#### **NUDD Compliance Assessment**
- **🟢 COMPLIANT**: All PBA tickets target end dates < Feature Complete (CP#3)
- **🔴 NON-COMPLIANT**: Any PBA ticket target end date ≥ Feature Complete (CP#3)
- **⚠️ AT RISK**: PBA tickets with target end dates close to CP#3 milestone

#### **Key Metrics**
- **NUDD Progress Percentage**: Overall completion status
- **PBA Compliance Rate**: Percentage of PBA tickets meeting milestone requirements
- **Action Needed Count**: Number of PBA tickets requiring immediate attention
- **Wait Issue Count**: Number of PBA tickets with blocking issues

#### **Example Analysis (BLADE PTL 14)**
```powershell
# NUDD Progress Summary:
# - Overall Progress: 100.0% (7/7)
# - Action Needed: 0
# - Wait Issue: 0

# Feature Complete (CP#3) Date: 2026/01/23

# PBA Tickets Analysis (20/20 compliant):
# - PBA-5429: 2024/10/30 ✅
# - PBA-5452: 2024/11/13 ✅
# - PBA-5539: 2025/04/10 ✅
# - PBA-5624: 2025/09/25 ✅
# - PBA-6272: 2025/12/26 ✅ (Latest, still 28 days before CP#3)
# - ... (all other PBA tickets completed before CP#3)

# Assessment: FULLY COMPLIANT (100% pass rate)
```

#### **Integration with Development Milestones**
**Critical Milestone Checks**:
- **Feature Complete (CP#3)**: All PBA tickets must be completed
- **Bug Cutoff (CP#4)**: Design changes should be frozen
- **FV Entry (CP#5)**: All architecture work finalized

**Risk Assessment**:
- **Schedule Risk**: PBA tickets approaching or exceeding milestone dates
- **Scope Risk**: New PBA tickets added after milestone deadlines
- **Quality Risk**: PBA tickets with incomplete deliverables

#### **Action Recommendations**
**COMPLIANT Status**:
- Continue monitoring PBA completion progress
- Maintain current milestone adherence
- Document best practices for future projects

**NON-COMPLIANT Status**:
- Immediate escalation to project management
- Rebaseline PBA target dates
- Implement daily progress tracking
- Consider milestone adjustment if necessary

**AT RISK Status**:
- Weekly progress reviews
- Proactive risk mitigation
- Resource allocation adjustments
- Stakeholder communication plan

## CPSE System Ticket Analysis

### Enhanced CPSE Ticket Search Strategies

Due to inconsistent naming conventions in JIRA ticket summaries, multiple search strategies are recommended:

#### **Strategy 1: Multiple Naming Patterns**
```powershell
# Search for various naming conventions
cd .windsurf/skills/jira-integration
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND (summary ~ 'PROJECT_NAME%BIOS' OR summary ~ 'PROJECT_NAME_BIOS' OR summary ~ 'PROJECT_NAME%BIOS' OR summary ~ 'PROJECT_NAME')"
```

#### **Strategy 2: Keyword Combination Search**
```powershell
# Extract keywords from project name and search combinations
$keywords = "BLADE", "PTL", "14"
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND (summary ~ 'BLADE' AND summary ~ 'PTL' AND summary ~ '14')"
```

#### **Strategy 3: Hierarchical Search**
```powershell
# Level 1: Exact match
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND summary = 'PROJECT_NAME'"

# Level 2: Pattern match
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND summary ~ 'PROJECT_NAME'"

# Level 3: Keyword combination
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND (summary ~ 'KEYWORD1' AND summary ~ 'KEYWORD2')"

# Level 4: Broad search + manual verification
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND (summary ~ 'KEYWORD1' OR summary ~ 'KEYWORD2')"
```

#### **Strategy 4: Fuzzy Matching with Post-Processing**
```powershell
# Broad search with similarity scoring
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND summary ~ 'PROJECT_NAME'" | Select-String -Pattern "summary"

# Manual verification of results
$results | Where-Object { $_.fields.summary -match [regex]::Escape($ProjectName.Replace(' ', '.*')) }
```

#### **Project Name Mapping Examples**
```powershell
# Common project name variations
$projectMappings = @{
    "BLADE PTL 14" = @("BLADE%PTL%14", "Blade%PTL%14", "BLADE14%PTL", "Blade14%PTL", "Blade14_PTL_BIOS")
    "CITADEL NVL" = @("CITADEL%NVL", "Citadel%NVL", "CITADEL_NVL_BIOS")
    "CITADEL GNR" = @("CITADEL%GNR", "Citadel%GNR", "CITADEL_GNR_BIOS")
}
```

#### **BIOS Status Extraction**
```powershell
# Extract detailed BIOS status from ticket description
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND summary ~ 'PROJECT_NAME'" | Select-String -Pattern "description" -Context 0,50

# Parse BIOS status information
# Look for: Overall Status, Issue Count, BIOS Release Plan, Hot Topics
```

#### **Example: BLADE PTL 14 Search**
```powershell
# Multiple search attempts for BLADE PTL 14
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND (summary ~ 'BLADE%PTL%14' OR summary ~ 'Blade%PTL%14' OR summary ~ 'BLADE14%PTL' OR summary ~ 'Blade14%PTL' OR summary ~ 'Blade14_PTL_BIOS')"

# Extract BIOS status from found ticket
python scripts/jira_tool.py search --jql "project = 'CPSE' AND type = 'system' AND summary ~ 'Blade14_PTL_BIOS'" | Select-String -Pattern "description" -Context 0,30
```

#### **Integration with Project Analysis**
CPSE ticket analysis provides:
- **BIOS Overall Status**: Green/Yellow/Red health indicators
- **Issue Count Statistics**: Detailed breakdown by severity and status
- **Release Planning**: BIOS version release schedules
- **Hot Topics**: Critical issues and focus areas
- **Timeline Information**: Next 14-30 days milestones

This complements the Confluence Issue Manager analysis with system-level BIOS status reporting.

## Report Management

### Automated Report Generation

The workflow automatically generates comprehensive analysis reports in multiple formats:

#### **Report Formats**
- **Markdown Report**: `.windsurf/Reports/PROJECT_NAME_BIOS_Analysis_YYYY-MM-DD_HH-mm-ss.md`
- **HTML Report**: `.windsurf/Reports/PROJECT_NAME_BIOS_Analysis_YYYY-MM-DD_HH-mm-ss.html`
- **JSON Data Export**: `.windsurf/Reports/PROJECT_NAME_BIOS_Analysis_YYYY-MM-DD_HH-mm-ss.json`

#### **Report Contents**
- **Executive Summary**: Overall project health status
- **BIOS Issue Status Analysis**: Detailed issue counts and breakdown
- **Chopsticks Threshold Assessment**: Health status vs thresholds
- **NUDD Compliance Check**: PBA ticket validation results
- **CPSE System Ticket Analysis**: System-level BIOS status
- **Integrated Risk Assessment**: Combined analysis results
- **Recommendations**: Action items based on findings

#### **Report Management**
```powershell
# List all generated reports
Get-ChildItem ".windsurf/Reports/*.md" | Sort-Object LastWriteTime -Descending | Select-Object Name, LastWriteTime

# Find latest report for a project
$latestReport = Get-ChildItem ".windsurf/Reports/*PROJECT_NAME*.md" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
Write-Host "Latest report: $($latestReport.Name)" -ForegroundColor Green

# Clean up old reports (keep last 10)
$oldReports = Get-ChildItem ".windsurf/Reports/*.md" | Sort-Object LastWriteTime -Descending | Select-Object -Skip 10
$oldReports | Remove-Item -Force
Write-Host "Cleaned up $($oldReports.Count) old reports" -ForegroundColor Yellow
```

#### **Custom Report Templates**
```powershell
# Generate custom report with specific sections
$customReport = @"
# Custom PROJECT_NAME Analysis

## Focus Area: BIOS Issue Reduction
- Current Open Issues: [COUNT]
- Target Reduction: [TARGET]
- Timeline: [TIMELINE]

## Critical Issues
1. [Issue 1]
2. [Issue 2]
3. [Issue 3]

## Action Plan
- [ ] Action item 1
- [ ] Action item 2
- [ ] Action item 3
"@

$customReport | Out-File -FilePath ".windsurf/Reports/PROJECT_NAME_Custom_Analysis_$timestamp.md" -Encoding UTF8
```

#### **Report Automation**
```powershell
# Schedule automated weekly reports
# Add to Windows Task Scheduler or cron job
$scriptPath = ".windsurf/workflows/project-bios-analysis.md"
$reportSchedule = "Weekly on Friday at 5:00 PM"

# Example PowerShell script for scheduled execution
$project = "BLADE PTL 14"
& .windsurf/workflows/project-bios-analysis.md $project
```

## Platform Issue Status Table Structure

### Table Logic and Calculations

The Overall BIOS Issue Status table follows a specific mathematical structure for issue tracking and reporting:

#### **Row-wise Calculations (Open Issues)**
For each severity level (Sev-1, Sev-2, Sev-3, and Total row):
```
Total Open = Submitted + Analyze UI-1 + Analyze UI-2 + Analyze UI-3 + Wait + Review + Verify
```

#### **Row-wise Calculations (Grand Totals)**
For each severity level (Sev-1, Sev-2, Sev-3, and Total row):
```
Total = Total Open + Closed + Post-RTS + ATS-P1 + ATS-P2 + ATS-P3 + ATS-P4 + ATS-P5 + EB/WAD
```

#### **Column-wise Calculations (Vertical Totals)**
For each column (Submitted, Analyze UI-1, Analyze UI-2, Analyze UI-3, Wait, Review, Verify, Total Open, Closed, Post-RTS, ATS-P1, ATS-P2, ATS-P3, ATS-P4, ATS-P5, EB/WAD, Total):
```
Total Row = Sev-1 + Sev-2 + Sev-3
```

#### **Table Structure**
The Overall BIOS issue status table has the following structure:

**Rows (4 total):**
- Sev-1 (High Severity)
- Sev-2 (Medium Severity) 
- Sev-3 (Low Severity)
- Total (Vertical sum of all severity levels)

**Columns (17 total):**
- **Status Columns**: Submitted, Analyze UI-1, Analyze UI-2, Analyze UI-3, Wait, Review, Verify, Total Open
- **Resolution Columns**: Closed
- **Special Categories**: Post-RTS, ATS-P1, ATS-P2, ATS-P3, ATS-P4, ATS-P5, EB/WAD
- **Grand Total**: Total

#### **Special Category Definitions**
- **Post-RTS**: Issues marked as Post-Release to Service (excluded from regular open/closed counts)
- **ATS-P1 to ATS-P5**: ATS (Acceptance Test System) priority levels 1-5 (excluded from regular counts)
- **EB/WAD**: Early Build/WAIVED issues (excluded from regular counts)

#### **Exclusion Logic**
The special categories (Post-RTS, ATS-P1-5, EB/WAD) use exclusion logic in JQL:
- These issues are **subtracted** from the main issue counts
- They appear as separate columns for tracking but don't affect Total Open calculations
- This prevents double-counting and maintains data integrity

#### **Example Calculation**
```
Sev-1 Row Example:
Submitted: 0
Analyze UI-1: 2
Analyze UI-2: 0
Analyze UI-3: 0
Wait: 0
Review: 0
Verify: 0
---
Total Open: 0 + 2 + 0 + 0 + 0 + 0 + 0 = 2

Closed: 291
Post-RTS: 0
ATS-P1: 0
ATS-P2: 0
ATS-P3: 0
ATS-P4: 0
ATS-P5: 0
EB/WAD: 0
---
Total: 2 + 291 + 0 + 0 + 0 + 0 + 0 + 0 + 0 = 293

Sev-2 Row Example:
Submitted: 0
Analyze UI-1: 0
Analyze UI-2: 0
Analyze UI-3: 0
Wait: 0
Review: 0
Verify: 2
---
Total Open: 0 + 0 + 0 + 0 + 0 + 0 + 2 = 2

Closed: 854
Post-RTS: 17
ATS-P1: 0
ATS-P2: 0
ATS-P3: 0
ATS-P4: 0
ATS-P5: 0
EB/WAD: 1
---
Total: 2 + 854 + 17 + 0 + 0 + 0 + 0 + 0 + 1 = 874

Vertical Total Row Example:
Total Open: 2 (Sev-1) + 2 (Sev-2) + [Sev-3 count] = [Vertical Total]
Closed: 291 (Sev-1) + 854 (Sev-2) + [Sev-3 count] = [Vertical Total]
```

## Open Issues Aging Analysis

### Aging Days Analysis Features

The project-analysis skill provides comprehensive aging analysis for all open issues to help teams track issue freshness and identify stale tickets requiring attention.

#### **Aging Categories**
- **0-7 days (Recent)**: Actively maintained issues ✅
- **8-14 days (Moderate)**: Issues needing attention ⚠️
- **15-30 days (Stale)**: Issues requiring immediate review 🔴
- **31-60 days (Very Stale)**: Critical issues needing escalation 🔴
- **61-90 days (Critical)**: High-priority stale issues 🔴
- **91+ days (Severe)**: Extreme aging requiring management intervention 🔴

#### **Analysis Capabilities**
- **Comprehensive Aging Distribution**: Categorize all open issues by aging brackets
- **Status Distribution**: Break down issues by current status (Analyze, Verify, Review, etc.)
- **Assignee Workload Analysis**: Identify team members with high ticket loads
- **Bottleneck Detection**: Find phases where issues accumulate
- **Performance Benchmarks**: Compare against industry standards
- **Risk Assessment**: Evaluate aging-related project risks

#### **JQL Queries for Aging Analysis**

```powershell
# Platform Total Open Issues Only (Based on Overall BIOS issue status Table)
cd .windsurf/skills/jira-integration

# Sev-1 Total Open Issues
python scripts/jira_tool.py batch-search --jql "project = \"PIMS\" AND issuetype = \"Defect\" AND ((status in (Review, Analyze, Verify, Wait) AND (filter = 107934 Or filter = 107932 Or filter = 107933)) OR (status = Submitted AND (filter = 137023 Or filter = 137021 Or filter = 137022))) AND (((\"Platform Found (PF)\" in (\"PROJECT_NAME\") OR \"Platform Affected with PAW\" in (\"PROJECT_NAME:VERIFIED_PRESENT\", \"PROJECT_NAME:VERIFIED_FIXED\")) )) AND \"Issue Severity\" = \"1-High\" AND (\"Discretionary Field 2\" is EMPTY OR \"Discretionary Field 2\" not in (\"ATS P1\",\"ATS P2\",\"ATS P3\",\"ATS P4\",\"ATS P5\",\"Post-RTS\",\"EB/WAD\"))" --save-report

# Sev-2 Total Open Issues
python scripts/jira_tool.py batch-search --jql "project = \"PIMS\" AND issuetype = \"Defect\" AND ((status in (Review, Analyze, Verify, Wait) AND (filter = 107934 Or filter = 107932 Or filter = 107933)) OR (status = Submitted AND (filter = 137023 Or filter = 137021 Or filter = 137022))) AND (((\"Platform Found (PF)\" in (\"PROJECT_NAME\") OR \"Platform Affected with PAW\" in (\"PROJECT_NAME:VERIFIED_PRESENT\", \"PROJECT_NAME:VERIFIED_FIXED\")) )) AND \"Issue Severity\" = \"2-Medium\" AND (\"Discretionary Field 2\" is EMPTY OR \"Discretionary Field 2\" not in (\"ATS P1\",\"ATS P2\",\"ATS P3\",\"ATS P4\",\"ATS P5\",\"Post-RTS\",\"EB/WAD\"))" --save-report

# Sev-3 Total Open Issues
python scripts/jira_tool.py batch-search --jql "project = \"PIMS\" AND issuetype = \"Defect\" AND ((status in (Review, Analyze, Verify, Wait) AND (filter = 107934 Or filter = 107932 Or filter = 107933)) OR (status = Submitted AND (filter = 137023 Or filter = 137021 Or filter = 137022))) AND (((\"Platform Found (PF)\" in (\"PROJECT_NAME\") OR \"Platform Affected with PAW\" in (\"PROJECT_NAME:VERIFIED_PRESENT\", \"PROJECT_NAME:VERIFIED_FIXED\")) )) AND \"Issue Severity\" = \"3-Low\" AND (\"Discretionary Field 2\" is EMPTY OR \"Discretionary Field 2\" not in (\"ATS P1\",\"ATS P2\",\"ATS P3\",\"ATS P4\",\"ATS P5\",\"Post-RTS\",\"EB/WAD\"))" --save-report

# Combined Platform Total Open (All Severities)
python scripts/jira_tool.py batch-search --jql "project = \"PIMS\" AND issuetype = \"Defect\" AND ((status in (Review, Analyze, Verify, Wait) AND (filter = 107934 Or filter = 107932 Or filter = 107933)) OR (status = Submitted AND (filter = 137023 Or filter = 137021 Or filter = 137022))) AND (((\"Platform Found (PF)\" in (\"PROJECT_NAME\") OR \"Platform Affected with PAW\" in (\"PROJECT_NAME:VERIFIED_PRESENT\", \"PROJECT_NAME:VERIFIED_FIXED\")) )) AND (\"Discretionary Field 2\" is EMPTY OR \"Discretionary Field 2\" not in (\"ATS P1\",\"ATS P2\",\"ATS P3\",\"ATS P4\",\"ATS P5\",\"Post-RTS\",\"EB/WAD\"))" --save-report
```

#### **Aging Analysis Workflow**

```powershell
# Step 1: Extract Platform Total Open Issues by Severity
cd .windsurf/skills/jira-integration

# Extract Sev-1, Sev-2, Sev-3 Total Open issues separately
python scripts/jira_tool.py batch-search --jql "project = \"PIMS\" AND issuetype = \"Defect\" AND ((status in (Review, Analyze, Verify, Wait) AND (filter = 107934 Or filter = 107932 Or filter = 107933)) OR (status = Submitted AND (filter = 137023 Or filter = 137021 Or filter = 137022))) AND (((\"Platform Found (PF)\" in (\"PROJECT_NAME\") OR \"Platform Affected with PAW\" in (\"PROJECT_NAME:VERIFIED_PRESENT\", \"PROJECT_NAME:VERIFIED_FIXED\")) )) AND \"Issue Severity\" = \"1-High\" AND (\"Discretionary Field 2\" is EMPTY OR \"Discretionary Field 2\" not in (\"ATS P1\",\"ATS P2\",\"ATS P3\",\"ATS P4\",\"ATS P5\",\"Post-RTS\",\"EB/WAD\"))" --save-report

# Step 2: Analyze aging for Platform Total Open tickets only
# Use PowerShell script to process Platform-defined Total Open tickets
# (See brickyard_aging_analysis.ps1 for example implementation, but filter for Platform Total Open only)

# Step 3: Generate Platform-focused aging report
# Report should align with Overall BIOS issue status table definitions
```

#### **Key Metrics and KPIs**

**Performance Indicators:**
- **Recent Activity Rate**: Percentage of tickets updated ≤7 days (Target: >70%)
- **Stale Issue Rate**: Percentage of tickets >15 days old (Target: <20%)
- **Average Aging**: Mean days since last update (Target: <21 days)
- **Median Aging**: Middle value of aging distribution
- **Workload Balance**: Standard deviation of tickets per assignee

**Risk Assessment:**
- **Aging Risk Level**: Based on stale issue percentage and aging distribution
- **Capacity Risk**: Based on assignee workload distribution
- **Process Risk**: Based on status bottlenecks and flow issues

#### **Industry Benchmarks**

| Metric | Excellent | Good | Acceptable | Concerning |
|--------|-----------|------|------------|------------|
| **Recent Activity** | >90% | 70-90% | 50-70% | <50% |
| **Stale Issues** | <5% | 5-15% | 15-25% | >25% |
| **Average Aging** | <7 days | 7-14 days | 14-21 days | >21 days |
| **Unassigned Rate** | <5% | 5-10% | 10-15% | >15% |

#### **Report Components**

**Executive Summary:**
- Overall aging performance assessment
- Key findings and risk level
- Comparison with industry benchmarks
- Top recommendations

**Detailed Analysis:**
- Aging distribution by category
- Status breakdown with percentages
- Assignee workload analysis
- Oldest and most recent tickets
- Process flow analysis

**Actionable Insights:**
- Immediate actions for stale issues
- Process improvement recommendations
- Workload balancing suggestions
- Long-term monitoring strategies

#### **Common Aging Patterns**

**Healthy Project Indicators:**
- 70%+ tickets in 0-7 days category
- <20% tickets older than 15 days
- Balanced distribution across statuses
- Even workload across team members

**Warning Signs:**
- High concentration in 15-30+ days categories
- Bottlenecks in specific statuses (usually Analyze)
- Uneven assignee workload
- High percentage of unassigned tickets

#### **Integration with Overall BIOS issue status**

**Primary Data Source: Overall BIOS issue status Table**
- **Structured Data**: All analysis uses Overall BIOS issue status table as primary data source
- **Total Open Definition**: Strictly follows Platform table definition (excludes Post-RTS, ATS-P1-5, EB/WAD)
- **Severity-Based Analysis**: Maintains Sev-1/2/3 separation as defined in Platform table
- **Consistent Metrics**: All aging metrics align with Overall BIOS issue status reporting standards

**Platform-Defined Total Open Issues:**
```
Total Open = Submitted + Analyze UI-1 + Analyze UI-2 + Analyze UI-3 + Wait + Review + Verify
Exclusions: Post-RTS, ATS-P1, ATS-P2, ATS-P3, ATS-P4, ATS-P5, EB/WAD
```

**Analysis Scope:**
- **Sev-1 Total Open**: High severity issues requiring immediate attention
- **Sev-2 Total Open**: Medium severity issues with standard priority
- **Sev-3 Total Open**: Low severity issues with routine handling
- **Combined Total**: All severities for comprehensive project view

**BRICKYARD Example (Platform-Based):**
- **Sev-1 Total Open**: 2 tickets
- **Sev-2 Total Open**: 2 tickets  
- **Sev-3 Total Open**: 0 tickets
- **Platform Total Open**: 4 tickets (vs 45 comprehensive open issues)

**Analysis Methodology:**
1. **Extract Platform Data**: Use Platform-defined JQL queries for each severity
2. **Calculate Aging**: Analyze days since last update for Platform Total Open tickets only
3. **Generate Reports**: Create aging analysis that aligns with Overall BIOS issue status metrics
4. **Maintain Consistency**: Ensure all aging analysis matches Platform table definitions

**Benefits of Platform-Based Analysis:**
- **Data Consistency**: Aligns with official Overall BIOS issue status reporting
- **Management Visibility**: Results match what management sees in Platform tables
- **Standardized Metrics**: Uses same definitions and exclusions as Platform reporting
- **Trend Analysis**: Enables consistent historical tracking using Platform definitions

## Output

### Console Output
- Real-time execution progress
- Individual query results
- Statistical summaries
- FV Entry compliance assessment

### JSON Output
```json
{
  "jql_queries": [...],           # All extracted JQL queries
  "results": {...},               # Query execution results
  "statistics": {...},            # Statistical summaries
  "compliance": {...},            # FV Entry assessment
  "metadata": {...}               # Page and execution info
}
```

### Statistical Report
```
=== Project Issue Status Analysis ===

Overall Statistics:
   Total Open Issues: 68
   Total Closed Issues: 146
   Grand Total: 214
   Closure Rate: 68.2%

Statistics by Severity:
   Sev-1:
     Total: 8 issues
     Closed: 9 issues
     Submitted: 2 issues
     Analyze: 3 issues
   Sev-2:
     Total: 57 issues
     Closed: 126 issues
     Submitted: 7 issues
     Analyze: 55 issues
   Sev-3:
     Total: 8 issues
     Closed: 11 issues
     Analyze: 2 issues

FV Entry Compliance Assessment:
   FV Entry Requirement: Zero open issues
   Current Open Issues: 68
   [FAIL] Non-compliant
   Risk Level: High
```

## Troubleshooting

### Platform Issues
```powershell
# Method 1: Use NPI Platform Information Lookup (For New Projects)
cd .windsurf/skills/confluence-integration
# Search NPI page for project references
python scripts/confluence_tool.py grep-page --id 311322473 --pattern "PROJECT_NAME"

# If found, get exact project page
python scripts/confluence_tool.py cql-search --query "title='PROJECT_NAME' AND space=CSEI" --limit 5

# Method 2: Use Sustaining Platform Information Lookup (For Sustaining Projects)
cd .windsurf/skills/confluence-integration
# Search Sustaining page for project references
python scripts/confluence_tool.py grep-page --id 313693926 --pattern "PROJECT_NAME"

# If found, get exact project page
python scripts/confluence_tool.py cql-search --query "title='PROJECT_NAME' AND space=CSEI" --limit 5

# Method 3: Project not found automatically - use direct page ID
python scripts/extract_platform_jql_counts.py --page-id [PAGE_ID]

# Method 4: Search manually for project pages across all spaces
python scripts/confluence_tool.py cql-search --query "title~'PROJECT_NAME'" --limit 20

# JQL execution failures
python scripts/extract_platform_jql_counts.py --project "PROJECT_NAME" --debug

# Verify page content manually
python scripts/confluence_tool.py get --id [PAGE_ID] | Select-String "Overall BIOS issue status"

# Common Platform Information Issues:
# - Project name might have different formatting in NPI/Sustaining pages
# - Try variations: "CITADEL NVL", "Citadel NVL", "CITADEL NVL Issue Manager"
# - Check if project is listed in NPI page (for new projects) or Sustaining page (for sustaining projects)
# - Sustaining projects often have different naming conventions (e.g., "CITADEL GNR" vs "CITADEL NVL")
```

### Integration with Other Skills
```powershell
# Combine with confluence-integration
cd .windsurf/skills/confluence-integration
python scripts/confluence_nudd.py extract --page-id 1086093660
```

## Development Phase Gates

Extract development milestone information from project pages:
```powershell
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py grep-page --id 1008911302 --pattern "Phase Exit|Entry|CP#[0-9]"

# Key development milestones:
# - Define Phase Exit
# - Plan Phase Exit  
# - ULV/MLV Entry (CP#1)
# - IEV/SLV Entry (CP#2)
# - Feature Complete (CP#3)
# - Bug Cutoff (CP#4)
# - FV Entry (CP#5)
# - FV Exit (CP#6)
# - RTS
```
```

**Development Phase Gates**:
- **Define Phase Exit**: Requirements definition completion
- **Plan Phase Exit**: Planning phase completion
- **ULV/MLV Entry (CP#1)**: Ultra-Low/Mid-Volume entry point
- **IEV/SLV Entry (CP#2)**: Initial/Small-Volume entry point
- **Feature Complete (CP#3)**: Feature development completion
- **Bug Cutoff (CP#4)**: Bug fixing cutoff date
- **FV Entry (CP#5)**: Final Validation entry
- **FV Exit (CP#6)**: Final Validation exit
- **RTS**: Release to Ship

**Development Focus**: These gates are critical for development teams to track progress and ensure timely delivery of milestones.

### Issue Risk Analysis

**FV Entry (CP#5) Milestone Compliance Check**:
```powershell
# Extract FV Entry date from project milestones
cd .windsurf/skills/confluence-integration
python scripts/confluence_tool.py grep-page --id 1008911302 --pattern "FV Entry.*CP#5|CP#5.*FV Entry"

# Found: FV Entry (CP#5): 2026/01/14

# Check Total Open Issues count from Issue Management Page
python scripts/confluence_tool.py grep-page --id 1008911303 --pattern "count.*true"

# Extract JQL queries for total open issues count
python scripts/confluence_tool.py grep-page --id 1008911303 --pattern "jqlQuery.*BLACKHAWK.*count.*true"
```

**Critical Risk Assessment**:
- **FV Entry (CP#5) Date**: 2026/01/14
- **Requirement**: Total Open Issues must be ZERO after FV Entry
- **Risk Status**: ❌ **HIGH RISK** if any open issues remain after 2026/01/14

**Risk Mitigation Timeline**:
- **Before 2026/01/14**: All PRTS issues must be resolved
- **After FV Entry**: Zero tolerance for open issues
- **Compliance Check**: Daily monitoring required as milestone approaches