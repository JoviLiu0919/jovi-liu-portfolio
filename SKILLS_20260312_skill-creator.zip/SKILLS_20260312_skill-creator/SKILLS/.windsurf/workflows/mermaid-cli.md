---
description: how to switch mermaid-cli puppeteer browser configs (chrome <-> edge)
---
1) Install prerequisites (new machine)
   - Ensure Node.js is installed (Dell Company Portal).
   - From repo root, run the installer script (skips Chromium download, installs mermaid-cli if missing):
     ```powershell
     .\install_mermaid_cli.ps1
     ```

2) Locate config files
   - Chrome: `puppeteer-config.json`
   - Edge:   `puppeteer-config-edge.json`

3) Run mermaid-cli with desired config (always followed by the post-processor)
   ```bash
   npx @mermaid-js/mermaid-cli -i <input.mmd> -o <output.svg> --puppeteerConfigFile puppeteer-config.json
   # or
   npx @mermaid-js/mermaid-cli -i <input.mmd> -o <output.svg> --puppeteerConfigFile puppeteer-config-edge.json
   ```
   Immediately after generating, **always** run the aligner (mandatory even for code_flow_example.svg):
   ```bash
   python SKILLS/.windsurf/skills/code-flow-chart/scripts/_align_svg_temp.py <output.svg>
   ```

4) If one browser fails (path missing), switch to the other
   - Edit the command to point to the alternate config.
   - Paths used:
     - Chrome: `C:\Program Files\Google\Chrome\Application\chrome.exe`
     - Edge:   `C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`

Note: If Node.js is not installed, install it via Dell Company Portal first, then rerun the commands above.

Important: Post-processor is mandatory (even without CODE BLOCK). If `.mmd` contains `CODE BLOCK` nodes, the aligner converts `¤` placeholders into indentation and left-aligns only `CODE BLOCK` nodes.

Reference: current CSS/color and CODE BLOCK writing rules (ustt_flow.mmd)
- Background: `#f9f7ff`
- Cluster: fill `#fff3ce`, stroke `#f6a623`, 2px, radius 16
- Nodes: fill `#ecf2ff`, stroke `#4f46e5`, 2px, radius 12
- Decisions: polygon fill `#ffe7cc`, stroke `#f6a623`
- Text default: color `#140f33`, font "IBM Plex Sans", 12px, weight 600
- CODE BLOCK (classDef code): fill `#e6f6ff`, stroke `#2b9ed8`, text `#0a6ca8`, mono font, 8px
- CODE BLOCK content uses `¤` for indentation, e.g.
  ```
  CODE BLOCK<br>Status = ...(<br>¤ &Param1,<br>¤ Param2);
  ```
  `_align_svg_temp.py` turns `¤` into indent and left-aligns CODE BLOCK nodes only.

General MMD writing guidelines
- Use `<br>` for manual line breaks inside labels.
- For indentation in CODE BLOCK text, use `¤` placeholders (one level = one symbol) and place a `<br>` before each new indented line.
- If adding CODE BLOCK nodes, include the text "CODE BLOCK" in the label so the post-processor can target them.

5) Verify output
   - Check that the SVG is created and not empty.
   - If you see font fallback warnings, you can ignore them; conversion stays offline.

6) (Optional) Update a config path
   - Edit the JSON `executablePath` to your installed browser path.
   - Keep exactly one `executablePath` key per file.
