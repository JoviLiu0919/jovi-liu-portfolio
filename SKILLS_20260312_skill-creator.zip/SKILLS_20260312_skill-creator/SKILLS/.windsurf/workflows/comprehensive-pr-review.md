---
name: comprehensive-pr-review
description: Comprehensive PR review workflow integrating code review and format checking for complete Pull Request assessment
---

# Comprehensive PR Review Workflow

This workflow integrates `code-review` and `pr-format-check` skills to provide a complete Pull Request review process, including code quality analysis, security detection, format validation, and automated PR management.

## 🎯 Review Scope

### 📝 Format Check (pr-format-check)
- ✅ Git commit message format validation
- 🔐 GPG signature status verification
- 🎫 JIRA ticket existence and type validation
- 📊 Multi-commit merge suggestions
- 🤖 Automated PR status updates

### 🔍 Code Review (code-review)
- 🛡️ Security vulnerability detection
- 📏 Code quality and style checking
- ⚡ Performance analysis
- 🏗️ BIOS/UEFI specific review
- 🧪 Test coverage analysis

## 📋 Workflow Steps

### 1. Get PR Information
- **Skill**: `pr-format-check`
- **Command**: `github_integration.py`
- **Parameters**:
  - `pr_url`: "https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/123"
  - `dry_run`: false (execute actual operations)
- **Output**: PR basic information and commit list

### 2. Format and Signature Check
- **Skill**: `pr-format-check`
- **Command**: `pr_format_checker.py`
- **Parameters**:
  - Commit messages from step 1
  - GPG signature verification
  - JIRA ticket validation
- **Output**: Format check report

### 3. Code Quality Review
- **Skill**: `code-review`
- **Command**: `code_review.py`
- **Parameters**:
  - `repo`: Extracted from PR URL
  - `pr_number`: Extracted from PR URL
  - `focus`: "security,performance,code_quality"
  - `detailed`: true
- **Output**: Code review report

### 4. Generate Comprehensive Report
- **Processing**: Merge outputs from both skills
- **Content**: 
  - Format check results
  - Code review results
  - Comprehensive score and recommendations
  - Action items list

### 5. Automated PR Management
- **Skill**: `pr-format-check`
- **Command**: `github_integration.py`
- **Operations**:
  - Auto-comment based on check results
  - Set review status (APPROVE/REQUEST_CHANGES)
  - Provide specific modification suggestions

## 🚀 Usage Examples

### Standard PR Review
```bash
/comprehensive-pr-review --pr-url "https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/123"
```

### Check Only (Dry Run)
```bash
/comprehensive-pr-review --pr-url "..." --dry-run
```

### Custom Review Focus
```bash
/comprehensive-pr-review --pr-url "..." --focus "security,performance" --severity "high"
```

### BIOS Specific Review
```bash
/comprehensive-pr-review --pr-url "..." --template bios --platform-specific true
```

## 📊 Expected Output Flow

```
🔍 Starting comprehensive PR review...
📄 Analyzing PR: CDC_AgS_2025/pull/123
✅ PR information retrieved successfully

📝 Checking commit format and signatures...
🔍 Checking 3 commits
✅ Format check completed
🔐 GPG signature verification: 2/3 passed
🎫 JIRA ticket verification: 3/3 valid

🔍 Executing deep code review...
📊 Analyzing 15 modified files
🛡️ Found 2 security issues
⚡ Found 3 performance optimization opportunities
📏 Code quality score: 8.5/10

📋 Generating comprehensive report...
✅ Report generated: .windsurf/Reports/comprehensive_pr_review_2026-03-05_16-30-00.md

🤖 Updating PR status...
⚠️ Request changes (format issues found)
💬 Review comment added
```

## 📈 Scoring System

### Comprehensive Score Composition
- **Format Check** (30%): commit format, GPG signature, JIRA validation
- **Code Quality** (40%): code style, structure, documentation
- **Security** (20%): vulnerability detection, security practices
- **Performance** (10%): performance optimization opportunities

### Score Levels
- **9.0-10.0**: 🟢 Excellent - Direct approval
- **7.0-8.9**: 🟡 Good - Minor improvement suggestions
- **5.0-6.9**: 🟠 Fair - Some modifications needed
- **0.0-4.9**: 🔴 Needs Improvement - Request changes

## 🎛️ Parameter Configuration

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `pr_url` | string | Required | GitHub PR URL |
| `dry_run` | boolean | false | Check only, don't execute |
| `focus` | string | "all" | Review focus (security,performance,code_quality) |
| `severity` | string | "medium" | Issue severity threshold |
| `template` | string | "general" | Review template (general,bios,security) |
| `auto_review` | boolean | true | Auto-set review status |
| `detailed_report` | boolean | true | Generate detailed report |

## 📁 Output Files

### Main Reports
- **Comprehensive Report**: `.windsurf/Reports/comprehensive_pr_review_YYYY-MM-DD_HH-MM-SS.md`
- **Format Check Report**: `.windsurf/Reports/pr_format_check_YYYY-MM-DD_HH-MM-SS.md`
- **Code Review Report**: `.windsurf/Reports/code_review_YYYY-MM-DD_HH-MM-SS.md`

### Report Structure
```markdown
# Comprehensive PR Review Report

## 📊 Executive Summary
- **PR Number**: #123
- **Comprehensive Score**: 7.8/10
- **Review Status**: Request Changes
- **Review Time**: 2026-03-05 16:30:00

## 📝 Format Check Results
### ✅ Passed Items
- Commit format: 3/3 passed
- JIRA tickets: 3/3 valid

### ❌ Failed Items
- GPG signatures: 2/3 passed (1 unsigned)

## 🔍 Code Review Results
### 🛡️ Security Issues (2)
- [High] Buffer overflow risk (file: xxx.c:123)
- [Medium] Unvalidated input (file: yyy.c:456)

### ⚡ Performance Suggestions (3)
- Optimize loop efficiency (file: zzz.c:789)
- Reduce memory allocation (file: aaa.c:101)

### 📏 Code Quality
- Score: 8.5/10
- Main issues: Naming conventions, documentation missing

## 🎯 Action Items
### 🔴 Must Fix
1. Fix buffer overflow risk
2. Add GPG signature to unsigned commit
3. Fix unvalidated input issues

### 🟡 Suggested Improvements
1. Optimize loop performance
2. Improve variable naming
3. Add function documentation

## 📈 Detailed Statistics
- **Files Modified**: 15
- **Code Lines**: +123/-45
- **Security Issues**: 2 (1 high, 1 medium)
- **Performance Issues**: 3
- **Format Issues**: 1
```

## 🔧 Setup Requirements

### 1. Install Dependencies (One-time)
```powershell
cd .windsurf/skills/pr-format-check && .\scripts\setup_env.ps1
cd .windsurf/skills/code-review && .\scripts\setup_env.ps1
```

### 2. Configuration Check
- **pr-format-check**: Uses `central_config.toml` for GitHub/JIRA tokens + local `config.toml` for skill-specific settings
- **code-review**: Uses local `config.toml` for review settings + `central_config.toml` via GitHubTool
- **Central Config**: Ensure `.windsurf/central_config.toml` has valid GitHub token and service URLs
- **Local Configs**: Verify skill-specific `config.toml` files are properly configured

## 🔄 Integration Logic

### Data Flow
1. **PR Information Extraction** → Format check + Code review
2. **Parallel Execution** → Both skills run simultaneously
3. **Result Merging** → Generate comprehensive report
4. **Automated Operations** → Update PR status and comments

### Decision Logic
```
if (format check fails OR high severity issues found):
    set review status = REQUEST_CHANGES
    generate detailed fix guide
else if (medium issues found):
    set review status = REQUEST_CHANGES  
    generate improvement suggestions
else:
    set review status = APPROVE
    generate confirmation comment
```

## 🎯 Use Cases

### 1. Regular PR Review
```bash
/comprehensive-pr-review --pr-url "https://githubcsg.cec.delllabs.net/CSG-Firmware-Engineering/CDC_AgS_2025/pull/123"
```

### 2. Security Critical Review
```bash
/comprehensive-pr-review --pr-url "..." --focus "security" --severity "high"
```

### 3. BIOS Specific Review
```bash
/comprehensive-pr-review --pr-url "..." --template "bios" --platform-specific "true"
```

### 4. Batch Review
```bash
/comprehensive-pr-review --batch --repo "CDC_AgS_2025" --pr-range "100-150"
```

## 🚀 Advanced Features

### Automation Rules
- **Auto Approval**: No issues and score > 9.0
- **Auto Request Changes**: High severity issues found
- **Auto Tagging**: Add tags based on issue types

### Integration Extensions
- **JIRA Integration**: Auto-create/update tasks
- **Slack Notifications**: Review result notifications
- **Report Dashboard**: Cumulative statistics and analysis

This comprehensive workflow provides complete, automated PR review process, significantly improving code quality and review efficiency!
