---
trigger: always_on
---
# Project Context & Directory Authority Map

**System Instruction:**
You are operating within a strictly structured environment. You MUST identify and respect the following **7 critical directory paths**.
Each directory has a specific **Authority Level** and **Usage Protocol** that you cannot violate.

---

## 1. ⚙️ Windsurf Configuration & Docs
* **Path Symbol:** `Windsurf/.windsurf/`
* **Description:** Contains IDE-specific settings, memory bank configurations, and tool definitions.
* **Authority:** **System Level**.
* **AI Protocol:**
    * Read these files to understand your own capabilities and constraints within the IDE.
    * Do not modify files in this directory unless explicitly instructed.

## 2. 🛡️ Generic Rules (The Iron Laws)
* **Path Symbol:** 
    - `Windsurf/GenericRules-json/`
    - `Windsurf/GenericRules/`
* **Description:** Contains the absolute, non-negotiable laws for AI behavior (e.g., "No Hallucinations", "Security First").
* **Authority:** **HIGHEST (Immutable)**.
* **AI Protocol:**
    * **VIOLATION IS FORBIDDEN.**
    * These rules override ALL other instructions.

## 3. 🎭 AI Persona (Identity Core)
* **Path Symbol:** `Windsurf/Persona/`
* **Description:** Contains the definitions of your role, expertise, and working philosophy (e.g., "Senior UEFI Architect").
* **Authority:** **Identity Level**.
* **AI Protocol:**
    * Adopt the tone, expertise level, and decision-making framework defined here.
    * Never break character.

## 4. 📚 Reference Documents (Source of Truth)
* **Path Symbol:** `Windsurf/Documents/`
* **Description:** The central repository for **External Specifications**, Datasheets, and Standards (e.g., UEFI Spec, Dell Proprietary Spec v2.0, Intel EDS).
* **Authority:** **Knowledge Authority (Read-Only)**.
* **AI Protocol:**
    * **Mandatory Lookup:** Before designing or coding, you MUST search this directory for relevant specifications.
    * **Citation Rule:** When answering technical questions, you MUST cite the specific document and section (e.g., ``).
    * **Anti-Hallucination:** If a user instruction conflicts with a document in this folder, you must **Cite the Document** and ask for clarification.

## 5. 📝 OpenSpec Artifacts (The Workspace)
* **Path Symbol:** `Windsurf/openspec/`
* **Description:** The structured workspace for the OpenSpec Framework (Proposals, Specs, Designs, Tasks).
* **Authority:** **Workflow Level**.
* **AI Protocol:**
    * **Write Access:** ALLOWED. This is your primary output destination.
    * **Structure Enforcement:** Strictly follow the folder structure (e.g., `changes/<slug>/`).
    * **Sequence:** Do not generate code until artifacts here are approved.

## 6. 💻 Code Base (Target Implementation)
* **Path Symbol:** 
    - `AgS_2024/`
    - `AgS_2025/`
    - `AgS_2026/`
* **Description:** The active source code repository (e.g., UEFI EDKII source, Driver files).
* **Authority:** **Target Level**.
* **AI Protocol:**
    * **Read Access:** ALWAYS allowed for context analysis.
    * **Write Access:** RESTRICTED. Wait for approved `tasks.md`.

## 7. 🛠️ Active Skills (Capabilities)
* **Path Symbol:** `Windsurf/.windsurf/skills/`
* **Description:** Contains executable workflows (e.g., OpenSpec Generator) that define *how* to perform complex tasks.
* **Authority:** **Capability Level**.
* **AI Protocol:**
    * Windsurf automatically indexes these skills.
    * Invoke them via trigger commands (e.g., `/openspec`) or when the user's intent matches the skill description.

---

**CRITICAL INITIALIZATION STEP:**
Before replying to any user query, confirm you have located these 7 directories and loaded their contexts.