---
name: dup-7zip-checker
description: Dell Update Package (DUP) 7-Zip version checker. Analyzes DUP EXE files to extract embedded 7-Zip version, architecture, compression method, and DUP framework info. Use when checking 7-Zip versions in DUP packages, batch scanning directories, or generating compliance reports.
---

# DUP 7-Zip Version Checker Skill

Dedicated skill for checking the embedded 7-Zip version inside Dell Update Package (DUP) EXE files.

## Function Features

### Core Analysis
- **Binary Pattern Scanning** - Directly scans EXE binary data for 7-Zip version strings
- **Multi-Architecture Detection** - Detects x64, x86, and arm64 SFX modules
- **7z Archive Header Parsing** - Reads embedded 7z archive format version
- **DUP Framework Info Extraction** - Extracts DUP framework version, product name, description

### Advanced Features
- **7-Zip CLI Integration** - Uses installed 7-Zip for detailed archive analysis (compression method, file count, etc.)
- **Batch Directory Scanning** - Scan entire directories for DUP files
- **Multiple Output Formats** - Text, JSON, Markdown
- **Bilingual Report Generation** - English + Traditional Chinese reports saved to `.windsurf/Reports/`

## Configuration

### 1. Configuration File
Edit `config.toml`:

```toml
[scanner]
extensions = [".exe", ".EXE"]
recursive = true
max_file_size_mb = 2048

[sevenzip]
path = ""           # Auto-detect if empty
use_cli = true      # Use 7z CLI for additional details

[output]
format = "text"     # text, json, markdown
include_archive_details = true
include_dup_info = true
language = "bilingual"
```

### 2. Prerequisites
- **Python 3.11+** (standard library only, no extra dependencies)
- **7-Zip** (optional, for enhanced archive analysis) - auto-detected from standard paths

## Usage

### 1. Check a Single DUP File

```powershell
# Basic check (text output)
python .windsurf/skills/dup-7zip-checker/scripts/dup_7zip_checker.py check "C:\Downloads\MyDUP.EXE"

# JSON output
python .windsurf/skills/dup-7zip-checker/scripts/dup_7zip_checker.py check "C:\Downloads\MyDUP.EXE" --format json

# Markdown output
python .windsurf/skills/dup-7zip-checker/scripts/dup_7zip_checker.py check "C:\Downloads\MyDUP.EXE" --format markdown

# Binary-only analysis (skip 7-Zip CLI)
python .windsurf/skills/dup-7zip-checker/scripts/dup_7zip_checker.py check "C:\Downloads\MyDUP.EXE" --no-cli
```

### 2. Batch Scan a Directory

```powershell
# Scan directory recursively
python .windsurf/skills/dup-7zip-checker/scripts/dup_7zip_checker.py batch "C:\Downloads" --recursive

# Scan directory (non-recursive)
python .windsurf/skills/dup-7zip-checker/scripts/dup_7zip_checker.py batch "C:\Downloads" --no-recursive

# JSON output for batch
python .windsurf/skills/dup-7zip-checker/scripts/dup_7zip_checker.py batch "C:\Downloads" --format json
```

### 3. Generate Report

```powershell
# Generate bilingual report (auto-saved to .windsurf/Reports/)
python .windsurf/skills/dup-7zip-checker/scripts/dup_7zip_checker.py report "C:\Downloads\MyDUP.EXE"

# Custom output path
python .windsurf/skills/dup-7zip-checker/scripts/dup_7zip_checker.py report "C:\Downloads" --output my_report.md
```

### 4. API Usage (for other skills)

```python
from dup_7zip_checker import DUP7ZipChecker

checker = DUP7ZipChecker()

# Check single file
result = checker.check_file("C:\\Downloads\\MyDUP.EXE")
print(result["sevenzip_versions"])  # List of detected 7-Zip versions

# Batch scan
batch_result = checker.check_directory("C:\\Downloads")
for r in batch_result["results"]:
    print(f"{r['file_name']}: {r['sevenzip_versions']}")

# Format output
print(checker.format_result(result, output_format="markdown"))

# Generate report
report_path = checker.generate_report(result)
```

## Usage Guidelines (Agent Behavior)

### Command Priority Guidelines
When users ask about DUP 7-Zip versions:
1. **Single file check:** Use `check` command with the file path
2. **Multiple files:** Use `batch` command on the directory
3. **Full report needed:** Use `report` command

### Common User Requests & Commands
| User Request Pattern | Recommended Command |
|---------------------|---------------------|
| "Check 7-Zip version in DUP" | `check <file>` |
| "What 7-Zip version is in this DUP?" | `check <file> --format text` |
| "Scan all DUP files in folder" | `batch <directory>` |
| "Generate a report" | `report <file_or_dir>` |
| "I need JSON output" | `check <file> --format json` |

### Expected Output Format

**Text output example:**
```
File: Intel-NPU-Driver_154CY_WIN64_32.0.100.4512_A00_02.EXE
Size: 27.63 MB

7-Zip Embedded Versions (2 found):
  - Version 25.01 (x64) [2025-08-03]
  - Version 25.01 (arm64) [2025-08-03]

DUP Framework Info:
  Description: Dell Update Package: Intel NPU Driver, 32.0.100.4512, A00
  Framework Version: 5.6.2.99
  Product Version: 32.0.100.4512
```

**JSON output example:**
```json
{
  "file_name": "MyDUP.EXE",
  "sevenzip_versions": [
    {
      "version": "25.01",
      "architecture": "x64",
      "date": "2025-08-03"
    }
  ],
  "dup_info": {
    "dup_framework_version": "5.6.2.99",
    "product_version": "32.0.100.4512"
  }
}
```

## How It Works

1. **Binary Scan** - Reads the DUP EXE file as raw bytes and searches for the regex pattern `7-Zip X.XX (arch) : Copyright ...` to find all embedded 7-Zip SFX module versions.
2. **7z Header Parsing** - Locates the `7z\xBC\xAF\x27\x1C` magic signature to find the embedded archive and reads its format version.
3. **PE Version Info** - Extracts DUP framework metadata (FileVersion, ProductVersion, ProductName, FileDescription) from the PE resource section.
4. **CLI Enhancement** (optional) - Runs `7z l -slt` on the file to get compression method, solid flag, and file count details.

## Troubleshooting

### Common Issues

#### 1. Python Not Found
```
ERROR: Python was not found
```
**Solution:** Ensure Python 3.11+ is installed and in PATH. On Windows, use the full path, e.g., `"C:\Program Files\Python314\python.exe"`

#### 2. 7-Zip CLI Not Available
The tool will still work without 7-Zip CLI (binary-only mode). To enable full analysis, install 7-Zip from https://www.7-zip.org/ or set the path in `config.toml`.

#### 3. File Too Large
Adjust `max_file_size_mb` in `config.toml` if you need to scan very large DUP files.

#### 4. No 7-Zip Version Found
If the file is not a Dell DUP or does not use 7-Zip SFX, no version will be detected. Verify the file is a genuine DUP package.

---

*Last Update: 2026-04-10*
*Version: 1.0*
