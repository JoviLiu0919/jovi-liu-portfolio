#!/usr/bin/env python3
"""
Dell Update Package (DUP) 7-Zip Version Checker

Analyzes DUP EXE files to extract embedded 7-Zip version information,
archive metadata, and DUP framework details.

Usage:
    python dup_7zip_checker.py check <file_or_directory> [options]
    python dup_7zip_checker.py batch <directory> [options]
    python dup_7zip_checker.py report <file_or_directory> [options]
"""

import argparse
import json
import os
import re
import struct
import subprocess
import sys
from datetime import datetime
from pathlib import Path

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib
    except ImportError:
        tomllib = None


class DUP7ZipChecker:
    """Analyzes Dell Update Package (DUP) EXE files for embedded 7-Zip version info."""

    # Known 7-Zip version patterns in binary
    SEVENZIP_VERSION_PATTERN = re.compile(
        rb"7-Zip\s+(\d+\.\d+)\s+\((x64|x86|arm64|ARM64)\)\s*:\s*Copyright\s*\(c\)\s*[\d\-]+\s*Igor Pavlov\s*:\s*([\d\-]+)"
    )
    # 7z archive signature
    SEVENZIP_SIGNATURE = b"7z\xbc\xaf\x27\x1c"
    # PE version info patterns (UTF-16LE)
    PE_FILEVERSION_PATTERN = re.compile(
        rb"F\x00i\x00l\x00e\x00V\x00e\x00r\x00s\x00i\x00o\x00n\x00\x00\x00.{0,8}([\d\x00\.]+)\x00"
    )
    PE_PRODUCTNAME_PATTERN = re.compile(
        rb"P\x00r\x00o\x00d\x00u\x00c\x00t\x00N\x00a\x00m\x00e\x00\x00\x00.{0,8}([\x20-\x7e\x00]+?)\x00\x00\x00"
    )
    PE_PRODUCTVERSION_PATTERN = re.compile(
        rb"P\x00r\x00o\x00d\x00u\x00c\x00t\x00V\x00e\x00r\x00s\x00i\x00o\x00n\x00\x00\x00.{0,8}([\d\x00\.]+)\x00"
    )
    PE_FILEDESC_PATTERN = re.compile(
        rb"F\x00i\x00l\x00e\x00D\x00e\x00s\x00c\x00r\x00i\x00p\x00t\x00i\x00o\x00n\x00\x00\x00.{0,8}([\x20-\x7e\x00]+?)\x00\x00\x00"
    )

    def __init__(self, config_path=None):
        self.config = self._load_config(config_path)
        self.sevenzip_path = self._find_7zip()

    def _load_config(self, config_path=None):
        """Load configuration from config.toml."""
        default_config = {
            "scanner": {
                "extensions": [".exe", ".EXE"],
                "recursive": True,
                "max_file_size_mb": 2048,
            },
            "sevenzip": {
                "path": "",
                "use_cli": True,
            },
            "output": {
                "format": "text",
                "include_archive_details": True,
                "include_dup_info": True,
                "language": "bilingual",
            },
        }

        if config_path is None:
            config_path = Path(__file__).parent.parent / "config.toml"

        if config_path and Path(config_path).exists():
            try:
                if tomllib:
                    with open(config_path, "rb") as f:
                        file_config = tomllib.load(f)
                    for section, values in file_config.items():
                        if section in default_config and isinstance(values, dict):
                            default_config[section].update(values)
                        else:
                            default_config[section] = values
            except Exception as e:
                print(f"[WARNING] Failed to load config: {e}, using defaults.")

        return default_config

    def _find_7zip(self):
        """Locate 7-Zip executable on the system."""
        # Check config first
        config_path = self.config.get("sevenzip", {}).get("path", "")
        if config_path and Path(config_path).exists():
            return str(config_path)

        # Common installation paths (Windows)
        candidates = [
            r"C:\Program Files\7-Zip\7z.exe",
            r"C:\Program Files (x86)\7-Zip\7z.exe",
        ]

        # Check PATH
        for cmd in ["7z", "7z.exe", "7za", "7za.exe"]:
            try:
                result = subprocess.run(
                    ["where", cmd] if os.name == "nt" else ["which", cmd],
                    capture_output=True, text=True, timeout=5
                )
                if result.returncode == 0:
                    path = result.stdout.strip().splitlines()[0]
                    if Path(path).exists():
                        return path
            except Exception:
                pass

        for path in candidates:
            if Path(path).exists():
                return path

        return None

    def check_file(self, file_path):
        """Check a single DUP EXE file for 7-Zip version info."""
        file_path = Path(file_path)
        if not file_path.exists():
            return {"error": f"File not found: {file_path}", "file": str(file_path)}
        if not file_path.is_file():
            return {"error": f"Not a file: {file_path}", "file": str(file_path)}

        max_size = self.config.get("scanner", {}).get("max_file_size_mb", 2048)
        file_size = file_path.stat().st_size
        if file_size > max_size * 1024 * 1024:
            return {"error": f"File too large ({file_size} bytes)", "file": str(file_path)}

        result = {
            "file": str(file_path),
            "file_name": file_path.name,
            "file_size_bytes": file_size,
            "file_size_mb": round(file_size / (1024 * 1024), 2),
            "scan_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "sevenzip_versions": [],
            "sevenzip_archive": None,
            "dup_info": None,
        }

        try:
            data = file_path.read_bytes()
        except Exception as e:
            result["error"] = f"Failed to read file: {e}"
            return result

        # 1. Extract 7-Zip SFX version strings from binary
        result["sevenzip_versions"] = self._extract_7zip_versions(data)

        # 2. Find 7z archive header and extract format version
        result["sevenzip_archive"] = self._extract_7z_archive_info(data)

        # 3. Extract DUP framework info from PE version resources
        if self.config.get("output", {}).get("include_dup_info", True):
            result["dup_info"] = self._extract_dup_info(data)

        # 4. Use 7-Zip CLI for additional archive details if available
        if (self.sevenzip_path
                and self.config.get("sevenzip", {}).get("use_cli", True)
                and self.config.get("output", {}).get("include_archive_details", True)):
            result["archive_details"] = self._get_cli_archive_info(file_path)

        return result

    def _extract_7zip_versions(self, data):
        """Extract all 7-Zip version strings from binary data."""
        versions = []
        for match in self.SEVENZIP_VERSION_PATTERN.finditer(data):
            version_str = match.group(1).decode("ascii", errors="ignore")
            arch = match.group(2).decode("ascii", errors="ignore")
            date_str = match.group(3).decode("ascii", errors="ignore")
            versions.append({
                "version": version_str,
                "architecture": arch,
                "date": date_str,
                "full_string": match.group(0).decode("ascii", errors="ignore"),
                "offset": match.start(),
            })
        return versions

    def _extract_7z_archive_info(self, data):
        """Find embedded 7z archive and extract header info."""
        offset = data.find(self.SEVENZIP_SIGNATURE)
        if offset < 0:
            return None

        info = {"offset": offset}

        # 7z header: signature(6) + major(1) + minor(1) + ...
        if len(data) > offset + 12:
            major = data[offset + 6]
            minor = data[offset + 7]
            info["format_version"] = f"{major}.{minor}"

        # Calculate embedded archive size (approximate)
        next_offset = data.find(self.SEVENZIP_SIGNATURE, offset + 6)
        if next_offset > 0:
            info["approximate_size_bytes"] = next_offset - offset
        else:
            info["approximate_size_bytes"] = len(data) - offset

        return info

    def _extract_dup_info(self, data):
        """Extract DUP framework info from PE version resources (UTF-16LE StringFileInfo)."""
        info = {}

        # Parse PE StringFileInfo blocks (UTF-16LE encoded)
        # Find the DUP's own StringFileInfo block (contains "Dell Inc.", not "Igor Pavlov")
        sfi_pattern = "StringFileInfo".encode("utf-16-le")
        dell_pattern = "Dell Inc.".encode("utf-16-le")
        offset = 0

        while True:
            idx = data.find(sfi_pattern, offset)
            if idx < 0:
                break

            # Read a generous block (PE version info can span 10KB+)
            block = data[idx:idx + 16000]
            # Check if this block belongs to Dell (not 7-Zip)
            if dell_pattern in block:
                text = block.decode("utf-16-le", errors="replace")
                # Remove null chars and non-printable for easier parsing
                clean = "".join(c if (32 <= ord(c) < 127) else "|" for c in text)
                info = self._parse_pe_version_strings(clean)
                break

            offset = idx + len(sfi_pattern)

        # Fallback: try ASCII patterns (some older DUPs use ASCII comment blocks)
        if not info:
            text = data.decode("ascii", errors="ignore")
            fv_match = re.search(r"FileVersion:\s*([\d\.]+)", text)
            if fv_match:
                info["dup_framework_version"] = fv_match.group(1)
            pv_match = re.search(r"ProductVersion:\s*([\d\.]+)", text)
            if pv_match:
                info["product_version"] = pv_match.group(1)
            pn_match = re.search(r"ProductName:\s*(.+?)(?:\r|\n|\x00)", text)
            if pn_match:
                info["product_name"] = pn_match.group(1).strip()
            fd_match = re.search(r"FileDescription:\s*(.+?)(?:\r|\n|\x00)", text)
            if fd_match:
                info["file_description"] = fd_match.group(1).strip()
            cn_match = re.search(r"CompanyName:\s*(.+?)(?:\r|\n|\x00)", text)
            if cn_match:
                info["company_name"] = cn_match.group(1).strip()

        return info if info else None

    def _parse_pe_version_strings(self, clean_text):
        """Parse version info fields from a cleaned PE StringFileInfo block."""
        info = {}
        # Map of PE version info keys to output keys
        field_map = {
            "CompanyName": "company_name",
            "FileDescription": "file_description",
            "FileVersion": "dup_framework_version",
            "ProductVersion": "product_version",
            "ProductName": "product_name",
            "InternalName": "internal_name",
            "OriginalFilename": "original_filename",
            "LegalCopyright": "legal_copyright",
        }

        # All known keys for boundary detection
        all_keys = list(field_map.keys()) + ["VarFileInfo", "Translation"]

        for pe_key, out_key in field_map.items():
            idx = clean_text.find(pe_key)
            if idx < 0:
                continue
            # Skip past the key name and leading separator(s)
            val_start = idx + len(pe_key)
            remainder = clean_text[val_start:val_start + 500]
            # Strip leading pipes
            remainder = remainder.lstrip("|")

            # Find the next known key as boundary
            end_pos = len(remainder)
            for other_key in all_keys:
                if other_key == pe_key:
                    continue
                pos = remainder.find(other_key)
                if 0 < pos < end_pos:
                    end_pos = pos

            value = remainder[:end_pos]
            # Clean: replace pipe sequences with nothing, strip whitespace
            value = re.sub(r"\|{2,}", "", value)
            value = value.replace("|", " ").strip()
            # For version fields, keep only version number characters
            if out_key in ("dup_framework_version", "product_version"):
                ver_match = re.match(r"[\d\.]+", value)
                if ver_match:
                    value = ver_match.group(0)
            if value:
                info[out_key] = value

        return info

    def _get_cli_archive_info(self, file_path):
        """Use 7-Zip CLI to get archive details."""
        if not self.sevenzip_path:
            return None

        try:
            result = subprocess.run(
                [self.sevenzip_path, "l", "-slt", str(file_path)],
                capture_output=True, text=True, timeout=60, encoding="utf-8", errors="replace"
            )
            if result.returncode != 0:
                return {"error": f"7z CLI returned code {result.returncode}"}

            output = result.stdout
            details = {}

            # Extract archive type
            type_match = re.search(r"^Type\s*=\s*(.+)$", output, re.MULTILINE)
            if type_match:
                details["archive_type"] = type_match.group(1).strip()

            # Extract method
            method_match = re.search(r"^Method\s*=\s*(.+)$", output, re.MULTILINE)
            if method_match:
                details["compression_method"] = method_match.group(1).strip()

            # Extract solid flag
            solid_match = re.search(r"^Solid\s*=\s*(.+)$", output, re.MULTILINE)
            if solid_match:
                details["solid"] = solid_match.group(1).strip()

            # Extract blocks
            blocks_match = re.search(r"^Blocks\s*=\s*(.+)$", output, re.MULTILINE)
            if blocks_match:
                details["blocks"] = blocks_match.group(1).strip()

            # Count files in archive
            file_count = len(re.findall(r"^Path = [^\[\-]", output, re.MULTILINE))
            details["file_count"] = file_count

            # Extract physical size
            phys_match = re.search(r"^Physical Size\s*=\s*(\d+)$", output, re.MULTILINE)
            if phys_match:
                details["physical_size_bytes"] = int(phys_match.group(1))

            return details

        except subprocess.TimeoutExpired:
            return {"error": "7z CLI timed out"}
        except Exception as e:
            return {"error": f"7z CLI error: {e}"}

    def check_directory(self, directory, recursive=None):
        """Scan a directory for DUP EXE files and check each one."""
        directory = Path(directory)
        if not directory.exists() or not directory.is_dir():
            return {"error": f"Directory not found: {directory}"}

        if recursive is None:
            recursive = self.config.get("scanner", {}).get("recursive", True)

        extensions = self.config.get("scanner", {}).get("extensions", [".exe", ".EXE"])
        pattern = "**/*" if recursive else "*"
        results = []

        for ext in extensions:
            for file_path in directory.glob(f"{pattern}{ext}"):
                if file_path.is_file():
                    result = self.check_file(file_path)
                    # Only include files that have 7-Zip embedded (likely DUP files)
                    if result.get("sevenzip_versions"):
                        results.append(result)

        return {
            "directory": str(directory),
            "scan_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "files_found": len(results),
            "results": results,
        }

    def format_result(self, result, output_format=None):
        """Format check result for display."""
        fmt = output_format or self.config.get("output", {}).get("format", "text")

        if fmt == "json":
            return json.dumps(result, indent=2, ensure_ascii=False)
        elif fmt == "markdown":
            return self._format_markdown(result)
        else:
            return self._format_text(result)

    def _format_text(self, result):
        """Format result as plain text."""
        lines = []

        # Single file result
        if "file" in result and "sevenzip_versions" in result:
            return self._format_single_text(result)

        # Batch result
        if "results" in result:
            lines.append(f"=== DUP 7-Zip Version Scan ===")
            lines.append(f"Directory: {result.get('directory', 'N/A')}")
            lines.append(f"Scan Time: {result.get('scan_time', 'N/A')}")
            lines.append(f"DUP Files Found: {result.get('files_found', 0)}")
            lines.append("=" * 60)
            for r in result.get("results", []):
                lines.append("")
                lines.append(self._format_single_text(r))
                lines.append("-" * 60)

        return "\n".join(lines)

    def _format_single_text(self, result):
        """Format a single file result as text."""
        lines = []
        lines.append(f"File: {result.get('file_name', result.get('file', 'N/A'))}")
        lines.append(f"Size: {result.get('file_size_mb', 'N/A')} MB")

        if result.get("error"):
            lines.append(f"ERROR: {result['error']}")
            return "\n".join(lines)

        # 7-Zip versions
        versions = result.get("sevenzip_versions", [])
        if versions:
            lines.append(f"\n7-Zip Embedded Versions ({len(versions)} found):")
            for v in versions:
                lines.append(f"  - Version {v['version']} ({v['architecture']}) [{v['date']}]")
        else:
            lines.append("\nNo embedded 7-Zip version found.")

        # Archive info
        archive = result.get("sevenzip_archive")
        if archive:
            lines.append(f"\n7z Archive:")
            lines.append(f"  Format Version: {archive.get('format_version', 'N/A')}")
            lines.append(f"  Offset: {archive.get('offset', 'N/A')}")

        # DUP info
        dup = result.get("dup_info")
        if dup:
            lines.append(f"\nDUP Framework Info:")
            if dup.get("file_description"):
                lines.append(f"  Description: {dup['file_description']}")
            if dup.get("dup_framework_version"):
                lines.append(f"  Framework Version: {dup['dup_framework_version']}")
            if dup.get("product_version"):
                lines.append(f"  Product Version: {dup['product_version']}")
            if dup.get("product_name"):
                lines.append(f"  Product Name: {dup['product_name']}")

        # CLI archive details
        details = result.get("archive_details")
        if details and not details.get("error"):
            lines.append(f"\nArchive Details:")
            if details.get("compression_method"):
                lines.append(f"  Compression: {details['compression_method']}")
            if details.get("solid"):
                lines.append(f"  Solid: {details['solid']}")
            if details.get("file_count"):
                lines.append(f"  Files: {details['file_count']}")

        return "\n".join(lines)

    def _format_markdown(self, result):
        """Format result as Markdown."""
        lines = []

        # Single file
        if "file" in result and "sevenzip_versions" in result:
            return self._format_single_markdown(result)

        # Batch
        if "results" in result:
            lines.append(f"# DUP 7-Zip Version Scan Report")
            lines.append(f"")
            lines.append(f"- **Directory:** `{result.get('directory', 'N/A')}`")
            lines.append(f"- **Scan Time:** {result.get('scan_time', 'N/A')}")
            lines.append(f"- **DUP Files Found:** {result.get('files_found', 0)}")
            lines.append("")

            # Summary table
            lines.append("## Summary")
            lines.append("")
            lines.append("| File | 7-Zip Version | Architecture | DUP Framework | Product Version |")
            lines.append("|------|---------------|-------------|---------------|-----------------|")
            for r in result.get("results", []):
                versions = r.get("sevenzip_versions", [])
                ver_str = ", ".join(v["version"] for v in versions) if versions else "N/A"
                arch_str = ", ".join(set(v["architecture"] for v in versions)) if versions else "N/A"
                dup = r.get("dup_info") or {}
                fw_ver = dup.get("dup_framework_version", "N/A")
                prod_ver = dup.get("product_version", "N/A")
                lines.append(f"| {r.get('file_name', 'N/A')} | {ver_str} | {arch_str} | {fw_ver} | {prod_ver} |")

            lines.append("")

            # Detailed sections
            lines.append("## Details")
            lines.append("")
            for r in result.get("results", []):
                lines.append(self._format_single_markdown(r))
                lines.append("---")
                lines.append("")

        return "\n".join(lines)

    def _format_single_markdown(self, result):
        """Format a single file result as Markdown."""
        lines = []
        lines.append(f"### {result.get('file_name', result.get('file', 'N/A'))}")
        lines.append("")
        lines.append(f"- **Path:** `{result.get('file', 'N/A')}`")
        lines.append(f"- **Size:** {result.get('file_size_mb', 'N/A')} MB")

        if result.get("error"):
            lines.append(f"- **ERROR:** {result['error']}")
            return "\n".join(lines)

        versions = result.get("sevenzip_versions", [])
        if versions:
            lines.append(f"")
            lines.append(f"**Embedded 7-Zip Versions:**")
            lines.append("")
            lines.append("| Version | Architecture | Date | Offset |")
            lines.append("|---------|-------------|------|--------|")
            for v in versions:
                lines.append(f"| {v['version']} | {v['architecture']} | {v['date']} | {v['offset']} |")
        else:
            lines.append(f"- **7-Zip:** Not found")

        dup = result.get("dup_info")
        if dup:
            lines.append("")
            lines.append("**DUP Framework Info:**")
            lines.append("")
            if dup.get("file_description"):
                lines.append(f"- **Description:** {dup['file_description']}")
            if dup.get("dup_framework_version"):
                lines.append(f"- **Framework Version:** {dup['dup_framework_version']}")
            if dup.get("product_version"):
                lines.append(f"- **Product Version:** {dup['product_version']}")
            if dup.get("product_name"):
                lines.append(f"- **Product Name:** {dup['product_name']}")

        details = result.get("archive_details")
        if details and not details.get("error"):
            lines.append("")
            lines.append("**Archive Details:**")
            lines.append("")
            if details.get("compression_method"):
                lines.append(f"- **Compression:** {details['compression_method']}")
            if details.get("solid"):
                lines.append(f"- **Solid:** {details['solid']}")
            if details.get("file_count"):
                lines.append(f"- **Files in Archive:** {details['file_count']}")

        return "\n".join(lines)

    def generate_report(self, result, output_path=None):
        """Generate and save a bilingual report."""
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

        # Build report content
        md_content = self.format_result(result, output_format="markdown")

        # Add bilingual summary
        summary_lines = []
        summary_lines.append("")
        summary_lines.append("---")
        summary_lines.append("")
        summary_lines.append("## Bilingual Summary")
        summary_lines.append("")

        if "results" in result:
            count = result.get("files_found", 0)
            summary_lines.append(f"**English:** Scanned directory and found {count} DUP file(s) with embedded 7-Zip.")
            summary_lines.append(f"**Traditional Chinese:** 掃描目錄後發現 {count} 個內嵌 7-Zip 的 DUP 檔案。")
        elif "sevenzip_versions" in result:
            versions = result.get("sevenzip_versions", [])
            if versions:
                ver_str = ", ".join(f"{v['version']} ({v['architecture']})" for v in versions)
                summary_lines.append(f"**English:** Found embedded 7-Zip version(s): {ver_str}")
                summary_lines.append(f"**Traditional Chinese:** 發現內嵌 7-Zip 版本: {ver_str}")
            else:
                summary_lines.append("**English:** No embedded 7-Zip version found in this file.")
                summary_lines.append("**Traditional Chinese:** 在此檔案中未發現內嵌的 7-Zip 版本。")

        full_report = f"""---
# DUP 7-Zip Version Check Report
**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Tool:** DUP 7-Zip Checker v1.0
---

{md_content}
{"".join(chr(10) + l for l in summary_lines)}
"""

        if output_path is None:
            reports_dir = Path(__file__).parent.parent.parent.parent / "Reports"
            reports_dir.mkdir(exist_ok=True)
            output_path = reports_dir / f"dup_7zip_check_{timestamp}.md"

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(full_report, encoding="utf-8")

        return str(output_path)


def main():
    parser = argparse.ArgumentParser(
        description="Dell Update Package (DUP) 7-Zip Version Checker",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Check a single DUP file
  python dup_7zip_checker.py check "C:\\Downloads\\MyDUP.EXE"

  # Batch scan a directory
  python dup_7zip_checker.py batch "C:\\Downloads" --recursive

  # Generate a markdown report
  python dup_7zip_checker.py report "C:\\Downloads\\MyDUP.EXE" --output report.md

  # Output as JSON
  python dup_7zip_checker.py check "C:\\Downloads\\MyDUP.EXE" --format json
        """
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # check command
    check_parser = subparsers.add_parser("check", help="Check a single DUP file or directory")
    check_parser.add_argument("path", help="Path to DUP EXE file or directory")
    check_parser.add_argument("--format", choices=["text", "json", "markdown"], default="text",
                              help="Output format (default: text)")
    check_parser.add_argument("--config", help="Path to config.toml")
    check_parser.add_argument("--no-cli", action="store_true",
                              help="Skip 7-Zip CLI analysis (binary-only)")

    # batch command
    batch_parser = subparsers.add_parser("batch", help="Batch scan a directory for DUP files")
    batch_parser.add_argument("directory", help="Directory to scan")
    batch_parser.add_argument("--recursive", action="store_true", default=True,
                              help="Scan recursively (default: True)")
    batch_parser.add_argument("--no-recursive", dest="recursive", action="store_false",
                              help="Do not scan subdirectories")
    batch_parser.add_argument("--format", choices=["text", "json", "markdown"], default="text",
                              help="Output format (default: text)")
    batch_parser.add_argument("--config", help="Path to config.toml")

    # report command
    report_parser = subparsers.add_parser("report", help="Generate a full report")
    report_parser.add_argument("path", help="Path to DUP EXE file or directory")
    report_parser.add_argument("--output", "-o", help="Output report file path")
    report_parser.add_argument("--config", help="Path to config.toml")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    checker = DUP7ZipChecker(config_path=getattr(args, "config", None))

    if args.command == "check":
        path = Path(args.path)
        if getattr(args, "no_cli", False):
            checker.config["sevenzip"]["use_cli"] = False

        if path.is_file():
            result = checker.check_file(path)
        elif path.is_dir():
            result = checker.check_directory(path)
        else:
            print(f"ERROR: Path not found: {path}", file=sys.stderr)
            sys.exit(1)

        print(checker.format_result(result, output_format=args.format))

    elif args.command == "batch":
        result = checker.check_directory(
            args.directory,
            recursive=args.recursive,
        )
        print(checker.format_result(result, output_format=args.format))

    elif args.command == "report":
        path = Path(args.path)
        if path.is_file():
            result = checker.check_file(path)
        elif path.is_dir():
            result = checker.check_directory(path)
        else:
            print(f"ERROR: Path not found: {path}", file=sys.stderr)
            sys.exit(1)

        report_path = checker.generate_report(result, output_path=getattr(args, "output", None))
        print(f"Report saved to: {report_path}")
        print()
        print(checker.format_result(result, output_format="markdown"))


if __name__ == "__main__":
    main()
