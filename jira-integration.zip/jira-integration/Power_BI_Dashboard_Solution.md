# Power BI Dashboard Solution for JIRA Filter 147288

## Overview
This solution provides a complete Power BI dashboard for the JIRA filter "2026 SUS PIMS Collection" (Filter ID: 147288).

## Data Source
- **JIRA Filter**: 2026 SUS PIMS Collection
- **Filter ID**: 147288
- **Total Issues**: 1,026
- **Project**: PIMS
- **Issue Type**: Defect
- **Time Range**: 2026-01-01 to 2026-12-31

## Data Fields
The extracted CSV file contains the following fields:
- Key: JIRA issue key
- Summary: Issue summary
- Status: Current status
- Priority: Issue priority
- Assignee: Assigned user
- Created: Creation date
- Updated: Last update date
- Components: JIRA components
- Labels: Issue labels
- LOB Found: Line of Business where issue was found
- Component_Subcomponent: Component/Subcomponent classification

## Files Provided
1. **jira_filter_147288_powerbi.csv**: Clean data file ready for Power BI import
2. **jira_filter_147288_powerbi.json**: JSON format for reference
3. **extract_powerbi_data.py**: Script to refresh data from JIRA
4. **powerbi_automated_refresh.py**: Automated refresh script for Power BI

## Power BI Dashboard Setup Instructions

### Step 1: Import Data into Power BI Desktop
1. Open Power BI Desktop
2. Click "Get Data" → "Text/CSV"
3. Select `jira_filter_147288_powerbi.csv`
4. Click "Load"

### Step 2: Create Visualizations

#### Status Distribution (Donut Chart)
1. Select "Donut Chart" from Visualizations
2. Drag "Status" to "Legend" and "Values"
3. Format: Show percentage and count

#### LOB Found Distribution (Column Chart)
1. Select "Column Chart" from Visualizations
2. Drag "LOB Found" to "Axis"
3. Drag "Key" to "Values" (Count)
4. Sort by count descending

#### Component/Subcomponent Analysis (Tree Map)
1. Select "Tree Map" from Visualizations
2. Drag "Component_Subcomponent" to "Group"
3. Drag "Key" to "Values" (Count)

#### Status by LOB Found (Matrix)
1. Select "Matrix" from Visualizations
2. Drag "LOB Found" to "Rows"
3. Drag "Status" to "Columns"
4. Drag "Key" to "Values" (Count)

#### Timeline Analysis (Line Chart)
1. Select "Line Chart" from Visualizations
2. Drag "Created" to "Axis"
3. Drag "Key" to "Values" (Count)
4. Add "Status" to "Legend"

### Step 3: Add Slicers (Filters)
Create slicers for the requested filters:

1. **Status Slicer**:
   - Add "Slicer" visual
   - Drag "Status" to the field
   - Format as buttons

2. **LOB Found Slicer**:
   - Add "Slicer" visual
   - Drag "LOB Found" to the field
   - Format as dropdown list

3. **Component/Subcomponent Slicer**:
   - Add "Slicer" visual
   - Drag "Component_Subcomponent" to the field
   - Format as search box

### Step 4: Create Dashboard Layout
Recommended layout:
- **Top row**: Title, KPI cards (Total Issues, Open Issues, Closed Issues)
- **Middle row**: Status distribution (left), LOB distribution (right)
- **Bottom row**: Component analysis (left), Status by LOB matrix (right)
- **Right sidebar**: Slicers (Status, LOB Found, Component/Subcomponent)

### Step 5: Publish to Power BI Service
1. Click "Publish" in Power BI Desktop
2. Select your workspace
3. Wait for upload to complete
4. Access dashboard in Power BI Service

## Automated Data Refresh

### Option 1: Manual Refresh Script
Run the `extract_powerbi_data.py` script to refresh data from JIRA:
```powershell
cd .windsurf/skills/jira-integration
python extract_powerbi_data.py
```

### Option 2: Scheduled Refresh
For Power BI Service:
1. Upload the CSV file to OneDrive or SharePoint
2. Configure Power BI dataset to use the cloud file
3. Set up scheduled refresh in Power BI Service
4. Update the CSV file regularly using the extraction script

### Option 3: Power BI API Integration
Use the `powerbi_automated_refresh.py` script to push data directly to Power BI Service (requires Power BI API credentials).

## Customization Options

### Additional Visualizations
- **Priority Distribution**: Pie chart showing issue priority
- **Assignee Workload**: Bar chart showing issues per assignee
- **Trend Analysis**: Line chart showing issue creation over time
- **Resolution Time**: Calculate days between Created and Updated/Resolved

### Advanced Filters
- Date range slicer for Created/Updated fields
- Priority slicer
- Assignee slicer
- Labels slicer

### Calculated Measures
- Open Issues: Count where Status not in ("Closed", "Resolved", "Cancelled")
- Resolution Rate: Closed Issues / Total Issues
- Average Resolution Time: Average days to resolution

## Maintenance
- Run `extract_powerbi_data.py` weekly or daily to refresh data
- Update the CSV file in Power BI Service
- Monitor dashboard performance
- Adjust visualizations based on user feedback

## Troubleshooting
- **Data not refreshing**: Check JIRA API access and token validity
- **Missing fields**: Verify custom field IDs are correct
- **Performance issues**: Consider using data source refresh instead of file upload
- **Access denied**: Ensure Power BI Service permissions are configured

## Support
For issues with:
- JIRA data extraction: Check jira-integration skill documentation
- Power BI setup: Refer to Microsoft Power BI documentation
- API integration: Verify Power BI API credentials and permissions
