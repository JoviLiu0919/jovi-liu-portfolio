#!/usr/bin/env python3
"""
Automated Power BI Data Refresh Script
This script extracts JIRA data and can optionally push to Power BI Service via API
"""
import json
import csv
from pathlib import Path
from datetime import datetime
try:
    import tomllib
except ImportError:
    import tomli as tomllib
from atlassian import Jira

# Load JIRA config
config_path = Path(__file__).parent / "config.toml"
with open(config_path, "rb") as f:
    config = tomllib.load(f)

jira_cfg = config.get("jira", {})

def extract_jira_data():
    """Extract data from JIRA filter 147288"""
    print(f"=== Starting JIRA Data Extraction - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===")
    
    jira = Jira(
        url=jira_cfg.get("url"),
        token=jira_cfg.get("token"),
        verify_ssl=False
    )
    
    filter_id = "147288"
    try:
        filter_info = jira.get_filter(filter_id)
        print(f"Filter: {filter_info.get('name')}")
        print(f"Owner: {filter_info.get('owner', {}).get('displayName')}")
        
        jql = filter_info.get('jql')
        lob_found_field = "customfield_28469"
        component_subcomponent_field = "customfield_28436"
        
        # Extract all issues with pagination
        start_at = 0
        max_results = 100
        all_issues = []
        
        while True:
            result = jira.jql(jql, fields=f"key,summary,status,assignee,priority,created,updated,components,labels,{lob_found_field},{component_subcomponent_field}", start=start_at, limit=max_results)
            issues = result.get('issues', [])
            all_issues.extend(issues)
            print(f"Fetched {len(issues)} issues (total: {len(all_issues)})")
            
            if len(issues) < max_results:
                break
            start_at += max_results
        
        # Process data for Power BI
        power_bi_data = []
        for issue in all_issues:
            fields = issue.get('fields', {})
            
            # Handle LOB Found field
            lob_found = fields.get(lob_found_field, '')
            if isinstance(lob_found, list) and len(lob_found) > 0:
                lob_found = ', '.join([item.get('value', str(item)) for item in lob_found])
            elif isinstance(lob_found, dict):
                lob_found = lob_found.get('value', '')
            
            # Handle Component/Subcomponent field
            component_subcomponent = fields.get(component_subcomponent_field, '')
            if isinstance(component_subcomponent, list):
                component_subcomponent = ', '.join([c.get('value', str(c)) for c in component_subcomponent])
            elif isinstance(component_subcomponent, dict):
                component_subcomponent = component_subcomponent.get('value', '')
            
            power_bi_data.append({
                'Key': issue.get('key'),
                'Summary': fields.get('summary'),
                'Status': fields.get('status', {}).get('name'),
                'Priority': fields.get('priority', {}).get('name'),
                'Assignee': fields.get('assignee', {}).get('displayName') if fields.get('assignee') else 'Unassigned',
                'Created': fields.get('created'),
                'Updated': fields.get('updated'),
                'Components': ', '.join([c.get('name') for c in fields.get('components', [])]),
                'Labels': ', '.join(fields.get('labels', [])),
                'LOB Found': lob_found,
                'Component_Subcomponent': component_subcomponent
            })
        
        # Save to CSV
        output_file = Path(__file__).parent / "jira_filter_147288_powerbi.csv"
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=power_bi_data[0].keys())
            writer.writeheader()
            writer.writerows(power_bi_data)
        
        # Save to JSON
        json_file = Path(__file__).parent / "jira_filter_147288_powerbi.json"
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(power_bi_data, f, indent=2, ensure_ascii=False)
        
        print(f"\n=== Extraction Complete ===")
        print(f"Total records: {len(power_bi_data)}")
        print(f"CSV saved to: {output_file}")
        print(f"JSON saved to: {json_file}")
        
        return power_bi_data
        
    except Exception as e:
        print(f"Error extracting data: {e}")
        import traceback
        traceback.print_exc()
        return None

def push_to_powerbi_api(data, workspace_id, dataset_id, client_id, client_secret):
    """
    Push data to Power BI Service via REST API
    Requires Power BI API credentials and setup
    
    Parameters:
    - data: List of dictionaries containing the data
    - workspace_id: Power BI workspace ID
    - dataset_id: Power BI dataset ID
    - client_id: Azure AD application client ID
    - client_secret: Azure AD application client secret
    """
    print("=== Power BI API Integration ===")
    print("Note: This requires Power BI API setup and credentials.")
    print("Please refer to the solution document for setup instructions.")
    print("\nCurrent status: Data extraction complete. CSV file ready for Power BI import.")

def main():
    """Main execution"""
    print("=== Power BI Automated Data Refresh ===")
    print("This script extracts JIRA data for Power BI dashboard\n")
    
    # Extract data
    data = extract_jira_data()
    
    if data:
        print(f"\n=== Next Steps ===")
        print("1. Import the CSV file into Power BI Desktop")
        print("2. Create visualizations as per the solution document")
        print("3. Publish to Power BI Service")
        print("4. Set up scheduled refresh if needed")
        print("\nFor automated API integration, configure Power BI credentials in config.toml")

if __name__ == "__main__":
    main()
