#!/usr/bin/env python3
"""
Generic Jira Tool
Arguments-based tool for general Jira operations.
"""

import argparse
import json
import re
import sys
import os
import subprocess
import requests
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
import io
from datetime import datetime
import hashlib
import glob

class LLMConfluenceAnalyzer:
    """LLM-powered Confluence analyzer for intelligent filter extraction."""
    
    def __init__(self):
        self.filter_patterns = [
            r'filter\s*=\s*(\d+)',
            r'jira.*?filter.*?(\d+)',
            r'jqlQuery.*?filter\s*=\s*(\d+)',
            r'JQL.*?filter\s*=\s*(\d+)'
        ]
        
        self.table_contexts = {
            'PBA_Ask': ['PBA Ask', 'Table 1', 'NUDD Raw Data', '26Q1/26Q2/26Q3'],
            'PBA_Epic': ['PBA Epic', 'Table 2', 'Epic'],
            'CBA_Projects': ['CBA Projects', 'Platform Generation', '26Q1', '26Q2', '26Q3'],
            'General': ['filter', 'JIRA', 'jql']
        }
    
    def extract_all_filters(self, content: str) -> List[Tuple[str, str, int]]:
        """Extract all filter IDs with their context and position."""
        filters = []
        for pattern in self.filter_patterns:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                filter_id = match.group(1)
                position = match.start()
                
                # Extract context around the match
                start_pos = max(0, position - 200)
                end_pos = min(len(content), position + 200)
                context = content[start_pos:end_pos]
                
                filters.append((filter_id, context, position))
        
        return filters
    
    def determine_filter_type(self, context: str) -> str:
        """Determine the type of filter based on context."""
        context_lower = context.lower()
        
        for filter_type, keywords in self.table_contexts.items():
            for keyword in keywords:
                if keyword.lower() in context_lower:
                    return filter_type
        
        return 'Unknown'
    
    def rank_filters_by_relevance(self, filters: List[Tuple[str, str, int]]) -> List[Dict]:
        """Rank filters by relevance using LLM-like analysis."""
        ranked_filters = []
        
        for filter_id, context, position in filters:
            filter_type = self.determine_filter_type(context)
            
            # Calculate relevance score
            score = 0
            
            # Higher score for PBA_Ask (most common for NUDD)
            if filter_type == 'PBA_Ask':
                score += 100
            elif filter_type == 'PBA_Epic':
                score += 80
            elif filter_type == 'CBA_Projects':
                score += 60
            elif filter_type == 'General':
                score += 40
            
            # Bonus for specific keywords
            if 'NUDD' in context:
                score += 50
            if 'Architecture' in context:
                score += 30
            if 'Table 1' in context:
                score += 20
            
            # Prefer filters that appear earlier in the document
            if position < len(context) / 2:
                score += 10
            
            ranked_filters.append({
                'filter_id': filter_id,
                'filter_type': filter_type,
                'context_snippet': context[:100] + '...' if len(context) > 100 else context,
                'position': position,
                'score': score
            })
        
        # Sort by score (descending)
        ranked_filters.sort(key=lambda x: x['score'], reverse=True)
        return ranked_filters
    
    def analyze_confluence_content(self, content: str) -> Dict:
        """Analyze Confluence content and return the best filter recommendation."""
        if not content:
            return {
                'success': False,
                'error': 'No content provided',
                'recommended_filter': None,
                'confidence': None,
                'alternatives': []
            }
        
        # Extract all filters
        all_filters = self.extract_all_filters(content)
        
        if not all_filters:
            return {
                'success': False,
                'error': 'No filter IDs found in content',
                'recommended_filter': None,
                'confidence': None,
                'alternatives': []
            }
        
        # Rank filters by relevance
        ranked_filters = self.rank_filters_by_relevance(all_filters)
        
        # Get the best filter
        best_filter = ranked_filters[0]
        
        # Calculate confidence based on score
        confidence = 'Low'
        if best_filter['score'] >= 100:
            confidence = 'High'
        elif best_filter['score'] >= 60:
            confidence = 'Medium'
        
        return {
            'success': True,
            'recommended_filter': best_filter['filter_id'],
            'filter_type': best_filter['filter_type'],
            'confidence': confidence,
            'score': best_filter['score'],
            'context_snippet': best_filter['context_snippet'],
            'total_filters_found': len(all_filters),
            'alternatives': ranked_filters[1:5]  # Top 5 alternatives
        }

class DownloadManager:
    """Smart download manager to avoid duplicate downloads."""
    
    def __init__(self, base_dir: str):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
    
    def get_file_hash(self, file_path: Path) -> Optional[str]:
        """Get file hash for comparison."""
        if not file_path.exists():
            return None
        
        try:
            with open(file_path, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        except Exception:
            return None
    
    def find_existing_files(self, filename_pattern: str) -> List[Path]:
        """Find existing files with similar names."""
        pattern = filename_pattern.replace('[', '?').replace(']', '?')
        search_pattern = f"*{pattern}*"
        
        existing_files = []
        for file_path in self.base_dir.glob(search_pattern):
            if file_path.is_file():
                existing_files.append(file_path)
        
        return existing_files
    
    def should_download(self, filename: str, new_content_hash: str = None) -> Tuple[bool, List[Path]]:
        """
        Determine if a file should be downloaded.
        
        Returns:
            Tuple of (should_download, existing_files)
        """
        existing_files = self.find_existing_files(filename)
        
        if not existing_files:
            return True, []
        
        if not new_content_hash:
            # If we don't have content hash, check if exact filename exists
            exact_matches = [f for f in existing_files if f.name == filename]
            return len(exact_matches) == 0, existing_files
        
        # Check if any existing file has the same content
        for existing_file in existing_files:
            existing_hash = self.get_file_hash(existing_file)
            if existing_hash == new_content_hash:
                return False, existing_files
        
        return True, existing_files
    
    def generate_unique_filename(self, filename: str, existing_files: List[Path]) -> str:
        """Generate a unique filename if conflicts exist."""
        if not any(f.name == filename for f in existing_files):
            return filename
        
        base_name = Path(filename).stem
        extension = Path(filename).suffix
        
        counter = 1
        while True:
            new_filename = f"{base_name}_{counter}{extension}"
            if not any(f.name == new_filename for f in existing_files):
                return new_filename
            counter += 1

def extract_filter_from_confluence_content(content: str) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """
    Extract JIRA filter IDs from Confluence page content using pattern matching.
    
    Returns:
        Tuple of (primary_filter_id, filter_type, confidence_level)
    """
    if not content:
        return None, None, None
    
    # Pattern 1: filter = [number]
    filter_pattern = r'filter\s*=\s*(\d+)'
    matches = re.findall(filter_pattern, content, re.IGNORECASE)
    
    if matches:
        # Use the first match as primary filter
        primary_filter = matches[0]
        
        # Determine filter type based on context
        if "PBA Ask" in content or "Table 1" in content:
            filter_type = "PBA_Ask"
        elif "PBA Epic" in content or "Table 2" in content:
            filter_type = "PBA_Epic"
        elif "CBA Projects" in content or "Platform Generation" in content:
            filter_type = "CBA_Projects"
        else:
            filter_type = "Unknown"
        
        return primary_filter, filter_type, "High"
    
    return None, None, None

def analyze_confluence_filter(confluence_page_id: str) -> Dict[str, Any]:
    """
    Analyze Confluence page to extract filter information using LLM analysis.
    
    Args:
        confluence_page_id: Confluence page ID to analyze
        
    Returns:
        Dictionary containing filter analysis results
    """
    try:
        # Get Confluence page content using simpler path resolution
        import os
        current_script_dir = os.path.dirname(os.path.abspath(__file__))
        jira_integration_dir = os.path.dirname(current_script_dir)
        skills_dir = os.path.dirname(jira_integration_dir)
        confluence_script = os.path.join(skills_dir, "confluence_integration", "scripts", "confluence_tool.py")
        config_path = os.path.join(skills_dir, "confluence_integration", "config.toml")
        
        if not os.path.exists(confluence_script):
            return {
                'success': False,
                'error': f'Confluence integration script not found at {confluence_script}',
                'filter_id': None
            }
        
        if not os.path.exists(config_path):
            return {
                'success': False,
                'error': f'Confluence config not found at {config_path}',
                'filter_id': None
            }
        
        # Run confluence get command with correct config path
        result = subprocess.run([
            'python', confluence_script, '--config', config_path, 'get', '--id', confluence_page_id
        ], capture_output=True, text=True, cwd=os.path.dirname(skills_dir))
        
        if result.returncode != 0:
            return {
                'success': False,
                'error': f'Failed to fetch Confluence page: {result.stderr}',
                'filter_id': None
            }
        
        # Extract page title from Confluence API response
        page_title = "Unknown"
        try:
            import json
            page_data = json.loads(result.stdout)
            if 'title' in page_data:
                page_title = page_data['title']
        except:
            pass
        
        # Use LLM analyzer to process the content
        analyzer = LLMConfluenceAnalyzer()
        analysis_result = analyzer.analyze_confluence_content(result.stdout)
        
        if not analysis_result['success']:
            return {
                'success': False,
                'error': analysis_result['error'],
                'filter_id': None
            }
        
        # Return the LLM analysis result
        return {
            'success': True,
            'filter_id': analysis_result['recommended_filter'],
            'filter_type': analysis_result['filter_type'],
            'confidence': analysis_result['confidence'],
            'score': analysis_result['score'],
            'context_snippet': analysis_result['context_snippet'],
            'total_filters_found': analysis_result['total_filters_found'],
            'alternatives': analysis_result['alternatives'],
            'page_title': page_title,
            'confluence_page_id': confluence_page_id
        }
        
    except Exception as e:
        return {
            'success': False,
            'error': f'Analysis failed: {str(e)}',
            'filter_id': None
        }

# Report generation function following skill_guides standards
def save_report(content, report_name, description="", skill_name="jira_integration"):
    """
    Save markdown report to centralized Reports directory following skill_guides standards
    
    Args:
        content: Report content in markdown format
        report_name: Base name for the report file
        description: Optional description for the report
        skill_name: Name of the skill generating the report
    """
    try:
        # Get Reports directory path - .windsurf/Reports/
        reports_dir = Path(__file__).parent.parent.parent.parent / "Reports"
        reports_dir.mkdir(exist_ok=True)
        
        # Generate timestamped filename
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        filename = f"{report_name}_{timestamp}.md"
        filepath = reports_dir / filename
        
        # Add report metadata header
        report_header = f"""---
# {report_name} Report
**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Description:** {description}
**Skill:** {skill_name}
---

"""
        
        # Combine header and content
        full_content = report_header + content
        
        # Save to file
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(full_content)
        
        return f" Report saved to: {filepath}"
        
    except Exception as e:
        return f"❌ Failed to save report: {str(e)}"

try:
    import tomllib
except ImportError:
    import tomli as tomllib

from atlassian import Jira

# Import centralized configuration loader
skills_dir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(skills_dir))
try:
    from config_loader import load_skill_config_with_central_fallback
except ImportError:
    # Fallback if central config loader not available
    def load_skill_config_with_central_fallback(config_path):
        if not config_path.exists():
            print(f"ERROR: Config file not found: {config_path}", file=sys.stderr)
            sys.exit(1)
        with open(config_path, "rb") as f:
            return tomllib.load(f)

def load_config(config_path: Path):
    """Load configuration with central config fallback"""
    return load_skill_config_with_central_fallback(config_path)

def get_client(config):
    try:
        print(f"DEBUG: URL={config['jira']['url']}", file=sys.stderr)
        print(f"DEBUG: Token={config['jira']['token'][:5]}...", file=sys.stderr)
        jira = Jira(
            url=config["jira"]["url"],
            token=config["jira"]["token"]
        )
        return jira
    except Exception as e:
        print(f"ERROR: Failed to initialize Jira client: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_get(jira: Jira, args):
    try:
        # If fields is provided, split by comma
        fields = args.fields.split(",") if args.fields else None
        
        # In atlassian-python-api, if fields=None is passed explicitly in the issue() 
        # call, it might return no fields. To get default fields, we omit it.
        if fields:
            issue = jira.issue(args.key, fields=fields, expand=args.expand)
        else:
            issue = jira.issue(args.key, expand=args.expand)
            
        print(json.dumps(issue, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to get issue {args.key}: {e}", file=sys.stderr)
        if hasattr(e, "response") and e.response is not None:
             print(f"Response: {e.response.text}", file=sys.stderr)
        sys.exit(1)

def cmd_search(jira: Jira, args):
    try:
        # jql is required
        results = jira.jql(args.jql, limit=args.limit, start=args.start)
        print(json.dumps(results, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to search: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_batch_search(jira: Jira, args):
    """Search and batch process multiple tickets with summary information"""
    try:
        # First search for tickets
        results = jira.jql(args.jql, limit=args.limit, start=args.start)
        issues = results.get('issues', [])
        
        if not issues:
            print("No tickets found.")
            return
            
        # Generate report content
        report_content = f"""# JIRA Batch Search Analysis Report

**Analysis Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**JQL Query:** {args.jql}
**Total Tickets Found:** {len(issues)}

## 📊 Search Results Summary

| Key | Summary | Assignee | Status |
|-----|----------|----------|--------|
"""
        
        # Console output
        print(f"JQL Query Results Summary")
        print("=" * 80)
        print(f"Query: {args.jql}")
        print(f"Total tickets found: {len(issues)}")
        print("=" * 80)
        
        for issue in issues:
            key = issue['key']
            fields = issue.get('fields', {})
            
            # Extract key information
            summary = fields.get('summary', 'No summary')
            assignee_data = fields.get('assignee')
            assignee = assignee_data.get('displayName', 'Unassigned') if assignee_data else 'Unassigned'
            status = fields.get('status', {}).get('name', 'Unknown')
            
            # Console output
            print(f"Key: {key}")
            print(f"  Summary: {summary}")
            print(f"  Assignee: {assignee}")
            print(f"  Status: {status}")
            print()
            
            # Add to report (escape markdown special characters)
            safe_summary = summary.replace('|', '\\|').replace('\n', ' ')
            safe_assignee = assignee.replace('|', '\\|')
            report_content += f"| {key} | {safe_summary} | {safe_assignee} | {status} |\n"
            
        print("=" * 80)
        
        # Add bilingual summary
        report_content += f"""

## 📋 BilingualSummary / Bilingual Summary

### 🇹🇼 Traditional Chinese

- **Total Tickets:** {len(issues)}
- **JQL Query:** {args.jql}
- **Analysis Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

### 🇺🇸 English Summary

- **Total Tickets:** {len(issues)}
- **JQL Query:** {args.jql}
- **Analysis Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        
        # Save report if requested
        if hasattr(args, 'save_report') and args.save_report:
            save_result = save_report(
                report_content, 
                "jira_batch_search", 
                f"JIRA batch search analysis for query: {args.jql}",
                "jira_integration"
            )
            print(save_result)
        
    except Exception as e:
        print(f"ERROR: Failed to batch search: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_check_tbabp1(jira: Jira, args, config=None):
    """Check TBABP1 ticket for required description fields and Epic Link"""
    try:
        # Get the ticket details with more fields for summary
        issue = jira.issue(args.key, fields='summary,description,customfield_12300,status,assignee,priority,reporter,created,updated')
        
        if not issue:
            print(f"ERROR: Ticket {args.key} not found", file=sys.stderr)
            sys.exit(1)
            
        key = issue['key']
        fields = issue.get('fields', {})
        summary = fields.get('summary', 'No summary')
        description = fields.get('description', '')
        epic_link = fields.get('customfield_12300')
        
        # Extract basic ticket information
        status = fields.get('status', {}).get('name', 'Unknown')
        assignee_data = fields.get('assignee')
        assignee = assignee_data.get('displayName', 'Unassigned') if assignee_data else 'Unassigned'
        priority = fields.get('priority', {}).get('name', 'Unknown')
        reporter_data = fields.get('reporter')
        reporter = reporter_data.get('displayName', 'Unknown') if reporter_data else 'Unknown'
        created = fields.get('created', '')[:10]  # Just date part
        updated = fields.get('updated', '')[:10]  # Just date part
        
        # Get Jira base URL for ticket link
        ticket_url = ""
        if config and 'jira' in config and 'url' in config['jira']:
            base_url = config['jira']['url'].rstrip('/')
            ticket_url = f"{base_url}/browse/{key}"
        
        # Display ticket summary first
        print(f"{key} CheckResult")
        print("=" * 50)
        if ticket_url:
            print(f"Ticket Link: {ticket_url}")
        print(f"Summary: {summary}")
        print(f"Status: {status}")
        print(f"Assignee: {assignee}")
        print(f"Priority: {priority}")
        print(f"Reporter: {reporter}")
        print(f"Created: {created}")
        print(f"Updated: {updated}")
        print()
        
        print("Required field check:")
        print()
        
        # Parse description for required fields
        found_fields = {}
        required_fields = ['SSID', 'BIOS_Version', 'BIOS_Source']
        
        for field in required_fields:
            pattern = f"{field}=(.+)"
            match = re.search(pattern, description)
            if match:
                value = match.group(1).strip()
                # Only consider field present if value is not empty
                if value:
                    found_fields[field] = value
        
        # Display field check results with status indicators
        all_fields_present = True
        
        for field in required_fields:
            if field in found_fields:
                print(f"{field}: {found_fields[field]} ✅")
            else:
                print(f"{field}: MISSING ❌")
                all_fields_present = False
        
        # Check Epic Link
        if epic_link:
            # Epic Link is usually an object with key and summary fields
            if isinstance(epic_link, dict):
                epic_key = epic_link.get('key', 'Unknown')
                epic_summary = epic_link.get('summary', '')
                
                # Create hyperlink format: CPSE-XXX (Epic Name)
                if epic_summary:
                    epic_display = f"{epic_key} ({epic_summary})"
                else:
                    epic_display = epic_key
                    
                print(f"Epic Link: {epic_display} ✅")
            else:
                # If it's just a string key, try to get more details
                epic_key = str(epic_link)
                try:
                    # Try to fetch the epic details
                    epic_details = jira.issue(epic_key, fields='summary')
                    epic_summary = epic_details.get('fields', {}).get('summary', '')
                    if epic_summary:
                        epic_display = f"{epic_key} ({epic_summary})"
                    else:
                        epic_display = epic_key
                except:
                    epic_display = epic_key
                    
                print(f"Epic Link: {epic_display} ✅")
        else:
            print("Epic Link: MISSING ❌")
            all_fields_present = False
        
        print()
        # Final result
        if all_fields_present:
            print("✅ PASSED - All required fields are correctly filled")
            print()
            print("This TBABP1 ticket meets all specification requirements, can continue handling.")
        else:
            print("❌ FAILED - Missing required fields, please supplement and check again")
        
    except Exception as e:
        print(f"ERROR: Failed to check TBABP1 ticket {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_transition(jira: Jira, args):
    try:
        # For transition, we might need resolution if closing
        # Atlassian python api uses 'set_issue_status' which tries to find the transition by name
        
        # Check if resolution is provided
        fields = {}
        if args.resolution:
            fields["resolution"] = {"name": args.resolution}
            
        jira.set_issue_status(args.key, args.status, fields=fields)
        print(json.dumps({"success": True, "key": args.key, "status": args.status}, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to transition issue {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_comment(jira: Jira, args):
    try:
        jira.issue_add_comment(args.key, args.body)
        print(json.dumps({"success": True, "key": args.key, "message": "Comment added"}, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to add comment to {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_get_comments(jira: Jira, args):
    try:
        comments = jira.issue_get_comments(args.key)
        # Handle cases where it returns a dict with 'comments' key or a list
        if isinstance(comments, dict):
            comments_list = comments.get('comments', [])
        else:
            comments_list = comments

        if args.json:
            print(json.dumps(comments_list, indent=2))
            return

        print(f"\n### Comments for {args.key}\n")
        header = f"{'ID':<15} | {'Author':<30} | {'Created':<25} | {'Body Snippet'}"
        print(header)
        print("-" * len(header))

        for c in comments_list:
            cid = c.get('id', 'Unknown')
            author = c.get('author', {}).get('displayName', 'Unknown')
            created = c.get('created', 'Unknown')
            body = c.get('body', '')
            snippet = (body[:50] + '...') if len(body) > 50 else body
            print(f"{cid:<15} | {author:<30} | {created:<25} | {snippet}")

    except Exception as e:
        print(f"ERROR: Failed to get comments for {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_delete_comment(jira: Jira, args):
    try:
        # endpoint: rest/api/2/issue/{issueIdOrKey}/comment/{id}
        jira.delete(f"rest/api/2/issue/{args.key}/comment/{args.id}")
        print(json.dumps({"success": True, "key": args.key, "id": args.id, "action": "deleted"}, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to delete comment {args.id} from {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_edit_comment(jira: Jira, args):
    try:
        jira.issue_edit_comment(args.key, args.id, args.body)
        print(json.dumps({"success": True, "key": args.key, "id": args.id, "message": "Comment updated"}, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to edit comment {args.id} from {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_link(jira: Jira, args):
    try:
        # atlassian-python-api: create_issue_link(data)
        payload = {
            "type": {"name": args.type},
            "inwardIssue": {"key": args.inward},
            "outwardIssue": {"key": args.outward}
        }
        jira.create_issue_link(payload)
        print(json.dumps({"success": True, "inward": args.inward, "outward": args.outward, "type": args.type}, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to link issues: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_assign(jira: Jira, args):
    try:
        jira.assign_issue(args.key, args.user)
        print(json.dumps({"success": True, "key": args.key, "assignee": args.user}, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to assign issue {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_add_watcher(jira: Jira, args):
    try:
        jira.issue_add_watcher(args.key, args.user)
        print(json.dumps({"success": True, "key": args.key, "watcher": args.user, "action": "added"}, indent=2))
    except Exception as e:
        print(f"ERROR: Failed to add watcher to {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_update_field(jira: Jira, args):
    try:
        # Smart handling based on common fields or ID prefix
        field = args.field
        value = args.value
        
        # Determine the correct key and payload structure
        # If user provides a name, try to map it (simple list for now)
        mapping = {
            "status-flag": "customfield_27700",
            "start-date": "customfield_17803",
            "bios-se": "customfield_23603",
            "sw-se": "customfield_27801",
            "resolution-details": "customfield_21004",
            "due-date": "duedate",
            "reporter": "reporter"
        }
        
        field_id = mapping.get(field.lower(), field)
        
        # Get field type from editmeta to determine payload structure
        em = jira.issue_editmeta(args.key)
        field_info = em.get('fields', {}).get(field_id)
        
        if not field_info:
            print(f"ERROR: Field {field_id} not found or not editable on {args.key}.", file=sys.stderr)
            sys.exit(1)
            
        ftype = field_info.get('schema', {}).get('type')
        custom = field_info.get('schema', {}).get('custom', '')
        
        payload = value
        if ftype == 'user' or 'userpicker' in custom:
            payload = {"name": value}
        elif ftype == 'array' and 'multiuserpicker' in custom:
            payload = [{"name": v.strip()} for v in value.split(",")]
        elif ftype == 'option' or 'select' in custom:
            payload = {"value": value}
        
        jira.update_issue(args.key, {"fields": {field_id: payload}})
        print(json.dumps({"success": True, "key": args.key, "field": field_id, "value": value}, indent=2))

    except Exception as e:
        print(f"ERROR: Failed to update field {args.field} on {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_unlink(jira: Jira, args):
    try:
        # 1. Get links for the issue
        issue = jira.issue(args.key, fields='issuelinks')
        links = issue.get('fields', {}).get('issuelinks', [])
        
        link_id = None
        target_link = None
        
        # 2. Find the link ID for the target issue
        for link in links:
            # Check outwardIssue
            if 'outwardIssue' in link and link['outwardIssue']['key'] == args.target:
                link_id = link['id']
                target_link = link
                break
            # Check inwardIssue
            if 'inwardIssue' in link and link['inwardIssue']['key'] == args.target:
                link_id = link['id']
                target_link = link
                break
        
        if not link_id:
            print(f"ERROR: No link found between {args.key} and {args.target}", file=sys.stderr)
            sys.exit(1)
            
        # 3. Delete the link
        print(f"Found link ID {link_id} ({target_link.get('type', {}).get('name', 'Unknown')}). Deleting...", file=sys.stderr)
        
        # Try to find the correct method
        if hasattr(jira, 'delete_issue_link'):
            jira.delete_issue_link(link_id)
        elif hasattr(jira, 'remove_issue_link'):
            jira.remove_issue_link(link_id)
        elif hasattr(jira, 'remove_link'):
            jira.remove_link(link_id)
        else:
            # Fallback - try to use the REST API directly if method wrapper missing
            jira.delete(f"issueLink/{link_id}")
        
        print(json.dumps({"success": True, "key": args.key, "target": args.target, "action": "unlinked"}, indent=2))
        
    except Exception as e:
        print(f"ERROR: Failed to unlink {args.key} and {args.target}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_add_label(jira: Jira, args):
    try:
        # 1. Parse labels (support comma-separated)
        input_labels = [l.strip() for l in args.label.split(",") if l.strip()]
        if not input_labels:
            print("No valid labels provided.")
            return

        # 2. Get current labels
        issue = jira.issue(args.key, fields='labels')
        fields = issue.get('fields')
        
        current_labels = []
        if fields:
             current_labels = fields.get('labels', [])
             if current_labels is None:
                 current_labels = []

        labels_to_add = [l for l in input_labels if l not in current_labels]
        
        if not labels_to_add:
            print(f"All labels {input_labels} already exist on {args.key}. Nothing to do.")
            print(json.dumps({"success": True, "key": args.key, "action": "ignored", "labels": current_labels}))
            return

        new_labels = current_labels + labels_to_add
        
        # 3. Update issue
        print(f"Adding labels {labels_to_add} to {args.key}...", file=sys.stderr)
        jira.update_issue(args.key, {'fields': {'labels': new_labels}})
        
        print(json.dumps({"success": True, "key": args.key, "action": "added", "added_labels": labels_to_add, "all_labels": new_labels}, indent=2))

    except Exception as e:
        print(f"ERROR: Failed to add labels to {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_remove_label(jira: Jira, args):
    try:
        # 1. Parse labels (support comma-separated)
        input_labels = [l.strip() for l in args.label.split(",") if l.strip()]
        if not input_labels:
            print("No valid labels provided.")
            return

        # 2. Get current labels
        issue = jira.issue(args.key, fields='labels')
        fields = issue.get('fields')
        
        current_labels = []
        if fields:
             current_labels = fields.get('labels', [])
             if current_labels is None:
                 current_labels = []

        labels_to_remove = [l for l in input_labels if l in current_labels]
        
        if not labels_to_remove:
            print(f"None of the labels {input_labels} found on {args.key}. Nothing to do.")
            print(json.dumps({"success": True, "key": args.key, "action": "ignored", "labels": current_labels}))
            return

        new_labels = [l for l in current_labels if l not in labels_to_remove]
        
        # 3. Update issue
        print(f"Removing labels {labels_to_remove} from {args.key}...", file=sys.stderr)
        jira.update_issue(args.key, {'fields': {'labels': new_labels}})
        
        print(json.dumps({"success": True, "key": args.key, "action": "removed", "removed_labels": labels_to_remove, "all_labels": new_labels}, indent=2))

    except Exception as e:
        print(f"ERROR: Failed to remove labels from {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_add_component(jira: Jira, args):
    try:
        # 1. Parse component names
        input_comps = [c.strip() for c in args.component.split(",") if c.strip()]
        if not input_comps:
            print("No valid components provided.")
            return

        # 2. Get current components
        issue = jira.issue(args.key, fields='components')
        fields = issue.get('fields')
        current_comps = fields.get('components', []) if fields else []
        current_names = [c.get('name') for c in current_comps]

        comps_to_add = [c for c in input_comps if c not in current_names]
        
        if not comps_to_add:
            print(f"All components {input_comps} already exist on {args.key}. Nothing to do.")
            print(json.dumps({"success": True, "key": args.key, "action": "ignored", "components": current_names}))
            return

        # 3. Construct update - components expect [{'name': 'Value'}, ...]
        new_comp_list = []
        # Keep existing
        for c in current_names:
            new_comp_list.append({'name': c})
        # Add new ones
        for c in comps_to_add:
            new_comp_list.append({'name': c})
            
        print(f"Adding components {comps_to_add} to {args.key}...", file=sys.stderr)
        jira.update_issue(args.key, {'fields': {'components': new_comp_list}})
        
        all_names = [c['name'] for c in new_comp_list]
        print(json.dumps({"success": True, "key": args.key, "action": "added", "added_components": comps_to_add, "all_components": all_names}, indent=2))

    except Exception as e:
        print(f"ERROR: Failed to add components to {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_remove_component(jira: Jira, args):
    try:
        # 1. Parse component names
        input_comps = [c.strip() for c in args.component.split(",") if c.strip()]
        if not input_comps:
            print("No valid components provided.")
            return

        # 2. Get current components
        issue = jira.issue(args.key, fields='components')
        fields = issue.get('fields')
        current_comps = fields.get('components', []) if fields else []
        current_names = [c.get('name') for c in current_comps]

        comps_to_remove = [c for c in input_comps if c in current_names]
        
        if not comps_to_remove:
            print(f"None of the components {input_comps} found on {args.key}. Nothing to do.")
            print(json.dumps({"success": True, "key": args.key, "action": "ignored", "components": current_names}))
            return

        # 3. Construct update
        new_names = [c for c in current_names if c not in comps_to_remove]
        new_comp_list = [{'name': c} for c in new_names]
        
        print(f"Removing components {comps_to_remove} from {args.key}...", file=sys.stderr)
        jira.update_issue(args.key, {'fields': {'components': new_comp_list}})
        
        print(json.dumps({"success": True, "key": args.key, "action": "removed", "removed_components": comps_to_remove, "all_components": new_names}, indent=2))

    except Exception as e:
        print(f"ERROR: Failed to remove components from {args.key}: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_link_types(jira: Jira, args):
    try:
        types = jira.get_issue_link_types()
        
        if args.json:
            print(json.dumps(types, indent=2))
            return
            
        print("\n### Issue Link Types\n")
        header = f"{'ID':<10} | {'Name':<35} | {'Inward (Desc)':<35} | {'Outward (Desc)'}"
        print(header)
        print("-" * len(header))
        
        for t in types:
            uid = t.get('id', 'Unknown')
            name = t.get('name', 'Unknown')
            inward = t.get('inward', 'Unknown')
            outward = t.get('outward', 'Unknown')
            print(f"{uid:<10} | {name:<35} | {inward:<35} | {outward}")
            
    except Exception as e:
        print(f"ERROR: Failed to get link types: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_analyze_fields(jira: Jira, args):
    try:
        # 1. Get all fields
        print(f"Fetching all fields...", file=sys.stderr)
        all_fields = jira.get_all_fields()
        id_to_name = {f['id']: f['name'] for f in all_fields}
        
        # 2. Analyze issues
        issue_keys = args.keys.split(',')
        issue_field_presence = {key: [] for key in issue_keys}
        all_found_fields = set()
        
        print(f"Analyzing {len(issue_keys)} issues...", file=sys.stderr)
        for key in issue_keys:
            try:
                issue = jira.issue(key)
                # Issue structure from atlassian-python-api might differ slightly from jira-python
                # Usually issue['fields'] is a dict
                fields_dict = issue.get('fields', {})
                found = []
                for field_id in fields_dict:
                    # Ignore None values if desired, or keep all keys present
                    if fields_dict[field_id] is not None:
                        found.append(field_id)
                        all_found_fields.add(field_id)
                issue_field_presence[key] = found
            except Exception as e:
                print(f"WARN: Failed to fetch {key}: {e}", file=sys.stderr)
        
        # 3. Generate Markdown
        # Sort fields: Standard first, then Custom
        sorted_fields = sorted(list(all_found_fields), key=lambda x: (x.startswith('customfield'), id_to_name.get(x, x).lower()))
        
        print("### Jira Field Summary\n")
        header = ["Field ID", "Field Name"] + issue_keys
        print("| " + " | ".join(header) + " |")
        print("|" + "|".join(["-" * len(h) for h in header]) + "|")
        
        for fid in sorted_fields:
            fname = id_to_name.get(fid, "Unknown")
            row = [fid, fname]
            for key in issue_keys:
                row.append("Yes" if fid in issue_field_presence[key] else "-")
            print("| " + " | ".join(row) + " |")
            
    except Exception as e:
        print(f"ERROR: Failed to analyze fields: {e}", file=sys.stderr)
        if hasattr(e, "response") and e.response is not None:
             print(f"Response: {e.response.text}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)

def cmd_changelog(jira: Jira, args):
    try:
        issue = jira.issue(args.key, expand='changelog')
        
        # summary info
        fields = issue.get('fields') or {}
        assignee = fields.get('assignee') or {}
        status = fields.get('status') or {}
        
        print(f"Summary: {fields.get('summary', 'Unknown')}")
        print(f"Assignee: {assignee.get('displayName', 'Unknown')}")
        print(f"Status: {status.get('name', 'Unknown')}")
        
        print("\n--- Changelog Summary ---")
        changelog = issue.get('changelog', {})
        histories = changelog.get('histories', [])
        
        if not histories:
            print("No history found.")
            return

        for history in histories:
            author = history.get('author', {}).get('displayName', 'Unknown')
            created = history.get('created', 'Unknown')
            print(f"\n{created} by {author}:")
            for item in history.get('items', []):
                field = item.get('field', 'Unknown')
                fromString = item.get('fromString', 'None')
                toString = item.get('toString', 'None')
                print(f"  - {field}: {fromString} -> {toString}")

    except Exception as e:
        print(f"ERROR: Failed to get changelog for {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def safe_get(obj, path, default=None):
    """Safely get nested dict values."""
    try:
        current = obj
        for key in path.split('.'):
            if current is None:
                return default
            if isinstance(current, dict):
                current = current.get(key)
            else:
                return default
        return current if current is not None else default
    except Exception:
        return default

def cmd_summarize(jira: Jira, args):
    try:
        # Fetch issue with summary fields and changelog
        fields_list = [
            'summary', 'status', 'assignee', 'priority', 'labels', 'issuelinks',
            'comment', 'components', 'duedate', 'reporter', 'attachment',
            'customfield_27700', 'customfield_17803', 'customfield_23603',
            'customfield_27801', 'customfield_21004'
        ]
        issue = jira.issue(args.key, fields=','.join(fields_list), expand='changelog')
        
        # Guard against fields being None (API error or permission issue)
        f = issue.get('fields')
        if f is None:
            print(f"ERROR: Could not retrieve fields for {args.key}. The issue might exist but fields are inaccessible (permissions?).", file=sys.stderr)
            # Try to show at least self/id if available
            print(f"Issue ID: {issue.get('id', 'Unknown')}")
            print(f"Self: {issue.get('self', 'Unknown')}")
            sys.exit(1)
        
        print(f"\n{'='*80}")
        print(f" ISSUE SUMMARY: {args.key}")
        print(f"{'='*80}")
        
        # Use safe_get or direct get with default safeguards
        summary = f.get('summary', 'Unknown')
        status = safe_get(f, 'status.name', 'Unknown')
        assignee = safe_get(f, 'assignee.displayName', 'Unassigned')
        priority = safe_get(f, 'priority.name', 'Unknown')
        
        labels = f.get('labels', []) or []
        label_str = ', '.join(labels) if labels else 'None'

        comps = f.get('components', []) or []
        comp_names = [c.get('name') for c in comps]
        comp_str = ', '.join(comp_names) if comp_names else 'None'
        
        due_date = f.get('duedate', 'None')
        reporter = safe_get(f, 'reporter.displayName', 'Unknown')
        
        print(f"  Summary:    {summary}")
        print(f"  Status:     {status}")
        print(f"  Assignee:   {assignee}")
        print(f"  Priority:   {priority}")
        print(f"  Labels:     {label_str}")
        print(f"  Components: {comp_str}")
        print(f"  Due Date:   {due_date}")
        print(f"  Reporter:   {reporter}")
        
        # Custom CPSE fields
        sflag = safe_get(f, 'customfield_27700.value', 'None')
        sdate = f.get('customfield_17803', 'None')
        bios_se = safe_get(f, 'customfield_23603.displayName', 'None')
        
        sw_se_users = f.get('customfield_27801', []) or []
        sw_se_list = [u.get('displayName') for u in sw_se_users if isinstance(u, dict)]
        sw_se = ', '.join(sw_se_list) or 'None'
        
        print(f"  Status-Flag: {sflag}")
        print(f"  Start Date: {sdate}")
        print(f"  BIOS SE:    {bios_se}")
        print(f"  SW SE:      {sw_se}")

        # Attachments
        attachments = f.get('attachment', []) or []
        print(f"\n  --- Attachments ({len(attachments)}) ---")
        if not attachments:
            print("  None")
        else:
            for a in attachments:
                size_kb = a.get('size', 0) // 1024
                print(f"  - [{a.get('id')}] {a.get('filename')} ({size_kb} KB)")
        
        # Linked Issues
        links = f.get('issuelinks', []) or []
        print(f"\n  --- Linked Issues ({len(links)}) ---")
        if not links:
            print("  None")
        else:
            for l in links:
                ltype = safe_get(l, 'type.name', 'Unknown')
                if 'outwardIssue' in l:
                    out = l['outwardIssue']
                    key = out.get('key', 'Unknown')
                    st = safe_get(out, 'fields.status.name', 'Unknown')
                    print(f"  - {ltype:<20} | Outward -> {key} | {st}")
                elif 'inwardIssue' in l:
                    inw = l['inwardIssue']
                    key = inw.get('key', 'Unknown')
                    st = safe_get(inw, 'fields.status.name', 'Unknown')
                    print(f"  - {ltype:<20} | Inward  <- {key} | {st}")

        # Recent History
        changelog = issue.get('changelog', {})
        histories = changelog.get('histories', []) or []
        print(f"\n  --- Recent History (Last 5 changes) ---")
        if not histories:
            print("  No history found.")
        else:
            # Show last 5 history items
            for h in histories[-5:]:
                author = safe_get(h, 'author.displayName', 'Unknown')
                created = h.get('created', '')[:16]
                for item in h.get('items', []):
                    field = item.get('field', 'Unknown')
                    f_from = item.get('fromString', 'None')
                    f_to = item.get('toString', 'None')
                    print(f"  {created} | {author:20} | {field:15}: {f_from} -> {f_to}")

        # Comments
        comments_obj = f.get('comment', {}) or {}
        comments = comments_obj.get('comments', []) or []
        print(f"\n  --- Recent Comments ({len(comments)}) ---")
        if not comments:
            print("  None")
        else:
            # Show last 5 comments
            for c in comments[-5:]:
                cid = c.get('id')
                author = safe_get(c, 'author.displayName', 'Unknown')
                created = c.get('created', '')[:16] # Just date and time
                body = c.get('body', '')
                snippet = (body[:100] + '...') if len(body) > 100 else body
                print(f"  [{cid}] {author} ({created}):")
                print(f"  {snippet}\n")
        
        print(f"{'='*80}\n")
        
    except Exception as e:
        print(f"ERROR: Failed to summarize {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_get_links(jira: Jira, args):
    try:
        # Fetch only issuelinks field initially
        issue = jira.issue(args.key, fields='issuelinks,summary,status')
        fields = issue.get('fields') or {}
        links = fields.get('issuelinks', [])
        
        result_data = {
            "key": args.key,
            "summary": fields.get('summary', 'Unknown'),
            "status": fields.get('status', {}).get('name', 'Unknown'),
            "linked_issues": []
        }
        
        # Process links
        for link in links:
            link_type = link.get('type', {}).get('name', 'Unknown')
            
            # Determine direction and target issue
            if 'outwardIssue' in link:
                direction = "Outward" # "is blocked by", "relates to"
                target_node = link['outwardIssue']
            elif 'inwardIssue' in link:
                direction = "Inward" # "blocks", "relates to"
                target_node = link['inwardIssue']
            else:
                continue

            target_key = target_node.get('key', 'Unknown')
            link_info = {
                "type": link_type,
                "direction": direction,
                "key": target_key,
                "summary": target_node.get('fields', {}).get('summary', 'Unknown'),
                "status": target_node.get('fields', {}).get('status', {}).get('name', 'Unknown')
            }
            
            # If detailed requested, fetch full issue details
            if args.detailed:
                print(f"Fetching details for linked issue {target_key}...", file=sys.stderr)
                try:
                    full_target = jira.issue(target_key)
                    link_info["details"] = full_target
                except Exception as e:
                    print(f"WARN: Failed to fetch details for {target_key}: {e}", file=sys.stderr)
                    link_info["details_error"] = str(e)
            
            result_data["linked_issues"].append(link_info)

        # Output handling
        if args.output:
            # Write key details to file
            try:
                with open(args.output, 'w', encoding='utf-8') as f:
                    json.dump(result_data, f, indent=2)
                print(f"Successfully wrote linked issues to {args.output}")
            except Exception as e:
                print(f"ERROR: Failed to write to {args.output}: {e}", file=sys.stderr)
                sys.exit(1)
        elif args.json or args.detailed:
            # Print JSON to stdout
            print(json.dumps(result_data, indent=2))
        else:
            # Print table summary (legacy default)
            print(f"Issue: {result_data['key']}")
            print(f"Summary: {result_data['summary']}")
            print(f"Status: {result_data['status']}")
            print(f"\nTotal Linked Issues: {len(result_data['linked_issues'])}")
            
            if not result_data['linked_issues']:
                return

            print("\n--- Linked Issues ---")
            # Header
            header = f"{'Type':<20} | {'Direction':<10} | {'Key':<15} | {'Status':<15} | {'Summary'}"
            print(header)
            print("-" * len(header))

            for link in result_data['linked_issues']:
                print(f"{link['type']:<20} | {link['direction']:<10} | {link['key']:<15} | {link['status']:<15} | {link['summary']}")

    except Exception as e:
        print(f"ERROR: Failed to get links for {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_analyze_pims(jira: Jira, args):
    try:
        # Fetch issue with changelog
        issue = jira.issue(args.key, expand='changelog')
        fields = issue.get('fields', {})
        status = fields.get('status', {}).get('name', 'Unknown')
        summary = fields.get('summary', '')
        assignee = fields.get('assignee', {}).get('displayName', 'Unassigned')
        
        # Calculate Time in Current State
        changelog = issue.get('changelog', {})
        histories = changelog.get('histories', [])
        
        last_change_date = None
        
        # Sort histories by created desc to find most recent status change
        histories.sort(key=lambda x: x.get('created', ''), reverse=True)
        
        for h in histories:
            found = False
            for item in h.get('items', []):
                if item.get('field') == 'status':
                    # Looking for the transition TO the current status
                    if item.get('toString') == status:
                        last_change_date = h.get('created')
                        found = True
                        break
            if found:
                break
        
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        
        days_in_state = 0
        date_used = last_change_date
        
        if not date_used:
             # Fallback to created date if no status change found
             date_used = fields.get('created')
             
        if date_used:
             # Parse Jira date format: 2023-10-27T06:33:04.996+0000
             # We try multiple formats to be safe
             formats = [
                 "%Y-%m-%dT%H:%M:%S.%f%z",
                 "%Y-%m-%dT%H:%M:%S%z"
             ]
             dt_obj = None
             for fmt in formats:
                 try:
                     dt_obj = datetime.strptime(date_used, fmt)
                     break
                 except ValueError:
                     continue
             
             if dt_obj:
                 diff = now - dt_obj
                 days_in_state = diff.days

        result = {
            "key": args.key,
            "status": status,
            "days_in_state": days_in_state,
            "assignee": assignee,
            "summary": summary
        }
        print(json.dumps(result, indent=2))

    except Exception as e:
        print(f"ERROR: Failed to analyze PIMS {args.key}: {e}", file=sys.stderr)
        # Return partial error object rather than crashing to update calling script
        print(json.dumps({"key": args.key, "error": str(e)}))

def cmd_download_attachment(jira: Jira, args):
    try:
        # atlassian-python-api: get_attachment(attachment_id) returns metadata
        attachment = jira.get_attachment(args.id)
        if not attachment:
            print(f"ERROR: Attachment {args.id} not found.", file=sys.stderr)
            sys.exit(1)
            
        filename = attachment.get('filename', f"attachment_{args.id}")
        download_url = attachment.get('content')
        
        if not download_url:
            print(f"ERROR: No download URL found for attachment {args.id}", file=sys.stderr)
            sys.exit(1)
            
        print(f"Downloading {filename} from {download_url}...", file=sys.stderr)
        
        # Use the Jira client's session to download (handles auth)
        response = jira.session.get(download_url, stream=True)
        response.raise_for_status()
        
        out_path = Path(args.out) if args.out else Path(filename)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(out_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    
        print(json.dumps({
            "success": True, 
            "id": args.id, 
            "filename": filename, 
            "saved_to": str(out_path.absolute())
        }, indent=2))
        
    except Exception as e:
        print(f"ERROR: Failed to download attachment {args.id}: {e}", file=sys.stderr)
        sys.exit(1)


# ==================== NUDD ARCHITECTURE DOCUMENT DOWNLOADER ====================

class NuddDocumentDownloader:
    """NUDD Architecture Document Downloader class for processing PBA tickets."""
    
    def __init__(self, base_dir: str = "NUDD"):
        # Use absolute path from workspace root
        # Path: scripts/jira_integration/scripts/jira_tool.py -> workspace root
        workspace_root = Path(__file__).parent.parent.parent.parent.parent  # Go up 5 levels to reach workspace root
        self.base_dir = workspace_root / base_dir
        self.base_dir.mkdir(exist_ok=True)
        
        # Initialize download manager for version checking
        self.download_manager = DownloadManager(str(self.base_dir))
        
        # Version tracking file
        self.version_file = self.base_dir / ".nudd_version_tracking.json"
        self.version_data = self.load_version_data()
        
        # Architecture document patterns - more specific to avoid false positives
        self.ad_patterns = [
            r'.*AD\s*[0-9\.]+\.(docx|pdf|pptx)$',  # AD1.0, AD0.5, AD2.0, etc. (with optional space)
            r'.*FD\s*[0-9\.]+\.(docx|pdf|pptx)$',   # FD1.0, FD0.5, FD2.0, etc. (Functional Documents)
            r'.*Architecture.*Document\.(docx|pdf|pptx)$',  # Architecture Document
            r'.*-AD\s*[0-9\.]*\.(docx|pdf|pptx)$',  # -AD1.0, -AD2.0 (with optional space)
            r'.*-FD\s*[0-9\.]*\.(docx|pdf|pptx)$',   # -FD1.0, -FD2.0 (with optional space)
            r'.*Architecture.*Design\.(docx|pdf|pptx)$',  # Architecture Design
            r'.*System.*Architecture\.(docx|pdf|pptx)$',  # System Architecture
            r'.*Technical.*Architecture\.(docx|pdf|pptx)$',  # Technical Architecture
            r'.*Platform.*Architecture\.(docx|pdf|pptx)$'  # Platform Architecture
        ]
    
    def check_summary_relevance(self, parent_summary: str, filename: str, ticket_key: str) -> bool:
        """Check if an Architecture Document filename is relevant to the parent ticket summary.
        
        Args:
            parent_summary: The summary of the parent PBA ticket
            filename: The Architecture Document filename
            ticket_key: The current ticket key (for context)
            
        Returns:
            bool: True if the document appears relevant to the parent ticket
        """
        if not parent_summary or parent_summary == 'No Summary Available':
            return True  # If no summary available, assume relevant
        
        # Convert to lowercase for case-insensitive comparison
        summary_lower = parent_summary.lower()
        filename_lower = filename.lower()
        
        # Extract key terms from summary (words longer than 3 characters)
        summary_words = [word.strip('()[]{}.,;:!?') for word in summary_lower.split() 
                        if len(word.strip('()[]{}.,;:!?')) > 3]
        
        # Extract key terms from filename (remove file extension)
        filename_base = filename_lower.rsplit('.', 1)[0]  # Remove extension
        filename_words = [word.strip('()[]{}.,;:!?-') for word in filename_base.replace('_', ' ').replace('-', ' ').split()
                          if len(word.strip('()[]{}.,;:!?-')) > 2]
        
        # Check for direct keyword matches
        matched_keywords = []
        for word in summary_words:
            if word in filename_base:
                matched_keywords.append(word)
        
        # Check for partial matches (at least 4 characters)
        for word in summary_words:
            for fword in filename_words:
                if len(word) >= 4 and word in fword:
                    matched_keywords.append(word)
                elif len(fword) >= 4 and fword in word:
                    matched_keywords.append(fword)
        
        # Special relevance patterns
        relevance_patterns = [
            # Check if ticket key is in filename (already handled elsewhere, but include for completeness)
            ticket_key.lower(),
            # Common technical terms that might indicate relevance
            'architecture', 'design', 'specification', 'document', 'technical',
            'platform', 'system', 'implementation', 'feature', 'function'
        ]
        
        for pattern in relevance_patterns:
            if pattern in summary_lower and pattern in filename_base:
                matched_keywords.append(pattern)
        
        # Decision logic
        if len(matched_keywords) >= 2:
            # Strong relevance: 2 or more keyword matches
            relevance_score = "high"
            is_relevant = True
        elif len(matched_keywords) == 1:
            # Moderate relevance: 1 keyword match
            relevance_score = "medium"
            is_relevant = True
        elif any(word in filename_base for word in ['ad', 'fd']) and (ticket_key.lower() in filename_base):
            # Weak relevance: contains AD/FD and ticket key
            relevance_score = "low"
            is_relevant = True
        elif any(word in filename_base for word in ['architecture', 'design']) and len(matched_keywords) == 0:
            # Only generic architecture terms, no specific matches - not relevant enough
            relevance_score = "none"
            is_relevant = False
        else:
            # No clear relevance
            relevance_score = "none"
            is_relevant = False
        
        # Log the relevance check for debugging
        if matched_keywords:
            print(f"    🧩 Summary relevance check: {relevance_score} (matched: {', '.join(matched_keywords)})")
        else:
            print(f"    🧩 Summary relevance check: {relevance_score} (no matches)")
        
        return is_relevant
    
    def _has_relevance_potential(self, parent_summary: str, child_summary: str) -> bool:
        """Quick check if two summaries have any relevance potential."""
        if not parent_summary or not child_summary:
            return False
        
        parent_lower = parent_summary.lower()
        child_lower = child_summary.lower()
        
        # Extract key terms (words longer than 3 characters)
        parent_words = set(word.strip('()[]{}.,;:!?') for word in parent_lower.split() 
                         if len(word.strip('()[]{}.,;:!?')) > 3)
        child_words = set(word.strip('()[]{}.,;:!?') for word in child_lower.split() 
                        if len(word.strip('()[]{}.,;:!?')) > 3)
        
        # Check for any common words
        common_words = parent_words.intersection(child_words)
        
        # If there are 2+ common words, likely relevant
        return len(common_words) >= 2
    
    def load_version_data(self):
        """Load existing version tracking data."""
        if self.version_file.exists():
            try:
                with open(self.version_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
    
    def save_version_data(self):
        """Save version tracking data."""
        try:
            with open(self.version_file, 'w', encoding='utf-8') as f:
                json.dump(self.version_data, f, indent=2)
        except Exception as e:
            print(f"  ⚠️  Failed to save version data: {e}")
    
    def is_new_file(self, ticket_key: str, attachment_id: str, filename: str, created_date: str):
        """Check if this is a new file or updated version."""
        file_key = f"{ticket_key}_{attachment_id}"
        
        if file_key not in self.version_data:
            # New file
            self.version_data[file_key] = {
                'filename': filename,
                'created_date': created_date,
                'first_seen': datetime.now().isoformat()
            }
            return True, "new"
        
        existing = self.version_data[file_key]
        if existing.get('filename') != filename or existing.get('created_date') != created_date:
            # Updated file
            old_info = existing.copy()
            self.version_data[file_key] = {
                'filename': filename,
                'created_date': created_date,
                'first_seen': existing.get('first_seen', datetime.now().isoformat()),
                'last_updated': datetime.now().isoformat(),
                'previous_filename': existing.get('filename'),
                'previous_created_date': existing.get('created_date')
            }
            return True, f"updated from {old_info.get('filename', 'unknown')}"
        
        return False, "existing"
        
    def sanitize_filename(self, filename: str) -> str:
        """Sanitize filename for safe filesystem usage."""
        invalid_chars = r'[<>:"/\\|?*]'
        filename = re.sub(invalid_chars, '_', filename)
        if len(filename) > 200:
            name, ext = os.path.splitext(filename)
            filename = name[:200-len(ext)] + ext
        return filename
    
    def sanitize_folder_name(self, folder_name: str) -> str:
        """Sanitize folder name for safe filesystem usage."""
        invalid_chars = r'[<>:"/\\|?*]'
        folder_name = re.sub(invalid_chars, '_', folder_name)
        folder_name = re.sub(r'[ ,]', '_', folder_name)
        if len(folder_name) > 80:
            folder_name = folder_name[:80]
        return folder_name
    
    def is_architecture_document(self, filename: str) -> bool:
        """Check if a filename matches Architecture Document patterns."""
        for pattern in self.ad_patterns:
            if re.match(pattern, filename, re.IGNORECASE):
                return True
        return False
    
    def get_ticket_summary(self, jira, ticket_key: str) -> Dict:
        """Get ticket summary using JIRA API."""
        try:
            # Get issue with summary, status, assignee, and attachments
            issue = jira.issue(ticket_key, fields='summary,status,assignee,priority,reporter,created,updated,attachment')
            
            if not issue:
                print(f"Error getting summary for {ticket_key}: Issue not found")
                return {}
            
            fields = issue.get('fields', {})
            summary = fields.get('summary', 'No Summary Available')
            status = fields.get('status', {}).get('name', 'Unknown') if fields.get('status') else 'Unknown'
            assignee = fields.get('assignee', {}).get('displayName', 'Unassigned') if fields.get('assignee') else 'Unassigned'
            priority = fields.get('priority', {}).get('name', 'Unknown') if fields.get('priority') else 'Unknown'
            reporter = fields.get('reporter', {}).get('displayName', 'Unknown') if fields.get('reporter') else 'Unknown'
            created = fields.get('created', '')[:10]
            updated = fields.get('updated', '')[:10]
            
            # Parse attachments
            attachments = fields.get('attachment', [])
            attachment_list = []
            for attachment in attachments:
                attachment_list.append({
                    'id': str(attachment.get('id', '')),
                    'filename': attachment.get('filename', ''),
                    'size': attachment.get('size', 0),
                    'size_kb': str(round(attachment.get('size', 0) / 1024))
                })
            
            return {
                'summary': summary,
                'status': status,
                'assignee': assignee,
                'priority': priority,
                'reporter': reporter,
                'created': created,
                'updated': updated,
                'attachments': attachment_list
            }
                
        except Exception as e:
            print(f"Exception getting summary for {ticket_key}: {e}")
            return {}
    
    def download_attachment(self, jira, ticket_key: str, attachment_id: str, filename: str, target_path: Path, config=None) -> bool:
        """Download a JIRA attachment using JIRA API with smart version checking."""
        try:
            # Get attachment metadata first to calculate content hash
            jira_base_url = config['jira']['url'] if config and 'jira' in config else 'https://jira.cpg.dell.com'
            attachment_url = f"{jira_base_url}/rest/api/2/attachment/{attachment_id}"
            
            try:
                attachment_response = jira.session.get(attachment_url, timeout=10)
                attachment_response.raise_for_status()
                attachment = attachment_response.json()
            except requests.exceptions.RequestException as e:
                print(f"  ❌ Failed to get attachment metadata: {e}")
                return False
            
            if not attachment:
                print(f"  ❌ Attachment {attachment_id} not found")
                return False
            
            # Calculate content hash for version checking
            content_hash = None
            download_url = attachment.get('content')
            if download_url:
                try:
                    # Get content hash from response headers or calculate from content
                    content_response = jira.session.get(download_url, stream=True, timeout=30)
                    content_response.raise_for_status()
                    
                    # Calculate MD5 hash of content for comparison
                    import hashlib
                    hash_md5 = hashlib.md5()
                    for chunk in content_response.iter_content(chunk_size=8192):
                        if chunk:
                            hash_md5.update(chunk)
                    content_hash = hash_md5.hexdigest()
                    
                    # Reset connection for actual download
                    content_response = jira.session.get(download_url, stream=True, timeout=30)
                    content_response.raise_for_status()
                except requests.exceptions.RequestException:
                    content_hash = None
            
            # Check if we should download this file
            should_download, existing_files = self.download_manager.should_download(filename, content_hash)
            
            if not should_download:
                if existing_files:
                    existing_file = existing_files[0]
                    print(f"  ⏭️  Skipping {filename} (already exists: {existing_file.name})")
                    return True
                else:
                    print(f"  ⏭️  Skipping {filename} (duplicate content)")
                    return True
            
            if not download_url:
                print(f"  ❌ No download URL found for attachment {attachment_id}")
                return False
            
            # Generate unique filename if needed
            final_filename = self.download_manager.generate_unique_filename(filename, existing_files)
            final_target_path = target_path.parent / final_filename
            
            # Download the file with timeout
            try:
                if content_hash:
                    # Use the content we already fetched
                    response = content_response
                else:
                    response = jira.session.get(download_url, stream=True, timeout=30)
                    response.raise_for_status()
            except requests.exceptions.RequestException as e:
                print(f"  ❌ Failed to download file: {e}")
                return False
            
            # Ensure parent directory exists
            final_target_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Download with progress indication for large files
            total_size = int(response.headers.get('content-length', 0))
            downloaded_size = 0
            
            with open(final_target_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded_size += len(chunk)
            
            status_msg = f"  📄 Downloaded {ticket_key} attachment {attachment_id}: {final_filename} ({downloaded_size} bytes)"
            if final_filename != filename:
                status_msg += f" (renamed from {filename})"
            print(status_msg)
            
            return True
            
        except Exception as e:
            print(f"  ❌ Unexpected error downloading attachment {attachment_id}: {e}")
            return False
    
    def process_ticket(self, jira, ticket_key: str, config=None) -> Dict:
        """Process a single PBA ticket and download Architecture Documents."""
        print(f"\n🔍 Processing {ticket_key}...")
        
        # Get ticket summary
        summary_data = self.get_ticket_summary(jira, ticket_key)
        
        if not summary_data:
            print(f"  ⚠️  Could not get summary for {ticket_key}")
            return {
                'ticket_key': ticket_key,
                'error': 'Could not retrieve ticket summary',
                'downloaded_files': []
            }
        
        summary = summary_data.get('summary', 'No Summary Available')
        status = summary_data.get('status', 'Unknown')
        assignee = summary_data.get('assignee', 'Unassigned')
        attachments = summary_data.get('attachments', [])
        
        # Handle case where summary is empty or missing (like PBA-1767)
        if not summary or summary.strip() == '' or summary == 'No Summary Available':
            summary = f"No_Summary_{ticket_key}"
            print(f"  ℹ️  No summary found for {ticket_key}, using placeholder")
        
        # Create folder based on ticket key and summary
        folder_name = f"{ticket_key}_{self.sanitize_folder_name(summary)}"
        ticket_dir = self.base_dir / folder_name
        ticket_dir.mkdir(exist_ok=True)
        
        # Filter for Architecture Documents from main ticket
        ad_attachments = []
        for attachment in attachments:
            filename = attachment.get('filename', '')
            if self.is_architecture_document(filename):
                ad_attachments.append(attachment)
                print(f"  Found Architecture Document: {filename}")
        
        # Get linked issues and check for Architecture Documents (LIMITED TO 2 LAYERS)
        try:
            print(f"  Checking linked issues (2-layer limit)...")
            linked_issue = jira.issue(ticket_key, fields='issuelinks')
            linked_issues = linked_issue.get('fields', {}).get('issuelinks', [])
            
            processed_tickets = set()  # Avoid duplicates
            processed_tickets.add(ticket_key)  # Skip self
            
            for link in linked_issues:
                # Get both inward and outward issues
                target_issue = link.get('outwardIssue') or link.get('inwardIssue')
                if not target_issue:
                    continue
                
                linked_key = target_issue.get('key')
                if not linked_key or linked_key in processed_tickets:
                    continue
                
                # Only check PBA tickets (simplified scope)
                linked_project = linked_key.split('-')[0]
                if linked_project != 'PBA':
                    continue
                
                processed_tickets.add(linked_key)
                
                print(f"  Analyzing linked issue: {linked_key}")
                
                # Get linked issue details
                linked_summary_data = self.get_ticket_summary(jira, linked_key)
                if linked_summary_data:
                    linked_attachments = linked_summary_data.get('attachments', [])
                    linked_summary = linked_summary_data.get('summary', 'No Summary Available')
                    linked_status = linked_summary_data.get('status', 'Unknown')
                    
                    print(f"    📋 {linked_key}: {linked_summary[:50]}... ({linked_status})")
                    print(f"    📎 Found {len(linked_attachments)} attachments")
                    
                    # Quick relevance check before processing attachments
                    if not self._has_relevance_potential(summary, linked_summary):
                        print(f"    ⚠️  Skipping - no relevance potential with parent summary")
                        continue
                    
                    # Check for Architecture Documents in linked issue
                    for attachment in linked_attachments:
                        filename = attachment.get('filename', '')
                        if self.is_architecture_document(filename):
                            # Additional check: verify relevance to linked ticket summary
                            is_relevant = self.check_summary_relevance(linked_summary, filename, linked_key)
                            
                            if is_relevant:
                                ad_attachment = attachment.copy()
                                ad_attachment['linked_from'] = linked_key
                                ad_attachment['linked_summary'] = linked_summary
                                ad_attachment['linked_type'] = 'Linked Issue'
                                ad_attachment['relevance_score'] = 'medium'
                                ad_attachments.append(ad_attachment)
                                print(f"    Found Relevant Architecture Document in linked issue: {filename}")
                            else:
                                print(f"    Architecture Document not relevant to linked issue: {filename}")
            
            # Only check Target end relationships (simplified - no reverse search)
            print(f"  Checking Target end relationships...")
            try:
                # Get current ticket's Target end field
                current_issue = jira.issue(ticket_key, fields='customfield_25202')
                target_end = current_issue.get('fields', {}).get('customfield_25202')
                
                if target_end and target_end.strip():
                    target_key = target_end.strip()
                    print(f"  Analyzing Target end issue: {target_key}")
                    
                    # Get target issue details
                    target_summary_data = self.get_ticket_summary(jira, target_key)
                    if target_summary_data:
                        target_attachments = target_summary_data.get('attachments', [])
                        target_summary = target_summary_data.get('summary', 'No Summary Available')
                        target_status = target_summary_data.get('status', 'Unknown')
                        
                        print(f"    📋 {target_key}: {target_summary[:50]}... ({target_status})")
                        print(f"    📎 Found {len(target_attachments)} attachments")
                        
                        # Quick relevance check
                        if not self._has_relevance_potential(summary, target_summary):
                            print(f"    ⚠️  Skipping - no relevance potential with parent summary")
                        else:
                            # Filter for Architecture Documents in target issue
                            for attachment in target_attachments:
                                filename = attachment.get('filename', '')
                                if self.is_architecture_document(filename):
                                    # Additional check: verify relevance to target ticket summary
                                    is_relevant = self.check_summary_relevance(target_summary, filename, target_key)
                                    
                                    if is_relevant:
                                        ad_attachment = attachment.copy()
                                        ad_attachment['linked_from'] = target_key
                                        ad_attachment['linked_summary'] = target_summary
                                        ad_attachment['linked_type'] = 'Target end'
                                        ad_attachment['relevance_score'] = 'high'
                                        ad_attachments.append(ad_attachment)
                                        print(f"    Found Relevant Architecture Document in Target end issue: {filename}")
                                    else:
                                        print(f"    Architecture Document not relevant to target: {filename}")
                else:
                    print(f"  No Target end relationship found")
                    
            except Exception as e:
                print(f"  Error checking Target end relationships: {e}")
                
        except Exception as e:
            print(f"  Error checking linked issues: {e}")
            print(f"  ⚠️  Error checking linked issues: {e}")
        
        # Step 4: Smart reverse search using JIRA fields and summary relevance
        print(f"  Checking reverse references using JIRA fields...")
        try:
            # Method 1: Check customfield_46401 field - most efficient for reverse lookup
            reverse_jql = f"project = PBA AND cf[46401] = {ticket_key}"
            print(f"    Searching for tickets with cf[46401] = {ticket_key}...")
            
            try:
                reverse_results = jira.jql(reverse_jql, limit=20)
                reverse_tickets = reverse_results.get('issues', [])
                
                if reverse_tickets:
                    print(f"    ✅ Found {len(reverse_tickets)} tickets with cf[46401] reference to {ticket_key}")
                    
                    for reverse_ticket in reverse_tickets:
                        reverse_key = reverse_ticket.get('key')
                        if reverse_key == ticket_key or reverse_key in processed_tickets:
                            continue
                        
                        reverse_summary_data = self.get_ticket_summary(jira, reverse_key)
                        if reverse_summary_data:
                            reverse_attachments = reverse_summary_data.get('attachments', [])
                            reverse_summary = reverse_summary_data.get('summary', 'No Summary Available')
                            reverse_status = reverse_summary_data.get('status', 'Unknown')
                            
                            print(f"      📋 {reverse_key}: {reverse_summary[:50]}... ({reverse_status})")
                            print(f"      📎 Found {len(reverse_attachments)} attachments")
                            
                            # Check for Architecture Documents
                            for attachment in reverse_attachments:
                                filename = attachment.get('filename', '')
                                if self.is_architecture_document(filename):
                                    print(f"      🎯 Found Architecture Document: {filename}")
                                    
                                    ad_attachment = attachment.copy()
                                    ad_attachment['linked_from'] = reverse_key
                                    ad_attachment['linked_summary'] = reverse_summary
                                    ad_attachment['linked_type'] = 'cf[46401] Reference'
                                    ad_attachment['relevance_score'] = 'high'
                                    ad_attachments.append(ad_attachment)
                                    print(f"      ✅ Added Architecture Document from {reverse_key}")
                else:
                    print(f"    No tickets found with cf[46401] = {ticket_key}")
                    
            except Exception as e:
                print(f"    cf[46401] search failed: {e}")
            
            # Method 2: Check summary relevance (only if no cf[46401] results)
            if not ad_attachments:
                print(f"    No cf[46401] references found, checking summary relevance...")
                
                # Extract key terms from current ticket summary for relevance matching
                current_summary_data = self.get_ticket_summary(jira, ticket_key)
                current_summary = current_summary_data.get('summary', '') if current_summary_data else ''
                
                # Extract key terms (remove common words, keep technical terms)
                key_terms = []
                if current_summary:
                    words = [w.strip('()[]{}.,;:!?-') for w in current_summary.split() 
                           if len(w.strip('()[]{}.,;:!?-')) > 3]
                    # Filter out common words and keep technical terms
                    common_words = {'the', 'and', 'for', 'with', 'from', 'this', 'that', 'will', 'have', 'been', 'are', 'was', 'were', 'has', 'had', 'not', 'but', 'they', 'their', 'them', 'would', 'could', 'should'}
                    key_terms = [w for w in words if w.lower() not in common_words and len(w) > 3][:5]  # Top 5 key terms
                
                if key_terms:
                    print(f"    Key terms for relevance: {', '.join(key_terms)}")
                    
                    # Search for PBA tickets with similar summaries
                    summary_jql = "project = PBA AND attachments is not EMPTY ORDER BY key ASC"
                    summary_results = jira.jql(summary_jql, limit=10)  # Reduced limit for efficiency
                    
                    print(f"    Checking {len(summary_results.get('issues', []))} tickets for summary relevance...")
                    
                    relevance_count = 0
                    for ticket in summary_results.get('issues', []):
                        if relevance_count >= 5:  # Limit relevance checks
                            break
                            
                        check_key = ticket.get('key')
                        if check_key == ticket_key or check_key in processed_tickets:
                            continue
                        
                        check_summary_data = self.get_ticket_summary(jira, check_key)
                        if check_summary_data:
                            check_summary = check_summary_data.get('summary', '')
                            check_attachments = check_summary_data.get('attachments', [])
                            
                            # Quick relevance check
                            if self._has_relevance_potential(current_summary, check_summary):
                                relevance_count += 1
                                check_status = check_summary_data.get('status', 'Unknown')
                                
                                print(f"      📋 {check_key}: {check_summary[:50]}... ({check_status})")
                                print(f"      📎 Found {len(check_attachments)} attachments")
                                
                                # Check for Architecture Documents
                                for attachment in check_attachments:
                                    filename = attachment.get('filename', '')
                                    if self.is_architecture_document(filename):
                                        # Additional check: verify filename relevance
                                        if any(term.lower() in filename.lower() for term in key_terms) or ticket_key.lower() in filename.lower():
                                            print(f"      🎯 Found relevant Architecture Document: {filename}")
                                            
                                            ad_attachment = attachment.copy()
                                            ad_attachment['linked_from'] = check_key
                                            ad_attachment['linked_summary'] = check_summary
                                            ad_attachment['linked_type'] = 'Summary Relevance'
                                            ad_attachment['relevance_score'] = 'medium'
                                            ad_attachments.append(ad_attachment)
                                            print(f"      ✅ Added Architecture Document from {check_key}")
                else:
                    print(f"    No key terms extracted from summary, skipping relevance check")
                    
        except Exception as e:
            print(f"  Error in smart reverse search: {e}")
        
        # Download Architecture Documents
        downloaded_files = []
        new_files = []
        updated_files = []
        
        for attachment in ad_attachments:
            filename = self.sanitize_filename(attachment.get('filename', ''))
            target_path = ticket_dir / filename
            
            # Check if this is a new or updated file
            attachment_id = attachment.get('id', '')
            created_date = attachment.get('created_date', '')
            is_new, status = self.is_new_file(ticket_key, attachment_id, filename, created_date)
            
            if is_new:
                if status == "new":
                    new_files.append(filename)
                    print(f"  🆕 New Architecture Document: {filename}")
                elif status.startswith("updated"):
                    updated_files.append((filename, status))
                    print(f"  🔄 Updated Architecture Document: {filename} ({status})")
            
            # Add linked issue info to filename if applicable
            if attachment.get('linked_from'):
                linked_from = attachment.get('linked_from')
                filename_with_source = f"{linked_from}_{filename}"
                filename_with_source = self.sanitize_filename(filename_with_source)
                target_path = ticket_dir / filename_with_source
                print(f"  📄 Downloading from linked issue {linked_from}")
            
            if self.download_attachment(jira, ticket_key, attachment_id, filename, target_path, config):
                downloaded_files.append({
                    'filename': filename,
                    'path': str(target_path),
                    'size_kb': attachment.get('size_kb', '0'),
                    'type': 'Architecture Document',
                    'attachment_id': attachment_id,
                    'linked_from': attachment.get('linked_from', ''),
                    'linked_summary': attachment.get('linked_summary', ''),
                    'linked_type': attachment.get('linked_type', ''),
                    'relevance_score': attachment.get('relevance_score', ''),
                    'version_status': status,
                    'is_new': is_new
                })
        
        # Save version data
        self.save_version_data()
        
        result = {
            'ticket_key': ticket_key,
            'summary': summary,
            'status': status,
            'assignee': assignee,
            'folder_name': folder_name,
            'total_attachments': len(attachments),
            'ad_attachments': len(ad_attachments),
            'downloaded_files': downloaded_files,
            'new_files': new_files,
            'updated_files': updated_files
        }
        
        print(f"  📊 Found {len(attachments)} total attachments, {len(ad_attachments)} Architecture Documents")
        print(f"  💾 Downloaded {len(downloaded_files)} files to {folder_name}")
        
        return result
    
    def get_all_pba_tickets_from_filter(self, jira, filter_id: str = "139839") -> List[str]:
        """Get all PBA ticket keys from filter."""
        try:
            # Get filter results using JQL
            results = jira.jql(f"filter = {filter_id}", limit=200)
            issues = results.get('issues', [])
            
            if not issues:
                print("❌ No tickets found in filter")
                return []
            
            ticket_keys = [issue.get('key', '') for issue in issues if issue.get('key', '').startswith('PBA-')]
            
            print(f"📋 Found {len(ticket_keys)} PBA tickets from filter {filter_id}")
            return ticket_keys
                
        except Exception as e:
            print(f"❌ Exception getting tickets from filter: {e}")
            return []
    
    def process_all_tickets(self, jira, filter_id: str = "139839", config=None) -> Dict:
        """Process all PBA tickets from the NUDD filter."""
        print("🚀 Starting NUDD Architecture Document Downloader")
        print("=" * 60)
        
        ticket_keys = self.get_all_pba_tickets_from_filter(jira, filter_id)
        
        if not ticket_keys:
            print("❌ No tickets found to process")
            return {
                'processed_tickets': [],
                'total_tickets': 0,
                'tickets_with_ads': 0,
                'total_downloads': 0,
                'errors': []
            }
        
        results = {
            'processed_tickets': [],
            'total_tickets': len(ticket_keys),
            'tickets_with_ads': 0,
            'total_downloads': 0,
            'errors': []
        }
        
        for i, ticket_key in enumerate(ticket_keys, 1):
            print(f"\n[{i}/{len(ticket_keys)}] Processing {ticket_key}")
            
            try:
                result = self.process_ticket(jira, ticket_key, config)
                results['processed_tickets'].append(result)
                
                if result.get('ad_attachments', 0) > 0:
                    results['tickets_with_ads'] += 1
                    results['total_downloads'] += len(result.get('downloaded_files', []))
                
            except Exception as e:
                error_msg = f"Error processing {ticket_key}: {e}"
                results['errors'].append(error_msg)
                print(f"❌ {error_msg}")
        
        return results
    
    def generate_report(self, results: Dict) -> str:
        """Generate a comprehensive report of the download process."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Calculate percentage
        percentage = ((results['tickets_with_ads']/results['total_tickets'])*100) if results['total_tickets'] > 0 else 0
        percentage = round(percentage, 1)
        
        # Collect version information
        all_new_files = []
        all_updated_files = []
        
        for ticket_result in results.get('processed_tickets', []):
            all_new_files.extend(ticket_result.get('new_files', []))
            all_updated_files.extend(ticket_result.get('updated_files', []))
        
        report = f"""# NUDD Architecture Documents Download Report

**Generated:** {timestamp}
**Total Tickets Processed:** {results['total_tickets']}
**Tickets with Architecture Documents:** {results['tickets_with_ads']}
**Total Files Downloaded:** {results['total_downloads']}

## 📊 Summary

- Successfully processed {len(results['processed_tickets'])} tickets
- Found Architecture Documents in {results['tickets_with_ads']} tickets ({percentage}%)
- Downloaded {results['total_downloads']} files total

## 🆕 New Files Detected

"""
        
        if all_new_files:
            for filename in all_new_files:
                report += f"- 🆕 {filename}\n"
        else:
            report += "- No new files detected\n"
        
        report += f"""
## 🔄 Updated Files Detected

"""
        
        if all_updated_files:
            for filename, update_info in all_updated_files:
                report += f"- 🔄 {filename} ({update_info})\n"
        else:
            report += "- No updated files detected\n"
        
        report += f"""
## 🎯 Architecture Document Details

"""
        
        # Sort tickets by key for better organization
        processed_tickets = sorted(results['processed_tickets'], 
                                  key=lambda x: x.get('ticket_key', ''))
        
        for ticket_result in processed_tickets:
            if ticket_result.get('ad_attachments', 0) > 0:
                report += f"### {ticket_result.get('ticket_key', 'Unknown')}: {ticket_result.get('summary', 'Unknown Summary')}\n"
                report += f"- **Status:** {ticket_result.get('status', 'Unknown')}\n"
                report += f"- **Assignee:** {ticket_result.get('assignee', 'Unknown')}\n"
                report += f"- **Folder:** `{ticket_result.get('folder_name', 'Unknown')}`\n"
                report += f"- **Architecture Documents:** {ticket_result.get('ad_attachments', 0)}\n"
                report += f"- **Files Downloaded:** {len(ticket_result.get('downloaded_files', []))}\n\n"
                
                for file_info in ticket_result.get('downloaded_files', []):
                    version_indicator = ""
                    if file_info.get('is_new'):
                        if file_info.get('version_status') == 'new':
                            version_indicator = " 🆕"
                        elif file_info.get('version_status', '').startswith('updated'):
                            version_indicator = " 🔄"
                    
                    linked_info = f" (from {file_info.get('linked_from', 'main ticket')})" if file_info.get('linked_from') else ""
                    report += f"  - 📄{version_indicator} {file_info.get('filename', 'Unknown')} ({file_info.get('size_kb', 0)} KB){linked_info}\n"
                report += "\n"
        
        # Add tickets without Architecture Documents
        tickets_without_ads = [t for t in processed_tickets if t.get('ad_attachments', 0) == 0 and 'error' not in t]
        if tickets_without_ads:
            report += "## ❌ Tickets Without Architecture Documents\n\n"
            for ticket_result in tickets_without_ads[:20]:  # Limit to first 20
                report += f"- {ticket_result.get('ticket_key', 'Unknown')}: {ticket_result.get('summary', 'Unknown Summary')}\n"
            if len(tickets_without_ads) > 20:
                report += f"- ... and {len(tickets_without_ads) - 20} more\n"
            report += f"\n**Total tickets without Architecture Documents:** {len(tickets_without_ads)}\n\n"
        
        # Add tickets with errors
        tickets_with_errors = [t for t in processed_tickets if 'error' in t]
        if tickets_with_errors:
            report += "## 🚨 Tickets With Processing Errors\n\n"
            for ticket_result in tickets_with_errors:
                report += f"- {ticket_result.get('ticket_key', 'Unknown')}: {ticket_result.get('error', 'Unknown error')}\n"
            report += f"\n**Total tickets with errors:** {len(tickets_with_errors)}\n\n"
        
        if results.get('errors'):
            report += "## 🚨 System Errors\n\n"
            for error in results['errors']:
                report += f"- {error}\n"
        
        # Add version summary
        report += f"""
## 📈 Version Summary

- **New files:** {len(all_new_files)}
- **Updated files:** {len(all_updated_files)}
- **Version tracking file:** `.nudd_version_tracking.json`

"""
        
        # Add version information
        report += f"---\n\n**Report generated by NUDD Architecture Document Downloader**\n"
        report += f"**Base directory:** {self.base_dir}\n"
        report += f"**Processing completed:** {timestamp}\n"
        
        return report


def cmd_nudd_single(jira, args, config=None):
    """Command to download Architecture Documents from a single PBA ticket and its linked issues."""
    try:
        downloader = NuddDocumentDownloader(base_dir=args.base_dir)
        
        print(f"🚀 Starting NUDD Architecture Document Downloader for single ticket")
        print(f"🎯 Target ticket: {args.key}")
        print("=" * 60)
        
        # Process the single ticket
        result = downloader.process_ticket(jira, args.key, config)
        
        # Generate results structure for report
        results = {
            'processed_tickets': [result],
            'total_tickets': 1,
            'tickets_with_ads': 1 if result.get('ad_attachments', 0) > 0 else 0,
            'total_downloads': len(result.get('downloaded_files', [])),
            'errors': []
        }
        
        # Generate report
        report_content = downloader.generate_report(results)
        
        # Save report if requested
        if args.save_report:
            report_path = save_report(
                content=report_content,
                report_name=f"nudd_single_{args.key}",
                description=f"NUDD Architecture Documents download from ticket {args.key}",
                skill_name="jira_integration"
            )
            print(f"\n📋 Report saved to: {report_path}")
        else:
            print("\n" + report_content)
        
        # Print summary
        print(f"\n=== Processing Complete ===")
        print(f"📊 Summary:")
        print(f"   - Ticket processed: {args.key}")
        print(f"   - Architecture Documents found: {result.get('ad_attachments', 0)}")
        print(f"   - Files downloaded: {len(result.get('downloaded_files', []))}")
        print(f"   - Errors: {len(results.get('errors', []))}")
        print(f"\n📁 Files saved to: {downloader.base_dir}")
        
        if result.get('ad_attachments', 0) > 0:
            print(f"\n🎯 Architecture Documents found:")
            for file_info in result.get('downloaded_files', []):
                linked_info = f" (from {file_info.get('linked_from', 'main ticket')})" if file_info.get('linked_from') else ""
                print(f"   - {file_info.get('filename', 'Unknown')}{linked_info}")
        
    except Exception as e:
        print(f"ERROR: Failed to download Architecture Documents from {args.key}: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_nudd_download(jira, args, config=None):
    """Command to download NUDD Architecture Documents."""
    import time
    
    # Record start time
    start_time = time.time()
    print(f"Starting NUDD Architecture Document Downloader at {time.strftime('%Y-%m-%d %H:%M:%S')}")
    
    try:
        # Auto-detect filter from Confluence if confluence_page_id is provided
        filter_to_use = args.filter
        confluence_info = None
        
        if hasattr(args, 'confluence_page_id') and args.confluence_page_id:
            print(f"Analyzing Confluence page {args.confluence_page_id} for filter...")
            confluence_info = analyze_confluence_filter(args.confluence_page_id)
            
            if confluence_info['success']:
                filter_to_use = confluence_info['filter_id']
                print(f"Found filter {filter_to_use} ({confluence_info['filter_type']}) from Confluence page '{confluence_info['page_title']}'")
                print(f"Analysis confidence: {confluence_info['confidence']} (score: {confluence_info['score']})")
                if confluence_info.get('total_filters_found', 0) > 1:
                    print(f"Found {confluence_info['total_filters_found']} filters total, selected the most relevant one")
            else:
                print(f"❌ Failed to analyze Confluence page: {confluence_info['error']}")
                print(f"Confluence page analysis failed - possible causes:")
                print(f"   - Page ID {args.confluence_page_id} may not exist")
                print(f"   - Page may not contain JIRA filter information")
                print(f"   - Confluence configuration may be incorrect")
                print(f"\n💡 Suggestions:")
                print(f"   1. Use manual filter: --filter <filter_id>")
                print(f"   2. Try a different Confluence page ID")
                print(f"   3. Check Confluence configuration")
                
                print(f"\n❌ Aborting due to Confluence page analysis failure.")
                sys.exit(1)
        
        downloader = NuddDocumentDownloader(base_dir=args.base_dir)
        results = downloader.process_all_tickets(jira, filter_to_use, config)
        report_content = downloader.generate_report(results)
        
        # Record end time and calculate duration
        end_time = time.time()
        duration = end_time - start_time
        hours = int(duration // 3600)
        minutes = int((duration % 3600) // 60)
        seconds = int(duration % 60)
        
        # Format duration string
        if hours > 0:
            duration_str = f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            duration_str = f"{minutes}m {seconds}s"
        else:
            duration_str = f"{seconds}s"
        
        print(f"\n✅ Completed at {time.strftime('%Y-%m-%d %H:%M:%S')} (Total time: {duration_str})")
        
        # Save report if requested
        if args.save_report:
            report_description = f"NUDD Architecture Documents download from filter {filter_to_use}"
            if confluence_info and confluence_info['success']:
                report_description += f" (auto-detected from Confluence page {args.confluence_page_id})"
            elif hasattr(args, 'confluence_page_id') and args.confluence_page_id:
                report_description += f" (Confluence analysis failed, used fallback)"
            
            report_path = save_report(
                content=report_content,
                report_name="nudd_architecture_documents_download",
                description=report_description,
                skill_name="jira_integration"
            )
            print(f"\n📋 Report saved to: {report_path}")
        else:
            print("\n" + report_content)
        
        # Print summary
        print(f"\n=== Processing Complete ===")
        print(f"📊 Summary:")
        print(f"   - Total tickets processed: {results['total_tickets']}")
        print(f"   - Tickets with Architecture Documents: {results['tickets_with_ads']}")
        print(f"   - Total files downloaded: {results['total_downloads']}")
        print(f"   - Errors: {len(results.get('errors', []))}")
        print(f"   - Total processing time: {duration_str}")
        
        # Show filter source with clear indication
        if confluence_info and confluence_info['success']:
            print(f"   - Filter source: ✅ Confluence page '{confluence_info['page_title']}' ({confluence_info['filter_type']})")
            print(f"   - Analysis confidence: {confluence_info['confidence']} (score: {confluence_info['score']})")
        elif hasattr(args, 'confluence_page_id') and args.confluence_page_id:
            print(f"   - Filter source: ❌ Confluence analysis failed (used fallback)")
            print(f"   - Original page ID: {args.confluence_page_id}")
        else:
            print(f"   - Filter source: Manual input")
            
        print(f"\n📁 Files saved to: {downloader.base_dir}")
        
        if results['tickets_with_ads'] > 0:
            print(f"\n🎯 Found Architecture Documents in the following tickets:")
            for ticket_result in results['processed_tickets']:
                if ticket_result.get('ad_attachments', 0) > 0:
                    print(f"   - {ticket_result.get('ticket_key', 'Unknown')}: {ticket_result.get('summary', 'Unknown Summary')}")
        
    except Exception as e:
        print(f"ERROR: Failed to download NUDD Architecture Documents: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="Generic Jira Tool")
    parser.add_argument("--config", default="config.toml", help="Path to config file")
    
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # GET
    p_get = subparsers.add_parser("get", help="Get issue details")
    p_get.add_argument("--key", required=True, help="Issue key")
    p_get.add_argument("--fields", help="Comma-separated fields to retrieve")
    p_get.add_argument("--expand", help="Expand specific parameters (e.g. changelog,renderedFields)")
    p_get.set_defaults(func=cmd_get)
    
    # CHANGELOG
    p_changelog = subparsers.add_parser("changelog", help="Get issue changelog summary")
    p_changelog.add_argument("--key", required=True, help="Issue key")
    p_changelog.set_defaults(func=cmd_changelog)

    # GET LINKS
    p_get_links = subparsers.add_parser("get-links", help="Get linked issues summary")
    p_get_links.add_argument("--key", required=True, help="Issue key")
    p_get_links.add_argument("--json", action="store_true", help="Output as JSON")
    p_get_links.add_argument("--detailed", action="store_true", help="Fetch full details for linked issues (slow)")
    p_get_links.add_argument("--output", help="Write output to file")
    p_get_links.set_defaults(func=cmd_get_links)

    # ANALYZE PIMS
    p_analyze = subparsers.add_parser("analyze-pims", help="Analyze PIMS ticket for time-in-state")
    p_analyze.add_argument("--key", required=True, help="Issue key")
    p_analyze.set_defaults(func=cmd_analyze_pims)
    
    # SEARCH
    p_search = subparsers.add_parser("search", help="Search issues (JQL)")
    p_search.add_argument("--jql", required=True, help="JQL query")
    p_search.add_argument("--limit", type=int, default=50, help="Max results")
    p_search.add_argument("--start", type=int, default=0, help="Start index")
    p_search.set_defaults(func=cmd_search)
    
    # BATCH SEARCH
    p_batch_search = subparsers.add_parser("batch-search", help="Search and batch process multiple tickets with summary")
    p_batch_search.add_argument("--jql", required=True, help="JQL query")
    p_batch_search.add_argument("--limit", type=int, default=50, help="Max results")
    p_batch_search.add_argument("--start", type=int, default=0, help="Start index")
    p_batch_search.add_argument("--save-report", action="store_true", help="Save report to .windsurf/Reports directory")
    p_batch_search.set_defaults(func=cmd_batch_search)
    
    # CHECK TBABP1
    p_check_tbabp1 = subparsers.add_parser("check-tbabp1", help="Check TBABP1 ticket for required fields (SSID, BIOS_Version, BIOS_Source, Epic Link)")
    p_check_tbabp1.add_argument("--key", required=True, help="TBABP1 ticket key")
    p_check_tbabp1.set_defaults(func=cmd_check_tbabp1)
    
    # NUDD DOWNLOAD
    p_nudd_download = subparsers.add_parser("nudd-download", help="Download NUDD Architecture Documents from PBA tickets")
    p_nudd_download.add_argument("--filter", default="139839", help="JIRA filter ID for PBA tickets (default: 139839, will be auto-detected if --confluence-page-id is provided)")
    p_nudd_download.add_argument("--confluence-page-id", help="Confluence page ID to auto-detect filter from (overrides --filter)")
    p_nudd_download.add_argument("--base-dir", default="NUDD", help="Base directory for downloaded files (default: NUDD)")
    p_nudd_download.add_argument("--save-report", action="store_true", help="Save report to .windsurf/Reports directory")
    p_nudd_download.set_defaults(func=cmd_nudd_download)
    
    # NUDD SINGLE TICKET
    p_nudd_single = subparsers.add_parser("nudd-single", help="Download Architecture Documents from a single PBA ticket and its linked issues")
    p_nudd_single.add_argument("--key", required=True, help="PBA ticket key to analyze")
    p_nudd_single.add_argument("--base-dir", default="NUDD", help="Base directory for downloaded files (default: NUDD)")
    p_nudd_single.add_argument("--save-report", action="store_true", help="Save report to .windsurf/Reports directory")
    p_nudd_single.set_defaults(func=cmd_nudd_single)
    
    # TRANSITION
    p_trans = subparsers.add_parser("transition", help="Transition issue status")
    p_trans.add_argument("--key", required=True, help="Issue key")
    p_trans.add_argument("--status", required=True, help="Target status name")
    p_trans.add_argument("--resolution", help="Resolution name (e.g. 'Fixed') if closing")
    p_trans.set_defaults(func=cmd_transition)
    
    # COMMENT
    p_comment = subparsers.add_parser("comment", help="Add comment")
    p_comment.add_argument("--key", required=True, help="Issue key")
    p_comment.add_argument("--body", required=True, help="Comment body")
    p_comment.set_defaults(func=cmd_comment)
    
    # GET COMMENTS
    p_get_comments = subparsers.add_parser("get-comments", help="List comments for an issue")
    p_get_comments.add_argument("--key", required=True, help="Issue key")
    p_get_comments.add_argument("--json", action="store_true", help="Output as JSON")
    p_get_comments.set_defaults(func=cmd_get_comments)

    # DELETE COMMENT
    p_del_comment = subparsers.add_parser("delete-comment", help="Delete a comment from an issue")
    p_del_comment.add_argument("--key", required=True, help="Issue key")
    p_del_comment.add_argument("--id", required=True, help="Comment ID")
    p_del_comment.set_defaults(func=cmd_delete_comment)

    # EDIT COMMENT
    p_edit_comment = subparsers.add_parser("edit-comment", help="Edit a comment on an issue")
    p_edit_comment.add_argument("--key", required=True, help="Issue key")
    p_edit_comment.add_argument("--id", required=True, help="Comment ID")
    p_edit_comment.add_argument("--body", required=True, help="New comment body")
    p_edit_comment.set_defaults(func=cmd_edit_comment)
    
    # SUMMARIZE
    p_summarize = subparsers.add_parser("summarize", help="Consolidated issue summary dashboard")
    p_summarize.add_argument("--key", required=True, help="Issue key")
    p_summarize.set_defaults(func=cmd_summarize)
    
    # LINK
    p_link = subparsers.add_parser("link", help="Link issues")
    p_link.add_argument("--type", required=True, help="Link type (e.g. Relates)")
    p_link.add_argument("--inward", required=True, help="Source/Inward issue key")
    p_link.add_argument("--outward", required=True, help="Target/Outward issue key")
    p_link.set_defaults(func=cmd_link)
    
    # ASSIGN
    p_assign = subparsers.add_parser("assign", help="Assign issue")
    p_assign.add_argument("--key", required=True, help="Issue key")
    p_assign.add_argument("--user", required=True, help="Username or AccountId")
    p_assign.set_defaults(func=cmd_assign)

    # ADD WATCHER
    p_watcher = subparsers.add_parser("add-watcher", help="Add a watcher to an issue")
    p_watcher.add_argument("--key", required=True, help="Issue key")
    p_watcher.add_argument("--user", required=True, help="Username")
    p_watcher.set_defaults(func=cmd_add_watcher)

    # UPDATE FIELD
    p_update = subparsers.add_parser("update-field", help="Update a generic field on an issue")
    p_update.add_argument("--key", required=True, help="Issue key")
    p_update.add_argument("--field", required=True, help="Field name or ID (e.g. status-flag, duedate, customfield_123)")
    p_update.add_argument("--value", required=True, help="New value (for users, use username; for options, use value)")
    p_update.set_defaults(func=cmd_update_field)

    # UNLINK
    p_unlink = subparsers.add_parser("unlink", help="Unlink issues")
    p_unlink.add_argument("--key", required=True, help="Source Issue key")
    p_unlink.add_argument("--target", required=True, help="Target Linked Issue key")
    p_unlink.set_defaults(func=cmd_unlink)

    # ADD LABEL
    p_add_label = subparsers.add_parser("add-label", help="Add a label to an issue (appends)")
    p_add_label.add_argument("--key", required=True, help="Issue key")
    p_add_label.add_argument("--label", required=True, help="Label to add")
    p_add_label.set_defaults(func=cmd_add_label)

    # REMOVE LABEL
    p_remove_label = subparsers.add_parser("remove-label", help="Remove a label from an issue (preserves others)")
    p_remove_label.add_argument("--key", required=True, help="Issue key")
    p_remove_label.add_argument("--label", required=True, help="Label to remove")
    p_remove_label.set_defaults(func=cmd_remove_label)

    # ADD COMPONENT
    p_add_comp = subparsers.add_parser("add-component", help="Add components to an issue")
    p_add_comp.add_argument("--key", required=True, help="Issue key")
    p_add_comp.add_argument("--component", required=True, help="Component name(s), comma-separated")
    p_add_comp.set_defaults(func=cmd_add_component)

    # REMOVE COMPONENT
    p_remove_comp = subparsers.add_parser("remove-component", help="Remove components from an issue")
    p_remove_comp.add_argument("--key", required=True, help="Issue key")
    p_remove_comp.add_argument("--component", required=True, help="Component name(s), comma-separated")
    p_remove_comp.set_defaults(func=cmd_remove_component)

    # LINK TYPES
    p_link_types = subparsers.add_parser("link-types", help="List available issue link types")
    p_link_types.add_argument("--json", action="store_true", help="Output as JSON")
    p_link_types.set_defaults(func=cmd_link_types)

    # ANALYZE FIELDS
    p_analyze_fields = subparsers.add_parser("analyze-fields", help="Analyze field presence across issues")
    p_analyze_fields.add_argument("--keys", required=True, help="Comma-separated issue keys (e.g. KEY-1,KEY-2)")
    p_analyze_fields.set_defaults(func=cmd_analyze_fields)

    # ANALYZE (Deep Analysis)
    p_analyze_deep = subparsers.add_parser("analyze", help="Deep analysis of issue (PIMS)")
    p_analyze_deep.add_argument("--key", required=True, help="Issue key")
    p_analyze_deep.set_defaults(func=cmd_analyze)

    # DOWNLOAD ATTACHMENT
    p_download = subparsers.add_parser("download-attachment", help="Download an attachment from Jira")
    p_download.add_argument("--id", required=True, help="Attachment ID")
    p_download.add_argument("--out", help="Output path")
    p_download.set_defaults(func=cmd_download_attachment)

    args = parser.parse_args()
    
    # Load config relative to script -> skill root
    skill_dir = Path(__file__).parent.parent
    config_path = skill_dir / args.config
    config = load_config(config_path)
    
    jira = get_client(config)
    
    # Special handling for nudd commands to pass config
    if args.command in ["nudd-download", "nudd-single"]:
        args.func(jira, args, config)
    elif args.command == "check-tbabp1":
        args.func(jira, args, config)
    else:
        args.func(jira, args)

# --- Analysis Logic ---

# Field IDs for PIMS (Ported from analyze_jira.py)
PIMS_FIELDS = {
    "executive_status": "customfield_18717", # UI-1, UI-2, UI-3
    "comp_subcomp": "customfield_28436",
    "classify_subclassify": "customfield_36902",
    "executive_summary": "customfield_28473",
    "issue_severity": "customfield_28162",
    "steps_to_reproduce": "customfield_12707",
    "disposition_details": "customfield_26700", # Disposition Details
    "technical_root_cause": "customfield_18715", # Technical Root Cause
    "platform_impact": "customfield_28465", # Platform Impact Analysis
}

def get_value(field_data):
    """Safely extracts value from Jira field data."""
    if field_data is None: return "None"
    if isinstance(field_data, list):
        return ", ".join([get_value(item) for item in field_data])
    if isinstance(field_data, dict):
        return field_data.get('value') or field_data.get('name') or str(field_data)
    return str(field_data)

def get_dept(display_name):
    if not display_name or display_name == "None": return "Unknown"
    if '(' in display_name and ')' in display_name:
        return display_name.split('(')[1].split(')')[0]
    return "DELL / Internal"

def calculate_timeline(issue_data):
    histories = issue_data.get('changelog', {}).get('histories', [])
    created_str = issue_data.get('fields', {}).get('created')
    if not created_str: return {}

    states = {}
    assignments = {}
    depts = {}
    ui_levels = {}
    
    handoffs = []
    
    # Ensure histories are sorted by created timestamp
    sorted_histories = sorted(histories, key=lambda h: h['created'])
    last_time = datetime.fromisoformat(created_str.replace('Z', '+00:00'))
    
    # Initial state heuristics
    current_status = "Initial/Open"
    f = issue_data.get('fields', {})
    current_assignee = get_value(f.get('assignee'))
    current_ui = get_value(f.get(PIMS_FIELDS['executive_status']))
    
    # Find initial values from first changes (reverse logic or check first history?)
    # analyze_jira.py logic: scan histories to find first value that was changed FROM "None" or similar?
    # Actually analyze_jira.py logic was:
    # "Find initial values from first changes"
    for h in sorted_histories:
        for item in h.get('items', []):
            if item['field'] == 'assignee' and item['fromString']:
                current_assignee = item['fromString']
            if item['field'] == PIMS_FIELDS['executive_status'] and item['fromString']:
                current_ui = item['fromString']
        if current_assignee != "None" and current_ui != "None": break

    for h in sorted_histories:
        entry_time = datetime.fromisoformat(h['created'].replace('Z', '+00:00'))
        duration = (entry_time - last_time).total_seconds()
        author = h.get('author', {}).get('displayName', 'Unknown')
        
        if current_status:
            states[current_status] = states.get(current_status, 0) + duration
        if current_assignee and current_assignee != "None":
            assignments[current_assignee] = assignments.get(current_assignee, 0) + duration
            d = get_dept(current_assignee)
            depts[d] = depts.get(d, 0) + duration
        if current_ui and current_ui != "None":
            ui_levels[current_ui] = ui_levels.get(current_ui, 0) + duration

        for item in h.get('items', []):
            fld = item['field']
            f_from = item.get('fromString', 'None')
            f_to = item.get('toString', 'None')
            
            if fld == 'status': current_status = f_to
            elif fld == 'assignee': current_assignee = f_to if f_to else "None"
            elif fld == PIMS_FIELDS['executive_status']: current_ui = f_to if f_to else "None"
            elif fld in [PIMS_FIELDS['comp_subcomp'], PIMS_FIELDS['classify_subclassify']]:
                handoffs.append({
                    "time": h['created'][:16],
                    "author": author,
                    "field": "Org-Unit" if fld == PIMS_FIELDS['comp_subcomp'] else "Classify",
                    "from": f_from,
                    "to": f_to
                })
        
        last_time = entry_time

    # Current state until now
    now = datetime.now().astimezone()
    duration = (now - last_time).total_seconds()
    if current_status:
        states[current_status] = states.get(current_status, 0) + duration
    if current_assignee and current_assignee != "None":
        assignments[current_assignee] = assignments.get(current_assignee, 0) + duration
        d = get_dept(current_assignee)
        depts[d] = depts.get(d, 0) + duration
    if current_ui and current_ui != "None":
        ui_levels[current_ui] = ui_levels.get(current_ui, 0) + duration

    return {
        "statuses": {k: f"{v/3600:.2f}h" for k, v in states.items()},
        "assignees": {k: f"{v/3600:.2f}h" for k, v in assignments.items()},
        "departments": {k: f"{v/3600:.2f}h" for k, v in depts.items()},
        "ui_levels": {k: f"{v/3600:.2f}h" for k, v in ui_levels.items()},
        "handoffs": handoffs
    }

def cmd_analyze(jira: Jira, args):
    try:
        fields = f"summary,status,assignee,comment,attachment,description,reporter,components,created,issuelinks," \
                 f"resolution,fixVersions," \
                 f"{PIMS_FIELDS['executive_status']},{PIMS_FIELDS['comp_subcomp']},{PIMS_FIELDS['classify_subclassify']}," \
                 f"{PIMS_FIELDS['executive_summary']},{PIMS_FIELDS['issue_severity']},{PIMS_FIELDS['steps_to_reproduce']}," \
                 f"{PIMS_FIELDS['disposition_details']},{PIMS_FIELDS['technical_root_cause']},{PIMS_FIELDS['platform_impact']}"
        
        issue = jira.issue(args.key, fields=fields, expand="changelog")
        f = issue.get('fields', {})
        if not f:
             print(f"ERROR: Could not retrieve fields for {args.key}.", file=sys.stderr)
             sys.exit(1)
        
        project_key = args.key.split('-')[0]
        desc = f.get('description', 'No description provided.')
        status_name = f.get('status',{}).get('name')
        
        print(f"\n{'='*80}")
        print(f" JIRA DEEP ANALYSIS: {args.key} ({project_key})")
        print(f"{'='*80}")
        
        # --- Common Analysis (All Tickets) ---
        print(f"\n[1. Overview]")
        print(f"Summary       : {f.get('summary')}")
        print(f"Status        : {status_name}")
        
        assignee_name = get_value(f.get('assignee'))
        reporter_name = get_value(f.get('reporter'))
        print(f"Owner         : {assignee_name} ({get_dept(assignee_name)})")
        print(f"Reporter      : {reporter_name} ({get_dept(reporter_name)})")
        
        created_val = f.get('created', 'Unknown')
        print(f"Created       : {created_val[:16]}")

        # Description (Always show snippet if long, full if short)
        print(f"\nDescription   :")
        if len(desc) < 800:
            print(f"{desc.strip()}")
        else:
            print(f"{desc[:800].strip()}...\n(Description truncated, {len(desc)} chars total)")

        # --- Specialized Analysis ---
        if project_key == "CBDCIT":
            print(f"\n[2. CBDCIT Specific Analysis]")
            print("Purpose       : Common Code Change Notification")
            
            # Text Analysis
            platforms = []
            if "AgS" in desc:
                import re
                platforms = list(set(re.findall(r'AgS\d{4}(?:/Wave\d)?', desc)))
            print(f"Affected Repos: {', '.join(platforms) if platforms else 'None detected'}")

            # Change Type
            is_fix = any(x in desc.lower() for x in ["fix", "solve", "issue", "bug"])
            is_feat = any(x in desc.lower() for x in ["feature", "add", "support", "enable"])
            c_type = "Bug Fix" if is_fix else ("New Feature" if is_feat else "Unknown/Maintenance")
            print(f"Change Type   : {c_type}")

            # PCD Analysis
            has_pcd = "PCD" in desc or "Token" in desc
            print(f"UEFI PCDs     : {'Mentioned' if has_pcd else 'No explicit PCD mention'}")

        elif project_key == "PIMS":
            print(f"\n[2. PIMS Specific Analysis]")
            print(f"Context       : Validation/End-User Issue Tracking")
            print(f"UI Level      : {get_value(f.get(PIMS_FIELDS['executive_status']))}")
            print(f"Component     : {get_value(f.get(PIMS_FIELDS['comp_subcomp']))}")
            print(f"Issue Severity: {get_value(f.get(PIMS_FIELDS['issue_severity']))}")
            
            exec_sum = get_value(f.get(PIMS_FIELDS['executive_summary']))
            if exec_sum and exec_sum != "None":
                print(f"Exec Summary  : {exec_sum}")
            
            # Display new fields
            disposition = get_value(f.get(PIMS_FIELDS['disposition_details']))
            if disposition and disposition != "None":
                print(f"Disposition   : {disposition}")
            
            root_cause = get_value(f.get(PIMS_FIELDS['technical_root_cause']))
            if root_cause and root_cause != "None":
                print(f"Root Cause    : {root_cause}")
            
            platform_impact = get_value(f.get(PIMS_FIELDS['platform_impact']))
            if platform_impact and platform_impact != "None":
                print(f"Platform Impact: {platform_impact}")

        elif project_key == "CPSE":
            print(f"\n[2. CPSE Specific Analysis]")
            print(f"Context       : Function Team Discussion/Engineering Investigation")
            
        else:
            # Standard ticket, nothing specialized
            pass

        # --- Resolution / Current State Analysis ---
        print(f"\n[3. Resolution & Support Status]")
        is_closed = status_name.lower() in ['closed', 'resolved', 'done', 'completed', 'cancelled']
        
        if is_closed:
            print(f"State         : CLOSED / RESOLVED")
            resolution = get_value(f.get('resolution'))
            print(f"Resolution    : {resolution}")
            
            fix_versions = f.get('fixVersions', [])
            if fix_versions:
                 fv_str = ", ".join([v.get('name') for v in fix_versions])
                 print(f"Fix Version(s): {fv_str}")
            
            # Smart Solution Detection
            print(f"Sol. Evidence :")
            comments = f.get('comment', {}).get('comments', [])
            found_sol = False
            for c in reversed(comments[-5:]): # Check last 5 comments
                body = c.get('body', '').lower()
                if any(x in body for x in ['sha', 'commit', 'fixed', 'solution', 'merge', 'bios update', 'driver', 'released', 'release', 'registry']):
                    author = c.get('author', {}).get('displayName', 'Unknown')
                    snippet = c.get('body', '').replace('\n', ' ')[:100]
                    print(f"  - [{author}] ...{snippet}...")
                    found_sol = True
            
            if not found_sol:
                print("  (No direct keywords like 'SHA', 'Fixed', 'Merge' found in recent comments)")

        else:
            # Open Ticket Analysis
            print(f"State         : OPEN / ACTIVE")
            print(f"Handler       : {assignee_name} ({get_dept(assignee_name)})")
            
            # Determine staleness
            days_stale = 0
            # Rough calculation based on last history item time could be done, 
            # but simpler to rely on updated or basic heuristics if not in timeline obj
            
            # Check for support requests
            comments = f.get('comment', {}).get('comments', [])
            needs_support = False
            for c in reversed(comments[-3:]):
                if any(x in c.get('body', '').lower() for x in ['help', 'support', 'blocked', 'urgent', 'assign']):
                    print(f"Support Signal: Potential request in recent comments.")
                    needs_support = True
                    break
            
            if not needs_support:
                print(f"Support Signal: No explicit keyword triggers in last 3 comments.")

        # --- Timeline Analysis ---
        print(f"\n[4. Timeline Analysis]")
        timeline = calculate_timeline(issue)
        if timeline:
            print("Duration by Process State:")
            for s, d in timeline['statuses'].items(): print(f"  - {s:25}: {d}")
            
            if timeline['ui_levels'] and project_key == "PIMS":
                 print("\nDuration by UI Level:")
                 for u, d in timeline['ui_levels'].items(): print(f"  - {u:25}: {d}")

            if timeline['handoffs'] and project_key == "PIMS":
                print(f"\nOrganizational Hand-offs:")
                for h in timeline['handoffs']:
                     print(f"  {h['time']} | {h['author']} | {h['field']}: {h['from']} -> {h['to']}")

        # --- Attachments ---
        attachments = f.get('attachment', []) or []
        if attachments:
            print(f"\n[5. Attachments ({len(attachments)})]")
            for a in attachments:
                name = a.get('filename')
                size = a.get('size', 0)
                print(f"  - {name} ({size} bytes)")

        # --- Discussion Summary (Smart Scan) ---
        comments = f.get('comment', {}).get('comments', [])
        if comments:
            print(f"\n[6. Discussion Summary & Direction]")
            
            # 1. Key Highlights Extraction
            # Keywords for broad intent
            keywords = ["root cause", "plan", "next step", "action", "suggestion", "conclusion", "solution", "workaround", 
                        "release", "released", "verified", "pass", "fixed", "update", "provided", "upload"]
            
            # Regex for version numbers (e.g. 2.0.44, v1.2.3)
            import re
            valid_version_regex = re.compile(r'(?:v?\d+\.\d+(?:\.\d+)?)')
            
            highlights = []
            
            # --- Scan All Comments ---
            for i, c in enumerate(comments):
                body = c.get('body', '')
                body_lower = body.lower()
                lines = body.split('\n')
                author = c.get('author', {}).get('displayName', 'Unknown')
                date = c.get('created', '')[:10]
                
                # Special Logic: Always capture the very last comment if ticket is Closed/Resolved
                is_last_comment = (i == len(comments) - 1)
                
                for line in lines:
                    clean_line = line.strip()
                    if len(clean_line) < 5: continue
                    
                    # A. Keyword Match
                    if any(k in clean_line.lower() for k in keywords):
                        highlights.append(f"  [{date} {author}] {clean_line[:120]}")
                        continue # Avoid double adding if regex also matches
                    
                    # B. Version/Release Regex Match
                    if valid_version_regex.search(clean_line) and any(x in clean_line.lower() for x in ['release', 'ver', 'bios', 'driver', 'tool', 'registry']):
                        highlights.append(f"  [{date} {author}] {clean_line[:120]}")
                        continue

                # C. Last Comment Fallback (Context/Conclusion)
                if is_last_comment and is_closed:
                     # Keep the first meaningful line of the last comment as "Final Note"
                     first_meaningful = next((l for l in lines if len(l.strip()) > 10), None)
                     if first_meaningful:
                         highlights.append(f"  [{date} {author}] (Last Comment) {first_meaningful.strip()[:120]}")
            
            if highlights:
                print("Key Highlights (Plans, Actions, Findings, Releases):")
                # Show unique highlights, limit to last 10 to capture enough history
                seen = set()
                unique_highlights = []
                for h in highlights:
                    if h not in seen:
                        unique_highlights.append(h)
                        seen.add(h)
                        
                for h in unique_highlights[-10:]:
                    print(h)
            else:
                print("No explicit 'Plan', 'Root Cause' or 'Release' info detected.")

            # 2. Recent Discussion (Raw & Unfiltered)
            print(f"\nRecent Discussion (Last 3 Comments - Untouched):")
            for c in comments[-3:]:
                author = c.get('author', {}).get('displayName', 'Unknown')
                date = c.get('created', '')[:16].replace('T', ' ')
                body = c.get('body', '').strip()
                print(f"\n  [{date} | {author}]")
                # Indent body for readability
                for line in body.split('\n'):
                    print(f"    {line}")

        # --- Deep Link Expansion ---
        print(f"\n[6. Linked Ticket Deep Search]")
        
        visited_links = set()
        
        def recursive_link_search(current_key, depth):
            if depth > 1: return
            if current_key in visited_links: return
            visited_links.add(current_key)
            
            indent = "  " * depth
            
            try:
                # If it's the root ticket, we already have links in 'issue' object
                if current_key == args.key:
                    links = f.get('issuelinks', [])
                else:
                    # Fetch minimal fields for linked tickets
                    l_issue = jira.issue(current_key, fields="summary,issuelinks,status")
                    if not l_issue: return
                    links = l_issue.get('fields', {}).get('issuelinks', [])
                    
                    # Print Summary of this node
                    summ = l_issue.get('fields', {}).get('summary', 'No Summary')
                    stat = l_issue.get('fields', {}).get('status', {}).get('name', 'Unknown')
                    print(f"{indent}-> {current_key}: {summ} [{stat}]")
            
            except Exception as e:
                # print(f"{indent}[!] Failed to fetch {current_key}: {e}")
                return

            # Analyze children
            for link in links:
                # Determine direction
                outward = link.get('outwardIssue')
                inward = link.get('inwardIssue')
                target = outward or inward
                if not target: continue
                
                t_key = target.get('key')
                if not t_key: continue
                
                # Filter: Only PIMS, CPSE, CBDCIT, PBA, CBA, CEC, CEP, CBT, CBF, CBDSE
                t_proj = t_key.split('-')[0]
                if t_proj not in ['PIMS', 'CPSE', 'CBDCIT', 'PBA', 'CBA', 'CEC', 'CEP', 'CBT', 'CBF', 'CBDSE']:
                    continue
                
                if t_key not in visited_links:
                    recursive_link_search(t_key, depth + 1)

        recursive_link_search(args.key, 0)

        print(f"\n{'='*80}\n")
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"ERROR: Failed to analyze issue {args.key}: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
