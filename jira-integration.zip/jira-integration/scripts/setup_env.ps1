# PowerShell Setup Script for Jira Integration Skill
# Creates an isolated virtual environment with required dependencies

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillDir = Split-Path -Parent $ScriptDir
$VenvDir = Join-Path $SkillDir ".venv"

Write-Host "=== Jira Integration Skill Setup (Windows) ==="
Write-Host "Skill directory: $SkillDir"
Write-Host ""

# Check Python version
$PythonCmd = ""
if (Get-Command "python" -ErrorAction SilentlyContinue) {
    $PythonCmd = "python"
} elseif (Get-Command "py" -ErrorAction SilentlyContinue) {
    # Prefer latest Python 3 if using py launcher
    $PythonCmd = "py -3"
} else {
    Write-Error "Python not found. Please install Python 3.11+"
    exit 1
}

# Check version
try {
    $VersionOutput = Invoke-Expression "$PythonCmd --version 2>&1"
    Write-Host "Using: $VersionOutput"
} catch {
    Write-Error "Failed to check python version"
    exit 1
}

# Create virtual environment
if (Test-Path $VenvDir) {
    Write-Host "Virtual environment already exists at $VenvDir"
    $Response = Read-Host "Recreate? (y/N)"
    if ($Response -match "^[Yy]$") {
        Remove-Item -Recurse -Force $VenvDir
        Write-Host "Removed existing environment"
    } else {
        Write-Host "Keeping existing environment"
    }
}

if (-not (Test-Path $VenvDir)) {
    Write-Host "Creating virtual environment..."
    Invoke-Expression "$PythonCmd -m venv `"$VenvDir`""
    Write-Host "Created: $VenvDir"
}

# Install dependencies
Write-Host ""
Write-Host "Installing dependencies..."
$PipCmd = Join-Path $VenvDir "Scripts\pip.exe"

& $PipCmd install --upgrade pip -q
& $PipCmd install -r (Join-Path $SkillDir "requirements.txt")

Write-Host ""
Write-Host "=== Setup Complete ==="
Write-Host ""
Write-Host "To use the skill:"
Write-Host "  1. Copy config.toml.example to config.toml and fill in your values"
Write-Host "  2. Run: & `"$VenvDir\Scripts\python.exe`" `"$SkillDir\scripts\create_ticket.py`" --help"
Write-Host ""
