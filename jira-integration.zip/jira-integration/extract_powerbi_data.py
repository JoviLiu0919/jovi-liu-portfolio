#!/usr/bin/env python3
"""Extract JIRA filter 147288 data with correct field IDs for Power BI"""
import json
import csv
from pathlib import Path
try:
    import tomllib
except ImportError:
    import tomli as tomllib
from atlassian import Jira

# Load config
config_path = Path(__file__).parent / "config.toml"
with open(config_path, "rb") as f:
    config = tomllib.load(f)

jira_cfg = config.get("jira", {})
jira = Jira(
    url=jira_cfg.get("url"),
    token=jira_cfg.get("token"),
    verify_ssl=False
)

# Get filter details
filter_id = "147288"
try:
    filter_info = jira.get_filter(filter_id)
    print("=== Filter Information ===")
    print(f"Name: {filter_info.get('name')}")
    print(f"Owner: {filter_info.get('owner', {}).get('displayName')}")
    print()
    
    # Get all issues from filter with correct field IDs
    jql = filter_info.get('jql')
    print(f"=== Extracting all issues with correct fields ===")
    
    # Correct field IDs for PIMS
    lob_found_field = "customfield_28469"
    component_subcomponent_field = "customfield_28436"
    
    start_at = 0
    max_results = 100
    all_issues = []
    
    while True:
        result = jira.jql(jql, fields=f"key,summary,status,assignee,priority,created,updated,components,labels,{lob_found_field},{component_subcomponent_field}", start=start_at, limit=max_results)
        issues = result.get('issues', [])
        all_issues.extend(issues)
        print(f"Fetched {len(issues)} issues (total: {len(all_issues)})")
        
        if len(issues) < max_results:
            break
        start_at += max_results
    
    print(f"\n=== Total Issues: {len(all_issues)} ===")
    
    # Extract relevant fields for Power BI
    power_bi_data = []
    for issue in all_issues:
        fields = issue.get('fields', {})
        
        # Handle LOB Found field (can be list of dicts, dict with 'value', or string)
        lob_found = fields.get(lob_found_field, '')
        if isinstance(lob_found, list) and len(lob_found) > 0:
            lob_found = ', '.join([item.get('value', str(item)) for item in lob_found])
        elif isinstance(lob_found, dict):
            lob_found = lob_found.get('value', '')
        
        # Handle Component/Subcomponent field (can be list of dicts or string)
        component_subcomponent = fields.get(component_subcomponent_field, '')
        if isinstance(component_subcomponent, list):
            component_subcomponent = ', '.join([c.get('value', str(c)) for c in component_subcomponent])
        elif isinstance(component_subcomponent, dict):
            component_subcomponent = component_subcomponent.get('value', '')
        
        # Parse Component/Subcomponent into separate columns
        # Format: "Component, SubComponent1, SubComponent2, ..."
        parts = [p.strip() for p in component_subcomponent.split(',') if p.strip()]
        component = parts[0] if len(parts) > 0 else ''
        sub_component = parts[1] if len(parts) > 1 else ''
        sub_component2 = parts[2] if len(parts) > 2 else ''
        sub_component3 = parts[3] if len(parts) > 3 else ''
        
        # Generate JIRA URL
        jira_url = f"https://jira.cpg.dell.com/browse/{issue.get('key')}"
        
        power_bi_data.append({
            'Key': issue.get('key'),
            'Summary': fields.get('summary'),
            'Status': fields.get('status', {}).get('name'),
            'Priority': fields.get('priority', {}).get('name'),
            'Assignee': fields.get('assignee', {}).get('displayName') if fields.get('assignee') else 'Unassigned',
            'Created': fields.get('created'),
            'Updated': fields.get('updated'),
            'Components': ', '.join([c.get('name') for c in fields.get('components', [])]),
            'Labels': ', '.join(fields.get('labels', [])),
            'LOB Found': lob_found,
            'Component_Subcomponent': component_subcomponent,  # Keep original for reference
            'Component': component,
            'SubComponent': sub_component,
            'SubComponent2': sub_component2,
            'SubComponent3': sub_component3,
            'JIRA URL': jira_url
        })
    
    # Save to CSV for Power BI
    output_file = Path(__file__).parent / "jira_filter_147288_powerbi.csv"
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=power_bi_data[0].keys())
        writer.writeheader()
        writer.writerows(power_bi_data)
    
    print(f"\n=== Data saved to: {output_file} ===")
    print(f"=== Total records: {len(power_bi_data)} ===")
    
    # Also save as JSON for reference
    json_file = Path(__file__).parent / "jira_filter_147288_powerbi.json"
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(power_bi_data, f, indent=2, ensure_ascii=False)
    print(f"=== JSON saved to: {json_file} ===")
    
    # Show sample data
    print(f"\n=== Sample Data (first 3 records) ===")
    for i, record in enumerate(power_bi_data[:3], 1):
        print(f"\n{i}. {record['Key']}")
        print(f"   Status: {record['Status']}")
        print(f"   LOB Found: {record['LOB Found']}")
        print(f"   Component/Subcomponent: {record['Component_Subcomponent']}")
    
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
